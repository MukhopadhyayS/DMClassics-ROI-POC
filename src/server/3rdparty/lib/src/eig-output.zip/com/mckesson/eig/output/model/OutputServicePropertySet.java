/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

/**
 * @author OFS
 * @author Jon Anderson
 *
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "outputServicePropertySet")
@XmlType(name = "outputServicePropertySet")
public class OutputServicePropertySet implements Serializable {

	private static final String START_NAME_TAG = "<property><name>";
	private static final String END_NAME_TAG = "</name>";
	private static final String START_VALUE_TAG = "<value>";
	private static final String END_VALUE_TAG = "</value></property>";
	private static final String EMPTY_VALUE_TAG = "<value/>";

	private static final int SEVEN = 7;
    private static final int EIGHT = 8;
    private static final int ELEVEN = 11;

	private HashMap<String, String> _values = new HashMap<String, String>();
	private OutputLoV _lov;

	/**
     *
     */
	public OutputServicePropertySet() {
		super();
	}

	public OutputServicePropertySet(String xmlValue) {
		_values.clear();
		parse(xmlValue);
	}

	public List<Property> getValues() {

		List<Property> values = new ArrayList<Property>();
		for (Entry<String, String> entry : _values.entrySet()) {
			Property property = new Property();
			property.setName(entry.getKey());
			property.setValue(entry.getValue());
			values.add(property);
		}

		return values;
	}

	@XmlElement (name = "values", type = Property.class)
	public void setValues(List<Property> values) {

		_values.clear();
		if (values != null) {
			for (Property property : values) {
				_values.put(property.getName(), property.getValue());
			}
		}
	}

	public String get(String key) {
		return _values.get(key);
	}

	public void put(String key, String value) {
		_values.put(key, value);
	}

	public Map<String, String> getMap() {
		return _values;
	}

	@XmlTransient
	public void setMap(Map<String, String> map) {
		_values.clear();
		if (map != null) {
			_values.putAll(map);
		}
	}

	public String getMarshallerXML() {
		String s = "";
		for (Entry<String, String> entry : _values.entrySet()) {
			s += START_NAME_TAG + entry.getKey() + END_NAME_TAG;
			s += START_VALUE_TAG + entry.getValue() + END_VALUE_TAG;
		}
		return s;
	}

	private void parse(String str) {
		int startPt = 0;

		boolean isContinue = true;
		while (isContinue) {
		    int nameStart = str.indexOf(START_NAME_TAG, startPt) + START_NAME_TAG.length();
		    int nameEnd = str.indexOf(END_NAME_TAG, startPt);

		    if (nameStart > nameEnd) { isContinue = false; continue; }

		    String name = str.substring(nameStart, nameEnd);

            int emptyValueStart = nameEnd + SEVEN;
            int emptyValueEnd   = emptyValueStart + EIGHT;

            String emptyValStr = str.substring(emptyValueStart, emptyValueEnd);
            String value;
            if (EMPTY_VALUE_TAG.equalsIgnoreCase(emptyValStr)) {
                value = "";
                startPt = emptyValueEnd + ELEVEN;
            } else {

                int valueStart = str.indexOf(START_VALUE_TAG, startPt)
                + START_VALUE_TAG.length();
                int valueEnd = str.indexOf(END_VALUE_TAG, startPt);

                value = (valueEnd == -1) ? "" : str.substring(valueStart, valueEnd);
                startPt = valueEnd + END_VALUE_TAG.length();
            }

		    put(name.trim(), value.trim());

		    isContinue = str.indexOf(START_NAME_TAG, startPt) >= 0;
		}
	}

	public OutputLoV getLov() {
		return _lov;
	}

	@XmlTransient
	public void setLov(OutputLoV lov) {
		_lov = lov;
	}

}
