/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.util.Arrays;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * <code>DestInfo</code> represents the OutputService's most current status information for a
 * destination.
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "destInfo")
@XmlType(name = "destInfo")
public class DestInfo extends DestDef {

	private static final long serialVersionUID = 1L;

	private static final int HASH_MULTIPLY = 7;
	private static final int HASH_INIT = 29;

    private String _serviceID;
    private StatusInfo _statusInfo;
    private PropertyDef[] _propertyDefs;
    private PropertyDef[] _jobOptionDefs;

	/**
     * Constructor
     */
    public DestInfo() {
        super();
    }

	@Override
    public boolean equals(Object arg0) {

        if (!super.equals(arg0)) {
            return false;
        }

        DestInfo dest = (DestInfo) arg0;
        if (!ObjectUtils.equals(_serviceID, dest._serviceID)) {
            return false;
        }
        if (!ObjectUtils.equals(_statusInfo, dest._statusInfo)) {
            return false;
        }
        if (dest._propertyDefs == null
        		|| !Arrays.equals(_propertyDefs, dest._propertyDefs)) {
            return false;
        }
        if ((dest._jobOptionDefs == null)
        		|| !Arrays.equals(_jobOptionDefs, dest._jobOptionDefs)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        HashCodeBuilder hcb = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
        hcb.appendSuper(super.hashCode());
        hcb.append(_serviceID);
        hcb.append(_statusInfo);
        hcb.append(_propertyDefs);
        hcb.append(_jobOptionDefs);
        return hcb.toHashCode();
    }

	/**
	 * The <code>serviceID</code> member uniquely identifies the OutputService instance
	 * which "owns" the destination
	 *
	 * @return the _serviceID
	 */
	public String getServiceID() {
		return _serviceID;
	}

	/**
	 * @param serviceID the _serviceID to set
	 */
	@XmlElement(name = "serviceID")
	public void setServiceID(String serviceID) {
		_serviceID = serviceID;
	}

	/**
	 * The <code>statusInfo</code> member represents the current status of the destination
	 *
	 * @return the _statusInfo
	 */
	public StatusInfo getStatusInfo() {
		return _statusInfo;
	}

	/**
	 * @param statusInfo the _statusInfo to set
	 */
	@XmlElement (name = "statusInfo", type = StatusInfo.class)
	public void setStatusInfo(StatusInfo statusInfo) {
		_statusInfo = statusInfo;
	}

    /**
     * Returns the definitions of properties that may be set for the destination
     *
     * @return the _propertyDefs
     */
    public PropertyDef[] getPropertyDefs() {
        return _propertyDefs;
    }

    /**
     * @param propertyDefs the _propertyDefs to set
     */
    @XmlElementWrapper(name = "propertyDefs")
    @XmlElement(name = "propertyDef", type = PropertyDef.class)
    public void setPropertyDefs(PropertyDef[] propertyDefs) {
        _propertyDefs = propertyDefs;
    }

    /**
	 * @return the _jobOptionDefs
	 */
	public PropertyDef[] getJobOptionDefs() {
		return _jobOptionDefs;
	}

	/**
	 * @param optionDefs the _jobOptionDefs to set
	 */
    @XmlElementWrapper(name = "jobOptionDefs")
    @XmlElement(name = "propertyDef", type = PropertyDef.class)
	public void setJobOptionDefs(PropertyDef[] optionDefs) {
		_jobOptionDefs = optionDefs;
	}

}
