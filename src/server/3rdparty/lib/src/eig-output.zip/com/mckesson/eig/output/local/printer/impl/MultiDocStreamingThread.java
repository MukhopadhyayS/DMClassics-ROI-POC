/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.printer.impl;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PipedOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * MultiDocStreamingThread consumes set of files and streams data to piped
 * output stream.
 * 
 * Works in conjunction with corresponding thread that consumes the stream.
 * 
 * @see PrintThread
 * 
 * @author Srini Paduri
 * 
 * @since 13.5.2
 */
public class MultiDocStreamingThread implements Runnable {

    private PipedOutputStream _pos = null;

    private final List<String> _fileList = new ArrayList<String>();
    private boolean _done = false;

    private static final long FILE_WAIT_TIME = 200;
    private static final int BYTE_SIZE = 1024;
    private static final Log LOG = LogFactory
            .getLogger(MultiDocStreamingThread.class);

    public MultiDocStreamingThread(PipedOutputStream pos, OutputJob job) {
        _pos = pos;
    }

    public void run() {
        LOG.debug("Start merging and streaming... ");
        try {

            byte[] b = new byte[BYTE_SIZE];
            while (!isDone() || !_fileList.isEmpty()) {
                while (_fileList.isEmpty()) {
                    Thread.sleep(FILE_WAIT_TIME);
                    if (isDone()) {
                        break;
                    }
                }
                if (_fileList.size() > 0) {
                    String fileName = _fileList.remove(0);
                    LOG.debug("Getting filename: " + fileName);
                    File f = new File(fileName + ".ready");
                    while (!f.exists()) {
                        LOG.debug("Waiting on file: " + f.getAbsolutePath());
                        Thread.sleep(FILE_WAIT_TIME);
                    }
                    LOG.debug("Start merging filename: " + fileName);
                    InputStream inputStream = null;
                    try {
                        inputStream = new BufferedInputStream(new FileInputStream(
                                fileName));
                        int j = 0;
                        while ((j = inputStream.read(b)) != -1) {
                            _pos.write(b, 0, j);
                        }
                        LOG.debug("End merging filename: " + fileName);
                    } finally {
                        IOUtilities.close(inputStream);
                        f.delete();
                        new File(fileName).delete();
                    }
                }
            }
            LOG.debug("End merging...");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            IOUtilities.close(_pos);
        }
        LOG.info("Finished merging and streaming");
    }

    public boolean isDone() {
        return _done;
    }

    public void setDone(boolean done) {
        LOG.debug("Done set");
        _done = done;
    }

    public void addFile(String file) {
        if (!_done) {
            LOG.debug("Add file" + file);
            _fileList.add(file);
        }
    }
}
