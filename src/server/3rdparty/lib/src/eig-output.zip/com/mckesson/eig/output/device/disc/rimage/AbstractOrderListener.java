package com.mckesson.eig.output.device.disc.rimage;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.mckesson.eig.output.local.device.disc.DiscStatusListener;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.rimage.client.api.OrderStatusListener;

public abstract class AbstractOrderListener implements OrderStatusListener {
	
	private final String XML_FOLDER = "/XML/";
	protected static final Log LOG = LogFactory.getLogger(AbstractOrderListener.class);
	protected DiscStatusListener _discStatusListener;
	
	public AbstractOrderListener(DiscStatusListener listener) {
		_discStatusListener = listener;
	}

	@Override
	public abstract void onStatus(String arg0);
	
	/*-------------------------------------------------------------------------
	  Function: resetDTD: Reset the DOCTYPE base URI to point to the working
              folder of this PC.
    Input: XML string points to different working folder of DTD
    Output: XML string with correct working DTD folder
	--------------------------------------------------------------------------*/
	protected String resetDTD(String str) {
	  int n = str.indexOf("SYSTEM");
	  String left = str.substring(0, n + 8);

	  int m = str.indexOf(".dtd");
	  String temp = str.substring(0, m);

	  int p = temp.lastIndexOf("\\");
	  if (p == -1) p = temp.lastIndexOf("/");
	  String middle = temp.substring(p + 1);

	  String right = str.substring(m);
	  return left + XML_FOLDER + middle + right;
	}
	
	/*-----------------------------------------------------------------------------
	Function: parseXML(): Constructs an XML document(tree structure) in memory.
	Input: XML string conforming to either ProductionOrder.DTD or ImageOrder.DTD.
	Output: Returns Parsed Document.
	------------------------------------------------------------------------------*/
	protected Document parseXML(String xmlOrderStatus) {
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    Document document = null;
	
	    // Specifies that the parser produced by this code will validate
	    factory.setValidating(true);
	
	    try {
	      DocumentBuilder builder = factory.newDocumentBuilder();
	      builder.setEntityResolver(new EntityResolver()  {
	            public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
	                if (systemId.contains(".dtd")) {
	                	String id = systemId;
	                	if (id.startsWith("file://")) {
	                		id = id.substring(5);
	                		id = id.replace("/", "\\");
	                	}
	                    InputStream dtdStream = new FileInputStream(id);
	                    return new InputSource(dtdStream);
	                } else {
	                    return null;
	                }
	            }
	      });	      
	      document = builder.parse(new InputSource((Reader)new StringReader(xmlOrderStatus)));
	    } catch (Exception spe) {
	    	LOG.error("Failed to parseXML:" + spe.getMessage());
	    	return null;
	    }
	    return document;
	}
	
    /*-----------------------------------------------------------------------------
    Function: getElementAtt(): Searches the DOM tree to find a text value of a
              specific attribute within a specific element.
    Input: Parsed XML Document, Element name, Attribute name.
    Output: Returns the text value (if one was found) of that attribute.
	-------------------------------------------------------------------------------*/
	protected String getElementAtt(Document document, String tagName, String attribute)	{
	  NodeList list = document.getElementsByTagName(tagName);
	  Node thisStatusNode;
	  NamedNodeMap thisNamedNodeMap;
	  // Loop throught the list
	  for (int i=0; i<list.getLength(); i++) {
	      thisStatusNode = list.item(i);
	      thisNamedNodeMap = thisStatusNode.getAttributes();
	      if (thisNamedNodeMap == null) continue;
	      if (thisNamedNodeMap.getNamedItem(attribute) == null) continue;
	      if (thisNamedNodeMap.getNamedItem(attribute) instanceof org.w3c.dom.Node) {
	         return thisNamedNodeMap.getNamedItem(attribute).getNodeValue();
	      }
	  }
	  return "";
	}
	
	protected List<String> getElementsAtt(Document document, String tagName, String attribute)	{
		List<String> result = new ArrayList<String>();
		NodeList list = document.getElementsByTagName(tagName);
		Node thisStatusNode;
		NamedNodeMap thisNamedNodeMap;
		// Loop throught the list
		for (int i=0; i<list.getLength(); i++) {
			thisStatusNode = list.item(i);
			thisNamedNodeMap = thisStatusNode.getAttributes();
			if ((thisNamedNodeMap != null) && (thisNamedNodeMap.getNamedItem(attribute) != null)) {
				if (thisNamedNodeMap.getNamedItem(attribute) instanceof org.w3c.dom.Node) {
					result.add(thisNamedNodeMap.getNamedItem(attribute).getNodeValue());
				}
			}
		}
		return result;
	}

	protected DiscStatusListener getDiscStatusListener() {
		return _discStatusListener;
	}
}
