/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/


package com.mckesson.eig.output.local.device;

import com.mckesson.eig.output.local.BaseComponent;
import com.mckesson.eig.output.util.OutputProperty;


/**
 * @author Karthik, Easwaran
 * @date Aug 30, 2013
 * @since Aug 30, 2013
 *
 */
public class DeviceDestination
extends BaseComponent {

	private String _ipAddress;
	private String _portNumber;
	private String _templateLocation;
	private String _temporaryLocation;
	
	 @OutputProperty(
	            defaultValue = "",
	            description = "IP Address or hostName of the External Disc Device",
	            label = "Device IP Address",
				possibleValues = { "[a-zA-Z0-9.\\-]+[a-zA-Z0-9]*" },
	            required = "true",
	            index = "0")
	public String getIpAddress() { return _ipAddress; }
	public void setIpAddress(String ipAddress) { _ipAddress = ipAddress; }
	
	@OutputProperty(
            defaultValue = "",
            description = "Messaging Port Number of the External Disc System",
            label = "Device Port",
			possibleValues = { "[0-9]+" },
            required = "true",
            index = "1",
            size = "10")
	public String getPortNumber() { return _portNumber; }
	public void setPortNumber(String portNumber) { _portNumber = portNumber; }
	
	@OutputProperty(
            defaultValue = "",
            description = "Share Location of the Label templates",
            label = "Label Location",
			possibleValues = { "(\\\\\\\\(\\d{1,3}\\.){3,3}(\\d{1,3})|"
					   + "(\\\\\\\\)[^\\/:*|<>?\"]+)(\\\\[^\\/:*|<>?\"])*" },
            required = "false",
            index = "2")
	public String getTemplateLocation() { return _templateLocation; }
	public void setTemplateLocation(String templateLocation) { _templateLocation = templateLocation; }
	
	@OutputProperty(
            defaultValue = "",
            description = "Temporary File Location",
            label = "Temporary File Location",
			possibleValues = { "(\\\\\\\\(\\d{1,3}\\.){3,3}(\\d{1,3})|"
					   + "(\\\\\\\\)[^\\/:*|<>?\"]+)(\\\\[^\\/:*|<>?\"])*" },
            required = "false",
            index = "2")
	public String getTemporaryLocation() { return _temporaryLocation; }
	public void setTemporaryLocation(String temporaryLocation) { _temporaryLocation = temporaryLocation; }
}
