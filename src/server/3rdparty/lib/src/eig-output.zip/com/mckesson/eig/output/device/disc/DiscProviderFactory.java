/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/


package com.mckesson.eig.output.device.disc;

import java.util.Map;

import com.mckesson.eig.output.local.device.disc.DiscDeviceStatusListener;


public interface DiscProviderFactory {
    public DiscProviderManager getDiscProviderManager(String vendor); 
	public void addDiscProviderManager(String vendor, DiscProviderManager discProviderManager);
	public Map<String, DiscProviderManager> getDiscProviderManagerMap();
	public void setDiscProviderManagerMap(Map<String, DiscProviderManager> discProviderManagerMap);
    void setDiscDeviceStatusListener(DiscDeviceStatusListener listener);
}
