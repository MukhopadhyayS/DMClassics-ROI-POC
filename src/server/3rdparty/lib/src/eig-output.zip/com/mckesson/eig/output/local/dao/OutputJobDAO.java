/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.dao;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;

/**
 * DAO responsible for persisting OutputJobs
 *
 * @author Jon Anderson
 */
public interface OutputJobDAO {


	/**
	 * Stores the output job and the associated parts to any persistent object.
	 *
	 * @param job not <code>null</code>
	 * @return
	 */
    OutputJob createOutputJob(OutputJob job);
    OutputJob updateOutputJob(OutputJob job);

	/**
	 * This method is used to fetch the output job and the parts associated to the
	 * job by filtering it with the passed Job ID.
	 *
	 * @param jobID
	 * @return maybe <code>null</code>
	 */
	OutputJob readOutputJob(int jobID);

	/**
	 * This method is used to fetch all the output jobs and the parts associated to
	 * the job.
	 *
	 * @return not <code>null</code>
	 */
	Collection<OutputJob> readAllOutputJobs();

	/**
	 * This method returns all the jobs with the specified status and modified between
	 * a specified time frame. This can also return all the jobs on a particular status
	 * irrespective of the modified dates if the arguments for the fromDate and toDate
	 * are passed as null.
	 *
	 * @return
	 */
	Collection<OutputJob> fetchJobsByStatus(StatusInfo status, Date fromDate, Date toDate);

	OutputJob deleteOutputJobParts(int jobID);

	/**
	 * This method removes the parts associated to the job and resets the parts to the
	 * specified parts passed in the parameter.
	 *
	 * @param jobID
	 * @param jobParts
	 */
    OutputJob resubmitResetOutputJobParts(int jobID);
    OutputJob syncResetOutputJobParts(int jobID);
    OutputJob resubmitOutputJob(OutputJob job);
	/**
	 * This method is used to update the job status with the status id as
	 * specified in the StatusInfo object.
	 *
	 * @param jobID
	 * @param info
	 */
	void updateJobStatus(int jobID, StatusInfo info);
    void updateJobStatus(final List<Integer> jobSeq, final int statusId);

    /**
     * This method is used to delete a collection of jobs
     *
     * @param jobID
     * @param info
     */
    void deleteJob(final List<Integer> jobSeq);

    /**
     * This method is used to update the job page count
     *
     * @param jobID
     * @param pageCount
     */
    void updateJobPageCount(int jobID, int pageCount);

    /**
     * This method is used to get the job status id
     *
     * @param jobID
     */
    int fetchJobStatus(int jobID);

	/**
	 * This method is used to fetch the job part as specified by the ID.
	 *
	 * @param partID
	 * @return
	 */
	JobPart readOutputJobPart(int partID);

	/**
	 * This method is used to update the job part which is already created in
	 * the database.
	 *
	 * @param jobPart
	 */
	void updateJobPart(JobPart jobPart);

	/**
	 * This method is used to return the list of jobs which match the parameters
	 * which are passed in the queryOptions.
	 *
	 * @param queryOptions
	 * @return
	 */
	Collection<OutputJob> queryJobs(final Map<String, String> queryOptions);

	/**
	 * This method is used to return the next available job
	 * from a list of queues which job is process only one per queue.
	 *
	 * @param queues
	 * @param checkStatus
	 * @param setStatus
	 * @return Integer
	 */
	Integer getNextAvailableJobForOnePerQueue(List queues, RequestStatus requestStatus, RequestStatus processingStatus);
	
	/**
	 * This method is used to return the next available job
	 * from a list of queues.
	 *
	 * @param queues
	 * @param checkStatus
	 * @param processingStatus
	 * @return Integer
	 */
	Integer getNextAvailableJob(List queues, RequestStatus requestStatus, RequestStatus processingStatus);
	
	/**
	 * This method is used to get  the processing server from the Output_Service_Job table
	 * specified in the StatusInfo object.
	 *
	 * @param queues
	 * @param checkStatus
	 * @param hostNameOnly
	 * @return Integer
	 */
	Integer getCurrentProcessingJob(List queues, RequestStatus requestStatus, boolean hostNameOnly);
	
	void updateAllJobsStatusForServer(String processingServer, int origStatus, int newStatus, List queues);
	
	void updateJobResults(int jobID, String results);

	void updateJobResults(int jobID, StatusInfo status, String results);
	
	/**
	 * This method is used to reset the status from the Output_Service_Job table after the job is idle in minutes
	 *
	 * @param queues
	 * @param checkStatus
	 * @param resetStatus
	 * @param idleInMin
	 * @param errorMsg
	 */
	boolean processIdleJobByChangeStatus(List queues, RequestStatus checkStatus, RequestStatus resetStatus, int idleInMin, String errorMsg);

	/**
	 * This method is used to remove the processing server from the Output_Service_Job table after the job is idle in minutes
	 *
	 * @param queues
	 * @param checkStatus
	 * @param idleInMin
	 * @param errorMsg
	 */
	boolean processIdleJobByRemoveServerName(List queues, RequestStatus checkStatus, int idleInMin, String errorMsg);
	
	/**
	 * This method is used to reset the status in the Output_Service_Job table after the job is idle in days
	 *
	 * @param resetStatus
	 * @param checkStatus
	 * @param idleInMin
	 * @param errorMsg
	 */
	boolean processIdleJobInDaysByChangeStatus(List<RequestStatus> checkStatuses, RequestStatus resetStatus, int idleInDay, String errorMsg) ;

}
