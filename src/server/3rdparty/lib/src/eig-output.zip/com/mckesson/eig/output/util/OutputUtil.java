/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.Map.Entry;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.sax.SAXSource;

import org.apache.commons.lang.ObjectUtils;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.OutputManagerAware;
import com.mckesson.eig.output.model.AbstractOutputRequest;
import com.mckesson.eig.output.model.DestDef;
import com.mckesson.eig.output.model.DestDeviceDef;
import com.mckesson.eig.output.model.DestDeviceTypeDef;
import com.mckesson.eig.output.model.DestInfo;
import com.mckesson.eig.output.model.DestInfoList;
import com.mckesson.eig.output.model.DestTypeDef;
import com.mckesson.eig.output.model.DestTypeInfo;
import com.mckesson.eig.output.model.DestTypeInfoList;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.EndpointDefList;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.model.EndpointTypeDefList;
import com.mckesson.eig.output.model.JobFileList;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.JobTransformDef;
import com.mckesson.eig.output.model.JobTransformTypeDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputJobFiles;
import com.mckesson.eig.output.model.OutputJobList;
import com.mckesson.eig.output.model.OutputJobResults;
import com.mckesson.eig.output.model.OutputRequest;
import com.mckesson.eig.output.model.OutputServicePropertySet;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.model.PartTransformDef;
import com.mckesson.eig.output.model.PartTransformTypeDef;
import com.mckesson.eig.output.model.Property;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.PropertyDefList;
import com.mckesson.eig.output.model.RequestPart;
import com.mckesson.eig.output.model.SourceDef;
import com.mckesson.eig.output.model.SourceTypeDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.model.SubmitInfo;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.jaxb.EIGNamespacePrefixMapper;
import com.mckesson.eig.output.util.jaxb.NamespaceFilter;
import com.mckesson.eig.utility.io.FileLoader;
import com.mckesson.eig.utility.util.SpringUtilities;
import com.mckesson.eig.utility.util.StringUtilities;
import com.mckesson.eig.wsfw.EIGConstants;
import com.sun.xml.bind.marshaller.XMLWriter;

/**
 * Miscellaneous utilities for various output things.
 *
 * @author OFS
 * @author Jon Anderson
 *
 */
public final class OutputUtil {

	private static final EIGNamespacePrefixMapper NS_PREFIX_MAPPER
		= new EIGNamespacePrefixMapper();

    /**
	 * Holds the bean id of the jaxb context.
	 */
    private static JAXBContext _jaxbContext;

	private OutputUtil() {
		super();
	}

	/**
	 * Looks up the part identified by <code>partID</code> in
	 * <code>job</code>'s parts member
	 *
	 * @param job not <code>null</code>
	 * @param partID not <code>null</code>
	 * @return <code>null</code> if not found
	 */
	public static JobPart lookupJobPart(OutputJob job, String partID) {
		if (job == null) {
			throw new IllegalArgumentException("job argument is null");
		}
		if (partID == null) {
			throw new IllegalArgumentException("partID is null");
		}

		List<JobPart> parts = job.getParts();
		if (parts != null) {
			for (JobPart part : parts) {

				if (ObjectUtils.equals(part.getPartID(), partID)) {
					return part;
				}
			}
		}

		return null;
	}


    /**
     * Looks up the transform identified by <code>transformType</code> in
     * <code>job</code>'s  transform member
     *
     * @param job not <code>null</code>
     * @param transformType not <code>null</code>
     * @return <code>null</code> if not found
     */
    public static OutputTransform lookupJobTransform(OutputJob job, String transformType) {
        if (job == null) {
            throw new IllegalArgumentException("job argument is null");
        }

        if (transformType == null) {
            throw new IllegalArgumentException("transform type is null");
        }

        if (job.getTransforms() == null) {
            return null;
        }

        for (OutputTransform outputTransform : job.getTransforms()) {
            if (ObjectUtils.equals(outputTransform.getTransformType(), transformType)) {
                    return outputTransform;
            }
        }

        return null;
    }

    /**
     * Looks up the transform identified by <code>transformType</code> in
     * <code>job part</code>'s  transform member
     *
     * @param part not <code>null</code>
     * @param transformType not <code>null</code>
     * @return <code>null</code> if not found
     */
    public static OutputTransform lookupPartTransform(JobPart part, String transformType) {
        if (part == null) {
            throw new IllegalArgumentException("job part argument is null");
        }

        if (transformType == null) {
            throw new IllegalArgumentException("transform type is null");
        }

        if (part.getTransforms() == null) {
            return null;
        }

        for (OutputTransform outputTransform : part.getTransforms()) {
            if (ObjectUtils.equals(outputTransform.getTransformType(), transformType)) {
                    return outputTransform;
            }
        }

        return null;
    }

    /**
     * Looks up the transform identified by <code>transformType</code> in
     * <code>job part</code>'s  transform member
     *
     * @param part not <code>null</code>
     * @param transformType not <code>null</code>
     * @return <code>null</code> if not found
     */
    public static OutputTransform lookupPartTransform(OutputJob job, String transformType) {
        if (job == null) {
            throw new IllegalArgumentException("job argument is null");
        }

        if (transformType == null) {
            throw new IllegalArgumentException("transform type is null");
        }

        for (JobPart part : job.getParts()) {
            for (OutputTransform outputTransform : part.getTransforms()) {
                if (ObjectUtils.equals(outputTransform.getTransformType(), transformType)) {
                        return outputTransform;
                }
            }
        }

        return null;
    }


    /* TODO - This method assumes there is only one type of each transform
     * applied.  Re-factor to implement 0...n
     */
    public static List<OutputTransform> getOrderedOutputTransforms(OutputJob job) {

        ArrayList<OutputTransform> tmpList = new ArrayList<OutputTransform>();

        OutputTransform tmpTransform = null;

        tmpTransform = OutputUtil.lookupJobTransform(
                                       job,
                                       OutputConstants.OutputTransforms.WATERMARK.toString());
        if (tmpTransform != null) {
            tmpList.add(tmpTransform);
        }
        tmpTransform = OutputUtil.lookupJobTransform(
                                       job,
                                       OutputConstants.OutputTransforms.HEADER_FOOTER.toString());
        if (tmpTransform != null) {
            tmpList.add(tmpTransform);
        }

        tmpTransform = OutputUtil.lookupJobTransform(
                                       job,
                                       OutputConstants.OutputTransforms.PAGE_SEPARATOR.toString());
        if (tmpTransform != null) {
            tmpList.add(tmpTransform);
        }


       return tmpList;
    }

    public static List<OutputTransform> getOrderedOutputTransforms(JobPart part) {

        ArrayList<OutputTransform> tmpList = new ArrayList<OutputTransform>();

        OutputTransform tmpTransform = null;

        tmpTransform = OutputUtil.lookupPartTransform(
                                       part,
                                       OutputConstants.OutputTransforms.WATERMARK.toString());
        if (tmpTransform != null) {
            tmpList.add(tmpTransform);
        }
        tmpTransform = OutputUtil.lookupPartTransform(
                                       part,
                                       OutputConstants.OutputTransforms.HEADER_FOOTER.toString());
        if (tmpTransform != null) {
            tmpList.add(tmpTransform);
        }

        tmpTransform = OutputUtil.lookupPartTransform(
                                       part,
                                       OutputConstants.OutputTransforms.PAGE_SEPARATOR.toString());
        if (tmpTransform != null) {
            tmpList.add(tmpTransform);
        }


       return tmpList;
    }


	/**
	 * Tests if writer is a PrintWriter and wraps it in one if not
	 *
	 * @param writer not <code>null</code>
	 * @return not <code>null</code>
	 */
	public static PrintWriter toPrintWriter(Writer writer) {
	    if (writer == null) {
	        throw new IllegalArgumentException("writer argument is null");
	    }
	    if (writer instanceof PrintWriter) {
	        return (PrintWriter) writer;
	    }
	    return new PrintWriter(writer);
	}

    /**
     * Dumps the contents of the OutputJob to a string
     *
     * @param outputJob may be null
     * @return not null dump of contents
     */
	public static String dumpOutputJob(OutputJob outputJob) {
		StringWriter writer = new StringWriter();
		dumpOutputJob(outputJob, writer);
		return writer.getBuffer().toString();
	}

    /**
     * Dumps the contents of the JobPart collection to a string
     *
     * @param jobParts may be null
     * @return not null dump of contents
     */
    public static String dumpJobParts(Collection<JobPart> jobParts) {
        StringWriter writer = new StringWriter();
        dumpJobParts(jobParts, writer);
        return writer.getBuffer().toString();
    }

    /**
     * Dumps the contents of the OutputJob to a writer
     *
     * @param outputJob may be null
     * @param writer not null
     */
	public static void dumpOutputJob(OutputJob outputJob, Writer writer) {

		if (writer == null) {
			throw new IllegalArgumentException("writer argument is null");
		}

		PrintWriter printWriter = toPrintWriter(writer);
		if (outputJob == null) {
			printWriter.println("null");
			return;
		}

		printWriter.print("jobID: ");
		printWriter.println(outputJob.getJobSeq());

		printWriter.print(" destination: ");
		printWriter.println(outputJob.getDestID());

		printWriter.print("currentLocation: ");
		printWriter.println(outputJob.getCurrentLocation());
		printWriter.print("nextLocation: ");
		printWriter.println(outputJob.getNextLocation());

		printWriter.println("properties: ");
		dumpProperties(outputJob.getProperties(), printWriter);

		printWriter.println("statusInfo: ");
		dumpStatusInfo(outputJob.getStatusInfo(), printWriter);

		printWriter.println("submitInfo: ");
		printWriter.println(outputJob.getSubmitInfo());

		printWriter.println("submitInfo: ");
		dumpSubmitInfo(outputJob.getSubmitInfo(), printWriter);

		printWriter.println("transforms: ");
		List<OutputTransform> transforms = outputJob.getTransforms();
		if (transforms == null) {
			printWriter.println("null");
		} else {
			for (OutputTransform transform : transforms) {
				dumpOutputTransform(transform, printWriter);
			}
		}

		printWriter.println("parts: ");
		dumpJobParts(outputJob.getParts(), printWriter);
	}

    /**
     * Dumps the contents of the JobPart collection to a writer
     *
     * @param jobParts may be null
     * @param writer not null
     */
    public static void dumpJobParts(
            Collection<JobPart> jobParts,
            Writer writer) {

        if (writer == null) {
            throw new IllegalArgumentException("writer argument is null");
        }

        PrintWriter printWriter = toPrintWriter(writer);

        if (jobParts == null) {
            printWriter.println("null");
        } else {
            for (JobPart jobPart : jobParts) {
                dumpJobPart(jobPart, printWriter);
            }
        }
    }

    /**
     * Dumps the contents of the JobPart to a writer
     *
     * @param jobPart may be null
     * @param writer not null
     */
    public static void dumpJobPart(JobPart jobPart, Writer writer) {
		if (writer == null) {
			throw new IllegalArgumentException("writer argument is null");
		}

        PrintWriter printWriter = toPrintWriter(writer);
		if (jobPart == null) {
			printWriter.println("null");
			return;
		}

		printWriter.print("jobID: ");
		printWriter.println(jobPart.getJobID());
		printWriter.print("partID: ");
		printWriter.println(jobPart.getPartID());
		printWriter.print("contentID: ");
		printWriter.println(jobPart.getContentID());
		printWriter.print("contentSource: ");
		printWriter.println(jobPart.getContentSourceName());
		printWriter.print("currentLocation: ");
		printWriter.println(jobPart.getCurrentLocation());
		printWriter.print("nextLocation: ");
		printWriter.println(jobPart.getNextLocation());
		printWriter.println("statusInfo: ");
		dumpStatusInfo(jobPart.getStatusInfo(), printWriter);

		printWriter.println("sources: ");
		dumpSources(jobPart.getSourcesIterator(), printWriter);

		printWriter.println("properties: ");
		dumpProperties(jobPart.getProperties(), printWriter);


		printWriter.println("transforms: ");
		List<OutputTransform> transforms = jobPart.getTransforms();
		if (transforms == null) {
			printWriter.println("null");
		} else {
			for (OutputTransform transform : transforms) {
				dumpOutputTransform(transform, printWriter);
			}
		}

	}

    /**
     * Dumps the contents of the sources collection to a writer
     *
     * @param sources may be null
     * @param writer not null
     */
	public static void dumpSources(Iterator<String> sources, Writer writer) {

		if (writer == null) {
			throw new IllegalArgumentException("writer argument is null");
		}

        PrintWriter printWriter = toPrintWriter(writer);
		if (sources == null) {
			printWriter.println("null");
			return;
		}

		boolean first = true;
		while (sources.hasNext()) {

			if (first) {
				first = false;
			} else {
				printWriter.print(", ");
			}
			printWriter.print(sources.next());
		}
		printWriter.println("");
	}

    /**
     * Dumps the contents of statusInfo to a writer
     *
     * @param statusInfo may be null
     * @param writer not null
     */
	public static void dumpStatusInfo(StatusInfo statusInfo, Writer writer) {

		if (writer == null) {
			throw new IllegalArgumentException("writer argument is null");
		}

        PrintWriter printWriter = toPrintWriter(writer);
		if (statusInfo == null) {
			printWriter.println("null");
			return;
		}

		printWriter.print("status: ");
		printWriter.println(statusInfo.getStatus());
		printWriter.print("statusCode: ");
		printWriter.println(statusInfo.getStatusCode());
		printWriter.print("statusDate: ");
		printWriter.println(statusInfo.getStatusDate());
		printWriter.print("statusSource: ");
		printWriter.println(statusInfo.getStatusSource());
		printWriter.print("detail: ");
		printWriter.println(statusInfo.getDetail());
	}

    /**
     * Dumps the contents of the transform to a writer
     *
     * @param transform may be null
     * @param writer not null
     */
	public static void dumpOutputTransform(OutputTransform transform, Writer writer) {

		if (writer == null) {
			throw new IllegalArgumentException("writer argument is null");
		}

        PrintWriter printWriter = toPrintWriter(writer);
		if (transform == null) {
			printWriter.println("null");
			return;
		}

		printWriter.print("transformType: ");
		printWriter.println(transform.getTransformType());
		printWriter.print("properties: ");
		printWriter.println(transform.getProperties());
	}

    /**
     * Dumps the contents of the properties to a writer
     *
     * @param properties may be null
     * @param writer not null
     */
    public static void dumpProperties(Map<String, ? extends Object> properties, Writer writer) {

		if (writer == null) {
			throw new IllegalArgumentException("writer argument is null");
		}

        PrintWriter printWriter = toPrintWriter(writer);
		if (properties == null) {
			printWriter.println("null");
			return;
		}

		for (Entry<String, ? extends Object> entry : properties.entrySet()) {

			printWriter.print(entry.getKey());
			printWriter.print(": ");
			printWriter.println(entry.getValue());
		}
	}

    /**
     * Dumps the contents of the submitInfo  to a writer
     *
     * @param submitInfo may be null
     * @param writer not null
     */
	public static void dumpSubmitInfo(SubmitInfo submitInfo, Writer writer) {

		if (writer == null) {
			throw new IllegalArgumentException("writer argument is null");
		}

        PrintWriter printWriter = toPrintWriter(writer);
		if (submitInfo == null) {
			printWriter.println("null");
			return;
		}

		printWriter.print("submitDate: ");
		printWriter.println(submitInfo.getSubmitDate());
		printWriter.print("submitterData: ");
		printWriter.println(submitInfo.getSubmitterData());
		printWriter.print("submitMachine: ");
		printWriter.println(submitInfo.getSubmitMachine());
		printWriter.print("apllication: ");
		printWriter.println(submitInfo.getApplication());
		printWriter.print("user: ");
		printWriter.println(submitInfo.getUser());

	}

    /**
     * Creates an EndpointTypeDef object for the category
     * <code>endpointCategory</code>
     * @param endpointCategory category of type def to return
     * @return not null one of
     * <li>SourceTypeDef
     * <li>PartTransformTypeDef
     * <li>JobTransformTypeDef
     * <li>DestTypeDef
     */
    public static EndpointTypeDef createEndpointTypeDef(
            EndpointCategory endpointCategory) {

        switch (endpointCategory) {
            case SOURCE:
                return new SourceTypeDef();
            case PART_TRANSFORM:
                return new PartTransformTypeDef();
            case JOB_TRANSFORM:
                return new JobTransformTypeDef();
            case DESTINATION:
                return new DestTypeDef();
            case DESTINATION_DEVICE:
            	return new DestDeviceTypeDef();
            default:
                throw new IllegalArgumentException();
        }
    }

    /**
     * Creates an EndpointDef object for the category
     * <code>endpointCategory</code>
     * @param endpointCategory category of def to return
     * @return not null one of
     * <li>SourceDef
     * <li>PartTransformDef
     * <li>JobTransformDef
     * <li>DestDef
     */
    public static EndpointDef createEndpointDef(
            EndpointCategory endpointCategory) {

        switch (endpointCategory) {
            case SOURCE:
                return new SourceDef();
            case PART_TRANSFORM:
                return new PartTransformDef();
            case JOB_TRANSFORM:
                return new JobTransformDef();
            case DESTINATION:
                return new DestDef();
            case DESTINATION_DEVICE:
            	return new DestDeviceDef();
            default:
                throw new IllegalArgumentException();
        }
    }

    /**
     * Sets the OutputManager in <code>object</code> if it is
     * <code>OutputManagerAware</code>
     *
     * @param object object to test for <code>OutputManagerAware</code>
     * @param outputManager manager to set
     * @return <code>true</code> if <code>object</code> is
     * <code>OutputManagerAware</code>
     */
    public static boolean setOutputManager(
            Object object,
            OutputManager outputManager) {

        if (object instanceof OutputManagerAware) {
            ((OutputManagerAware) object).setOutputManager(outputManager);
            return true;
        }
        return false;
    }

    public static JAXBContext getJAXBContext()
    throws JAXBException {

        if (_jaxbContext != null) {
            return _jaxbContext;
        }
        _jaxbContext = JAXBContext.newInstance(AbstractOutputRequest.class,
                                               DestDef.class,
                                               DestInfo.class,
                                               DestInfoList.class,
                                               DestTypeInfo.class,
                                               DestTypeInfoList.class,
                                               DeviceInfo.class,
                                               EndpointDef.class,
                                               EndpointDefList.class,
                                               EndpointTypeDef.class,
                                               EndpointTypeDefList.class,
                                               JobFileList.class,
                                               JobPart.class,
                                               JobTransformTypeDef.class,
                                               MapModel.class,
                                               OutputJob.class,
                                               OutputJobFiles.class,
                                               OutputJobList.class,
                                               OutputJobResults.class,
                                               OutputRequest.class,
                                               OutputTransform.class,
                                               PartTransformDef.class,
                                               PartTransformTypeDef.class,
                                               Property.class,
                                               PropertyDef.class,
                                               PropertyDefList.class,
                                               RequestPart.class,
                                               SourceDef.class,
                                               SourceTypeDef.class,
                                               StatusInfo.class,
                                               SubmitInfo.class,
                                               OutputServicePropertySet.class,
                                               DestTypeDef.class,
                                               JobTransformDef.class,
                                               DestDeviceTypeDef.class);
        return _jaxbContext;
    }

    /**
     * Helper method used to convert the passed object values in to a XML formatted string
     *
     * @param sourceTypeDef
     *        Object need to be converted to XML string.
     *
     * @return componentInfoXML
     *         XML string for the corresponding object.
     */
    public static void getXML(Object object, Writer writer) {

        try {

          Marshaller m = getJAXBContext().createMarshaller();

          //Create a filter that will remove the xmlns attribute
          NamespaceFilter outFilter = new NamespaceFilter(null, false);

		  // Using prefix mapping, defining global namespace here.
          XMLWriter wri = new XMLWriter(writer, OutputConstants.ENCODING_UTF_16);
          wri.startPrefixMapping(StringUtilities.EMPTYSTRING, EIGConstants.TYPE_NS_V1);

          //Attach the writer to the filter
          outFilter.setContentHandler(wri);

          m.marshal(object, outFilter);

        } catch (Exception e) {
            throw new OutputException("Error writing the object to the writer ",
                                      e,
                                      OutputErrorCode.RUNTIME_ERROR);
        }
    }

    /**
     * Unmarshals Objects of this Unmarshaller's Class type. The Class must specify the proper
     * access methods (setters/getters) in order for instances of the Class to be properly
     * unmarshalled.
     *
     * @param fileName
     *        read the XML from the corresponding file.
     *
     * @return object Instance of an XML Content.
     */
    public static Object getObject(Reader reader) {

        try {

            Unmarshaller um = getJAXBContext().createUnmarshaller();

            //Create an XMLReader to use with our filter
            XMLReader xmlReader = XMLReaderFactory.createXMLReader();

            //Create the filter (to add namespace) and set the xmlReader as its parent.
            NamespaceFilter inFilter = new NamespaceFilter(null, true);
            inFilter.setParent(xmlReader);

            //Prepare the input, in this case a java.io.File (output)
            InputSource is = new InputSource(reader);

            //Create a SAXSource specifying the filter
            SAXSource source = new SAXSource(inFilter, is);

            //Do unmarshalling
            return um.unmarshal(source);

        } catch (Exception e) {
            throw new OutputException("Error converting the object from XML ",
                                      e,
                                      OutputErrorCode.RUNTIME_ERROR);
        }
    }

    /**
     * Helper method used to convert the XML formatted string in to respective object
     *
     * @param xmlString XML Content as string
     *
     * @return Instance of the respective object
     */
    public static Object getObject(String xmlString) {
        return getObject(new StringReader(xmlString));
    }

    public static String getUniqueServerName() {
    	return getServerName();
    }
    
    public static String getServerName() {
    	try {
    		return InetAddress.getLocalHost().getHostName();
    	} catch (UnknownHostException e) {
    		return null;
    	}
    }

	private static File resolveToFile(String path) {
		File file = FileLoader.getResourceAsFile(path);
		if (file == null) {
			file = new File(path);
			if ((file.exists() && !file.canRead())
					|| !file.getParentFile().canWrite()) {
				throw new IllegalArgumentException(path + " is not valid");
			}
		}
		return file;
	}

	private static String getSystemProperty(String property) {
		return System.getProperty(property);
	}

	public static Object getObjectFromSpring(String beanName) {
        try {
        	Object o = SpringUtilities.getInstance()
        		.getBeanFactory().getBean(beanName);
        	return o;
        } catch (Exception e) {
            return null;
        }
	}

	private static String getUniqueKeyProperty() {
    	Properties p = (Properties) getObjectFromSpring(
        		OutputSettingConstants.OUTPUT_SETTING_PROPERTIES_BEAN);
    	String key = p.getProperty(OutputSettingConstants.SYSTEM_PROPERTY_UNIQUE_KEY);
    	if (key != null) {
    		return key;
    	}
    	return OutputSettingConstants.DEFAULT_SYSTEM_PROPERTY_UNIQUE_KEY;
	}

    public static String getUUid() {
        try {
        	String path = (String) getObjectFromSpring(
        		OutputSettingConstants.UUID_SETTING_PROPERTIES_BEAN);
        	File f = resolveToFile(path);
        	Properties p = new Properties();
        	p.load(new FileInputStream(f));
        	String key = getSystemProperty(getUniqueKeyProperty());
        	String value = p.getProperty(key);
        	if (value != null) {
        		return value;
        	}
        	value = UUID.randomUUID().toString();
        	p.setProperty(key, value);
        	p.store(new FileOutputStream(f), null);
        	return value;
        } catch (Exception e) {
            return null;
        }
    }
}
