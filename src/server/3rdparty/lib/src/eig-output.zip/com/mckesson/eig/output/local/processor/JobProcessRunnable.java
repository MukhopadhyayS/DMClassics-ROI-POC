/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.MDC;

import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.mediator.MediatorJob;
import com.mckesson.eig.output.local.mediator.OutputJobException;
import com.mckesson.eig.output.local.mediator.OutputJobMediator;
import com.mckesson.eig.output.local.source.SourceListener;
import com.mckesson.eig.output.local.source.SourceProcessor;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.PdfSupport;
import com.mckesson.eig.output.util.PdfUtils;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class JobProcessRunnable implements Runnable, SourceListener {

	protected static final String JOB_ID = "JOBID";
	protected static final Log LOG = LogFactory.getLogger(JobProcessRunnable.class);
	protected static final String PDF = "application/pdf";

	protected final EndpointDAO _dao;
	protected OutputManager _outputManager;
	protected final OutputJob _job;
	protected final DestTypeHandler _handler;

	protected MediatorJob _mJob;

	protected int _totalPage = 0;

	protected final SourceProcessor _srcProcessor;

	public JobProcessRunnable(DefaultTypeHandlerFactory factory, EndpointDAO dao,
			OutputManager outputManager, OutputJob job) {
		_handler = getHandler(factory, job);
		_dao = dao;
		_outputManager = outputManager;
		_outputManager.getLocationStrategy().setJobLocations(job);
		_srcProcessor = new SourceProcessor(factory, _outputManager, dao);
		_job = job;
		MDC.put(JOB_ID, Integer.toString(job.getJobSeq()));
	}

	public void run() {
		try {
			long startTime = System.currentTimeMillis();
			LOG.debug("Start retieveing source for Job:" + _job.getJobSeq());
			_srcProcessor.process(_job, this);
			long finishTime = System.currentTimeMillis();
			LOG.debug("Finished retieveing source for  Job:" + _job.getJobSeq()
					+ " in: " + (finishTime - startTime) + " milliseconds");
		} catch (Exception e) {
			error(_job, e.getMessage());
		} finally {
			MDC.remove(JOB_ID);
		}
	}

	public void start(OutputJob job) {
		int destId = job.getDestID();
		Destination d = getDestination(destId);
		job.setDestination(d);
		try {
			_mJob = OutputJobMediator.createJob(job, d, _handler);
		} catch (Exception e) {
			_outputManager.updateJobStatus(
					job.getJobSeq(),
					StatusUtils.createRequestStatus(RequestStatus.ERROR,
							e.getMessage()));
		}
	}

	public void addFile(OutputJob job, String path) {
		File f = new File(path);
		try {
        	if (isPrintable(f)) {
	            calculatePageCount(f.getAbsolutePath());
        	} else {
        		_totalPage += 1;
         	}
			_mJob.addFile(f.getAbsolutePath());
		} catch (Exception e) {
			_outputManager.updateJobStatus(
					job.getJobSeq(),
					StatusUtils.createRequestStatus(RequestStatus.ERROR,
							e.getMessage()));
		}

	}

    private boolean isPrintable(File f) {
    	if (f != null) {
	        String fileType = PdfUtils.getFileType(f);
	        if (PDF.equalsIgnoreCase(fileType)) {
	        	return true;
	        }
    	}
        return false;
    }

	public void finish(OutputJob job) {
		try {
			_outputManager.updateJobPageCount(job.getJobSeq(), _totalPage);
			_mJob.doneWithJob();
		} catch (OutputJobException e) {
			LOG.error("Unable to finish Job " + job.getJobSeq() + " : "
					+ e.getMessage());
		} catch (IOException e) {
			LOG.error("Unable to finish Job " + job.getJobSeq() + " : "
					+ e.getMessage());
		} catch (InterruptedException e) {
			LOG.error("Unable to finish Job " + job.getJobSeq() + " : "
					+ e.getMessage());
		}
	}

	public void error(OutputJob job, String errorMessage) {
		LOG.error("Updating job " + job.getJobSeq() + " status to failed");
		_outputManager.updateJobStatus(job.getJobSeq(), StatusUtils
				.createRequestStatus(RequestStatus.ERROR, errorMessage));
	}

	protected Destination getDestination(int id) {
		EndpointDef def = _dao.getEndpointDef(id);
		return (Destination) _handler.createEndpoint(def);
	}

	private void calculatePageCount(String fileName) {
		_totalPage += PdfSupport.getPageCount(fileName);
	}

	private DestTypeHandler getHandler(DefaultTypeHandlerFactory factory,
			OutputJob job) {
		return (DestTypeHandler) factory.getHandlerMapping(job.getDestType());
	}
}
