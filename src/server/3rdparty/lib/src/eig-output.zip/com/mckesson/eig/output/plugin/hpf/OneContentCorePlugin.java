/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.plugin.hpf;

import com.mckesson.eig.CodeList;

/**
 * @author Shahm Nattarshah
 * @date  Oct 2013
 * @since  HPF 16.1
 *
 *
 *
 * This class is the output plugin implementation of OneContent application. The plugin extends
 * the HPFOutputPlugin as the OneContent application uses the HPF users. Therefore there may
 * be some implementation available in the HPFOutputPlugin. 
 */
public class OneContentCorePlugin extends HPFOutputPlugin {
	
	/**
	 * This constructor is invoked from the spring configuration. The application which
	 * uses the service is responsible to specify these parameters as they are used by 
	 * the class to communicate to the web service.
	 * 
	 * @param protocol
	 * @param server
	 * @param port
	 */
	public OneContentCorePlugin(String protocol, String server, String port) {
		super(protocol, server, port);		
	}	
	
	/**
	 * This method returns the output specific rights which the ROI application uses.
	 */
	protected CodeList getOutputRights() {
		
		CodeList codeList = new CodeList();
		
		final int exportToPDFRight = 6113;
		final int printFaxRight = 6112;
		final int emailRight = 6117;
		final int discRight = 6118;

		int[] codes = {exportToPDFRight, printFaxRight, emailRight, discRight};
		codeList.setCodes(codes);
		return codeList;
	}
}
