/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Corporation and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Corporation.
 */
package com.mckesson.eig.output.local.fax;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;

import org.apache.activemq.ActiveMQConnectionFactory;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.PdfSupport;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.SpringUtilities;

/**
 * This class provides the business methods implementations for RightFax
 *
 * @author OFS
 * @since Dec 4, 2009
 */
public class RightFaxImpl extends FaxDestination {

    private static final Log LOG = LogFactory
                .getLogger(FaxDestination.class);

    private static final String FAX_QUEUE         = "topic_eigFax";
    private static final String FAX_QUEUE_NAME    = "queue_name";
    private static final String CONNECTIONFACTORY = "connectionFactory";

    private String _queueName;
    private String _queuePassword;

    private String _mqFaxQueueName;

    private FaxStatusListener _listener;

    public RightFaxImpl() {
        super();
    }

    @OutputProperty(
          defaultValue = "",
          description = "Name for the Fax Queue",
          label = "Queue")
    public String getQueueName() {
        return _queueName;
    }

    public void setQueueName(String rightFaxQueueName) {
        this._queueName = rightFaxQueueName;
    }

    @OutputProperty(
            defaultValue = "",
            description = "Password for the Fax Queue",
            label = "Password")
    public String getQueuePassword() {
        return _queuePassword;
    }

    public void setQueuePassword(String rightFaxQueuePassword) {
        this._queuePassword = rightFaxQueuePassword;
    }

    public String getMqFaxQueueName() {
        if (_mqFaxQueueName == null) {
            return FAX_QUEUE;
        }
        return _mqFaxQueueName;
    }

    public void setMqFaxQueueName(String faxQueueName) {
        _mqFaxQueueName = faxQueueName;
    }

    /**
     * @see com.mckesson.eig.output.local.fax#processJob(com.mckesson.eig.output.model.OutputJob)
     */
    public void processJob(OutputJob job) {

        if (job == null) {
            throw new IllegalArgumentException("job argument is null");
        }

        getHandler().updateJobStatus(job.getJobSeq(),
            StatusUtils.createRequestStatus(RequestStatus.PROCESSING,
            "Start processing Output job to Fax"));
        try {

            ArrayList<String> faxList = new ArrayList<String>();
            for (JobPart part : job.getParts()) {

                Iterator<String> i = part.getSourcesIterator();
                while (i.hasNext()) {
                    addFaxList(part.getCurrentLocation(), i.next(), faxList);
                }
                
                i = part.getAttachmentsIterator();
                while (i.hasNext()) {
                	String attachFile = i.next();
    				String ext = part.getProperties().get(OutputConstants.ATTACHMENT_EXTENSION);
    				if (ext != null &&
    						ext.equalsIgnoreCase(OutputConstants.ATTACHMENT_PDF_FILE_EXT)) {
    					//verify attachment is pdf
    					try {
    						PdfSupport.getPageCount(part.getCurrentLocation()
    								+ File.separatorChar
    								+ attachFile);
    						addFaxList(part.getCurrentLocation(), attachFile, faxList);
    					} catch (Exception  pdfException) {
    						//ignore this exception
    						//could not verify attachment is pdf file
    						//do not process
    					}
    				} 
                }
            }
            if (faxList.size() > 0) {
                fax(job, faxList);
            } else {
            	//update status as error - nothing to fax
          
                getHandler().updateJobStatus(job.getJobSeq(),
                        StatusUtils.createRequestStatus(RequestStatus.ERROR,
                        "Error processing Output job to Fax - no pages to fax"));
           }
            LOG.info("finished processing job: " + job.getJobSeq());
        } catch (Exception e) {

            getHandler().updateJobStatus(job.getJobSeq(),
                StatusUtils.createRequestStatus(RequestStatus.ERROR,
                "Error processing Output job to Fax"));
            LOG.error("Error Processing Fax Job: " + job.getJobName() , e);
            throw new RuntimeException(e);
        }
    }

    private void addFaxList(String path, String f, ArrayList<String> faxList) {
        faxList.add(path + File.separatorChar + f);
    }

    /**
     * Creates fax object and sends the output message to fax destination queue
     *
     * @param job
     * @param list
     */
    private void fax(OutputJob job, ArrayList<String> list) {

        FaxObject faxObj = new FaxObject();
        faxObj.setToName(job.getJobName());
        faxObj.setJobId(job.getJobSeq());
        faxObj.setJobName(job.getJobName());

        String faxNo;
        faxNo = job.getPropertyValue(OutputConstants.OUTPUT_FAX_NUMBER);
        if (faxNo != null) {
            faxObj.setToFaxNumber(faxNo);
        } else {
            // Check in the job parts:
            for (Iterator<JobPart> iter = job.getParts().iterator(); iter.hasNext();) {
                JobPart part = iter.next();
                faxNo = part.getProperties() != null ? part.getProperties()
                                 .get(OutputConstants.OUTPUT_FAX_NUMBER) : null;
                faxObj.setToFaxNumber(faxNo);
                break;
            }
        }
        if (faxNo == null) {
            String msg = "FAX Number is null, Cannot perform FAX JOB";
            LOG.error(msg);
            throw new RuntimeException(msg);
        }
        faxObj.setFaxList(list);
        faxObj.setQueueName(getQueueName());
        faxObj.setQueuePassword(getQueuePassword());
        try {
            sendMesage(faxObj, job.getJobSeq());

        } catch (Exception e) {
            LOG.error("Exception in Fax", e);
            throw new RuntimeException(e);
        }
    }

    public void sendMesage(FaxObject obj, int jobId) throws Exception {
        if (obj != null) {
            sendMessage(getMqFaxQueueName(), obj);
        }
    }

    /**
     * Posts the fax output message in a topic and updates the status of job
     *
     * @param topicName
     * @param obj
     */
    public void sendMessage(String topicName, FaxObject obj) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Sending AUTO_ACKNOWLEDGE message to topic:  "
                    + topicName);
        }
        TopicConnection connection = null;
        TopicSession session = null;
        try {
        	ActiveMQConnectionFactory connectionFactory = getActiveMQConnectionFactory();
            if (LOG.isDebugEnabled()) {
                LOG.debug("ActiveMQ Broker URL:  " + connectionFactory.getBrokerURL());
            }
			connection = connectionFactory.createTopicConnection();
			session = connection.createTopicSession(true, Session.AUTO_ACKNOWLEDGE);
			connection.start();
			session.run();
			  // create request and response queues
			Topic t =  session.createTopic(topicName);
			TopicPublisher publisher = session.createPublisher(t);
			publisher.publish(session.createTextMessage(obj.toXml()));
			session.commit();
			session.close();
			connection.close();
			getHandler().updateJobStatus((int) obj.getJobId(),
				StatusUtils.createRequestStatus(RequestStatus.PROCESSING,
				"Sending to Fax Service"));
        } catch (Exception e) {
            getHandler().updateJobStatus((int) obj.getJobId(),
                    StatusUtils.createRequestStatus(RequestStatus.ERROR,
                    "Failed to send Fax Service"));
        } finally {
            try {
		if (null != session) {
		    session.close();
		}
		if (null != connection) {
		    connection.close();
		}
	    } catch (JMSException e) {
		LOG.debug("Failed to close ActiveMQ resources");
	    }
	}
    }

    public static ActiveMQConnectionFactory getActiveMQConnectionFactory() {
        return (ActiveMQConnectionFactory) SpringUtilities.getInstance().getBeanFactory()
                .getBean(CONNECTIONFACTORY);
    }

    public void configureFaxDestination(FaxTypeHandler handler,
                                        Map<String, String> queueProperties,
                                        String name) {
    	super.configureFaxDestination(handler, queueProperties, name);
        _mqFaxQueueName = queueProperties.get(FAX_QUEUE_NAME);
        handler.setUpListener();
    }
}
