/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.file;

import java.io.File;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;
import org.springframework.beans.BeansException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.mckesson.eig.audit.local.AuditLocalService;
import com.mckesson.eig.audit.model.AuditEvent;
import com.mckesson.eig.output.local.EndpointManager;
import com.mckesson.eig.output.local.dao.OutputLovDAO;
import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.JobFileList;
import com.mckesson.eig.output.model.OutputJobFiles;
import com.mckesson.eig.output.service.OutputBaseService;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.utility.util.SpringUtilities;

public class FilePurge extends QuartzJobBean implements StatefulJob {
	private static final String ACTION_CODE = "PP";
	private static final Long USER_ID = new Long(0);
	private static final String SUCCESS_COMMENT = "PDF file {0} purged from {1}.";
	private static final String FAIL_COMMENT = "PDF file {0} was not purged from {1}.";
    private static final String PURGE_FILE = "PURGE_FILE";

	@Override
	protected void executeInternal(JobExecutionContext ctx)
			throws JobExecutionException {
		try {
	        EndpointManager endpointManager =
	            (EndpointManager) ctx.getJobDetail().getJobDataMap().
	                                get(OutputConstants.ENDPOINT_MANAGER_BEAN_NAME_PROP);

	        if (endpointManager == null) {
	            throw new JobExecutionException("endpointManager reference is null");
	        }
	        Collection<ActiveEndpoint> fileEndpoints =
	            endpointManager.getActiveEndpoints(OutputConstants.FILE);
            OutputBaseService baseService = new OutputBaseService();
            OutputLovDAO lovDao = baseService.getOutputLovDAO();

	        for (ActiveEndpoint tmpEndpoint : fileEndpoints) {

	            String purgeTime = tmpEndpoint.getProperties()
	                                .getAsString(FileConstants.FILE_PURGE_TIME);


	            if (StringUtils.isBlank(purgeTime)) {
	                throw new JobExecutionException(
	                        "purgeTime reference is null");
	            }
	            int destId = tmpEndpoint.getEndpointDef().getId();
	            Calendar fileDate = Calendar.getInstance();
	            fileDate.add(Calendar.HOUR, -1 * (Integer.parseInt(purgeTime)));
	            List<JobFileList> fileList = lovDao.readAllFileInfoForDestination(destId,
	                                                                 fileDate.getTime());

	            purgeFiles(fileList);
	            lovDao.deleteAllFileInfoForDestination(destId, fileDate.getTime());
	       }
		} catch (Exception e) {
			throw new JobExecutionException(e);
		}
	}

	@SuppressWarnings("unchecked")
    private void purgeFiles(List<JobFileList> jobFileList)
			throws JobExecutionException {
		try {
		    if (jobFileList == null) {
		        return;
		    }
		    for (JobFileList fileList : jobFileList) {
		        if (fileList != null) {
    	            List<OutputJobFiles> jobFiles = fileList.getJobFileDetails();
    	            if (jobFiles != null) {
        	            for (OutputJobFiles tmpJobFiles : jobFiles) {
                            for (String fileName : tmpJobFiles.getFileNames()) {
                                File currFile = new File(fileName);
                                try {
                                   FileUtils.deleteQuietly(currFile);
                                   auditPurgeEvent(SUCCESS_COMMENT, currFile.getName(),
                                                    currFile.getAbsolutePath());
                                } catch (Exception e) {
                                    auditPurgeEvent(FAIL_COMMENT, fileName,
                                                    fileName);
                                }
                            }
        	            }
    	            }
		        }
		    }
		} catch (Exception e) {
			throw new JobExecutionException(e);
		}
	}

	private void auditPurgeEvent(String comment, String file, String directory) {
		if ((file != null) && file.endsWith("pdf"))  {
			AuditEvent event = createAuditEvent(comment, directory, file);
			audit(event);
		}
	}

	private AuditEvent createAuditEvent(String comment, String directoryName, String fileName) {
		AuditEvent event = new AuditEvent();
		Object[] args = new Object[] { fileName, directoryName };
		MessageFormat mf = new MessageFormat(comment);
		String remark =  mf.format(args);
		event.setComment(remark);
		event.setActionCode(ACTION_CODE);
		event.setUserId(USER_ID);
		return event;
	}

	private void audit(AuditEvent auditEvent) {
		AuditLocalService service = getAuditLocalService();
		if (service != null) {
			service.createAuditEntry(auditEvent);
		}
	}

	protected AuditLocalService getAuditLocalService() {
		try {
			return (AuditLocalService) SpringUtilities.getInstance()
            	.getBeanFactory().getBean(AuditLocalService.class.getName());
		} catch (BeansException e) {
			return null;
		}
	}
}
