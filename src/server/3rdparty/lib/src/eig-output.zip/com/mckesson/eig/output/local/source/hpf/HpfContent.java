package com.mckesson.eig.output.local.source.hpf;

public class HpfContent {
	private String _patientName;
	private String _mrn;
	private String _facility;
	private String _encounter;
	private String _documentName;
	private String _pageId;
	private String _pageNumber;

	public String getPatientName() {
		return _patientName;
	}

	public void setPatientName(String patientName) {
		_patientName = patientName;
	}

	public String getMrn() {
		return _mrn;
	}

	public void setMrn(String mrn) {
		_mrn = mrn;
	}

	public String getFacility() {
		return _facility;
	}

	public void setFacility(String facility) {
		_facility = facility;
	}

	public String getEncounter() {
		return _encounter;
	}

	public void setEncounter(String encounter) {
		_encounter = encounter;
	}

	public String getDocumentName() {
		return _documentName;
	}

	public void setDocumentName(String documentName) {
		_documentName = documentName;
	}

	public String getPageId() {
		return _pageId;
	}

	public void setPageId(String pageId) {
		_pageId = pageId;
	}

	public String getPageNumber() {
		return _pageNumber;
	}

	public void setPageNumber(String pageNumber) {
		_pageNumber = pageNumber;
	}
}
