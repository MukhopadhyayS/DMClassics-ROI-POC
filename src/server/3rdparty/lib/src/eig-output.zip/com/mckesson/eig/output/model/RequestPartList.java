/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.util.List;

import com.mckesson.eig.output.util.GetSetList;

/**
 * Castor-able container for RequestParts
 *
 * @author Jon Anderson
 */
public class RequestPartList extends GetSetList<RequestPart> {

    /**
     * Creates using an ArrayList as the delegate
     */
    public RequestPartList() {
        super();
    }

    /**
     * Constructs using <code>delegate</code> as the delegate
     *
     * @param delegate not null
     */
    public RequestPartList(List<RequestPart> delegate) {
        super(delegate);
    }


}
