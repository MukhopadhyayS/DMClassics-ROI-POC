package com.mckesson.eig.output.local.source.pl;

import java.util.Map;

import com.mckesson.eig.output.model.RequestPart;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class PLRequest {
	
	private static final Log LOG = LogFactory.getLogger(PLRequest.class);
	
	
	public PLRequest() {
	}


	Map getRequestParams(RequestPart part) {
		Map<String, String> map = part.getProperties();
		if (map == null) {
			LOG.error("Unable to retrieve request parameters map");
			return null;
		}
		return map;
	}
		
}
