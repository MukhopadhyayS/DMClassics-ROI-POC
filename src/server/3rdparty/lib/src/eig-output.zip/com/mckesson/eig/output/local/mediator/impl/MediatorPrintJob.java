/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.mediator.impl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.print.attribute.standard.PageRanges;

import com.lowagie.text.Document;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.mediator.MediatorJobForPrint;
import com.mckesson.eig.output.local.mediator.OutputJobException;
import com.mckesson.eig.output.local.printer.impl.LinuxPrintFacade;
import com.mckesson.eig.output.local.printer.impl.PrintFacade;
import com.mckesson.eig.output.local.printer.impl.WinPrintFacade;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;
import com.mckesson.eig.utility.util.StringUtilities;

/**
 * Mediator job mediates between sources and destinations.
 * 
 * @author Michael Macaluso
 * @author Srini Paduri
 * @version 13.5.2
 * @since 13.5.2
 */
public class MediatorPrintJob extends AbstractMediatorJob implements MediatorJobForPrint {

    private static final Log LOG = LogFactory.getLogger(MediatorPrintJob.class);

    /**
     * @since 13.5.2
     */
    private final ArrayList<String> _files;

    /**
     * @since 13.5.2
     */
    private final int _id;

    /**
     * @since 13.5.2
     */
    private final String _name;

    /**
     * varaible for listener.
     * 
     * @since 13.5.2
     */
    private Object _listener;

    /**
     * Facade for printing.
     * 
     * @since 13.5.2
     */
    private PrintFacade _facade;

    /**
     * Variable to mark type of job as PrintJob.
     * 
     * @since 13.5.2
     */
    private boolean _isPrintJob = false;

    /**
     * Variable for marking if page range is requested for print job.
     * 
     * @since 13.5.2
     */
    private boolean _isPrintPageRange = false;

    /**
     * Variable for marking if pages per sheet is requested for print job.
     * 
     * @since 13.5.2
     */
    private boolean _isPagesPerSheet = false;
    
    /**
     * Variable for windows os.
     * 
     * @since 13.5.2
     */
    private boolean _isWindows = false;

    /**
     * 
     * @param job
     * @since 13.5.2
     */
    public MediatorPrintJob(OutputJob job, Destination d, DestTypeHandler handler) {
		super(job, d, handler);
        _id = job.getJobSeq();
        _name = job.getJobName();
        _files = new ArrayList<String>();
    }

    public void initializeJob(Object listener) {
        // Initialize job.
        if (_job.getDestType().equalsIgnoreCase(
                OutputConstants.DestinationType.PRINT.toString())) {
            initializePrintJob(_job, listener);
        }
    }

    /**
     * Initialize print related attributes.
     * 
     * @param job
     */
    private void initializePrintJob(OutputJob job, Object listener) {
        job.logMetric("Initialize Print Job");
        _listener = listener;
        _isPrintJob = true;
        _isPrintPageRange = isPrintPageRange();
        _isPagesPerSheet = isPagesPerSheet();

        String os = System.getProperty("os.name").toLowerCase();
        LOG.debug("Operating System = " + os);

        // choose between windows or linux version of print facade.
        if (os.indexOf("win") > -1) {
            _isWindows = true;
            _facade = new WinPrintFacade(_job, _listener);
        } else {
            _facade = new LinuxPrintFacade(_job, _listener);
        }
    }
    /**
     * Adds a file that is ready for processing by destination.
     * 
     * @param fileName
     * @throws OutputJobException
     * @throws IOException
     * @throws InterruptedException
     */
    public void addFile(String fileName) throws IOException,
            InterruptedException {

        LOG.debug("File:" + fileName + " is added ");
        // synchronized to ensure multithreading doesn't cause issues.
        synchronized (_files) {
            _files.add(fileName);
        }

        if (!_isPrintPageRange && _isWindows) {
            _facade.addFile(fileName);
        }
    }

    /**
     * Indicate to mediator that all content for job has been added.
     * 
     * @throws OutputJobException
     * @throws IOException
     * @throws InterruptedException
     */
    public void doneWithJob() throws IOException, InterruptedException {

        if (_isPrintJob) {
            if (CollectionUtilities.isEmpty(_files)) {
                _facade.donewithJob();
                LOG.debug("File list is empty, Mediator is done with job..");
                return;
            }
            String outFile = _files.get(_files.size() - 1) + ".pdf";
            concatenateListOfFiles(_files, outFile);
            if (_isPrintPageRange && StringUtilities.hasContent(outFile)) {
                LOG.info("Applying page range : ");
                String inFile = outFile;
                outFile = outFile + ".pdf";
                applyPageRange(inFile, outFile);
            }
            if (_isPagesPerSheet && StringUtilities.hasContent(outFile)) {
                LOG.info("Applying pages per sheet : ");
                String inFile = outFile;
                outFile = outFile + ".pdf";
                applyPagesPerSheet(inFile, outFile);
            }
            if (!_isWindows && outFile != null) {
                _facade.addFile(outFile);
            }
            _facade.donewithJob();
            LOG.debug("Mediator is done with job..");
        }
    }

    public void concatenateListOfFiles(List<String> fileList,
            String outFile) {

        /*
         * Loop through files and build one PDF
         */
        try {
            int index = 0;
            Document document = null;
            PdfCopy writer = null;

            if (fileList.size() <= 0) {
                // nothing to process
                return;
            }
            while (index < fileList.size()) {
                PdfReader reader = new PdfReader(fileList.get(index));
                reader.consolidateNamedDestinations();
                int n = reader.getNumberOfPages();

                if (index == 0) {
                    document = new Document(reader.getPageSizeWithRotation(1));
                    writer = new PdfCopy(document,
                            new FileOutputStream(outFile));
                    document.open();
                }
                PdfImportedPage page;
                for (int i = 0; i < n;) {
                    ++i;
                    page = writer.getImportedPage(reader, i);
                    writer.addPage(page);
                }
                index++;
            }
            document.close();
        } catch (Exception e) {
            LOG.error("Error in concactenating files together " + e);
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

    public void applyPageRange(String inFile, String outFile) {

        /*
         * Loop through files and build one PDF
         */
        try {
            int[][] pageRange = getPageRange();
            Document document = null;
            PdfCopy writer = null;

            PdfReader reader = new PdfReader(inFile);
            reader.consolidateNamedDestinations();
            int n = reader.getNumberOfPages();
            document = new Document(reader.getPageSizeWithRotation(1));
            writer = new PdfCopy(document, new FileOutputStream(outFile));
            document.open();
            PdfImportedPage page;
            for (int i = 0; i < n;) {
                ++i;
                if (isInPageRange(pageRange, i)) {
                    page = writer.getImportedPage(reader, i);
                    writer.addPage(page);
                }
            }
            document.close();
        } catch (Exception e) {
            LOG.error("Error in concactenating files together " + e);
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

    public int getId() {
        return _id;
    }

    public String getName() {
        return _name;
    }

    private boolean isPrintPageRange() {
        Map<String, String> map = _job.getProperties();
        if (map == null) {
            return false;
        }
        String str = map.get("pageRange");
        if (StringUtilities.isEmpty(str) || str.equalsIgnoreCase("All")) {
            return false;
        }
        str = map.get("pages");
        if (StringUtilities.isEmpty(str) || str.equalsIgnoreCase("0")) {
            return false;
        }
        return true;
    }

    private boolean isPagesPerSheet() {
        Map<String, String> map = _job.getProperties();
        if (map == null) {
            return false;
        }
        String str = map.get("pagePerSheet");
        if (StringUtilities.isEmpty(str) || str.equalsIgnoreCase("1") || str.equalsIgnoreCase("0")) {
            return false;
        }
        return true;
    }
    
    private int[][] getPageRange() {
        Map<String, String> map = _job.getProperties();
        String str = map.get("pages");
        LOG.info("Page Range : " + str);
        PageRanges p = new PageRanges(str);
        return p.getMembers();
    }

    private String getPagesPerSheet() {
        Map<String, String> map = _job.getProperties();
        String str = map.get("pagePerSheet");
        LOG.info("Pages Per Sheet : " + str);
        return str;
    }
    
    private boolean isInPageRange(int[][] pageRange, int page) {
        for (int[] element : pageRange) {
            int min = element[0];
            int max = element[1];
            if (page >= min && page <= max) {
                return true;
            }
        }
        return false;
    }

    public Thread getPrintThread() {
        return _facade.getPrintThread();
    }

    public void applyPagesPerSheet(String inFile, String outFile) {

        try {
            String pagesPerSheet = getPagesPerSheet();
            double pow = getPowerForPagesPerSheet(pagesPerSheet);
            PdfReader reader = new PdfReader(inFile);
            // initializations
            Rectangle pageSize = reader.getPageSize(1);
            Rectangle newSize = (pow % 2) == 0 ?
                new Rectangle(pageSize.getWidth(), pageSize.getHeight()) :
                new Rectangle(pageSize.getHeight(), pageSize.getWidth());
            Rectangle unitSize = new Rectangle(pageSize.getWidth(), pageSize.getHeight());
            for (int i = 0; i < pow; i++) {
                unitSize = new Rectangle(unitSize.getHeight() / 2, unitSize.getWidth());
            }
            int n = (int)Math.pow(2, pow);
            int r = (int)Math.pow(2, pow / 2);
            int c = n / r;
            // step 1
            Document document = new Document(newSize, 0, 0, 0, 0);
            // step 2
            PdfWriter writer
               = PdfWriter.getInstance(document, new FileOutputStream(String.format(outFile, n)));
            // step 3
            document.open();
            // step 4
            PdfContentByte cb = writer.getDirectContent();
            PdfImportedPage page;
            Rectangle currentSize;
            float offsetX, offsetY, factor;
            int total = reader.getNumberOfPages();
            for (int i = 0; i < total; ) {
                if (i % n == 0) {
                    document.newPage();
                }
                currentSize = reader.getPageSize(++i);
                factor = Math.min(
                    unitSize.getWidth() / currentSize.getWidth(),
                    unitSize.getHeight() / currentSize.getHeight());
                offsetX = unitSize.getWidth() * ((i % n) % c)
                  + (unitSize.getWidth() - (currentSize.getWidth() * factor)) / 2f;
                offsetY = newSize.getHeight() - (unitSize.getHeight() * (((i % n) / c) + 1))
                  + (unitSize.getHeight() - (currentSize.getHeight() * factor)) / 2f;
                page = writer.getImportedPage(reader, i);
                cb.addTemplate(page, factor, 0, 0, factor, offsetX, offsetY);
            }
            // step 5
            document.close();
            
        } catch (Exception e) {
            LOG.error("Error in applying Pages Per Sheet " + e);
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

    private double getPowerForPagesPerSheet(String pagesPerSheet) {
        
        if (StringUtilities.isEmpty(pagesPerSheet) || "1".equalsIgnoreCase(pagesPerSheet)) {
            return 0;
        } else if ("2".equalsIgnoreCase(pagesPerSheet)) {
            return 1;
        } else if ("4".equalsIgnoreCase(pagesPerSheet)) {
            return 2;
        } else if ("6".equalsIgnoreCase(pagesPerSheet)) {
            return 2.6;
        } else if ("8".equalsIgnoreCase(pagesPerSheet)) {
            return 3;
        } else if ("16".equalsIgnoreCase(pagesPerSheet)) {
            return 4;
        }         
        return 0;
    }
    
}
