/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.util;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.local.OutputComponent;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.exception.ApplicationException;


/**
 * Utility Map and OutputComponent implementation which provides support for
 * enforcing PropertyDef restrictions. If the class has a PropertyDef array
 * provided, it will only allow values to be set which are present in
 * the array and will return default values for properties which are not
 * explicitly set. Additionally, with PropertyDefs set, the class will
 * maintain string converted values for efficient translation between
 * Map<String, String> and Map<String, Object> objects.
 *
 * @author Jon Anderson
 */
public class OutputPropertyMap implements Map<String, Object>, OutputComponent {

    /** Empty OutputPropertyMap  */
    public static final OutputPropertyMap EMPTY_MAP =
        new OutputPropertyMap(
                Collections.unmodifiableMap(new HashMap<String, Object>()));

    private static final int HASH_MULTIPLY = 11;
    private static final int HASH_INIT = 87;

    private HashMap<String, Object> _properties;
    private PropertyChangeSupport _changeSupport;
	private HashMap<String, String>  _stringValues;
	private PropertyDef[] _propertyDefs;

	/**
	 * construct with no PropertyDefs or initial values.
	 */
	public OutputPropertyMap() {
		_properties = new HashMap<String, Object>();
		_changeSupport = new PropertyChangeSupport(this);
	}

	/**
	 * Construct with no PropertyDefs and initial values. Note that if
	 * PropertyDefs are later going to be added, the map will have to
	 * be cleared.
	 *
	 * @param properties not <code>null</code> initial values
	 */
	public OutputPropertyMap(Map<String, ? extends Object> properties) {
		_properties = new HashMap<String, Object>();
		_changeSupport = new PropertyChangeSupport(this);
		putAll(properties);
	}

	/**
	 * Constructs with PropertyDefs and default initial values if
	 * <code>propertyDefs</code> is not <code>null</code>
	 * @param propertyDefs maybe <code>null</code.
	 */
	public OutputPropertyMap(PropertyDef[] propertyDefs) {
		_properties = new HashMap<String, Object>();
		_changeSupport = new PropertyChangeSupport(this);
		setPropertyDefs(propertyDefs);
	}

	/**
	 * Constructs with PropertyDefs and initial values. Note that
	 * <code>properties</code> will be validated against
	 * <code>propertyDefs</code> if not <code>null</code>
	 *
	 * @param properties not <code>null</code>
	 * @param propertyDefs maybe <code>null</code>
	 */
	public OutputPropertyMap(
			Map<String, ? extends Object> properties,
			PropertyDef[] propertyDefs) {

	    this(propertyDefs);

		if (properties == null) {
			throw new IllegalArgumentException("properties argument is null");
		}
		putAll(properties);
	}

	/**
	 * Will reset to default values if propertyDefs are set
	 *
	 * @see Map#clear()
	 */
	public void clear() {

		List<PropertyChangeEvent> events;

		synchronized (_properties) {

			if (_properties.size() == 0) {
				return;
			}

			events = new ArrayList<PropertyChangeEvent>();

			for (String key : new HashSet<String>(_properties.keySet())) {

				PropertyChangeEvent event = resetPropertyValue(key);
				if (event != null) {
					events.add(event);
				}
			}
		}

		firePropertyChangeEvents(events);
	}

	/**
	 * @see Map#containsKey(java.lang.Object)
	 */
	public boolean containsKey(Object key) {
		synchronized (_properties) {
			return _properties.containsKey(key);
		}
	}

	/**
	 * @see Map#containsValue(java.lang.Object)
	 */
	public boolean containsValue(Object value) {
		synchronized (_properties) {
			return _properties.containsValue(value);
		}
	}

	/**
	 * @see Map#entrySet()
	 */
	public Set<Entry<String, Object>> entrySet() {
		return _properties.entrySet();
	}

	/**
	 * If no propertyDefs are set follows {@link Map#equals(Object)} otherwise
	 * also compares propertyDefs
	 *
	 * @see Map#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {

		synchronized (_properties) {

		    if (_propertyDefs == null || !(o instanceof OutputPropertyMap)) {
		        return ObjectUtils.equals(_properties, o);
		    }

			OutputPropertyMap propertyMap = (OutputPropertyMap) o;
			if (!ObjectUtils.equals(propertyMap._properties, _properties)) {
				return false;
			}
			if (!ObjectUtils.equals(propertyMap._propertyDefs, _propertyDefs)) {
				return false;
			}
			if (!ObjectUtils.equals(propertyMap._stringValues, _stringValues)) {
				return false;
			}
		}

		return true;
	}

	/**
	 * If propertyDefs are set, will return the defaultValue if there is one
	 * and the property has not set
	 *
	 * @see Map#get(java.lang.Object)
	 */
	public Object get(Object key) {

		if (key == null) {
			throw new IllegalArgumentException("key " + key
					+ " is not a valid property name");
		}

		synchronized (_properties) {
			if (_propertyDefs != null) {

				if (PropertySupport.findPropertyDef(_propertyDefs, (String) key)
						== null) {
					throw new ApplicationException("key " + key
							+  " is not a valid property name");
				}
			}

			return _properties.get(key);
		}
	}

	/**
	 * If propertyDefs are set, will return the value converted as a string
	 * according to the propertyDef, otherwise, it will do the best it can
	 * to convert using {@link PropertySupport#valueToString(Object)}
	 *
	 * @param propertyName not <code>null</code>
	 * @return maybe <code>null</code>
	 */
	public String getAsString(String propertyName) {

		if (propertyName == null) {
			throw new IllegalArgumentException("propertyName argument is null");
		}

		synchronized (_properties) {
			if (_propertyDefs == null) {
				return PropertySupport.valueToString(
						_properties.get(propertyName));
			}

			if (PropertySupport.findPropertyDef(
					_propertyDefs, propertyName) == null) {
				throw new ApplicationException("propertyName "
						+ propertyName + " is not a valid property name");
			}

			return _stringValues.get(propertyName);
		}
	}

	/**
	 * If propertyDefs are set, will return the values converted as a strings
	 * according to the propertyDef, otherwise, it will do the best it can
	 * to convert using {@link PropertySupport#valueToString(Object)}
	 *
	 * @return not <code>null</code>
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getAsStrings() {

		synchronized (_properties) {
			if (_propertyDefs == null) {
				return PropertySupport.propertiesToStrings(_properties);
			}

			return (Map<String, String>) _stringValues.clone();
		}
	}

	/**
	 * @see Map#hashCode()
	 */
	@Override
	public int hashCode() {

	    HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
	    synchronized (_properties) {
			builder.append(_properties);
			builder.append(_propertyDefs);
			builder.append(_stringValues);
	    }
		return builder.toHashCode();
	}

	/**
	 * @see Map#isEmpty()
	 */
	public boolean isEmpty() {
		synchronized (_properties) {
			return _properties.isEmpty();
		}
	}

	/**
	 * @see Map#keySet()
	 */
	public Set<String> keySet() {
		synchronized (_properties) {
			return _properties.keySet();
		}
	}

	/**
	 * Stores a new property value. If propertyDefs are set this will throw
	 * if <code>key</code> is not a valid property. Also, if propertyDefs are
	 * set, <code>value</code> will get converted to the type of value defined
	 * in it's PropertyDef
	 *
	 * @see Map#put(Object, Object)
	 */
	public Object put(String key, Object value) {

		PropertyChangeEvent event;

		synchronized (_properties) {
			event = putPropertyValue(key, value);
		}

		if (event != null) {
			_changeSupport.firePropertyChange(event);
			return event.getOldValue();
		}

		// values didn't change
		return value;
	}

	private PropertyChangeEvent putPropertyValue(String key, Object value) {

		Object newValue;

		if (_propertyDefs == null) {

			newValue = value;

		} else {

			PropertyDef def = PropertySupport.findPropertyDef(
					_propertyDefs,
					key);
			if (def == null) {
				
				// CR# 353,939 - Queue Configuration
				// Modified to return null if the property not found in propertydef
//				throw new ApplicationException("key " + key
//						+  " is not a valid property name");
				return null;
			}

			String stringValue = PropertySupport.valueToString(value);
			_stringValues.put(key, stringValue);

			newValue = PropertySupport.propertyToValue(def, value);
		}

		Object oldValue = _properties.put(key, newValue);
		if (ObjectUtils.equals(oldValue, newValue)) {
			return null;
		}

		return new PropertyChangeEvent(this, key, oldValue, newValue);
	}

	/**
	 * Adds all the values in <code>map</code>
	 *
	 * @param map not <code>null</code>
	 * @see OutputPropertyMap#put(String, Object)
	 * @see Map#putAll(Map)
	 */
	public void putAll(Map< ? extends String, ? extends Object> map) {
		if (map == null) {
			throw new IllegalArgumentException("map argument is null");
		}

		List<PropertyChangeEvent> events = new ArrayList<PropertyChangeEvent>();

		synchronized (_properties) {

			for (Entry< ? extends String, ? extends Object> entry
					: map.entrySet()) {

				PropertyChangeEvent event =
					putPropertyValue(entry.getKey(), entry.getValue());
				if (event != null) {
					events.add(event);
				}
			}
		}

		firePropertyChangeEvents(events);
	}

	private void firePropertyChangeEvents(List<PropertyChangeEvent> events) {

		if (events != null && events.size() > 0) {

			for (PropertyChangeEvent event : events) {
				_changeSupport.firePropertyChange(event);
			}
		}
	}

	/**
	 * Removes the property if set. If propertyDefs are set, and the propertyDef
	 * for <code>key</code> has a default value, the property will effectively
	 * be reset to the default value.
	 *
	 * @param key propertyName of property to remove
	 * @see Map#remove(Object)
	 */
	public Object remove(Object key) {

		if (!(key instanceof String)) {
			throw new IllegalArgumentException("argument " + key
					+ " is not a string");
		}

		PropertyChangeEvent event;
		synchronized (_properties) {
			event = resetPropertyValue((String) key);
		}

		if (event != null) {
			_changeSupport.firePropertyChange(event);
			return event.getOldValue();
		}

		return null;
	}

	private PropertyChangeEvent resetPropertyValue(String key) {

		Object oldValue;
		Object newValue;

		PropertyDef def = null;
		String defaultValue = null;

		if (_propertyDefs != null) {

			def = PropertySupport.findPropertyDef(_propertyDefs, key);
			if (def != null) {
				defaultValue = def.getDefaultValue();
			}
		}

		// if there are propertyDefs set and it's being removed, we are really
		// setting this to the default value if available
		if (defaultValue != null) {

			newValue = PropertySupport.parsePropertyValue(
					def,
					defaultValue);

			oldValue = _properties.put(key, newValue);
			_stringValues.put(key, defaultValue);

		} else {

			newValue = null;
			oldValue = _properties.remove(key);
			if (_propertyDefs != null) {
				_stringValues.remove(key);
			}
		}

		if (ObjectUtils.equals(oldValue, newValue)) {
			return null;
		}

		return new PropertyChangeEvent(this, key, oldValue, newValue);
	}

	/**
	 * @see Map#size()
	 */
	public int size() {
		synchronized (_properties) {
			return _properties.size();
		}
	}

	/**
	 * @see Map#values()
	 */
	public Collection<Object> values() {
		synchronized (_properties) {
			return _properties.values();
		}
	}

	/**
	 * Add listener for any  event
	 *
	 * @param listener
	 * @see PropertyChangeSupport#addPropertyChangeListener(PropertyChangeListener)
	 */
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		_changeSupport.addPropertyChangeListener(listener);
	}

	/**
	 * Register listener for specific event
	 *
	 * @param propertyName
	 * @param listener
	 * @see PropertyChangeSupport#addPropertyChangeListener(String, PropertyChangeListener)
	 */
	public void addPropertyChangeListener(
			String propertyName,
			PropertyChangeListener listener) {
		_changeSupport.addPropertyChangeListener(propertyName, listener);
	}

	/**
	 * Return all listeners
	 *
	 * @return array of PropertyChangeListener
	 * @see PropertyChangeSupport#getPropertyChangeListeners()
	 */
	public PropertyChangeListener[] getPropertyChangeListeners() {
		return _changeSupport.getPropertyChangeListeners();
	}

	/**
	 * Return listeners for a given event
	 *
	 * @param propertyName
	 * @return array of PropertyChangeListener
	 * @see PropertyChangeSupport#getPropertyChangeListeners(String)
	 */
	public PropertyChangeListener[] getPropertyChangeListeners(
			String propertyName) {
		return _changeSupport.getPropertyChangeListeners(propertyName);
	}

	/**
	 * has listeners for a given property
	 *
	 * @param propertyName
	 * @return true if there are listeners
	 * @see PropertyChangeSupport#hasListeners(java.lang.String)
	 */
	public boolean hasListeners(String propertyName) {
		return _changeSupport.hasListeners(propertyName);
	}

	/**
	 * Remove listener
	 * @param listener
	 * @see PropertyChangeSupport#removePropertyChangeListener(PropertyChangeListener)
	 */
	public void removePropertyChangeListener(PropertyChangeListener listener) {
		_changeSupport.removePropertyChangeListener(listener);
	}

	/**
	 * Remove listener registered for specific name
	 *
	 * @param propertyName
	 * @param listener
	 * @see PropertyChangeSupport#removePropertyChangeListener(String, PropertyChangeListener)
	 */
	public void removePropertyChangeListener(
			String propertyName,
			PropertyChangeListener listener) {
		_changeSupport.removePropertyChangeListener(propertyName, listener);
	}

	/**
	 * The propertyDefs if set
	 * @return may be <code>null</code>
	 */
	public PropertyDef[] getPropertyDefs() {
		return _propertyDefs;
	}

	/**
	 * Sets the propertyDefs. This method cannot be called with a non-null value
	 * after property values have been set
	 *
	 * @param propertyDefs may be <code>null</code>
	 */
	public void setPropertyDefs(PropertyDef[] propertyDefs) {

		List<PropertyChangeEvent> events;

		synchronized (_properties) {

			if (propertyDefs == null) {
				_stringValues = null;
				_propertyDefs = propertyDefs;
				return;
			}

			if (_properties.size() > 0) {
				throw new OutputException(
						"propertyDefs cannot be set on non-empty map",
						OutputErrorCode.CONSISTENCY_ERROR);
			}

			_propertyDefs = propertyDefs;
			_stringValues = new HashMap<String, String>();
			events = new ArrayList<PropertyChangeEvent>();

			for (PropertyDef def : _propertyDefs) {

				String defaultValue = def.getDefaultValue();
				if (defaultValue != null) {

					String propertyName = def.getPropertyName();
					Object value = PropertySupport.parsePropertyValue(
							def, defaultValue);
					_properties.put(propertyName, value);
					_stringValues.put(propertyName, defaultValue);

					events.add(
							new PropertyChangeEvent(
									this,
									propertyName,
									null,
									value));
				}

			}
		}

		firePropertyChangeEvents(events);
	}

	/**
	 * @see com.mckesson.eig.output.local.OutputComponent#getProperties()
	 */
	public Map<String, Object> getProperties() {
		return this;
	}

	/**
	 * @see com.mckesson.eig.output.local.OutputComponent#getProperty(java.lang.String)
	 */
	public Object getProperty(String propertyName) {
		return get(propertyName);
	}

	/**
	 * @see com.mckesson.eig.output.local.OutputComponent#setProperty(String, Object)
	 */
	public void setProperty(String propertyName, Object value) {
		put(propertyName, value);
	}

	/**
	 * Sets this map to have the same contents as <code>properties</code>
	 *
	 * @param properties may be <code>null</code> which has the affect of
	 * clearing the map
	 */
	public void setProperties(Map<String, ? extends Object> properties) {

		if (properties == null) {
			clear();
			return;
		}

		Map<String, Object> workingMap = new HashMap<String, Object>(properties);
		List<PropertyChangeEvent> events = new ArrayList<PropertyChangeEvent>();

		synchronized (_properties) {

			List<Entry<String, Object>> entries =
				new ArrayList<Entry<String, Object>>(_properties.entrySet());

			for (Entry<String, Object> entry : entries) {

				String propertyName = entry.getKey();
				PropertyChangeEvent event;

				if (workingMap.containsKey(propertyName)) {
					Object value = workingMap.get(propertyName);
					event = putPropertyValue(propertyName, value);
					workingMap.remove(propertyName);
				} else {
					event = resetPropertyValue(propertyName);
				}

				if (event != null) {
					events.add(event);
				}
			}

			if (workingMap.size() > 0) {
				for (Entry<String, Object> entry : workingMap.entrySet()) {

					PropertyChangeEvent event = putPropertyValue(
							entry.getKey(),
							entry.getValue());
					if (event != null) {
						events.add(event);
					}
				}
			}
		}

		firePropertyChangeEvents(events);
	}

}
