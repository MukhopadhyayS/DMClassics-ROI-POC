/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;

import com.mckesson.eig.output.util.GetSetList;

/**
 * GetSetList decorator that works on EndpointDef's
 *
 * @author Jon Anderson
 */

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "endpointDefs")
@XmlType(name = "endpointDefs")
public class EndpointDefList extends GetSetList<EndpointDef> {

	/**
	 * Creates the list using an ArrayList as the underlying implementation
	 */
	public EndpointDefList() {
		super();
	}

	/**
	 * Creates the list using <code>delegate</code> as the underlying list
	 * implementation
	 *
	 * @param delegate not <code>null</code>
	 */
	public EndpointDefList(List<EndpointDef> delegate) {
		super(delegate);
	}

    /**
     * Lookup the Endpoint by name
     *
     * @param endpointName name of endpoint to lookup
     * @return <code>null</code> if not found
     */
    public EndpointDef findEndpointDef(String endpointName) {

        for (EndpointDef endpointDef : this) {

            if (ObjectUtils.equals(endpointDef.getName(), endpointName)) {
                return endpointDef;
            }
        }

        return null;
    }

    /**
     * Returns the index of the endpoint identified by <code>endpointName</code>
     *
     * @param endpointName name of endpoint to lookup
     * @return -1 if not found
     */
    public int indexOfEndpointDef(String endpointName) {

    	for (int i = 0; i < size(); ++i) {

    		EndpointDef endpointDef = get(i);
            if (ObjectUtils.equals(endpointDef.getName(), endpointName)) {
                return i;
            }

    	}

    	return -1;
    }
}
