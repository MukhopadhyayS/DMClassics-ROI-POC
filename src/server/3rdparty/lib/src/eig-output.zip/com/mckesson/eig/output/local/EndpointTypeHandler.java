/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;

/**
 * EndpointTypeHandlers are responsible for creating and destroying
 * the OutputEndpoints which do actual processing of OutputJobs
 *
 * @author Jon Anderson
 */
public interface EndpointTypeHandler extends OutputComponent  {

	/**
	 * Request to create an endpoint object which matches the requirements defined in
	 * <code>endpointDef</code>
	 *
	 * when creating endpoint, endpointDef status should be updated
	 * @param endpointDef parameters defining the new endpoint
	 * @return should not be <code>null</code>
	 */
	OutputEndpoint createEndpoint(EndpointDef endpointDef);

	/**
	 * Request to create destroy a endpoint object, giving the handler a chance to
	 * release any resources associated.
	 *
	 * @param endpoint the endpoint which is no longer in use
	 */
	void destroyEndpoint(OutputEndpoint endpoint);

	/**
	 * Called when the handler will no longer be used to create endpoints
	 *
	 */
	void cleanUp();

	/**
	 * Return a string list of content types which the OutputEndpoints created
	 * by this handler knows how to handle
	 *
	 * @return maybe <code>null</code> to indicate any type can be processed.
	 */
	String[] getEndpointContentTypes();

	/**
	 * Return the category of endpoint.
	 *
	 * @return not null
	 * @see EndpointCategory
	 */
	EndpointCategory getEndpointCategory();
	
	Map<String, EndpointTypeHandler> getSubHandlers();
	
	void updateEndpoints(List<ActiveEndpoint> endpointArr);

	boolean isEnabled();

}
