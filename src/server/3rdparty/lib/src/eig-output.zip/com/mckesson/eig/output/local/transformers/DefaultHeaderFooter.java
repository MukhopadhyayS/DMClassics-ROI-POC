package com.mckesson.eig.output.local.transformers;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.util.OutputConstants;

public class DefaultHeaderFooter {

    public Map< String, String > getHeaderFooterProperties(OutputManager m,
    		OutputTransform transform) {
        //NOOP -- header/footer will not be added to document
        return new HashMap< String, String >();
    }

    public void addHeaderFooter(InputStream in, OutputStream out,
			Map<String, String> properties) {
 	}

	public static void setJobTotalPage(Map<String, String> properties, int page) {
		properties.put(OutputConstants.JOB_TOTAL_PAGES, Integer.toString(page));
	}

	public static void setJobCurrentPage(Map<String, String> properties, int page) {
		properties.put(OutputConstants.JOB_CURRENT_PAGE_NUM, Integer.toString(page));
	}

	public static void setPartTotalPage(Map<String, String> properties, int page) {
		properties.put(OutputConstants.PART_TOTAL_PAGES, Integer.toString(page));
	}

	public static void setPartCurrentPage(Map<String, String> properties, int page) {
		properties.put(OutputConstants.PART_CURRENT_PAGE_NUM, Integer.toString(page));
	}

	public static void setHeaderString(Map<String, String> properties, String header) {
		properties.put(OutputConstants.HEADER_CENTER, header);
	}

	public static void setFooterString(Map<String, String> properties, String footer) {
		properties.put(OutputConstants.HEADER_CENTER, footer);
	}
}
