/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.mediator;

import java.io.IOException;

import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.fax.RightFaxImpl;
import com.mckesson.eig.output.local.mediator.impl.MediatorDiscJob;
import com.mckesson.eig.output.local.mediator.impl.MediatorEMailJob;
import com.mckesson.eig.output.local.mediator.impl.MediatorFileJob;
import com.mckesson.eig.output.local.mediator.impl.MediatorInterFaxJob;
import com.mckesson.eig.output.local.mediator.impl.MediatorPrintJob;
import com.mckesson.eig.output.local.mediator.impl.MediatorRightFaxJob;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants.DestinationType;

/**
 * OutputJobMediator mediates between output sources and destinations.
 * 
 * @author Michael Macaluso
 * @author Srini Paduri
 * @since 13.5.2
 */
public final class OutputJobMediator {

	/**
	 * Private constructor for utility class.
	 * 
	 */
	private OutputJobMediator() {

	}

	/**
	 * Creates a new destination job using the given file and sending it to the
	 * given Destination
	 * 
	 * @param jobId
	 * @param destinationType
	 * @param destinationName
	 * @param jobName
	 * @param userName
	 * @param numberOfFiles
	 * @param attributeSet
	 * @return {@link OutputDestinationJobJob}
	 * @throws OutputJobException
	 * @throws InterruptedException
	 * @throws IOException
	 * @since 13.5.2
	 */
	public static MediatorJob createJob(OutputJob job, Destination d, final DestTypeHandler handler) throws IOException,
			InterruptedException {
		if (DestinationType.PRINT.toString()
				.equalsIgnoreCase(job.getDestType())) {
			return new MediatorPrintJob(job, d, handler);
		} else if (DestinationType.FAX.toString().equalsIgnoreCase(
				job.getDestType())) {
			if(d instanceof RightFaxImpl) {
				return new MediatorRightFaxJob(job, d, handler);
			} else {
				return new MediatorInterFaxJob(job, d, handler);
			}
			
		} else if (DestinationType.EMAIL.toString().equalsIgnoreCase(
				job.getDestType())) {
			return new MediatorEMailJob(job, d, handler);
		} else if (DestinationType.FILE.toString().equalsIgnoreCase(
				job.getDestType())) {
			return new MediatorFileJob(job, d, handler);
		} else if (DestinationType.DISC.toString().equalsIgnoreCase(
				job.getDestType())) {
			return new MediatorDiscJob(job, d, handler);
		}
		return null;
	}
}
