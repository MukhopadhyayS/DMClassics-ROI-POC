package com.mckesson.eig.output.local.file;

import java.util.Date;

import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.StatefulJob;
import org.quartz.Trigger;
import org.quartz.TriggerUtils;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.mckesson.eig.output.local.EndpointManager;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


public class FilePurgeScheduler extends QuartzJobBean implements StatefulJob {
    private static final Log LOG = LogFactory.getLogger(FilePurgeScheduler.class);
    public static final String QUARTZ_SCHEDULE_NAME = "FileTempFileCleanup";
    public static final String QUARTZ_INTVERAL_MINS = "purgeIntervalMins";

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        try {
        if (context == null) {
            throw new IllegalArgumentException("context argument is null");
        }

        // For each active file destination add job to purge
        Scheduler scheduler = context.getScheduler();

        JobDataMap map = context.getMergedJobDataMap();

        EndpointManager endpointManager =
            (EndpointManager) map.get(OutputConstants.ENDPOINT_MANAGER_BEAN_NAME_PROP);

        if (endpointManager == null) {
            throw new JobExecutionException("endpointManager reference is null");
        }



        String triggerMinInterval = (String) map.get(QUARTZ_INTVERAL_MINS);
        Integer triggerInterval = Integer.valueOf(triggerMinInterval);

        JobDetail jobDetail = new JobDetail(QUARTZ_SCHEDULE_NAME,
                                  Scheduler.DEFAULT_GROUP,
                                  com.mckesson.eig.output.local.file.FilePurge.class);
        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put(OutputConstants.ENDPOINT_MANAGER_BEAN_NAME_PROP, endpointManager);
        jobDetail.setJobDataMap(jobDataMap);
        Trigger trigger = TriggerUtils.makeMinutelyTrigger(triggerInterval);
        trigger.setStartTime(new Date());
        trigger.setJobName(QUARTZ_SCHEDULE_NAME);
        trigger.setName(QUARTZ_SCHEDULE_NAME);
        scheduler.scheduleJob(jobDetail, trigger);

        } catch (Exception e) {
            throw new JobExecutionException(e);
        }
    }

}
