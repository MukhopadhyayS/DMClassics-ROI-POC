/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;

import com.mckesson.eig.output.model.DestInfo;
import com.mckesson.eig.output.model.DestTypeInfo;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.utility.exception.ApplicationException;

/**
  * @author OFS
 * @author Jon Anderson
 * @param <E>
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
public class GetSetList<E> implements List<E> {

	private List<E> _delegate;

	/**
	 *  TODO
	 */
	public GetSetList() {
		_delegate = new ArrayList<E>();
	}


	/**
	 * TODO
	 * @param delegate
	 */
	public GetSetList(List<E> delegate) {
		if (delegate == null) {
			throw new IllegalArgumentException("delegate argument is null");
		}
		_delegate = delegate;
	}


	/**
	 * @see java.util.List#add(java.lang.Object)
	 */
	public boolean add(E o) {
		return _delegate.add(o);
	}

	/**
	 * @see java.util.List#add(int, java.lang.Object)
	 */
	public void add(int index, E element) {
		_delegate.add(index, element);
	}

	/**
	 * @see java.util.List#addAll(java.util.Collection)
	 */
	public boolean addAll(Collection< ? extends E > c) {
		return _delegate.addAll(c);
	}

	/**
	 * @see java.util.List#addAll(int, java.util.Collection)
	 */
	public boolean addAll(int index, Collection< ? extends E > c) {
		return _delegate.addAll(index, c);
	}

	/**
	 * @see java.util.List#clear()
	 */
	public void clear() {
		_delegate.clear();
	}

	/**
	 * @see java.util.List#contains(java.lang.Object)
	 */
	public boolean contains(Object o) {
		return _delegate.contains(o);
	}

	/**
	 * @see java.util.List#containsAll(java.util.Collection)
	 */
	public boolean containsAll(Collection< ? > c) {
		return _delegate.containsAll(c);
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		return _delegate.equals(o);
	}

	/**
	 * @see java.util.List#get(int)
	 */
	public E get(int index) {
		return _delegate.get(index);
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return _delegate.hashCode();
	}

	/**
	 * @see java.util.List#indexOf(java.lang.Object)
	 */
	public int indexOf(Object o) {
		return _delegate.indexOf(o);
	}

	/**
	 * @see java.util.List#isEmpty()
	 */
	public boolean isEmpty() {
		return _delegate.isEmpty();
	}

	/**
	 * @see java.util.List#iterator()
	 */
	public Iterator<E> iterator() {
		return _delegate.iterator();
	}

	/**
	 * @see java.util.List#lastIndexOf(java.lang.Object)
	 */
	public int lastIndexOf(Object o) {
		return _delegate.lastIndexOf(o);
	}

	/**
	 * @see java.util.List#listIterator()
	 */
	public ListIterator<E> listIterator() {
		return _delegate.listIterator();
	}

	/**
	 * @see java.util.List#listIterator(int)
	 */
	public ListIterator<E> listIterator(int index) {
		return _delegate.listIterator(index);
	}

	/**
	 * @see java.util.List#remove(int)
	 */
	public E remove(int index) {
		return _delegate.remove(index);
	}

	/**
	 * @see java.util.List#remove(java.lang.Object)
	 */
	public boolean remove(Object o) {
		return _delegate.remove(o);
	}

	/**
	 * @see java.util.List#removeAll(java.util.Collection)
	 */
	public boolean removeAll(Collection< ? > c) {
		return _delegate.removeAll(c);
	}

	/**
	 * @see java.util.List#retainAll(java.util.Collection)
	 */
	public boolean retainAll(Collection< ? > c) {
		return _delegate.retainAll(c);
	}

	/**
	 * @see java.util.List#set(int, java.lang.Object)
	 */
	public E set(int index, E element) {
		return _delegate.set(index, element);
	}

	/**
	 * @see java.util.List#size()
	 */
	public int size() {
		return _delegate.size();
	}

	/**
	 * @see java.util.List#subList(int, int)
	 */
	public List<E> subList(int fromIndex, int toIndex) {
		return _delegate.subList(fromIndex, toIndex);
	}

	/**
	 * @see java.util.List#toArray()
	 */
	public Object[] toArray() {
		return _delegate.toArray();
	}

	/**
	 * @see java.util.List#toArray(T[])
	 */
	public <T> T[] toArray(T[] a) {
		return _delegate.toArray(a);
	}


	/**
	 * @return
	 */
	public List<E> getDelegate() {
		return _delegate;
	}

	/**
	 * TODO
	 *
	 * @param c
	 */
	@XmlAnyElement (lax = true)
	@XmlElementRefs({
	    @XmlElementRef(name = "destInfo", type = DestInfo.class),
	    @XmlElementRef(name = "endpointDef", type = EndpointDef.class),
	    @XmlElementRef(name = "endpointTypeDef", type = EndpointTypeDef.class),
	    @XmlElementRef(name = "destTypeInfo", type = DestTypeInfo.class),
	    @XmlElementRef(name = "propertyDef", type = PropertyDef.class),
	    @XmlElementRef(name = "property", type = MapModel.class)
	})
	public void setDelegate(List<E> delegate) {
		if (delegate == null) {
			throw new IllegalArgumentException("delegate argument is null");
		}

		_delegate = delegate;
	}

	@Override
    @SuppressWarnings("unchecked")
    public GetSetList<E> clone() {
	    try {
            return (GetSetList<E>) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new ApplicationException(e);
        }
	}
}
