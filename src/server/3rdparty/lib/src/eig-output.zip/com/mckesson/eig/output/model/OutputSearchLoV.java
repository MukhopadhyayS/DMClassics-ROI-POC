/**
 * 
 */
package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.Date;

/**
 * Represents the search LOV data
 * 
 * @author OFS
 * @since  Output 3.0; Nov 19, 2009
 *
 */
public class OutputSearchLoV implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The childId. */
	private int _childId;

	/** The createdBy. */
	private int _createdBy;

	/** The createdDate. */
	private Date _createdDate;

	/** The id. */
	private int _id;

	/** The modifiedBy. */
	private int _modifiedBy;

	/** The modifiedDate. */
	private Date _modifiedDate;

	/** The name. */
	private String _name;

	/** The organization. */
	private int _organization;

	/** The parentId. */
	private int _parentId;

	/** The value. */
	private String _value;

	/**
	 * Gets the childId.
	 * 
	 * @return the _childId
	 */
	public int getChildId() {
		return _childId;
	}

	/**
	 * Sets the childId.
	 * 
	 * @param childId the _childId to set
	 */
	public void setChildId(int childId) {
		_childId = childId;
	}

	/**
	 * Gets the createdBy.
	 * 
	 * @return the _createdBy
	 */
	public int getCreatedBy() {
		return _createdBy;
	}

	/**
	 * Sets the createdBy.
	 * 
	 * @param createdBy the _createdBy to set
	 */
	public void setCreatedBy(int createdBy) {
		_createdBy = createdBy;
	}

	/**
	 * Gets the createdDate.
	 * 
	 * @return the _createdDate
	 */
	public Date getCreatedDate() {
		return _createdDate;
	}

	/**
	 * Sets the createdDate.
	 * 
	 * @param createdDate the _createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		_createdDate = createdDate;
	}

	/**
	 * Gets the id.
	 * 
	 * @return the _id
	 */
	public int getId() {
		return _id;
	}

	/**
	 * Sets the id.
	 * 
	 * @param id the _id to set
	 */
	public void setId(int id) {
		_id = id;
	}

	/**
	 * Gets the modifiedBy.
	 * 
	 * @return the _modifiedBy
	 */
	public int getModifiedBy() {
		return _modifiedBy;
	}

	/**
	 * Sets the modifiedBy.
	 * 
	 * @param modifiedBy the _modifiedBy to set
	 */
	public void setModifiedBy(int modifiedBy) {
		_modifiedBy = modifiedBy;
	}

	/**
	 * Gets the modifiedDate.
	 * 
	 * @return the _modifiedDate
	 */
	public Date getModifiedDate() {
		return _modifiedDate;
	}

	/**
	 * Sets the modifiedDate.
	 * 
	 * @param modifiedDate the _modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	/**
	 * Gets the name.
	 * 
	 * @return the _name
	 */
	public String getName() {
		return _name;
	}

	/**
	 * Sets the name.
	 * 
	 * @param name the _name to set
	 */
	public void setName(String name) {
		_name = name;
	}

	/**
	 * Gets the organization.
	 * 
	 * @return the _organization
	 */
	public int getOrganization() {
		return _organization;
	}

	/**
	 * Sets the organization.
	 * 
	 * @param organization the _organization to set
	 */
	public void setOrganization(int organization) {
		_organization = organization;
	}

	/**
	 * Gets the parentId.
	 * 
	 * @return the _parentId
	 */
	public int getParentId() {
		return _parentId;
	}

	/**
	 * Sets the parentId.
	 * 
	 * @param parentId the _parentId to set
	 */
	public void setParentId(int parentId) {
		_parentId = parentId;
	}

	/**
	 * Gets the value.
	 * 
	 * @return the _value
	 */
	public String getValue() {
		return _value;
	}

	/**
	 * Sets the value.
	 * 
	 * @param value the _value to set
	 */
	public void setValue(String value) {
		_value = value;
	}
}
