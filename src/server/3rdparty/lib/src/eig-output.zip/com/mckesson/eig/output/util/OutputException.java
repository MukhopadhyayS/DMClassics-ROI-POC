/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.exception.ApplicationException;

/**
 * TODO
 * @author Jon Anderson
 *
 */
public class OutputException extends ApplicationException {

	private static final long serialVersionUID = 1L;
	private OutputErrorCode _outputErrorCode;

	/**
	 * TODO
	 */
	public OutputException() {
		this(OutputErrorCode.GENERAL_APP_ERROR);
	}

	/**
	 * TODO
	 * @param message
	 */
	public OutputException(OutputErrorCode errorCode) {
		this(StringUtils.EMPTY, errorCode);
	}

	/**
	 * @param message
	 * @param errorCode
	 */
	public OutputException(String message, OutputErrorCode errorCode) {
		this(message, null, errorCode);
	}

	/**
	 * @param errorCode
	 * @param thrown
	 */
	public OutputException(OutputErrorCode errorCode, Throwable thrown) {
		this(StringUtils.EMPTY, thrown, errorCode);
	}

	/**
	 * @param message
	 * @param thrown
	 * @param errorCode
	 */
	public OutputException(
			String message,
			Throwable thrown,
			OutputErrorCode errorCode) {
		super(message, thrown, errorCode.toString());
		_outputErrorCode = errorCode;
	}

	/**
	 * @return
	 */
	public OutputErrorCode getOutputErrorCode() {
		return _outputErrorCode;
	}


}
