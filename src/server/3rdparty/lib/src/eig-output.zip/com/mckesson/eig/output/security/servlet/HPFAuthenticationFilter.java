/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Corporation and/or one of its subsidiaries and is protected
 * under United States and international copyright and other intellectual
 * property laws. Use, disclosure, reproduction, modification, distribution,
 * or storage in a retrieval system in any form or by any means is prohibited
 * without the prior express written permission of McKesson Corporation.
 */
package com.mckesson.eig.output.security.servlet;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogContext;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.transaction.TransactionId;
import com.mckesson.eig.wsfw.model.authentication.AuthenticatedResult;
import com.mckesson.eig.wsfw.security.service.Authenticator;
import com.mckesson.eig.wsfw.security.servlet.AuthenticationFilter;
import com.mckesson.eig.wsfw.session.WsSession;

/**
 * <code>HPFAuthenticationFilter</code> validates the user by checking
 * gathering all the request values and pass on it to the <code>Authenticator</code>
 * with respect to the application.
 *
 * @author OFS
 * @date   Feb 23, 2009
 * @since  HPF 13.1 [ROI]; Feb 23, 2009
 */
public class HPFAuthenticationFilter
extends AuthenticationFilter {

    private FilterConfig _config;
    private static String _sessionExpiredPage;
    private static String _errPage;
    private static final Log LOG = LogFactory.getLogger(HPFAuthenticationFilter.class);
    private static final boolean DO_DEBUG = LOG.isDebugEnabled();

    private static final String APPN_ID = "applicationId";
    private static final String IS_LOGIN = "IsLogin";
    protected static final String APP_ID = "AppId";
    private static final String SHOW_ALL_JOBS = "ShowAllJobs";
    private static final String ERROR_PAGE = "errorpage";
    private static final String KEY_DOMAIN = "DOMAIN";
    private static final String KEY_DOMAINUSERNAME = "DOMAINUSERNAME";
    private static final String KEY_HPFUSERNAME = "HPFUSERNAME";
    public static final String KEY_IS_LDAP = "ISLDAP";

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

        _config = filterConfig;
        _errPage = "../jsp/ErrorInPage.jsp";
        _sessionExpiredPage = _config.getInitParameter("sessionExpired");
    }
    /**
     *
     * <p>The doFilter method of the Filter is called by the container each time
     * a request/response pair is passed through the chain due to a client
     * request for a resource at the end of the chain. and checks whether the
     * user is valid, and also checks the rights to access the webservice or
     *  even the operation in the service.</p>
     *
     * @param req
     *           Instance of servlet request contains the input parameters
     * @param res
     *           Instance of servlet response
     * @param chain
     *           Instance of <code>FilterChain</code>
     */
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
    throws IOException, ServletException {

        final String logSM = "doFilter(req, res, chain)";
        if (DO_DEBUG) {
            LOG.debug(logSM + ">>Start:");
        }
        HttpServletRequest httpReq  = (HttpServletRequest) req;
        HttpServletResponse httpRes = (HttpServletResponse) res;
        try {

            WsSession.initializeSession(httpReq.getSession());
            String showAllJobs = httpReq.getParameter(SHOW_ALL_JOBS);

            if (showAllJobs != null) {

                // To clear the page data based on status bar reqeust and menu request
                // for monitor jobs.
                setSessionData(httpReq, SHOW_ALL_JOBS);
                httpReq.getSession().removeAttribute(OutputConstants.BEAN_JOBVIEW);
                httpReq.getSession().removeAttribute(OutputConstants.BEAN_QVIEW);
            }

            if (!isAuthenticated(httpReq)) {

                if (httpReq.getParameter(APP_ID) == null) {
                   throw new OutputException("APP_ID == NULL", OutputErrorCode.INVALID_DATA);
                }
                
                String userName = httpReq.getParameter(KEY_DOMAINUSERNAME);
                String domain = httpReq.getParameter(KEY_DOMAIN);
                String hpfUser = httpReq.getParameter(KEY_HPFUSERNAME);
                
                if(domain != null) { 
                    WsSession.setSessionData(Authenticator.KEY_USERNAME,
                                             domain + "\\" + userName + "~" + hpfUser);
                    setSessionData(httpReq, Authenticator.KEY_PASSWORD);
                    WsSession.setSessionData(KEY_IS_LDAP, "true");
                    
                } else {
                    
                setSessionData(httpReq, Authenticator.KEY_USERNAME);
                setSessionData(httpReq, Authenticator.KEY_PASSWORD);
                WsSession.setSessionData(KEY_IS_LDAP, "false");
//                    WsSession.setSessionData(Authenticator.KEY_USERNAME, hpfUser);
                }
                
               // String domainUser = (String) WsSession.getSessionData(Authenticator.KEY_USERNAME);
                
                
                setSessionData(httpReq, Authenticator.KEY_TICKET);
                setSessionData(httpReq, Authenticator.KEY_TIMESTAMP);
                setSessionData(httpReq, SHOW_ALL_JOBS);
                WsSession.setSessionData(Authenticator.KEY_PASSWORD, decryptPassword());
                WsSession.setSessionData(APPN_ID, httpReq.getParameter(APP_ID));

                Authenticator authenticator = getAuthenticator();
                authenticator.validate();

                String transactionID = req.getParameter(Authenticator.KEY_TRANSACTION_ID);

                addTransactionIDtoLogContext(transactionID);
            }

            chain.doFilter(req, res);
            if (DO_DEBUG) {
                LOG.debug(logSM + "<<End:");
            }
         } catch (OutputException ex) {

             if (DO_DEBUG) {
                 LOG.error("<<Error:" + ex.getMessage());
             }


             WsSession.removeAllSessionData();
             ((HttpServletResponse) res).sendRedirect(_sessionExpiredPage);
         } catch (Throwable ex) {

             if (DO_DEBUG) {
                 LOG.error("<<Error:" + ex.getMessage());
             }
             httpRes.sendError(HttpServletResponse.SC_BAD_REQUEST, ex.getMessage());
        }
    }

    private void addTransactionIDtoLogContext(String transactionID) {

        if ((transactionID != null) && (transactionID.trim().length() > 0)) {
            LogContext.put("transactionid", new TransactionId(transactionID));
        }
	}

	/**
     * Validates whether session attribute exists
     *
     * @param HttpServletRequest
     * @return True/False
     */
    @SuppressWarnings("unchecked") // not supported by 3rd party API
    public boolean isAuthenticated(HttpServletRequest httpReq) {

        AuthenticatedResult result =
            (AuthenticatedResult) WsSession.getSessionData(WsSession.AUTHRESULT);

        if ((result == null) || (!result.isAuthenticated()
                || Boolean.valueOf(httpReq.getParameter(IS_LOGIN)))) {
                return false;
        }
        return true;
    }

    /**
     * This method used to set the parameter values to session
     * in order to use that in <code>Authenticator</code>
     *
     * @param httpReq
     *          Instance of <code>HttpServletRequest</code>, contains the
     *          request information
     *
     * @param key
     *          Key used to store the parameter value in the session
     */
    private void setSessionData(HttpServletRequest httpReq, String key) {
        WsSession.setSessionData(key, httpReq.getParameter(key));
    }
}
