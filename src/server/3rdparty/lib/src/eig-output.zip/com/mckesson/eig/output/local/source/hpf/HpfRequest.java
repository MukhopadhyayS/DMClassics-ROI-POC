package com.mckesson.eig.output.local.source.hpf;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import com.mckesson.eig.output.model.RequestPart;

public class HpfRequest {
	public static final String PATIENT_NAME = "p";
	public static final String MRN = "m";
	public static final String FACILITY = "f";
	public static final String ENCOUNTER = "e";
	public static final String DOCNAME = "d";
	public static final String IMNETS = "i";
	public static final String PAGENUMS = "n";

	public HpfRequest() {
	}

	public List<HpfContent> getContent(RequestPart part) {
		return getHPFContent(part);
	}

	private List<HpfContent> getHPFContent(RequestPart part) {
		Map<String, String> map = part.getProperties();
		List<HpfContent> result = new ArrayList<HpfContent>();
		if (map != null) {
			List<String> imnets = getListFromStr(map.get(IMNETS));
			List<String> pageNumbers = getListFromStr(map.get(PAGENUMS));
			String patientName = map.get(PATIENT_NAME);
			String mrn = map.get(MRN);
			String facility = map.get(FACILITY);
			String encounter = map.get(ENCOUNTER);
			String documentName = map.get(DOCNAME);

			for (int i = 0; i < imnets.size(); i++) {
				String imnet = imnets.get(i);
				String pageNumber = "1";

				if (pageNumbers.size() == imnets.size()){
					// one page number per imnet request scenario
					pageNumber = pageNumbers.get(i);
					HpfContent content = createContent(imnet, pageNumber,
							patientName, mrn, facility, encounter, documentName);
					result.add(content);
				} else if (pageNumbers.size() == 1){
					// multiple imnets one page number request scenario
					pageNumber = pageNumbers.get(0);
					HpfContent content = createContent(imnet, pageNumber,
							patientName, mrn, facility, encounter, documentName);
					result.add(content);
				} else if (imnets.size() == 1 && pageNumbers.size() > 1) {
					// one imnet multiple page number request scenario
					for (int p = 0; p < pageNumbers.size(); p++) {
						pageNumber = pageNumbers.get(p);
						HpfContent content = createContent(imnet, pageNumber,
								patientName, mrn, facility, encounter, documentName);
						result.add(content);
					}
				} else {
					// no page number request scenario
					HpfContent content = createContent(imnet, pageNumber,
							patientName, mrn, facility, encounter, documentName);
					result.add(content);
				}

			}
		}
		return result;
	}

	private HpfContent createContent(String imnet, String pageNumber,
			String patientName, String mrn, String facility, String encounter,
			String docName) {
		HpfContent result = new HpfContent();
		result.setPageId(imnet);
		result.setPageNumber(pageNumber);
		result.setMrn(mrn);
		result.setFacility(facility);
		result.setEncounter(encounter);
		result.setDocumentName(docName);
		return result;
	}

	private List<String> getListFromStr(String str) {
		List<String> result = new ArrayList<String>();
		if (str != null && str.trim().length() != 0) {
			StringTokenizer st = new StringTokenizer(str, ",");
			while (st.hasMoreTokens()) {
				result.add(st.nextToken());
			}
		}
		return result;
	}
}
