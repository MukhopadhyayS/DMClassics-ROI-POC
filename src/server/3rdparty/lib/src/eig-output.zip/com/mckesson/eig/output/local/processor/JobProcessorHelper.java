/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import java.util.List;

import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;

public class JobProcessorHelper {

	protected OutputJobDAO _jobDao;

	public JobProcessorHelper(OutputJobDAO jobDao) {
		_jobDao = jobDao;
	}

    public JobProcessorHelper() {
    }

	/**
	 * This method is used to return the next available job
	 * from a list of queues which job is process only one per queue.
	 *
	 * @param queues
	 * @param checkStatus
	 * @param setStatus
	 * @return Integer
	 */
	public Integer getNextAvailableJobForOnePerQueue(List<Integer> queues, RequestStatus checkStatus, RequestStatus setStatus) {
		if (queues.size() == 0) {
			return null;
		}
		return _jobDao.getNextAvailableJobForOnePerQueue(queues, checkStatus, setStatus);
	}

	/**
	 * This method is used to reset the status in the Output_Service_Job table after the job is idle in days
	 *
	 * @param resetStatus
	 * @param checkStatus
	 * @param idleInMin
	 * @param errorMsg
	 */
	public boolean processIdleJobInDaysByChangeStatus(List<RequestStatus> checkStatuses, RequestStatus resetStatus, int idleInDays, String errorMsg) {
		return _jobDao.processIdleJobInDaysByChangeStatus(checkStatuses, resetStatus, idleInDays, errorMsg);
	}
	
	/**
	 * This method is used to reset the status from the Output_Service_Job table after the job is idle in minutes
	 *
	 * @param queues
	 * @param checkStatus
	 * @param resetStatus
	 * @param idleInMin
	 * @param errorMsg
	 */
	public boolean processIdleJobByChangeStatus(List<Integer> queues, RequestStatus checkStatus, RequestStatus resetStatus, int idleInMin, String errorMsg) {
		if (queues.size() == 0) {
			return false;
		}
		return _jobDao.processIdleJobByChangeStatus(queues, checkStatus, resetStatus, idleInMin, errorMsg);
	}
	
	/**
	 * This method is used to remove the processing server from the Output_Service_Job table after the job is idle in minutes
	 *
	 * @param queues
	 * @param checkStatus
	 * @param idleInMin
	 * @param errorMsg
	 */
	public boolean processIdleJobByRemoveServerName(List<Integer> queues, RequestStatus checkStatus, int idleInMin, String errorMsg) {
		if (queues.size() == 0) {
			return false;
		}
		return _jobDao.processIdleJobByRemoveServerName(queues, checkStatus, idleInMin, errorMsg);
	}

	/**
	 * This method is used to return the next available job
	 * from a list of queues.
	 *
	 * @param queues
	 * @param checkStatus
	 * @param setStatus
	 * @return Integer
	 */
	public Integer getNextAvailableJob(List<Integer> queues, RequestStatus checkStatus, RequestStatus setStatus) {
		if (queues.size() == 0) {
			return null;
		}
		return _jobDao.getNextAvailableJob(queues, checkStatus, setStatus);
	}

	/**
	 * This method is used to get  the processing server from the Output_Service_Job table
	 * specified in the StatusInfo object.
	 *
	 * @param queues
	 * @param checkStatus
	 * @param hostNameOnly
	 */
	public Integer getCurrentProcessingJob(List<Integer> queues, RequestStatus checkStatus, boolean hostNameOnly) {
		if (queues.size() == 0) {
			return null;
		}
		return _jobDao.getCurrentProcessingJob(queues, checkStatus, hostNameOnly);
	}
}
