/**
 * Copyright � 2010 McKesson Corporation and/or one of its subsidiaries.
 * All rights reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.hpf.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ContentWebServiceExecutor {

	private List<WebServiceSetting> _settings = new ArrayList<WebServiceSetting>();
	private static int _webSettingIdx = 0;
	private boolean _available = false;
    private final ExecutorService _executorService;

	public ContentWebServiceExecutor(int poolSize, List<WebServiceSetting> settings) {
		_executorService = Executors.newFixedThreadPool(poolSize);
		_settings = settings;
	}

	public Future<ContentServiceRunnable> getContents(List<String> imnets,
			List<String> pageNumbers, List<File> files, boolean continueWithError) {
		ContentServiceRunnable service =
			new ContentServiceRunnable(getWebSetting(), imnets, pageNumbers, files, continueWithError);
		Future<ContentServiceRunnable> future = _executorService.submit(service, service);
		return future;
	}

	public void getContentToFile(String imnet, String pageNumber, File f, boolean continueIfFail) {
		WebServiceSetting setting = getWebSetting();
		setting.getContentWebServiceCaller().getContentToFile(setting, imnet, pageNumber, f, continueIfFail);
	}

	public void shutdown() {
		_executorService.shutdown();
	}

	private synchronized WebServiceSetting getWebSetting() {
		int result = _webSettingIdx;
		_webSettingIdx = _webSettingIdx < _settings.size() - 1 ? _webSettingIdx + 1 : 0;
		return _settings.get(result);
	}

	public boolean isAvailable() {
		return _available;
	}

	public void setAvailable(boolean b) {
		_available = b;
	}
}
