/*
 * Copyright 2009-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.security.authorization;


import com.mckesson.eig.output.security.AbstractAuthenticator;



/**
 * @author OFS
 * @date   Feb 23, 2009
 * @since  HPF 13.1 [ROI]; Feb 17, 2009
 */
public class OutputDispatchAuthenticator extends AbstractAuthenticator {

    /**
     * Gets the application id to get <code>OutputDispatchAuthenticator</code>
     *
     */
    public String getAppID() {
        return "outputdispatch";
    }
}
