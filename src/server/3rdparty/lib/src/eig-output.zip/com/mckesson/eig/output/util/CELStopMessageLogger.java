/**
 * 
 */
package com.mckesson.eig.output.util;
import com.mckesson.eig.output.model.ShutdownHook;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * @ Implements Output JBoss Shutdown Logging
 *
 */

public class CELStopMessageLogger implements ShutdownHook {

	private static final Log LOG = LogFactory.getLogger(CELStopMessageLogger.class);
	
	public void shutdown() {
		LOG.error(System.getenv("COMPUTERNAME")+ ": Common Output service stopped.");
	}
}
