/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

/*
 * TODO :  this should be rewritten as an object to the PdfHeaderFooter class
 * PdfHeaderFooter class should call get properties from this object for processing
 *
 * OR:  this class should be added to route before processing to set properties
 */
package com.mckesson.eig.output.local.transformers;


import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;


public class RMHeaderFooter extends DefaultHeaderFooter {

	public RMHeaderFooter() {
	    super();
	}

    public Map <String, String> getHeaderFooterProperties(OutputManager outputManager,
                                                          OutputTransform transform) {
       HashMap <String, String> properties = new HashMap <String, String>();
       setHeaderProperties(outputManager, transform, properties);
       setFooterProperties(outputManager, transform, properties);
       
       return properties;
    }

    public void addHeaderFooter(InputStream in, OutputStream out,
			Map<String, String> properties) {
    	new RMHeaderFooterProcessor().addHeaderFooter(in, out, properties);
	}

    
    //TODO:  should mrn masking be sent for snapshots
    private void setHeaderProperties(OutputManager outputManager,
                                     OutputTransform transform,
                                     HashMap <String, String> properties) {
        try {
        	
        	String content = "Patient: " + transform.getProperties()
			                                         .get(OutputConstants.HEADER_FOOTER_PATIENT_NAME);
			
			content += "     ";
			
			content += "Facility: " + transform.getProperties()
			                                     .get(OutputConstants.HEADER_FOOTER_FACILITY) ;
			
			content += "     ";
			
			content += "  MRN: " + transform.getProperties()
			                                .get(OutputConstants.HEADER_FOOTER_MRN);

			content += "     ";
			
			content += "  ENC: " + transform.getProperties()
										    .get(OutputConstants.HEADER_FOOTER_ENCOUNTER);
 			
        	properties.put(OutputConstants.HEADER_CENTER, content);


        } catch (Exception e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

    private void setFooterProperties(OutputManager outputManager,
                                     OutputTransform transform,
                                     HashMap <String, String> properties) {

        try {

        	properties.put(OutputConstants.FOOTER_LEFT, "pageNum");

        } catch (Exception e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }


}
