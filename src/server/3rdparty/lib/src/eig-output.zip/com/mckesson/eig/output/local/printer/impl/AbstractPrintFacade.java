/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.printer.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.local.printer.PrintDestination;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputSettingConstants;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.SpringUtilities;

/**
 * Abstract Facade for printing
 * 
 * @author Srini Paduri
 * 
 * @since 13.5.2
 * 
 */
public abstract class AbstractPrintFacade implements PrintFacade {

    private static final Log LOG = LogFactory.getLogger(AbstractPrintFacade.class);

    private String _printPdfPath = "../../pdf/bin/printpdf.bat";
    private String _pdfExePath;
    private File _pdfExeWorkingDir;

    private static final String SIDES = "-sides=";
    private static final String COPIES = "-copies=";
    private static final String DESCENDING = "-reverse";

    public static final int SINGLE_SIDED = 1;
    public static final int DEPLEX = 2;
    public static final int TUMBLE = 3;
    private int _duplex = 0;

    private final OutputJob _job;

    /**
     * Abstract print facade.
     * 
     */
    public AbstractPrintFacade(OutputJob job) {
        _job = job;
        setExePath(getPrintPdf());
    }

    private String getPrintPdf() {
        Properties outputSettings = (Properties) SpringUtilities.getInstance().getBeanFactory().
                getBean(OutputSettingConstants.OUTPUT_SETTING_PROPERTIES_BEAN);
        String pdfPath = null;
        if (null != outputSettings) {
            pdfPath = outputSettings.getProperty(OutputSettingConstants.PRINT_PDF);
        }
        if (null != pdfPath) {
            _printPdfPath = pdfPath;
        }
        return _printPdfPath;
    }

    private void setExePath(String exePath) {
        File f = new File(exePath);
        try {
            _pdfExePath = f.getCanonicalPath();
            _pdfExeWorkingDir = new File(_pdfExePath).getParentFile();
        } catch (Exception e) {
            LOG.error("Invalid Printer converter Path:" + exePath + "-" + e.getMessage());
        }
    }

    protected List<String> getPrintProperties(int copy, int side, boolean reverseOrder) {
        List<String> list = new ArrayList<String>();
        if (copy > 1) {
            list.add(COPIES + copy);
        }
        if (side > 0) {
            list.add(SIDES + side);
        }
        if (reverseOrder) {
            list.add(DESCENDING);
        }
        return list;
    }

    protected boolean isReversePrintOrder() {
        Map<String, String> map = _job.getProperties();
        if ((map != null) && (map.get("ReverseOutputOrder") != null)) {
            return Boolean.parseBoolean(map.get("ReverseOutputOrder"));
        }
        return false;
    }

    protected int getCopies() {
        Map<String, String> map = _job.getProperties();
        if (map != null && map.get("copies") != null) {
            return Integer.parseInt(map.get("copies"));
        }
        return ((PrintDestination) _job.getDestination()).getCopies();
    }

    protected int getDuplex() {
        if (_duplex > 0) {
            return _duplex;
        }
        Map<String, String> map = _job.getProperties();
        String duplex = "false";
        if (map != null) {
            duplex = map.get("duplex");
        }
        if (StringUtils.isNotBlank(duplex)) {
            if (new Boolean(duplex)) {
                _duplex = DEPLEX;
            } else {
                _duplex = SINGLE_SIDED;
            }
            return _duplex;
        }
        _duplex = SINGLE_SIDED;
        return _duplex;
    }

    public String getPrintPdfPath() {
        return _printPdfPath;
    }

    public void setPrintPdfPath(String printPdfPath) {
        _printPdfPath = printPdfPath;
    }

    public String getPdfExePath() {
        return _pdfExePath;
    }

    public void setPdfExePath(String pdfExePath) {
        _pdfExePath = pdfExePath;
    }

    public File getPdfExeWorkingDir() {
        return _pdfExeWorkingDir;
    }

    public void setPdfExeWorkingDir(File pdfExeWorkingDir) {
        _pdfExeWorkingDir = pdfExeWorkingDir;
    }

    public OutputJob getJob() {
        return _job;
    }

    public Thread getPrintThread() {
        return null;
    }
}
