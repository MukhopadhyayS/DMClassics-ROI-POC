/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * An <code>RequestPart</code> that is being processed by the Output Service
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "jobPart")
@XmlType(name = "jobPart")
public class JobPart extends RequestPart {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 27;
	private static final int HASH_INIT = 15;
	private static final String NO_OF_PAGES = "NO_OF_PAGES";

	private OutputJob _outputJob;
	private int _partID;
	private int _jobID;
	private int _pages;
	private int _orgSeq;
    private int _statusID;
//    private int _partIndex;
	private StatusInfo _statusInfo;
    private String _currentLocation;
    private String _baseLocation;
	private String _nextLocation;
	// contains pdf files for processing
	private List<String> _sources = new ArrayList<String>();
	// contains non-pdf files for processing
	private List<String> _attachments = new ArrayList<String>();
    private int _totalPages;

	/**
	 * Constructs the object
	 */
	public JobPart() {
		super();
	}

	@Override
	public boolean equals(Object o) {

		JobPart part = (JobPart) o;

		if (!super.equals(part)) {
			return false;
		}
		if (part._jobID != _jobID) {
			return false;
		}
		if (part._partID != _partID) {
			return false;
		}
		if (!ObjectUtils.equals(part._statusInfo, _statusInfo)) {
			return false;
		}
		if (!ObjectUtils.equals(_currentLocation, part._currentLocation)) {
			return false;
		}

		return true;
	}

	@Override
	public int hashCode() {

		HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
		builder.appendSuper(super.hashCode());
		builder.append(_jobID);
		builder.append(_partID);
		builder.append(_statusInfo);
		builder.append(_currentLocation);

		return builder.toHashCode();
	}

	@XmlTransient
	public void setOutputJob(OutputJob job) {
	    _outputJob = job;
	}

	public OutputJob getOutputJob() {
	    return _outputJob;
	}
	
	/**
	 * The unique id for the part with in the job
	 *
	 * @return may be <code>null</code>
	 */
	public int getPartID() {
		return _partID;
	}

	/**
	 * @param id
	 */
	@XmlElement (name = "partID")
	public void setPartID(int id) {
		_partID = id;
	}

	/**
	 * The unique id of the job which owns this part
	 *
	 * @return may be <code>null</code>
	 */
	public int getJobID() {
		return _jobID;
	}

	/**
	 * @param id
	 */
	@XmlElement (name = "jobID")
	public void setJobID(int id) {
		_jobID = id;
	}

	/**
	 * Returns the status info for the part.
	 *
	 * @return may be <code>null</code>
	 */
	public StatusInfo getStatusInfo() {

		if (_statusInfo == null) {
			_statusInfo = new StatusInfo();
		}
		return _statusInfo;
	}

	/**
	 * @param statusInfo
	 */
	@XmlElement (name = "statusInfo", type = StatusInfo.class)
	public void setStatusInfo(StatusInfo statusInfo) {
		_statusInfo = statusInfo;
	}

	/**
	 * Description of the current location of the part or job. Most likely a URN
	 *
	 * @return the _currentLocation member
	 */
	public String getCurrentLocation() {
		return _currentLocation;
	}

	/**
	 * @param currentLocation
	 */
	@XmlElement (name = "currentLocation")
	public void setCurrentLocation(String currentLocation) {
		_currentLocation = currentLocation;
	}

	/**
	 * TODO
	 *
	 * @return the _nextLocation
	 */
	public String getNextLocation() {
		return _nextLocation;
	}

	/**
	 * TODO
	 *
	 * @param nextLocation
	 *            the _nextLocation to set
	 */
	@XmlTransient
	public void setNextLocation(String nextLocation) {
		_nextLocation = nextLocation;
	}

    /**
     * Description of the base location of the part or job. Most likely a URN
     *
     * @return the _baseLocation member
     */
    public String getBaseLocation() {
        return _baseLocation;
    }

    /**
     * @param baseLocation
     */
    @XmlTransient
    public void setBaseLocation(String baseLocation) {
        _baseLocation = baseLocation;
    }

    /**
     * ID of the organization which submitted the job.
     *
     * TODO -  This will be defaulted to zero for now. Added to
     * accomplish future enhancements.
     *
     * @return
     */
	public int getOrgSeq() {
		return _orgSeq;
	}

	/**
	 * @param orgSeq
	 */
	@XmlTransient
	public void setOrgSeq(int orgSeq) {
		_orgSeq = orgSeq;
	}

	/**
	 * Represents the number of pages for the part.
	 *
	 * @return number of pages in the part.
	 */
	public int getPages() {
		return _pages;
	}

	/**
	 * @param pages
	 */
	@XmlTransient
	public void setPages(int pages) {
		_pages = pages;
	}

	public int getStatusID() {

		if (_statusID == 0) {
			_statusID = getStatusInfo().getStatusCode();
		}
		return _statusID;
	}

	public void setStatusID(int statusID) {

		getStatusInfo().setStatusCode(statusID);
		_statusID = statusID;
	}

	/**
	 * TODO
	 * @return
	 */
	public Iterator<String> getSourcesIterator() {
		return _sources.iterator();
	}

	public List<String> getSources() {
	    return _sources;
	}

	/**
	 * TODO
	 * @return
	 */
	public Iterator<String> getAttachmentsIterator() {
		return _attachments.iterator();
	}

	public List<String> getAttachments() {
	    return _attachments;
	}	
	
//	public int getPartIndex() {
//		return _partIndex;
//	}
//
//	public void setPartIndex(int partIndex) {
//		_partIndex = partIndex;
//	}

	/**
	 * TODO
	 * @param fileName
	 */
	public void addSource(String fileName) {
		_sources.add(fileName);
	}

	/**
	 * TODO
	 */
	public void clearSources() {
		_sources.clear();
	}
	
	/**
	 * TODO
	 * @param fileName
	 */
	public void addAttachment(String fileName) {
		_attachments.add(fileName);
	}

	/**
	 * TODO
	 */
	public void clearAttachments() {
		_attachments.clear();
	}	

	public int getNoOfPages() {
		String str = getProperties().get(NO_OF_PAGES);
		if (str == null) {
			return 0;
		}
		try {
			return Integer.parseInt(str);
		} catch (NumberFormatException e) {
			return 0;
		}
	}

	@XmlTransient
	public void setNoOfPages(int noOfPages) {
		getProperties().put(NO_OF_PAGES, String.valueOf(noOfPages));
		setPages(noOfPages);
	}

	public int getTotalPages() {
		return _totalPages;
	}

	@XmlTransient
	public void setTotalPages(int totalPages) {
		_totalPages = totalPages;
	}
}
