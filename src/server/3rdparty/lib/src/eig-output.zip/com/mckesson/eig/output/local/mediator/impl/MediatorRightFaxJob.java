package com.mckesson.eig.output.local.mediator.impl;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;

import org.apache.activemq.ActiveMQConnectionFactory;

import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.fax.FaxObject;
import com.mckesson.eig.output.local.fax.RightFaxImpl;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.SpringUtilities;

public class MediatorRightFaxJob extends MediatorFaxJob {

    private static final Log LOG = LogFactory.getLogger(MediatorRightFaxJob.class);
    private static final String CONNECTIONFACTORY = "connectionFactory";

    public MediatorRightFaxJob(OutputJob job, Destination d, DestTypeHandler handler) {
		super(job, d, handler);
	}
	
	protected RightFaxImpl getDestination() {
		return (RightFaxImpl) _destination;
	}

	public void doneWithJob() throws IOException, InterruptedException {
		try {
			if (_faxList.size() > 0) {
				fax(_job, _faxList);
			} else {
				// update status as error - nothing to fax
				updateStatus(_job.getJobSeq(), RequestStatus.ERROR, "Error processing Output job to Fax - no pages to fax");
			}
			LOG.info("finished processing job: " + _job.getJobSeq());
		} catch (Exception e) {
			updateStatus(_job.getJobSeq(), RequestStatus.ERROR, "Error processing Output job to Fax");
			LOG.error("Error Processing Fax Job: " + _job.getJobName(), e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Creates fax object and sends the output message to fax destination queue
	 * 
	 * @param job
	 * @param list
	 */
	private void fax(OutputJob job, List<String> list) {

		FaxObject faxObj = new FaxObject();
		faxObj.setToName(job.getJobName());
		faxObj.setJobId(job.getJobSeq());
		faxObj.setJobName(job.getJobName());

		String faxNo;
		faxNo = job.getPropertyValue(OutputConstants.OUTPUT_FAX_NUMBER);
		if (faxNo != null) {
			faxObj.setToFaxNumber(faxNo);
		} else {
			// Check in the job parts:
			for (Iterator<JobPart> iter = job.getParts().iterator(); iter
					.hasNext();) {
				JobPart part = iter.next();
				faxNo = part.getProperties() != null ? part.getProperties()
						.get(OutputConstants.OUTPUT_FAX_NUMBER) : null;
				faxObj.setToFaxNumber(faxNo);
				break;
			}
		}
		if (faxNo == null) {
			String msg = "FAX Number is null, Cannot perform FAX JOB";
			LOG.error(msg);
			throw new RuntimeException(msg);
		}
		faxObj.setFaxList(list);
		faxObj.setQueueName(getDestination().getQueueName());
		faxObj.setQueuePassword(getDestination().getQueuePassword());
		try {
			sendMesage(faxObj, job.getJobSeq());

		} catch (Exception e) {
			LOG.error("Exception in Fax", e);
			throw new RuntimeException(e);
		}
	}

	public void sendMesage(FaxObject obj, int jobId) throws Exception {
		if (obj != null) {
			sendMessage(getDestination().getMqFaxQueueName(), obj);
		}
	}

	/**
	 * Posts the fax output message in a topic and updates the status of job
	 * 
	 * @param topicName
	 * @param obj
	 */
	public void sendMessage(String topicName, FaxObject obj) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Sending AUTO_ACKNOWLEDGE message to topic:  "
					+ topicName);
		}
		TopicConnection connection = null;
		TopicSession session = null;
		try {
			ActiveMQConnectionFactory connectionFactory = getActiveMQConnectionFactory();
			if (LOG.isDebugEnabled()) {
				LOG.debug("ActiveMQ Broker URL:  "
						+ connectionFactory.getBrokerURL());
			}
			connection = connectionFactory.createTopicConnection();
			session = connection.createTopicSession(true,
					Session.AUTO_ACKNOWLEDGE);
			connection.start();
			session.run();
			// create request and response queues
			Topic t = session.createTopic(topicName);
			TopicPublisher publisher = session.createPublisher(t);
			publisher.publish(session.createTextMessage(obj.toXml()));
			session.commit();
			session.close();
			connection.close();
			updateStatus(_job.getJobSeq(), RequestStatus.PROCESSING, "Sending to Fax Service");
		} catch (Exception e) {
			updateStatus(_job.getJobSeq(), RequestStatus.ERROR, "Failed to send Fax Service");
		} finally {
			try {
				if (null != session) {
					session.close();
				}
				if (null != connection) {
					connection.close();
				}
			} catch (JMSException e) {
				LOG.debug("Failed to close ActiveMQ resources");
			}
		}
	}

	public static ActiveMQConnectionFactory getActiveMQConnectionFactory() {
		return (ActiveMQConnectionFactory) SpringUtilities.getInstance()
				.getBeanFactory().getBean(CONNECTIONFACTORY);
	}
}
