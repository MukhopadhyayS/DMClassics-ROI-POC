/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.file;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.mckesson.eig.output.local.AbstractTypeHandler;
import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.local.transformers.PdfBookmark;
import com.mckesson.eig.output.local.transformers.PdfConcatenate;
import com.mckesson.eig.output.model.DestDef;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.PdfUtils;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.output.util.status.StatusUtils;

/**
 * TODO
 * @author Jon Anderson
 *
 */
public class FileTypeHandler extends AbstractTypeHandler {
	
	private final Map<String, FileDestination> _fileDestinations = new HashMap<String, FileDestination>();
	private PdfConcatenate _pdfConcatenate;
	private PdfBookmark _pdfBookmark;
	private Properties _cryptoProperties;

	/**
	 * TODO
	 * @param outputDirs
	 */
	public FileTypeHandler() {
		super();
        _pdfConcatenate = new PdfConcatenate();  //default PDF Concatenate
	}

	public FileTypeHandler(String enabled) {
		this();
		setEnabled(enabled);
	}

	/**
	 * @see com.mckesson.eig.output.local.DestTypeHandler#cleanUp()
	 */
	public void cleanUp() {
		// TODO Auto-generated method stub

	}

	public OutputEndpoint createEndpoint(EndpointDef endpointDef) {

		if (endpointDef == null) {
			throw new IllegalArgumentException(
					"endpointDef argument is null");
		}

		DestDef destDef = (DestDef) endpointDef;
		FileDestination fileDestination = new FileDestination(this, destDef);
		_fileDestinations.put(destDef.getName(), fileDestination);
		return fileDestination;
	}


	/**
	 * @see DestTypeHandler#destroyEndpoint(OutputEndpoint)
	 */
	public void destroyEndpoint(OutputEndpoint destination) {
		// TODO Auto-generated method stub

	}

	/**
	 * @see com.mckesson.eig.output.local.DestTypeHandler#getEndpointContentTypes()
	 */
	public String[] getEndpointContentTypes() {
		return OutputConstants.ANY_CONTENT_TYPE;
	}

	/**
	 * @see com.mckesson.eig.output.local.DestTypeHandler#queryDeviceIDs()
	 */
	public Collection<String> queryDeviceIDs() {
		return  _fileDestinations.keySet();
	}

	/**
	 * @see DestTypeHandler#queryDeviceStatus(java.lang.String)
	 */
	public StatusInfo queryDeviceStatus(String deviceID) {
		return createDirStatusInfo(deviceID);
	}

	StatusInfo createDirStatusInfo(String dirName) {
		return StatusUtils.createEndpointStatus(EndpointStatus.OK, null);
	}

	/**
	 * @see DestTypeHandler#queryDeviceProperties(java.lang.String)
	 */
	public Map<String, Object> queryDeviceProperties(String deviceID) {
		return PropertySupport.createDefaultValuesMap(
		                 PropertySupport.extractAnnotatedProperties(FileDestination.class));
	}


	@Override
    public PropertyDef[] getPropertyDefs() {
	    return PropertySupport.extractAnnotatedProperties(FileDestination.class);
	}


	/**
	 * TODO
	 * @param deviceID
	 */
	public PropertyDef[] getDevicePropertyDefs(String deviceID) {
	    FileDestination tmpFileDestination =
	        _fileDestinations.get(deviceID);
		return tmpFileDestination.getPropertyDefs();
	}

	/**
	 * TODO
	 * @param dir
	 * @throws IOException
	 */
	public static final void validateDirectory(File dir) {
		if (dir == null) {
			throw new IllegalArgumentException("dir argument is null");
		}

		String path = dir.getAbsolutePath();
		if (!dir.exists() && !"".equalsIgnoreCase(dir.getName())) {
			if (!dir.mkdirs()) {
				throw new InvalidDefinitionException(
						"unable to create directories for: " + path,
						OutputErrorCode.RUNTIME_ERROR);
			}
		} else if (!dir.isDirectory()) {
			throw new InvalidDefinitionException(
					"not a directory: " + path,
					OutputErrorCode.RUNTIME_ERROR);
		} else if (!dir.canRead() || !dir.canWrite()) {
			throw new InvalidDefinitionException(
					"cannot read or write to " + path,
					OutputErrorCode.RUNTIME_ERROR);
		}
	}


    public String getConfigProperty(String key) {
        return (String) _outputManager.getProperty(key);
    }


    public void setBookmarkStrategy(PdfBookmark bookmark) {
        _pdfBookmark = bookmark;
    }

    public void setConcatenateStrategy(PdfConcatenate pdfConcatenate) {
        _pdfConcatenate = pdfConcatenate;
    }

    public PdfBookmark getBookmarkStrategy() {
        return _pdfBookmark;
    }

    public PdfConcatenate getConcatenateStrategy() {
        return _pdfConcatenate;
    }
    
    public Properties getCryptoProperties() {
    	return _cryptoProperties;
    }
    
	public void setPropertiesFile(String properties) {
		_cryptoProperties = PdfUtils.loadProperties(properties);
	}
}
