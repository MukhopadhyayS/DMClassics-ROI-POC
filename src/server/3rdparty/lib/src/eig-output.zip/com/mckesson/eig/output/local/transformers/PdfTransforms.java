/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 *
 *
 * author: Latonia
 */

package com.mckesson.eig.output.local.transformers;


import com.mckesson.eig.output.local.BaseComponent;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.OutputManagerAware;
import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.service.OutputBaseService.DAOName;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.utility.util.SpringUtilities;

/*
 * TO DO: Support dynamic route building and processing
 */

/*
 * Processes  Transformations
 */
public class PdfTransforms
extends BaseComponent
implements
OutputManagerAware {

    private OutputManager    _outputManager;
    private String           _transformType;

    public PdfTransforms() {

        super();
    }

    @OutputProperty(
                    defaultValue = "",
                    description = "Transform Type",
                    label = "TransformType")
    public String getTransformType() {
        return _transformType;
    }

    public void setTransformType(String transformType) {
        _transformType = transformType;
    }

    protected void updateJobStatus(OutputJob job, StatusInfo statusInfo) {

        _outputManager.updateJobStatus(job.getJobSeq(), statusInfo);
    }

    //TODO updatePartStatus

    public void setOutputManager(OutputManager outputManager) {

        _outputManager = outputManager;
    }


    public OutputManager getOutputManager() {
        return _outputManager;
    }

    protected boolean checkJobStatus(OutputJobDAO dao, int jobId) {

        int status = dao.fetchJobStatus(jobId);

        return ((status == RequestStatus.PAUSING.statusCode())
        || (status == RequestStatus.CANCELING.statusCode())) ? true : false;
    }

    protected OutputJobDAO getOutputJobDAO() {

        return (OutputJobDAO) SpringUtilities
                    .getInstance()
                        .getBeanFactory()
                            .getBean(DAOName.Output_JOB_DAO.toString());
    }
}
