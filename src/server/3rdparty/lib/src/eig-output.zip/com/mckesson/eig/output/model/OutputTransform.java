/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.builder.HashCodeBuilder;
import org.springframework.util.ObjectUtils;

import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.utility.util.CollectionUtilities;

/**
 * <code>OutputTransform</code>'s represent some operation that should be performed on an
 * OutputJob or RequestPart after the source content has been retrieved and prior to the
 * OutputJob being routed to it's destination
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "outputTransform")
@XmlType(name = "outputTransform")
public class OutputTransform implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 25;
	private static final int HASH_INIT = 5;
    private String _transformType;

    private String _transformName;
    private Map<String, String> _properties;

    //added for cxf migration
    private List<MapModel> _propertyList;

    /**
     *
     */
    public OutputTransform() {
        super();
    }

    /**
     * The type of transform to perform on the content. This member identifies which code should
     * handle the transformation.
     *
     * @return may be <code>null</code>
     */
    public String getTransformType() {
        return _transformType;
    }

    /**
     * @param transformType
     */
    @XmlElement (name = "transformType")
    public void setTransformType(String transformType) {
        _transformType = transformType;
    }

    /**
     * The name of transform to perform on the content.
     *
     * @return may be <code>null</code>
     */
    public String getTransformName() {
        return _transformName;
    }

    /**
     * @param transformName
     */
    @XmlElement (name = "transformName")
    public void setTransformName(String transformName) {
        _transformName = transformName;
    }


    /**
     * The properties member represents option settings which are specific to the type of transform
     * being done and provide specific instructions for the instance.
     *
     * @return may be <code>null</code>
     */
    public Map<String, String> getProperties() {

        if (CollectionUtilities.hasContent(_properties)) {
            return _properties;
        }
        
        if (CollectionUtilities.hasContent(_propertyList)) {

            Map<String, String> prop = new HashMap<String, String>();
            for (MapModel mapModel : _propertyList) {
                prop.put(mapModel.getKey().toString(), mapModel.getValue().toString());
            }
            setProperties(prop);
        }
        return _properties;
    }

    /**
     * @param properties
     */
    @XmlTransient
    public void setProperties(Map<String, String> properties) {

        if (properties != null) {

            if (CollectionUtilities.hasContent(_propertyList)) {
                _propertyList.clear();
            } else {
                _propertyList = new ArrayList<MapModel>();
            }

            for (Map.Entry<String, ? extends Object> e : properties.entrySet()) {
                _propertyList.add(new MapModel(e.getKey(), e.getValue()));
            }
            _properties = properties;
        }
    }

    @XmlElementWrapper (name = "properties")
    @XmlElement(name = "property", type = MapModel.class)
    public void setPropertiesList(List<MapModel> properties) {
        _propertyList = properties;
    }

    public List<MapModel> getPropertiesList() {
        
        if (_properties != null) {
            _propertyList = new ArrayList<MapModel>();
            for (Map.Entry<String, ? extends Object> e : _properties.entrySet()) {
                _propertyList.add(new MapModel(e.getKey(), e.getValue()));
            }
        }
        return _propertyList;
    }
    
    @Override
    public boolean equals(Object o) {

        OutputTransform t = (OutputTransform) o;
        if (!ObjectUtils.nullSafeEquals(t._transformType, _transformType)) {
            return false;
        }
        if (!ObjectUtils.nullSafeEquals(t._transformName, _transformName)) {
            return false;
        }
        if (!ObjectUtils.nullSafeEquals(t._properties, _properties)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {

        HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
        builder.append(_transformType);
        builder.append(_transformName);
        builder.append(_properties);

        return builder.toHashCode();
    }
}
