/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.roi;


/**
 * @author OFS
 * @date   Feb 3, 2009
 * @since  HPF 13.1; Feb 3, 2009
 */
public class ROIContent {

	private String _fileIds;
	private String _userName;
	private String _password;
	private String _contentType;

    public String getFileIds() { return _fileIds; }
    public void setFileIds(String fileIds) { _fileIds = fileIds; }

    public String getUserName() { return _userName; }
    public void setUserName(String name) { _userName = name; }

    public String getPassword() { return _password; }
    public void setPassword(String password) { _password = password; }

    public String getContentType() { return _contentType; }
    public void setContentType(String contentType) {
    	if (contentType == null) {
    		_contentType = "";
    	} else {
    		_contentType = contentType; 
    	}
    }

}
