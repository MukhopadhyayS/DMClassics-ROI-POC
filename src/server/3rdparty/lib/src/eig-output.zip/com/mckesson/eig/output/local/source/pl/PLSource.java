/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.pl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.io.FileUtils;

import com.mckesson.eig.output.local.source.Source;
import com.mckesson.eig.output.local.source.SourceListener;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.FileUtilities;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.StringUtilities;


public class PLSource extends Source {

	private static final Log LOG = LogFactory.getLogger(PLSource.class);

	//private PLRequest _request = new PLRequest();


	public PLSource() {
		super();
	}


	protected void processPart(JobPart part) throws Exception {
		if (part != null) {
			Map<String, String> props = part.getProperties();
			if (requiresAttachment(props)) {
				File destinationDir = new File(part.getCurrentLocation());
				File sourceFile =
				    new File(props.get(OutputConstants.MESSAGE_ATTACHMENT));
				FileUtils.copyFileToDirectory(sourceFile, destinationDir, true);
				String tmp = props.get(OutputConstants.MESSAGE_ATTACHMENT);
				StringTokenizer token = new StringTokenizer(tmp, ""
						+ File.separatorChar);
				String tmpStr, fileName = null;
				while (token.hasMoreTokens()) {
					tmpStr = token.nextToken();
					if (tmpStr.contains(".pdf")) {
						fileName = tmpStr;
					}
				}

				if (fileName != null) {
					part.addSource(fileName);
				} else {
					LOG.info("Failed to add file to source: ");
				}
			} // End if requiresAttachment()
			LOG.info("PL Source Processing part: " + part.getPartID());
		}
	}

	protected void processPart(OutputJob job, JobPart part,
			FileUtilities f, SourceListener listener) throws Exception {
		if (part != null) {
			Map<String, String> props = part.getProperties();
			if (requiresAttachment(props)) {
				File sourceFile =
				    new File(props.get(OutputConstants.MESSAGE_ATTACHMENT));
				File destinationFile = f.getFile();
				FileUtils.copyFile(sourceFile, destinationFile, true);
				saveSourceFile(destinationFile, job, part, listener);
			}
		}
	}

	private boolean requiresAttachment(Map<String, String> props) throws Exception {
		String attachment 	= props.get(OutputConstants.MESSAGE_ATTACHMENT);
		String body			= props.get(OutputConstants.MESSAGE_BODY);
		String emailTo		= props.get(OutputConstants.MESSAGE_TO);

		if (!StringUtilities.isEmpty(emailTo) && !StringUtilities.isEmpty(body)) {
		    return false;
		}
		return true;
	}
}
