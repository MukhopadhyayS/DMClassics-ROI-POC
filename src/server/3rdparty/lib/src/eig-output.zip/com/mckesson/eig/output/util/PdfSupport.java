/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

/**
 * Miscellaneous utilities for pdfs.
 *
 * @author Latonia Howard
 *
 */

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;

import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfDictionary;
import com.lowagie.text.pdf.PdfName;
import com.lowagie.text.pdf.PdfNumber;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;


public final class PdfSupport {
    private static final int    ROTATION_90  = 90;

    private PdfSupport() {

    }

    public static int getPageCount(String baseDirectory, Collection<String> fileNames) {
        int pageCount = 0;
        String currFileName = "";

        try {
            for (String fileName : fileNames) {
                currFileName = baseDirectory
                + File.separatorChar
                + fileName;

                PdfReader pdfReader = new PdfReader(currFileName);
                
                pageCount += pdfReader.getNumberOfPages();
                pdfReader.close();
            }
        } catch (Exception e) {
            throw new OutputException("Error finding page count for: " + currFileName,
                                      OutputConstants.OutputErrorCode.RUNTIME_ERROR);
        }
        return pageCount;
    }

    public static int getPageCount(String fileName) {
        int pageCount = 0;

        try {
            PdfReader pdfReader = new PdfReader(fileName);

            pageCount += pdfReader.getNumberOfPages();
            pdfReader.close();
        } catch (Exception e) {
            throw new OutputException();
        }
        return pageCount;
    }

    public static int getPartStartPage(OutputJob job, JobPart part) {
        int pageStart = 0;
        // TODO - :  assumption: part is a valid part and will be found

        for (JobPart tmpPart : job.getParts()) {
            if (tmpPart != part) {
                pageStart += tmpPart.getPages();
            } else {
                //return current value
                return pageStart;
            }
        }

        return pageStart;

    }

    /* List of filenames contain absolute filepath */
    public static int getPageCount(Collection<String> fileNames) {
        int pageCount = 0;
        String currFileName = null;

        try {
            for (String fileName : fileNames) {
                currFileName = fileName;
                PdfReader pdfReader = new PdfReader(fileName);

                pageCount += pdfReader.getNumberOfPages();
                pdfReader.close();
            }
        } catch (Exception e) {
            throw new OutputException("Error finding page count for: " + currFileName,
                                      OutputConstants.OutputErrorCode.RUNTIME_ERROR);
        }
        return pageCount;
    }

    public static void rotatePage(String baseDirectory,
                                  Collection<String> fileNames) {
        //rotates pages and overwrites original file
        try {
            Iterator <String> iter =  fileNames.iterator();
            while (iter.hasNext()) {
                PdfDictionary pageDict;
                int rotation;
                String currFileName = baseDirectory
                                        + File.separatorChar
                                        + iter.next();
                PdfReader reader = new PdfReader(currFileName);
                int n = reader.getNumberOfPages();
                for (int i = 1; i <= n; i++) {
                    rotation = reader.getPageRotation(i);
                    pageDict = reader.getPageN(i);
                    pageDict.put(PdfName.ROTATE, new PdfNumber(rotation + ROTATION_90));
                }
                PdfStamper stamper = new PdfStamper(reader, new
                                                    FileOutputStream(currFileName + "rotated"));
                stamper.close();
                FileUtils.deleteQuietly(new File(currFileName));
                FileUtils.moveFile(new File(currFileName + "rotated"), new File(currFileName));

            }
        } catch (IOException e) {
            throw new OutputException(e.toString(), OutputConstants.OutputErrorCode.RUNTIME_ERROR);
        } catch (DocumentException e) {
            throw new OutputException(e.toString(), OutputConstants.OutputErrorCode.RUNTIME_ERROR);
        } catch (Exception e) {
            throw new OutputException(e.toString(), OutputConstants.OutputErrorCode.RUNTIME_ERROR);
        }
    }

    public static long getFileSize(String fileName) {

        if (!StringUtils.isNotEmpty(fileName)) {
            throw new IllegalArgumentException("file name is empty");
        }
        File currFile = new File(fileName);
        if (!currFile.exists()) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR);
        }

        return currFile.length();
    }    
    
}
