/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.security.authorization;

import java.util.List;
import java.util.Map;

import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * @author Pranav Amarasekaran
 * @date   Jun 24, 2009
 * @since  Output 1.0; Jun 24, 2009
 */
public class OutputACL {

    private static final Log LOG = LogFactory.getLogger(OutputACL.class);
    private static final boolean DO_DEBUG = LOG.isDebugEnabled();

    private boolean _restrictDestination;
    private String _actorId;
    private Map<RIGHTS, Boolean> _outputRights;
    private List<Long> _allowedDestinations;

    public static final String OUTPUT_ACL_KEY = "output.acl";
    public enum RIGHTS {

        SubmitOutputJob,
        MonitorMyJobs,
        MonitorAllJobs,
        ConfigureOutputSettings;
    }

    public enum OPERATION {

        getDestinations,
        queryOutputJob,
        queryOutputJobs,
        submitOutputRequest,
        getServiceProperties,
        cancelOutputJob,
        resubmitOutputJob,
        submitJob,
        defineSystemDestination,
        getSystemDestinations,
        queryDestinationByNameAndType,
        updateSystemDestination,
        getDestTypeInfo,
        refreshDeviceLabels;
    }

    public Map <RIGHTS, Boolean> getOutputRights() { return _outputRights; }
    public void setOutputRights(Map <RIGHTS, Boolean> rights) { _outputRights = rights; }

    public List <Long> getAllowedDestinations() { return _allowedDestinations; }
    public void setAllowedDestinations(List <Long> destns) { _allowedDestinations = destns; }

    public boolean hasRestrictDestination() { return _restrictDestination; }
    public void setRestrictDestination(boolean destination) { _restrictDestination = destination; }

    public String getActorId() { return _actorId; }
    public void setActorId(String id) { _actorId = id; }

    /**
     * This method will check if the user has access rights to current operation
     *
     * @param operation
     * @param params
     * @return true/false
     */
    protected boolean checkAccessRights(String operation, List < ? > params) {

        final String logSM = "checkAccessRights(operation, params)";
        if (DO_DEBUG) {
            LOG.debug(logSM + ">>Start:");
        }

        boolean isAuthorized = false;

        try {

            switch (OPERATION.valueOf(operation)) {

            	case refreshDeviceLabels:
                case getDestinations:
                    isAuthorized = true;
                    break;

                case submitOutputRequest:
                case submitJob:
                    if (hasRequiredRight(RIGHTS.SubmitOutputJob)
                        && !hasRestrictDestination()) {

                        isAuthorized = checkAllowedDestinations(params);
                    }
                    break;

                default :
                	isAuthorized = checkOtherRights(operation);
                    break;
            }

        } catch (Throwable e) {
            if (DO_DEBUG) {
               LOG.debug(logSM + e.getMessage());
           }
        }
        if (DO_DEBUG) {
            LOG.debug(logSM + "<<End: HasRights == " + isAuthorized);
        }
        return isAuthorized;
    }

    private boolean checkOtherRights(String operation) {
    	
    	boolean isAuthorized = false;

    	switch (OPERATION.valueOf(operation)) {
    	
	        case cancelOutputJob:
	            isAuthorized = hasRequiredRight(RIGHTS.MonitorAllJobs);
	            if (!isAuthorized) {
	                isAuthorized = hasRequiredRight(RIGHTS.MonitorMyJobs);
	            }
	            break;
		    case resubmitOutputJob:
		        isAuthorized = hasRequiredRight(RIGHTS.MonitorAllJobs);
		        if (!isAuthorized) {
		            isAuthorized = hasRequiredRight(RIGHTS.MonitorMyJobs);
		        }
		        break;
		
		    case getServiceProperties:
		    case defineSystemDestination:
		    case getSystemDestinations:
		    case getDestTypeInfo:
		    case queryDestinationByNameAndType:
		    case updateSystemDestination:
		    case queryOutputJobs:
		        isAuthorized = hasRequiredRight(RIGHTS.ConfigureOutputSettings);
		        break;
		
		    case queryOutputJob:
		        isAuthorized = hasRequiredRight(RIGHTS.MonitorAllJobs);
		        if (!isAuthorized) {
		            isAuthorized = hasRequiredRight(RIGHTS.MonitorMyJobs);
		        }
		        break;
		        
		    default :
		    	break;
    	}

    	return isAuthorized;
	}
	/**
     * This method will check in DB whether the Actor is allowed  to access destinations
     * @param params
     * @return
     */
    private boolean checkAllowedDestinations(List < ? > params) {
      //TODO get parameter values and validate
      return true;
    }

    /**
     * This method checks if operation name has required right
     * @param requiredRight
     * @return
     */
    public boolean hasRequiredRight(RIGHTS right) {

        try {
            return getOutputRights().get(right);
        } catch (Throwable e) {
          return false;
        }
    }
}
