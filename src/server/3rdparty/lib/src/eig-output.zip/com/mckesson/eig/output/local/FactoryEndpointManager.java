/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local;

import java.util.Collection;
import java.util.Map;

import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * EndpointManager which uses an EndpointTypeHandlerFactory to create
 * EndpointTypeHandlers and provides noop methods for the activation methods.
 *
 * @author Jon Anderson
 */
public class FactoryEndpointManager extends AbstractEndpointManager {

    @SuppressWarnings("unused")
	private static final Log LOG = LogFactory.getLogger(
            FactoryEndpointManager.class);
    private EndpointTypeHandlerFactory _typeHandlerFactory;

    /**
     * Creates using createDefaultTypeHandlerFactory. Not public because
     * a valid DAO has not been set yet and loadActiveEndpointTypes needs to
     * be called and we do not know how to construct and types yet.
     */
    protected FactoryEndpointManager() {
        super();
        setTypeHandlerFactory(createDefaultTypeHandlerFactory());
    }

    /**
     * Creates with the typeHandlerFactory specified. Not public because
     * a valid DAO has not been set yet and loadActiveEndpointTypes needs to
     * be called.
     *
     * @param typeHandlerFactory not <code>null</code>
     */
    protected FactoryEndpointManager(
            EndpointTypeHandlerFactory typeHandlerFactory) {
        super();
        setTypeHandlerFactory(typeHandlerFactory);
    }

    /**
     * Creates with the typeHandlerFactory and DAO specified
     *
     * @param endpointDAO not <code>null</code>s
     * @param typeHandlerFactory not <code>null</code>
     */
    public FactoryEndpointManager(
            EndpointDAO endpointDAO,
            EndpointTypeHandlerFactory typeHandlerFactory) {

        super(endpointDAO);
        setTypeHandlerFactory(typeHandlerFactory);
        loadActiveEndpointTypes();
    }

    /**
     * Creates with a DefaultEndpointTypeFactory, the DAO specified, and the
     * mappings specified for the factory
     *
     * @param endpointDAO not <code>null</code>s
     * @param handlerMap not <code>null</code>
     */
    public FactoryEndpointManager(
            EndpointDAO endpointDAO,
            Map<String, EndpointTypeHandler> handlerMap) {

        super(endpointDAO);
        setTypeHandlerFactory(createDefaultTypeHandlerFactory());
        setHandlerMappings(handlerMap);
        loadActiveEndpointTypes();
    }

    /**
     * Called in construction to create the default EndpointTypeHandlerFactory
     * where one is not passed in to the constructor
     *
     * @return not <code>null</code>
     */
    protected EndpointTypeHandlerFactory createDefaultTypeHandlerFactory() {
        return new DefaultTypeHandlerFactory();
    }

    /**
     * @see AbstractEndpointManager#activateEndpoint(ActiveEndpoint)
     */
    @Override
    protected void activateEndpoint(ActiveEndpoint activeEndpoint) {
        // noop
    }

    /**
     * @see AbstractEndpointManager#deactivateEndpoint(ActiveEndpoint)
     */
    @Override
    protected void deactivateEndpoint(ActiveEndpoint activeEndpoint) {
        // noop
    }

    /**
     * @see AbstractEndpointManager#pauseActiveEndpoint(ActiveEndpoint)
     */
    @Override
    protected void pauseActiveEndpoint(ActiveEndpoint activeEndpoint) {
        // noop
    }

    /**
     * @see AbstractEndpointManager#restartActiveEndpoint(ActiveEndpoint)
     */
    @Override
    protected void restartActiveEndpoint(ActiveEndpoint activeEndpoint) {
        // noop
    }


    /**
     * Returns my EndpointTypeHandlerFactory
     *
     * @return not <code>null</code>
     */
    public EndpointTypeHandlerFactory getTypeHandlerFactory() {
        return _typeHandlerFactory;
    }

    /**
     * Sets the EndpointTypeHandlerFactory to use. Cannot be set once
     * ActiveEndpointTypes have been added.
     *
     * @param typeHandlerFactory not <code>null</code>
     */
    public void setTypeHandlerFactory(
            EndpointTypeHandlerFactory typeHandlerFactory) {

        if (typeHandlerFactory == null) {
            throw new IllegalArgumentException("typeHandlerFactory is null");
        }
        if (getActiveEndpointTypeCount() > 0) {
            throw new OutputException(
                    "cannot reset factory if types have been added",
                    OutputErrorCode.CONSISTENCY_ERROR);
        }

        _typeHandlerFactory = typeHandlerFactory;
    }

    /**
     * Returns the set of mappings defined for the factory if it is a
     * <code>DefaultTypeHandlerFactory</code>
     *
     * @return maybe <code>null</code> if the factory is not a
     * <code>DefaultTypeHandlerFactory</code>
     */
    public Map<String, EndpointTypeHandler> getHandlerMappings() {

        if (_typeHandlerFactory instanceof DefaultTypeHandlerFactory) {

            DefaultTypeHandlerFactory simpleFactory =
                (DefaultTypeHandlerFactory) _typeHandlerFactory;

            return simpleFactory.getHandlerMappings();

        }

        return null;
    }

    /**
     * Sets the set of mappings defined for this factory if the factory is a
     * <code>DefaultTypeHandlerFactory</code>
     *
     * @param handlerMappings may be <code>null</code>
     */
    public void setHandlerMappings(
            Map<String, EndpointTypeHandler> handlerMappings) {


        if (_typeHandlerFactory instanceof DefaultTypeHandlerFactory) {

            if (getActiveEndpointTypeCount() > 0) {
                throw new OutputException(
                        "cannot reset mappings if types have been added",
                        OutputErrorCode.CONSISTENCY_ERROR);
            }

            DefaultTypeHandlerFactory simpleFactory =
                (DefaultTypeHandlerFactory) _typeHandlerFactory;

            simpleFactory.setHandlerMappings(handlerMappings);

        } else {
            throw new IllegalArgumentException(
                    "handlerMappings cannot be set because factory is not "
                    + "a DefaultTypeHandlerFactory");
        }
    }

    /**
     * Uses the factory to create an EndpointTypeHandler
     *
     * @param typeName name of the type for which to create the handler
     * @return not <code>null</code>
     */
    public EndpointTypeDef createDefaultEndpointTypeDef(String typeName) {
        return _typeHandlerFactory.createDefaultTypeDef(typeName);
    }

    /**
     * Uses the factory to create an EndpointTypeHandler
     *
     * @param endpointTypeDef metadata for the handler to create
     * @return not <code>null</code>
     */
    @Override
    protected EndpointTypeHandler createEndpointTypeHandler(
            EndpointTypeDef endpointTypeDef) {
        return _typeHandlerFactory.createEndpointTypeHandler(endpointTypeDef);
    }

    /**
     * Delegates to the typeHandlerFactory's getSupportedTypes method
     *
     * @return not <code>null</code>
     */
    public Collection<String> getSupportedEndpointTypes() {
        return _typeHandlerFactory.getSupportedTypes();
    }

}
