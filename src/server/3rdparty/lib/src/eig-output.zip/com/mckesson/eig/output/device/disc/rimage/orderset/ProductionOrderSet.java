/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage.orderset;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ProductionOrderSet")
public class ProductionOrderSet {

    private Integer numberOfCopies;
    private Boolean ordersHaveLabels;
    private String mediaType;
    private String mediaSize;

    public Integer getNumberOfCopies() {
        return numberOfCopies;
    }

    @XmlAttribute(name = "Copies")
    public void setNumberOfCopies(Integer numberOfCopies) {
        this.numberOfCopies = numberOfCopies;
    }

    public Boolean getOrdersHaveLabels() {
        return ordersHaveLabels;
    }

    @XmlAttribute(name = "OrdersHaveLabels")
    public void setOrdersHaveLabels(Boolean ordersHaveLabels) {
        this.ordersHaveLabels = ordersHaveLabels;
    }

    public String getMediaType() {
        return mediaType;
    }

    @XmlAttribute(name = "MediaType")
    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }
    public String getMediaSize() {
        return mediaSize;
    }

    @XmlAttribute(name = "MediaSize")
    public void setMediaSize(String mediaSize) {
        this.mediaSize = mediaSize;
    }

}
