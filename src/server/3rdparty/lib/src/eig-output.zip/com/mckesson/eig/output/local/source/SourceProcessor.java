package com.mckesson.eig.output.local.source;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.MDC;

import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.LocationStrategy;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.transformers.PdfPageSeparator;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.util.FileUtilities;
import com.mckesson.eig.output.util.OutputConstants.OutputTransforms;
import com.mckesson.eig.output.util.OutputConstants.SourceType;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class SourceProcessor {
	private static final Log LOG = LogFactory.getLogger(SourceProcessor.class);
	private static final String SOURCE_DESTINATION = "SOURCE";
	private static final String JOB_ID = "JOBID";

	private SourceController _srcController;
    private LocationStrategy _strategy;


	public SourceProcessor(DefaultTypeHandlerFactory factory,
			OutputManager outputManager, EndpointDAO dao) {
		_srcController = new SourceController(factory, outputManager, dao);
		_strategy = outputManager.getLocationStrategy();
	}


	public void process(OutputJob job) throws Exception {
		process(job, new DefaultSourceListener());
	}

	public void process(OutputJob job, SourceListener listener) throws Exception {
		MDC.put(JOB_ID, Integer.toString(job.getJobSeq()));
		job.logMetric("Start Retrieving content");
		mapTotalPagesToJob(job);
		job.setPages(0);
		if (listener != null) {
			listener.start(job);
		}
		_strategy.setJobLocations(job);
		String location = job.getCurrentLocation()
			+ File.separator + SOURCE_DESTINATION;
		FileUtilities f = new FileUtilities(location);
		processPageSeparator(job, f, listener);
        for (JobPart part : job.getParts()) {
        	processPartSeparator(job, part, f, listener);
        	String sourceName = part.getContentSourceName();
        	_srcController.process(sourceName, job, part, f, listener);
        }
        job.setCurrentLocation(location);
		if (listener != null) {
			listener.finish(job);
		}
		job.logMetric("Finish Retrieving content");
		MDC.put(JOB_ID, Integer.toString(-1));
	}

	private void processPartSeparator(OutputJob job, JobPart part,
			FileUtilities f, SourceListener listener) {
		OutputTransform tranform = OutputUtil.lookupPartTransform(part,
				OutputTransforms.PAGE_SEPARATOR.toString());
		processPageSeparator(job, tranform, f, listener);
	}

	private void processPageSeparator(OutputJob job, FileUtilities f,
			SourceListener listener) {
		OutputTransform tranform = OutputUtil.lookupJobTransform(job,
				OutputTransforms.PAGE_SEPARATOR.toString());
		processPageSeparator(job, tranform, f, listener);
	}

	private void processPageSeparator(OutputJob job, OutputTransform tranform,
			FileUtilities f, SourceListener listener) {
		if (tranform != null) {
            PdfPageSeparator pdfPageSeparator = new PdfPageSeparator();

            StringBuilder pageSeparator = new StringBuilder();
            if (job.getSubmitInfo() == null) {
                throw new IllegalArgumentException("job submitter info argument is null");
            }
            if (StringUtils.isNotEmpty(job.getSubmitInfo().getSubmitterData())) {
                pageSeparator.append(job.getSubmitInfo().getSubmitterData());
            }

            //TODO - Modify to Support Local format
            SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy  HH:mm:ss");

            pageSeparator.append("      " + job.getDestName());
            pageSeparator.append("      " + dateFormatter.format(Calendar.getInstance().getTime()));
            byte[] content = pdfPageSeparator.createPageSeperator(pageSeparator.toString());
            String fileName = f.writeFile(content);
            if (listener != null) {
                listener.addFile(job, fileName);
            }
		}
	}

	private void mapTotalPagesToJob(OutputJob job) {
		int totalPage = 0;
		for (JobPart part : job.getParts()) {
			String contentSrc = part.getContentSourceName();
			if (contentSrc.equals(SourceType.HPF.toString())) {
				int page = getPageNumber(part.getProperties());
				part.setTotalPages(page);
				totalPage += page;
			}
		}
		job.setTotalPages(totalPage);
	}

	private int getPageNumber(Map<String, String> properties) {
		int result = 0;
		if (properties != null) {
			String pageNumber = properties.get("i");
			if (pageNumber != null) {
				String[] pgs = pageNumber.split(",");
				return pgs.length;
			}
		}
		return result;
	}

}
