/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Constants and enums used throughout the output code.
 *
 * @author Jon Anderson
 */
public final class OutputConstants {

    public static final String OCTET_STREAM = "application/octet-stream";
    public static final String TEXT_PLAIN = "text/plain";
    public static final String TEXT_XML = "text/xml";
    public static final String TEXT_HTML = "text/html";
    public static final String TIFF = "image/tiff";
    public static final String JPEG = "image/jpeg";
    public static final String GIF = "image/gif";
    public static final String PNG = "image/png";
    public static final String BMP = "image/bmp";
    public static final String PDF = "application/pdf";
    public static final String IMNET_ASCII = "application/imnet-ascii";


	public static final String MESSAGE_TO 			= "to";
	public static final String MESSAGE_CC 			= "Cc";
	public static final String MESSAGE_BCC 			= "Bcc";

	public static final String MESSAGE_FROM  		= "from";
	public static final String MESSAGE_FAXNO		= "faxNo";
	public static final String MESSAGE_SMTP_HOST	= "smtphost";
	public static final String MESSAGE_SMTP_PORT	= "smtpport";
	public static final String MESSAGE_BODY			= "content";
	public static final String MESSAGE_MIMETYPE 	= "mimetype";
	public static final String MESSAGE_SUBJECT		= "subject";
	public static final String MESSAGE_ATTACHMENT	= "filePath";
	
	//Secret Key for AES
    public static final String AES_SECRET_KEY = "OUTPUT_AES_KEY";
  //Secret Vector for AES
    public static final String AES_SECRET_IV = "OUTPUT_AES_KEY";
    

	/** TODO */
	public static final String[] ANY_CONTENT_TYPE = new String[0];

    /**
     * Set of codes which describe the current run state of the OutputService
     */
	public static enum RunState {
		/** the service is initializing */
		INIT ("Initializing", 100),
        /** the service is running */
		RUN ("Running", 101),
        /** the service has been paused */
		PAUSE ("Paused", 102),
        /** the service has been shutdown */
		STOP ("Stopped", -100);

        private final String _statusString;
        private final int _statusCode;

        RunState(String statusString, int statusCode) {
            _statusString = statusString;
            _statusCode = statusCode;
        }

        /**
         * The descriptive string for the status
         *
         * @return not <code>null</code>
         */
        public String statusString() {
            return _statusString;
        }

        /**
         * The code value for the status
         *
         * @return the code
         */
        public int statusCode() {
            return _statusCode;
        }
	}

	/**
	 * Set of codes which describe an output request's current status.
	 * 
	 * TODO:  UPDATE the requestProcessing method if you add a non processing state
	 */
	public static enum RequestStatus {

		/** The output request is ready */
		READY("ready", 199),
		/** The output request is being processed */
		PROCESSING("processing", 200),
        /** The output request  has been canceled */
        CANCELED("canceled", 201),
       /** The output request has been paused */
		PAUSED("paused", 202),
        /** The output request has been sent to it's final destination */
		SENT("sent", 203),
        /** The output request has been completed */
		COMPLETED("completed", 204),
        /** The output request is being canceled */
        CANCELING("canceling", 205),
        /** The output request is being paused */
        PAUSING("pausing", 206),
        /** The output request is resuming processing */
        RESUMING("resuming", 207),
        /** The output request has been puased because destination is paused */
        DEST_PAUSED("resuming", 208),
        /** The output request has errored */
		ERROR("error", -200),
		/** The output request has been purged */
		PURGED("purged", 209),
		PURGED_ERR("purgedErr", 210),
		PRINTING("printing", 211),
		FAXING("faxing", 212),
		EMAILING("emailing", 213),
		/** The output request is sending image creation request */
		DISC_PREPARING_READY("disc preparing ready", 214),
		/** The output request is waiting for the image creation request to be complete */
		DISC_PREPARING_PROCESSING("disc preparing processing", 215),
		/** The output request is sending request for disc burning */
		DISC_BURNING_READY("disc burning ready", 216),
		/** The output request is waiting for the disc burning to be complete */
		DISC_BURNING_PROCESSING("disc burning processing", 217),
		/** The output request content is being retrieved and pdf(s) created */
		FILE_PREPARING("file preparing", 218);
		

		private final String _statusString;
		private final int _statusCode;

		RequestStatus(String statusString, int statusCode) {
			_statusString = statusString;
			_statusCode = statusCode;
		}

		@Override
		public String toString()  {
			return _statusString;
		}

		/**
		 * The descriptive string for the status
		 *
		 * @return not <code>null</code>
		 */
		public String statusString() {
			return _statusString;
		}

		/**
		 * The code value for the status
		 *
		 * @return the code
		 */
		public int statusCode() {
			return _statusCode;
		}
		
		public static boolean isRequestInProcessingState(int statusCode) {
			boolean processing = true;
			
			if (statusCode ==  201 //Canceled
				|| statusCode == 205 //canceling
				|| statusCode == -200 //Error
				|| statusCode == 209 //Purged
				|| statusCode == 210 //Purged Error
				|| statusCode == 204 //Completed
				) {
					processing = false;
			}
			return processing;
		}
	}

	
	public static enum JobDetailStatus {
		/** Overall Status codes for job*/
		OK("OK", 700),
		INFO("INFO", 701),
		ERROR("ERROR", 702);
		
		private final String _statusString;
		private final int _statusCode;

		JobDetailStatus(String statusString, int statusCode) {
			_statusString = statusString;
			_statusCode = statusCode;
		}

		/**
		 * @return the string
		 */
		public String statusString() {
			return _statusString;
		}

		/**
		 * @return the code
		 */
		public int statusCode() {
			return _statusCode;
		}
		
	}
	
	/** Status codes for Destinations and Devices */
	public static enum EndpointStatus {

		/** the endpoint is processing */
		OK("Active", 300),
		/** the endpoint has been paused, either explicitly or through
		 * a system pause */
		PAUSED("Paused", 301),
		/** the endpoint has been stopped or shutdown */
		STOPPED("Stopped", 302),
		/** an error has occurred but may be recoverable */
		ERR_RECOVERABLE("System is attempting to recover", -301),
        /** an error has occurred and the system does not know what to do */
		ERR_UNKNOWN("Unknown State", -302),
        /** an error has occurred and can be recovered from with
         * user intervention */
		ERR_HELP("User Intervention Required", -303);

		private final String _statusString;
		private final int _statusCode;

		EndpointStatus(String statusString, int statusCode) {
			_statusString = statusString;
			_statusCode = statusCode;
		}

		/**
		 * @return the string
		 */
		public String statusString() {
			return _statusString;
		}

		/**
		 * TODO
		 * @return the code
		 */
		public int statusCode() {
			return _statusCode;
		}
	}

	/**  Defines data types for property values */
	public static enum PropertyType {
		/** String type */
		STRING(String.class),
		/** Number type */
		NUMBER(Number.class),
		/** boolean type */
		BOOLEAN(Boolean.class),
		/** collection type */
		COLLECTION(Collection.class);

		private final Class< ? > _typeClass;

		PropertyType(Class< ? > c) {
			_typeClass = c;
		}

		/**
		 * @return the class for this type
		 */
		public Class< ? > typeClass() {
			return _typeClass;
		}
	}

	/** Defines available PDF Transformers and order of route */
	public static enum OutputTransforms {
        WATERMARK,
        HEADER_FOOTER,
		PAGE_SEPARATOR
	}

	/**
	 * Defines the categories of endpoints that OutputManager deals with
	 * Endpoints are nodes within the OutputManager's routing scheme, and it's
	 * type defines where it will get processed.
	 */
	public static enum EndpointCategory {
		/** Source for Content */
		SOURCE,
		/** Transform at the part level */
		PART_TRANSFORM,
		/** Transform at the job level */
		JOB_TRANSFORM,
		/** Destination for output */
		DESTINATION,
		/** Destination device for ouptut */
		DESTINATION_DEVICE
	}

	/**
	 * General error codes for Output related errors
	 */
	public static enum OutputErrorCode {

		/** An attempt was made to define an object that is already defined */
		NAME_ALREADY_DEFINED,
		/** An object definition references another object that does not
		 * exist or cannot be used */
		REFERENCE_INVALID,
		/** An attempt to perform the requested operation could cause system
		 * integrity problems */
		CONSISTENCY_ERROR,
		/** Expected data in some definition is not found */
		MISSING_DATA,
		/** Type of data passed is invalid */
		INVALID_DATA,
		/** A critical error has occurred during processing and the system
		 * probably does not know how to recover */
		RUNTIME_ERROR,
        /** An operation was attempted that cannot be performed with the
         * object in it's current state */
		STATE_ERROR,
		/** TODO */
		GENERAL_APP_ERROR,
		/** An error occurring during creating an entity in persistence */
		PERSISTENCE_CREATE_ERROR,
		/** An error occurring when merge operation is performed on an
		 * entity in persistence */
		PERSISTENCE_MERGE_ERROR,
		/** An error occurring when delete operation is performed on an
		 * entity in persistence */
		PERSISTENCE_DETETE_ERROR,
		/** An error occurring in the hibernate layer when multiple requests
		 * try to modify the same data in the database */
		OPTIMISTIC_LOCKING_COLLISION,
		/** An error occurring when a user having no rights tries to access a
		 * 	particular operation */
		NO_RIGHTS_ERROR,
		/** An error occurring when trying to access an invalid destination id. */
		DESTINATION_INVALID,
		/** An error occurring when trying to access an invalid/disabled sources. */
		SOURCE_INVALID,
		/** An error occurring when any webservice invoked is not available
		 * or returns error */
		SERVICE_ERROR,
		PERSISTENCE_DUPLICATE_DATA,
		XMLMAPPING_ERROR,
		XMLMARSHAL_ERROR,
		XMLUNMARSHAL_ERROR,
		/**
		 * An error occurring when any Save As file location specified in invalid
		 * after creating the queue or removed the access.
		 */
		INVALID_DIRECTORY,
		
		/**
		 * Error code added for the invalid disc Queue
		 */
		INVALID_DISC_DEVICE,
		
		/**
		 * Invalid extension is configured for filtering, the files
		 */
		INVALID_EXTENSION,
		
		DEVICE_ERROR
		
		
	}

	//NAMESPACE Constants
	public static final String NS_PREFIX = "eig";
	public static final String KEY_NS_PREFIX = "com.sun.xml.bind.namespacePrefixMapper";
	public static final String ENCODING_UTF_16 = "UTF-16";

	//CAMEL Constants
    public static final String DEFAULT_URI_PREFIX = "eig:";
    public static final String DEFAULT_ROUTE_TYPE = "part";

	//Output job for Fax
	public static final String OUTPUT_FAX_NUMBER = "ouput.fax.number";

	//HPF Request
    public static final String PATIENT_NAME = "p";
    public static final String MRN = "m";
    public static final String FACILITY = "f";
    public static final String ENCOUNTER = "e";
    public static final String DOCNAME = "d";
    public static final String DOCNAME_SUBTITLE = "ds";
    // CR# 365589
    public static final String DOC_ID = "docId";
    public static final String DOC_DATE_TIME = "ddt";
    public static final String DELIMITER = "~!~";
    public static final String UNDERSCORE="_";
    
    public static final String IMNETS = "i";
    public static final String PAGENUMS = "n";
    
    //Attachment Request
    public static final String ATTACHMENT_EXTENSION = "FILE_EXTS";
    public static final String ATTACHMENT_PDF_FILE_EXT = "pdf";
    public static final String ATTACHMENT_XML_FILE_EXT = "xml";
    public static final String ATTACHMENT_PAGE_COUNT = "pgCnt";

    //Output job PRINT
    public static final String PRINT_NUM_PAGES = "printNumPages";
    public static final String PRINT_PAGE_ORIENTATION = "pageOrientation";
    public static final String PRINT_COLOR = "color";
    public static final String PRINT_RESOLUTION = "printResolution";
    public static final String PRINT_IMG_FORMAT = "printImgFormat";
    public static final String PRINT_NUM_QUEUES = "printNumQueues";
    public static final String PRINT_NUM_WORKERS = "printNumWorkers";

    //Output job JOB Details KEY
    public static final String OUTPUT_JOB_DETAILS = "jobDetails";
    public static final String DEST_NAME = "destName";
    public static final String DEST_TYPE = "destType";

	//Output job for Save As File
	public static final String OUTPUT_FILE_MEDIA = "output.file.media";
	public static final String OUTPUT_FILE_PASSWORD = "output.file.password";
	public static final String OUTPUT_FILE_REQUEST_PASSWORD = "output.file.request.password";
	public static final String OUTPUT_PASSWORD_ENCRYPTED = "output.password.encrypted";
	public static final String OUTPUT_FILE_REQUEST_ID = "output.file.requestId";
	public static final String OUTPUT_FILE_RELEASE_NUM = "ouput.file.releaseNum";
	public static final String OUTPUT_FILE_PREPEND = "output.file.prepend";
	public static final String OUTPUT_FILE_REQUEST_DATE = "output.file.request.date";
    public static final String OUTPUT_FILE_NAME_EXPR = "output.file.name.expr";
    public static final String OUTPUT_ATTACHMENT_NAME_EXPR = "output.attachment.name.expr";
    public static final String OUTPUT_ATTACHMENT_COLLECTION_NAME_EXPR = "output.attachment.collection.name.expr";
    public static final String OUTPUT_JOB_COLLECTION_NAME_EXPR = "output.job.collection.name.expr";
    public static final String OUTPUT_ATTACHMENT_EXT = "FILE_EXTS";
    public static final String OUTPUT_FILE_NAME_VER = "OS_VER";
    public static final String OUTPUT_FILE_NAME_PART = "OS_PART";
    public static final String OUTPUT_DISC_NAME_PART = "OS_DISC";
    public static final String OUTPUT_FILE_GENERATED_FILENAME = "output.file.generated.fileName";
    public static final String FILE_PROPS_DIRECTORY_NAME = "directoryName";
    public static final String OUTPUT_REQUESTOR_GROUPING_KEY = "requestor.grouping.key";
    public static final String REQUESTOR_GROUPING_ENABLED = "requestor.grouping.enabled";
    public static final String INVOICE_TYPE = "overDueInvoice";
    public static final String REQUETOR_LETTER_TYPE = "requestorletter";
    //CR# 353,939 - Queue Configuration
    //Added default value for the CD/DVD size property
    public static final long OUTPUT_DEFAULT_CD_SIZE_MB = 620;
    public static final long OUTPUT_DEFAULT_DVD_SIZE_MB = 4096;
    public static final String OUTPUT_KEY_CD_SIZE_MB = "cdSizeMb";
    public static final String OUTPUT_KEY_DVD_SIZE_MB = "dvdSizeMb";

	//Output job for ROI Header/Footer
	public static final String HEADER_FOOTER_PATIENT_NAME = "hfpn";
	public static final String HEADER_FOOTER_MRN = "hfm";
	public static final String HEADER_FOOTER_ENCOUNTER = "hfe";
	public static final String HEADER_FOOTER_FACILITY = "hff";
	// CR# 354134 - constant added for header footer
	public static final String FOOTER_ENABLED = "fc";
	public static final String HEADER_ENABLED = "hc";
	//pass in these to override system defaults
	//value should be either yes/no
	public static final String OUTPUT_HEADER = "output_header";
	public static final String OUTPUT_FOOTER = "output_footer";

    public static final String HEADER_LEFT = "header_left";
    public static final String HEADER_CENTER = "header_center";
    public static final String HEADER_RIGHT = "header_right";
	public static final String FOOTER_LEFT = "footer_left";
	public static final String FOOTER_CENTER = "footer_center";
	public static final String FOOTER_RIGHT = "footer_right";
	public static final String JOB_TOTAL_PAGES = "job_total_pages";
	public static final String JOB_CURRENT_PAGE_NUM = "job_curr_page_num";
	public static final String PART_TOTAL_PAGES = "part_total_pages";
	public static final String PART_CURRENT_PAGE_NUM = "part_curr_page_num";
	
	public static final String OUTPUT_DISC_PASSWORD = "output.disc.q.password";
	public static final String OUTPUT_DISC_MEDIA = "output.disc.media";
	public static final String OUTPUT_DISC_LABEL_NAME = "disc.label.template.name";


	private OutputConstants() {
		super();
	}

	// Job Configuration
	public static final String KEY_SAVE_COMPLETED_JOBS_IN_HRS = "SaveCompletedJobsInHrs";
	public static final String KEY_SYSTEM_RETRY_ATTEMPTS_IN_SEC = "SystemRetryAttemptsInSec";
	public static final String KEY_DISPLAY_WATERMARK = "DisplayWatermark";
	public static final String KEY_WATERMARK_TEXT = "WaterMarkText";
	public static final String KEY_DISPLAY_HEADER = "DisplayHeader";
	public static final String KEY_DISPLAY_FOOTER = "DisplayFooter";
	public static final String KEY_DISPLAY_ABSOLUTE_PAGE_NO = "DisplayAbsolutePageNumber";
	public static final String KEY_ABSOLUTE_PAGE_NO_LOC = "AbsolutePageNumberLocation";
	public static final String KEY_DISPLAY_REL_PAGE_NO = "DisplayRelativePageNumber";
	public static final String KEY_REL_PAGE_NO_LOC = "RelativePageNumberLocation";
	public static final String KEY_DISPLAY_PATIENT_NAME = "DisplayPatientName";
	public static final String KEY_DISPLAY_PATIENT_NAME_LOC = "PatientNameLocation";
	public static final String KEY_DISPLAY_ENCOUNTER = "DisplayEncounter";
	public static final String KEY_ENCOUNTER_LOC = "EncounterLocation";
	public static final String KEY_DISPLAY_MRN = "DisplayMRN";
	public static final String KEY_MRN_LOC = "MRNLocation";
	public static final String KEY_MRN_MASKING = "MRNMasking";

	public static final String KEY_WHERE = "output.queue.where";
	public static final String KEY_COMMENT = "output.queue.comment";
	public static final String KEY_COPIES = "Copies";
	public static final String KEY_COLLATE = "Collate";
	public static final String KEY_PAGE_ORIENTATION = "PageOrientation";
	public static final String KEY_PAGE_SEPERATOR = "PageSeperator";
	public static final String KEY_FAX_NUMBER = "FaxNumber";
	public static final String KEY_DEFAULT_PDF_MEDIA = "DefaultPDFMedia";
	public static final String KEY_DEFAULT_PASSWORD = "DefaultPassword";

	// Server Configuration
	public static final String KEY_SAVE_CPMPLETED_JOBS = "SaveCompletedJobsInHrs";
	public static final String KEY_SYSTEM_RETRY_ATTEMPTS_IN_SECS = "SystemRetryAttemptsInSec";

	public static final String HEADER  = "Header";
    public static final String FOOTER  = "Footer";
    public static final String YES     = "Yes";
    public static final String NO      = "No";
    public static final String DISABLE     = "Disable";
    public static final String ENABLE      = "Enable";
    public static final String ZERO    = "0";
    public static final String TRUE    = "true";
    public static final String FALSE   = "false";
    public static final String SINGLE  = "single";
    public static final String MULTIPLE  = "multiple";
    public static final String VALUE     = "value";

    public static final String STYLE_NORMAL_LABEL = "normal-label";
    public static final String STYLE_MANDATORY_ICON = "mandatory-icon";
    public static final String VOS_STYLE1 = "v1";
    public static final String VOS_STYLE2 = "v2";
    public static final String VOS_STYLE3 = "v3";

    public static final String PREFIX_LABEL            = "label";
    public static final String PREFIX_DYNA_CONTROL     = "include-queue-id:addorEditForm:";

    public static final String ACTION_ADD_ENDPOINT = "add.endpoint";
    public static final String ACTION_EDIT_ENDPOINT = "edit.endpoint";

    public static final String ACTION_ADD_DEVICE = "add.device";
    public static final String ACTION_EDIT_DEVICE = "edit.device";

    public static final String HEADER_FOOTER = "Header,Footer";
    public static final String HEADERS = "Header,Header";
    public static final String FOOTERS = "Footer,Footer";

    public static final String SUCCESS = "success";
    public static final String FAILURE = "failure";

    public static final String KEY_DISPLAY_HEADER_FOOTER        = "DisplayHeaderFooter";

    public static final String KEY_DYNA_PROPS_PANEL_ID          = "dyna-props-panel";
    public static final String KEY_DYNA_PROPS_BEAN_NAME         = "dynaProps";
    public static final String KEY_DYNA_PROPS_BEAN              = "endpointBean";

    public static final String PATTERN_DYNA_PROPS_START         = "#{" + KEY_DYNA_PROPS_BEAN + "."
                                                                 + KEY_DYNA_PROPS_BEAN_NAME + "['";
    public static final String PATTERN_DYNA_PROPS_END           = "']}";
    public static final String DELIMETER_COMMA                  = ",";
    public static final String DEFAULT_ENDPOINT                 = "Print";

    public static final String START_PATTERN                    = "#{";
    public static final String BRACE_PATTERN                    = "['";
    public static final String END_PATTERN                      = "']}";

    public static final String PREFIX_ADD_CLIENT_ID = "include-queue-id:addJSP:addForm";

    public static final String PREFIX_EDIT_CLIENT_ID = "include-queue-id:editJSP:editForm";

    public static final String MANDATORY_IMG_LOC                = "../images/required.png";

    public static final String BEAN_JOBVIEW                     = "jobbean";
    public static final String BEAN_QVIEW                       = "queuebean";

    public static final String DYNA_PROPS_SOURCE_BEAN           = "sourceBean.dynaProps";
    public static final String DYNA_PROPS_EP_BEAN               = "endpointBean.dynaProps";
    public static final String DYNA_PROPS_DEVICE_BEAN           = "deviceBean.dynaProps";

    public static final String SOURCE_DYNA_PROPS_START         = "#{" + DYNA_PROPS_SOURCE_BEAN + "."
                                                                 + KEY_DYNA_PROPS_BEAN_NAME + "['";

    public static final String KEY_MB_QUEUE_DELETION            = "ConfirmQueueDeletion";
    public static final String KEY_MBUNSAVED_CHANGE             = "UnSavedChanges";
    public static final String PREFIX_MANDATORY                 = "mandatory.";

    public static final String TITLE_DIALOG_UN_SAVED_CHANGES    = "mb_title_unsaved_changes";
    public static final String MB_TITLE_ERROR                   = "mb_title_error";
    public static final String MB_TITLE_SAF_CANNOT_BE_COMPLETED = "mb_title_save_cannot_compl";
    public static final String MB_TITLE_RELEASE_UNSUCCESSFUL    = "mb_title_release_unsucessful";
    public static final String MB_TITLE_LET_CREAT_UNSUCCESSFUL  =
                                                    "mb_title_let_creation_unsuccessful";
    public static final String MB_TITLE_PAUSED                  = "mb_title_pause";
    public static final String MB_TITLE_RESUMED                 = "mb_title_resumed";
    public static final String MB_TITLE_CANCELLED               = "mb_title_cancelled";
    public static final String MB_TITLE_CONFIRM_Q_DEL           = "mb_title_queue_del";
    public static final String MB_TITLE_INVALID_VAL             = "mb_title_inv_val";
    public static final String MB_TITLE_SYSTEM_ERR = "mb_title_system_err";

    public static final String MB_BODY_DIALOG_UN_SAVED_CHANGES = "mb_body_unsaved_changes";
    public static final String MB_BODY_SAF_CANNOT_BE_COMPLETED = "mb_body_save_cannot_compl";
    public static final String MB_BODY_RELEASE_UNSUCCESSFUL    = "mb_body_release_unsucessful";
    public static final String MB_BODY_LET_CREAT_UNSUCCESSFUL  =
                                                        "mb_body_let_creation_unsuccessful";
    public static final String MB_BODY_PAUSED                  = "mb_body_pause";
    public static final String MB_BODY_RESUMED                 = "mb_body_resumed";
    public static final String MB_BODY_CANCELLED               = "mb_body_cancelled";
    public static final String MB_BODY_CONFIRM_Q_DELETION      = "mb_body_queue_del";
    public static final String MB_BODY_INVALID_VALUES          = "mb_body_inv_val";

    public static final String MB_TOOL_TIP_UNSAVED_BTN1        = "mb_tooltip_btn1_unsaved_changes";
    public static final String MB_TOOL_TIP_UNSAVED_BTN2        = "mb_tooltip_btn2_unsaved_changes";

    public static final String MB_TOOL_TIP_Q_DEL_BTN1          = "mb_tooltip_btn1_queue_del";
    public static final String MB_TOOL_TIP_Q_DEL_BTN2          = "mb_tooltip_btn2_queue_del";

    public static final String ERROR_MSG_SELECT_NULL           = "err_msg_select_none";

    public static final String KEY_ENDPOINT_TYPE = "EndPoint.Type";
    public static final String KEY_JOB_STATUS = "Job.Status";
    public static final String KEY_ENDPOINT_NAME = "destination";
    public static final String KEY_JOB_USERID = "Job.UserID";
    public static final String KEY_JOB_ID = "jobId";
    public static final String KEY_JOB_NAME = "jobName";
    public static final String KEY_DEST_ID = "destId";
    public static final String KEY_DEST_TYPE_ID = "destTypeId";
    public static final String KEY_FROM_DATE = "fromDate";
    public static final String KEY_TO_DATE = "toDate";

    public static final String ALL_QUEUES = "All Queues";
    public static final String ALL_USERS = "All Users";

	public static final String PRINT = "PRINT";
	public static final String FAX = "FAX";
	public static final String FILE = "FILE";
	public static final String EMAIL = "EMAIL";
	public static final String SOCKET = "SOCKET";
	public static final String TYPE_PDF = "PDF";
	public static final String FILE_PATHS = "FILEPATHS";
	public static final String FILEPATH = "FILEPATH";
	public static final String DISC = "DISC";
	
	public static final String UNKNOWN = "UNKNOWN";

	//CR# 350687 alignment issue fix
	public static final int TEXT_FIELD_SIZE = 41;
	
	public static final int TEXT_AREA_COL_SIZE = 43;
	
	// Constant defined for the application Id ROI
	public static final String APPID_ROI = "roi";

    public static enum JobStatus {

        READY("ready"),
        COMPLETE("complete"),
        FAILED("failed"),
        PAUSED("paused"),
        CANCELED("canceled"),
        PROCESSING("processing");

        private final String _status;

        private JobStatus(String name) { _status = name; }

        @Override
        public String toString() { return _status; }
    }

    public static enum DestinationType {
    	
        EMAIL("EMAIL"),
        FILE("FILE"),
        FAX("FAX"),
        PRINT("PRINT"),
        DISC("DISC"),
        SOCKET("SOCKET");

        private final String _type;

        private DestinationType(String name) { _type = name; }

        @Override
        public String toString() { return _type; }
    }

    public static enum SourceType {
    	PHYSICIANLETTER("PHYSICIANLETTER"),
    	HPF("MPF"),
      	ROI("ROI"),
        FILEPATH("FILEPATH");
        private final String _type;

        private SourceType(String name) { _type = name; }

        @Override
        public String toString() { return _type; }
    }

    public static enum PartTransformType {
        WATERMARK_PART("WATERMARK_PART"),
        PAGE_SEPARATOR_PART("PAGE_SEPARATOR_PART"),
        HEADER_FOOTER_PART("HEADER_FOOTER_PART");

        private final String _type;

        private PartTransformType(String name) { _type = name; }

        @Override
        public String toString() { return _type; }
    }

    public static enum JobTransformType {
        WATERMARK_JOB("WATERMARK_JOB"),
        PAGE_SEPARATOR_JOB("PAGE_SEPARATOR_JOB"),
        HEADER_FOOTER_JOB("HEADER_FOOTER_JOB");

        private final String _type;

        private JobTransformType(String name) { _type = name; }

        @Override
        public String toString() { return _type; }
    }
    
    public static enum DeviceType {
    	
        DISC_DEVICE("DISC_DEVICE");

        private final String _type;

        private DeviceType(String name) { _type = name; }

        @Override
        public String toString() { return _type; }
    }    

    public static final String JOB_SUFFIX = "_JOB";
    public static final String PART_SUFFIX = "_PART";
    public static final String TRANSFORM_TYPE = "transformType";
    public static final String CAMEL_ROUTE_HEADER = "outputRoutingSlipHeader";
    public static final String CAMEL_START_JOB_HEADER = "outputStartJobHeader";
    public static final String CAMEL_ROUTE_JOB_HEADER = "outputJobRouteHeader";
    public static final String CAMEL_IMAGE_ROUTE_HEADER = "outputImageRoutingSlipHeader";
    public static final String CAMEL_JOB_TRANSFORM_HEADER = "outputJobTransformHeader";
    public static final String CAMEL_PART_TRANSORM_HEADER = "outputPartTransformHeader";
    public static final String CAMEL_SOURCES_HEADER = "outputSourcesHeader";
    public static final String CAMEL_DESTINATION_ROUTE_HEADER =
                                                    "outputDestinationRoutingSlipHeader";
    public static final String CAMEL_ROUTE_DELIMITER = "#";
    public static final String ENDPOINT_DELIMITER = "!";
    public static final String COLON_DELIMETER = ":";
    public static final String CAMEL_ERROR_QUEUE = "outputErrorQueue";
    public static final String CAMEL_PAUSED_QUEUE = "outputPausedQueue";
    public static final String CAMEL_SUBMIT_QUEUE = "outputSubmitQueue";
    public static final String CAMEL_IMAGE_QUEUE = "imageConversionQueue";
    public static final String CAMEL_DESTINATION_QUEUE = "destinationQueue";
    public static final String IMAGECONVERTER_TYPE = "IMAGECONVERTER";
    public static final String IMAGECONVERTER_NAME = "IMAGECONVERTER";
    public static final String DEFAULT_SOURCE_TYPE    = "ROI";
    public static final String PRINTER_NAME    = "printerName";
    public static final String AVAILABLE_PRINTERS    = "availablePrinters";
    public static final String PRINTER    = "Printer Name";

    public static final Map<Integer, String> JOB_STATUS_MAP = new HashMap<Integer, String>();
    public static final Map<Integer, String> QUEUE_STATUS_MAP = new HashMap<Integer, String>();
    public static final Map<String, String> DEST_TYPES_MAP = new HashMap<String, String>();
    public static final Map<String, String> DEVICE_TYPES_MAP = new HashMap<String, String>();
    public static final List<String> NEGLECT_PROPS = new ArrayList<String>();

    public static final String QUEUE_NAME    = "queue_name";
    public static final String QUEUE_TYPE    = "queue_type";
    public static final String QUEUE_DESC    = "queue_desc";
    public static final String QUEUE_STATUS    = "queue_status";
    public static final String QUEUE_JOBS      = "queue_jobs";
    public static final String QUEUE_CREATOR_SYSTEM = "system";
    public static final String QUEUE_CREATOR_USER = "user";
    
    public static final String DEVICE_NAME    = "device_name";
    public static final String DEVICE_TYPE    = "device_type";
    public static final String DEVICE_DESC    = "device_desc";
    public static final String DEVICE_VENDOR  = "device_vendor";
    public static final String VENDOR_NAME 	  = "vendorName";

    public static final String JOB_STATUS    = "job_status";
    public static final String JOB_TYPE      = "job_type";
    public static final String JOB_DATE      = "job_date";
    public static final String JOB_NAME      = "job_name";
    public static final String JOB_PAGES     = "job_pages";
    public static final String JOB_QUEUE     = "job_queue";
    public static final String JOB_ID        = "job_id";
    public static final String JOB_USER      = "job_user";

    public static final String UP_ARROW    = "../images/UpArrow.gif";
    public static final String DOWN_ARROW    = "../images/DownArrow.gif";

    public static final String USER_NAME    = "user_name";
    public static final String USER_ID      = "user_id";
    public static final String USER_IS_SELECTED = "user_is_selected";
    
    public static final String KEY_DEST_DEVICE_ID = "device";
    public static final String KEY_DEST_DEVICE_NAME = "deviceName";
    public static final String PASSWORD = "password";
    public static final String KEY_LABEL_TEMPLATE = "labelTemplate";
	public final static String DISC_PDF_TEMP = "pdf";
	
	public static String ENDPOINT_STATUS_KEY = "ENDPOINT_STATUS_KEY";
	public static String ENDPOINT_STATUS_ADDITIONAL_INFO_KEY = "ENDPOINT_STATUS_ADDITIONAL_INFO_KEY";
   
    //regex for share location
    public static final String SHARE_LOCATION_REGEX = "(\\\\\\\\(\\d{1,3}\\.){3,3}(\\d{1,3})|"
    										+ "(\\\\\\\\)[^\\/:*|<>?\"]+)(\\\\[^\\/:*|<>?\"])*";

    static {

        JOB_STATUS_MAP.put(RequestStatus.CANCELED.statusCode(), "Canceled");
        JOB_STATUS_MAP.put(RequestStatus.PAUSED.statusCode(), "Paused");
        JOB_STATUS_MAP.put(RequestStatus.DEST_PAUSED.statusCode(), "Paused");
        JOB_STATUS_MAP.put(RequestStatus.ERROR.statusCode(), "Failed");
        JOB_STATUS_MAP.put(RequestStatus.PROCESSING.statusCode(), "Processing");
        JOB_STATUS_MAP.put(RequestStatus.COMPLETED.statusCode(), "Complete");
        JOB_STATUS_MAP.put(RequestStatus.READY.statusCode(), "Ready");
        JOB_STATUS_MAP.put(RequestStatus.PAUSING.statusCode(), "Pausing");
        JOB_STATUS_MAP.put(RequestStatus.CANCELING.statusCode(), "Canceling");
        JOB_STATUS_MAP.put(RequestStatus.PRINTING.statusCode(), "Printing");
        JOB_STATUS_MAP.put(RequestStatus.FAXING.statusCode(), "Faxing");
        JOB_STATUS_MAP.put(RequestStatus.RESUMING.statusCode(), "Resuming");
        JOB_STATUS_MAP.put(RequestStatus.DISC_BURNING_PROCESSING.statusCode(), "Writing Disc");
        JOB_STATUS_MAP.put(RequestStatus.DISC_BURNING_READY.statusCode(), "Processing");
        JOB_STATUS_MAP.put(RequestStatus.DISC_PREPARING_PROCESSING.statusCode(), "Processing");
        JOB_STATUS_MAP.put(RequestStatus.DISC_PREPARING_READY.statusCode(), "Processing");
        JOB_STATUS_MAP.put(RequestStatus.FILE_PREPARING.statusCode(), "Processing");
        JOB_STATUS_MAP.put(0, "Unknown");

        // Queue types
        DEST_TYPES_MAP.put("PRINT", "Print");
        DEST_TYPES_MAP.put("FILE", "PDF");
        DEST_TYPES_MAP.put("FAX", "Fax");
        DEST_TYPES_MAP.put("EMAIL", "Email");
        DEST_TYPES_MAP.put("SOCKET", "Socket");
        DEST_TYPES_MAP.put("DISC", "Disc");

        DEST_TYPES_MAP.put("Print", "PRINT");
        DEST_TYPES_MAP.put("PDF", "FILE");
        DEST_TYPES_MAP.put("Fax", "FAX");
        DEST_TYPES_MAP.put("Email", "EMAIL");
        DEST_TYPES_MAP.put("Socket", "SOCKET");
        DEST_TYPES_MAP.put("Disc", "DISC");

        // Source types
        DEST_TYPES_MAP.put("HPF", "HPF");
        DEST_TYPES_MAP.put("ROI", "ROI");
        DEST_TYPES_MAP.put("PHYSICIANLETTER", "PHYSICIANLETTER");
        DEST_TYPES_MAP.put("FILEPATH", "FILEPATH");

        QUEUE_STATUS_MAP.put(EndpointStatus.OK.statusCode(), "Active");
        QUEUE_STATUS_MAP.put(EndpointStatus.PAUSED.statusCode(), "Held");
        QUEUE_STATUS_MAP.put(EndpointStatus.ERR_UNKNOWN.statusCode(), "Unknown");
        QUEUE_STATUS_MAP.put(EndpointStatus.ERR_HELP.statusCode(), "Error");
        QUEUE_STATUS_MAP.put(EndpointStatus.ERR_RECOVERABLE.statusCode(), "Error");
        QUEUE_STATUS_MAP.put(EndpointStatus.STOPPED.statusCode(), "Error");
        
        DEVICE_TYPES_MAP.put("DISC", "DISC_DEVICE");        
        DEVICE_TYPES_MAP.put("DISC_DEVICE", "DISC");
        
        // Added for constructing view output settings dynamically
        // These properties will not be listed in the view output settings modal panel
        // File
        NEGLECT_PROPS.add(OUTPUT_FILE_PREPEND);
        NEGLECT_PROPS.add(OUTPUT_FILE_RELEASE_NUM);
        NEGLECT_PROPS.add(OUTPUT_FILE_REQUEST_ID);
        NEGLECT_PROPS.add(OUTPUT_FILE_PREPEND);
        NEGLECT_PROPS.add(DEST_NAME);
        NEGLECT_PROPS.add(DEST_TYPE);
        NEGLECT_PROPS.add(KEY_WHERE);
        NEGLECT_PROPS.add(KEY_COMMENT);

        //Print
        NEGLECT_PROPS.add("scaling");
        NEGLECT_PROPS.add("color");
        NEGLECT_PROPS.add("PAGE_SEPARATOR");
        NEGLECT_PROPS.add("printerName");
        NEGLECT_PROPS.add("location");
        NEGLECT_PROPS.add("pagePerSheet");
        
        //ENDPOINT STATUS
        NEGLECT_PROPS.add(ENDPOINT_STATUS_KEY);
        NEGLECT_PROPS.add(ENDPOINT_STATUS_ADDITIONAL_INFO_KEY);
    }

    /** OutputCleanupJob Constants */
    public static final String OUTPUT_MANAGER_BEAN_NAME_PROP =
        "OutputManagerBeanName";
    public static final String ENDPOINT_MANAGER_BEAN_NAME_PROP =
        "EndpointManagerBeanName";

    public static final String STAGING_DIR = "STAGING_DIR";
    public static final Object FILEPATHS = "FILEPATHS";

    // Attachment
    public static final String CONTENT_TYPE = "CONTENT_TYPE";
    public static final String ATTACHMENT = "attachment";

    // Constants for Printer Destination.
    /**
     *  MediaSize constants used to indicate paper size for printer.
     */
    public static enum MediaSizeConstants {


	    /** The N a_10 x13_ envelope. */
    	NA_10X13_ENVELOPE("NA_10X13_ENVELOPE"),

	    /** The N a_10 x14_ envelope. */
	    NA_10X14_ENVELOPE("NA_10X14_ENVELOPE"),

	    /** The N a_10 x15_ envelope. */
	    NA_10X15_ENVELOPE("NA_10X15_ENVELOPE"),

	    /** The N a_5 x7. */
	    NA_5X7("NA_5X7"),

	    /** The N a_6 x9_ envelope. */
	    NA_6X9_ENVELOPE("NA_6X9_ENVELOPE"),

	    /** The N a_7 x9_ envelope. */
	    NA_7X9_ENVELOPE("NA_7X9_ENVELOPE"),

	    /** The N a_8 x10. */
	    NA_8X10("NA_8X10"),

	    /** The N a_9 x11_ envelope. */
	    NA_9X11_ENVELOPE("NA_9X11_ENVELOPE"),

	    /** The N a_9 x12_ envelope. */
	    NA_9X12_ENVELOPE("NA_9X12_ENVELOPE"),

	    /** The N a_ legal. */
	    NA_LEGAL("NA_LEGAL"),

	    /** The N a_ letter. */
	    NA_LETTER("NA_LETTER"),

	    /** The N a_ numbe r_10_ envelope. */
	    NA_NUMBER_10_ENVELOPE("NA_NUMBER_10_ENVELOPE"),

	    /** The N a_ numbe r_11_ envelope. */
	    NA_NUMBER_11_ENVELOPE("NA_NUMBER_11_ENVELOPE"),

	    /** The N a_ numbe r_12_ envelope. */
	    NA_NUMBER_12_ENVELOPE("NA_NUMBER_12_ENVELOPE"),

	    /** The N a_ numbe r_14_ envelope. */
	    NA_NUMBER_14_ENVELOPE("NA_NUMBER_14_ENVELOPE"),

	    /** The N a_ numbe r_9_ envelope. */
	    NA_NUMBER_9_ENVELOPE("NA_NUMBER_9_ENVELOPE");

        private final String _type;

        private MediaSizeConstants(String name) { _type = name; }

        @Override
        public String toString() { return _type; }
    }

    /**
     * Media Tray Constants.
     */
    public static enum MediaTrayConstants {

    	/** The BOTTOM. */
	    BOTTOM("BOTTOM"),

	    /** The ENVELOPE. */
	    ENVELOPE("ENVELOPE"),

	    /** The LARG e_ capacity. */
	    LARGE_CAPACITY("LARGE_CAPACITY"),

	    /** The MAIN. */
	    MAIN("MAIN"),

	    /** The MANUAL. */
	    MANUAL("MANUAL"),

	    /** The MIDDLE. */
	    MIDDLE("MIDDLE"),

	    /** The SIDE. */
	    SIDE("SIDE"),

	    /** The TOP. */
	    TOP("TOP");

    	private final String _type;

        private MediaTrayConstants(String name) { _type = name; }

        @Override
        public String toString() { return _type; }
    }

    public static enum PageOrientationConstants {

    	/** The LANDSCAPE. */
	    LANDSCAPE("LANDSCAPE"),

	    /** The PORTRAIT. */
	    PORTRAIT("PORTRAIT"),

	    /** The REVERS e_ landscape. */
	    REVERSE_LANDSCAPE("REVERSE_LANDSCAPE");

    	private final String _type;

        private PageOrientationConstants(String name) { _type = name; }

        @Override
        public String toString() { return _type; }
    }
    
    /*
     * Constants used to report device overall status
     * Constants are converted to client side user messages using locale based resource file
     */
	public static String DEVICE_ONLINE = "disc.device.DEVICE_ONLINE";
	public static String DEVICE_OFFLINE = "disc.device.DEVICE_OFFLINE";
	public static String DEVICE_SHUTTING_DOWN = "disc.device.DEVICE_SHUTTING_DOWN";
	public static String DEVICE_RESUMING = "disc.device.DEVICE_RESUMING";
	public static String DEVICE_PAUSING = "disc.device.DEVICE_PAUSING";    

	
	public static String MSG_PRINT_COMPLETED = "Print Job Completed";    
	public static String MSG_DISC_COMPLETED = "Disc Job Completed";    
	public static String MSG_EMAIL_COMPLETED = "Email Job Completed";    
	public static String MSG_FILE_COMPLETED = "Save to File Completed";    
	public static String MSG_SOCKET_COMPLETED = "Save to Socket Completed";    
	public static String MSG_FAX_COMPLETED = "Fax Job Completed";
	
	public static String MSG_PRINT_IN_PROGRESS = "Printing in Progress";    
	public static String MSG_PRINT_ERROR = "Error When Printing";    

	public static String MSG_DISC_READY_TO_WRITE = "Preparing to Write to Disc";    
	public static String MSG_DISC_READY_TO_CREATE = "Creating PDFs to Write to Disc";    
	
	public static String MSG_FILE_ERROR = "Error When Creating PDFs";    

	
	
	

	
	

}
