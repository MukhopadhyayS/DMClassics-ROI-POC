/**
 * Copyright � 2010 McKesson Corporation and/or one of its subsidiaries.
 * All rights reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.hpf.service;

import java.io.File;
import java.util.List;

public class ContentServiceRunnable implements Runnable {

	private final ContentWebServiceCaller _caller;
	private final WebServiceSetting _setting;
	private final List<String> _imnets;
	private final List<String> _pageNumbers;
	private final List<File> _files;
	private final boolean  _continueWithError;

	public ContentServiceRunnable(WebServiceSetting setting,
			List<String> imnets, List<String> pageNumbers, List<File> files, boolean continueWithError) {
		_caller = setting.getContentWebServiceCaller();
		_setting = setting;
		_imnets = imnets;
		_pageNumbers = pageNumbers;
		_files = files;
		_continueWithError = continueWithError;
	}

	public void run() {
		for (int i = 0; i < _imnets.size(); i++) {
			_caller.getContentToFile(_setting, _imnets.get(i),
					_pageNumbers.get(i), _files.get(i), _continueWithError);
		}
	}

	public List<File> getFiles() {
		return _files;
	}

	public String getImnet(int idx) {
		if ((_imnets == null) || (_imnets.size() < idx)) {
			return null;
		}
		return _imnets.get(idx);
	}

	public String getPageNumber(int idx) {
		if ((_pageNumbers == null) || (_pageNumbers.size() < idx)) {
			return null;
		}
		return _pageNumbers.get(idx);
	}
}
