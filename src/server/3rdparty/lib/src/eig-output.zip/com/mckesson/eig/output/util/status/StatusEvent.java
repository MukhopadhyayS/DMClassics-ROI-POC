/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util.status;

import java.util.EventObject;

import com.mckesson.eig.output.model.StatusInfo;

/**
 * Event that gets fired when status changes on an Endpoint, the OutputManager,
 * a Job or a JobPart
 *
 * @author Jon Anderson
 */
public class StatusEvent extends EventObject {

	private StatusInfo _previousStatus;
	private StatusInfo _newStatus;
	private StatusUtils.StatusObjectType _objectType;

	/**
	 * Constructor which
	 * @param previousStatus
	 * @param newStatus
	 * @param source
	 */
	public StatusEvent(
			StatusInfo previousStatus,
			StatusInfo newStatus,
			Object source) {
		super(source);

		if (newStatus == null) {
			throw new IllegalArgumentException("newStatus argument is null");
		}

		_objectType = StatusUtils.typeForObject(source);
		_previousStatus = previousStatus;
		_newStatus = newStatus;
	}

	/**
	 * TODO
	 * @return the _previousStatus
	 */
	public StatusInfo getPreviousStatus() {
		return _previousStatus;
	}

	/**
	 * TODO
	 * @return the _newStatus
	 */
	public StatusInfo getNewStatus() {
		return _newStatus;
	}

	/**
	 * TODO
	 * @return the _objectType
	 */
	public StatusUtils.StatusObjectType getObjectType() {
		return _objectType;
	}


}
