/* Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

 package com.mckesson.eig.output.device.disc.rimage;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.local.device.disc.DiscDeviceStatusListener;
import com.mckesson.eig.output.local.device.disc.DiscStatusListener;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.StringUtilities;
import com.rimage.client.api.OrderDescription;
import com.rimage.client.api.OrderManager;
import com.rimage.client.api.ProductionOrderDescription;
import com.rimage.client.api.ServerManager;
import com.rimage.client.api.SystemManager;
import com.rimage.client.api.exception.SystemException;
import com.rimage.exception.BaseException;
import com.rimage.msg.exception.MsgConnectFailedException;
import com.rimage.msg.exception.MsgDisconnectFailedException;
import com.rimage.msg.exception.MsgNotConnectedException;

/**
 * This Class holds the RIMAGE connection related items. 
 * SystemListener, ServerListener, OrderListener and actual connection.
 * 
 * @author Latonia Howard
 * @author Eric Yu
 * @author ShahM Nattarshah (OFS)
 */
public class RimageConnection {
	//TODO DONE - Pass device ID when creating connection.
	// Holds the list of deviceIds that are using the same rimageconnection.
	private List<Integer> _deviceIds = new ArrayList<Integer>();
	
	//IP Address or hostname for the rimage device.
	private String _ipAddress;
	
	// Port that used to connect rimage device.
	private String _port;
	
	// Holds connectionId
	private String _connectionId;
	
	//Holds Listeners to update the disc queue status and disc device status.
	private DiscStatusListener _discStatusListener;
	private DiscDeviceStatusListener _discDeviceStatusListener;
	
	//Holds imageorder for current device connection.
	private ImageOrderListener _ioListener;
	
	//Holds ProductionOrderListener for the current device connection.
	private ProductionOrderListener _poListener;
	
	// Holds ServerListener and System Listener for the current device connection. 
	private ServerAndSystemListener _ssListener; 
	
	// LOG
	protected static final Log LOG = LogFactory.getLogger(RimageConnection.class);
	
	public RimageConnection(int deviceId, String ipAddress, String port, DiscStatusListener listener, DiscDeviceStatusListener deviceStatusListener) {
		_ipAddress = ipAddress;
		_port = port;
		_discStatusListener = listener;
		_discDeviceStatusListener = deviceStatusListener;
		String hostName = OutputUtil.getServerName();
		_connectionId = hostName + ":" + ipAddress + ":" + port;
		addDevice(deviceId);
	}	

	/**
	 * This method is used to add a DeviceId to the RimageConnection class which is one connection per 
	 * RIMAGE Device. 
	 * 
	 * If we have multiple queues that are using the same RIMAGE device, the queue Id is added as device
	 * 
	 * @param deviceId - Disc device queue ID.
	 */
	public void addDevice(int deviceId) {
		if (!_deviceIds.contains(deviceId)) {
			_deviceIds.add(deviceId);
		}
	}
	
	public String getPort() {
		return _port;
	}

	public void setPort(String port) {
		_port = port;
	}

	public String getIpAddress() {
		return _ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		_ipAddress = ipAddress;
	}
	
	public List<Integer> getDeviceIds() {
		return _deviceIds;
	}
	
    public int hashCode() {
        return new HashCodeBuilder(17, 31). // two randomly chosen prime numbers
            // if deriving: appendSuper(super.hashCode()).
            append(_ipAddress).
            append(_port).
            toHashCode();
    }
 	
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (obj == this)
            return true;
        if (!(obj instanceof RimageConnection))
            return false;

        RimageConnection conn = (RimageConnection) obj;
        return new EqualsBuilder().
            // if deriving: appendSuper(super.equals(obj)).
            append(getIpAddress(), conn.getIpAddress()).
            append(getPort(), conn.getPort()).
            isEquals();
    }

    /**
     * This method will do a actual connection to RIMAGE device.
     * @return
     */
    public boolean connect() {
    	boolean result = false;
    	String statusDetails = null;
    	//TODO: make number of retries configurable
    	for(int retry=0; retry < 3; retry++){
    		result = connect(retry);
    	}
    	
    	if(!result){
    		_ssListener.onServerConnectionFailed(statusDetails);
    	}else {
    		_ssListener.onServerConnectionSuccess();
    	}
    	return result;
    }

	private boolean connect(int retry) {
		boolean result = false;
		LOG.debug("Trying to create connection for ip address=" +
				this._ipAddress + ", port=" + this._port + ". Attempt: " + retry);
		try {
			connectByServerPort();
			result = true;
    	} catch (MsgConnectFailedException e) {
	   		String errorMsg = "Failed to create connection for ip address=" +
					this._ipAddress + ", port=" + this._port +
					". Will attempt to retry again. MsgConnectFailedException occured: ";
			LOG.error(errorMsg + e.getMessage());
			if (StringUtilities.isEmpty(_connectionId)) {
				try {
					connectByServerPort();
					result = true;
			   	} catch (MsgConnectFailedException ee) {
					LOG.error(errorMsg + ee.getMessage());
			   	}
			}
    	}
		return result;
	}
    
    /**
     * This method is to check whether the current RImageConnection object has a connection active or not.
     * @return
     */
    public boolean isConnected() {
			return SystemManager.getInstance().isConnected(_connectionId);
    }
    
    /**
     * This method is used to establish the same listerer object to the newly created connection.
     * @throws SystemException
     */
	private void establishListeners() throws SystemException {
		try {
			
			/*
			 * Initialize and establish the System Listener, Server Listener
			 */
			_ssListener = new ServerAndSystemListener(this._discDeviceStatusListener, this);
			SystemManager.getInstance().listenForSystemStatus(_connectionId, _ssListener);
			ServerManager.getInstance().listenForServerEvents(_connectionId, _ssListener);
			
			/*
			 * Initialize and establish the Order Listener (Image, Production). 
			 * Same Listener instance are used for all the jobs. 
			 * This minimize the recover process to re-initialize only one instance of listener.
			 */
			this._ioListener = new ImageOrderListener(this._discStatusListener);
			this._poListener = new ProductionOrderListener(this._discStatusListener);
			
		} catch (MsgNotConnectedException e) {
			LOG.debug("Failed to establish listeners. MsgNotConnectedException occured: ", e);
			throw new SystemException("Failed to establish listeners.", e);
		} catch (SystemException e) {
			LOG.debug("Failed to establish listeners. SystemException occured: ", e);
			throw new SystemException("Failed to establish listeners.", e);
		}
	}
	
	/**
	 * This method is used to connect the server using connection and port.
	 * @throws MsgConnectFailedException
	 */
	public void connectByServerPort() throws MsgConnectFailedException {
		try {
			disconnect();
			String clientID = OutputUtil.getServerName() + "_" + _ipAddress;
			_connectionId = SystemManager.getInstance().connect(clientID, _ipAddress, _port);
			establishListeners();
		} catch (MsgConnectFailedException e) {
			processConnectionException(e);
		} catch (MsgNotConnectedException e) {
			processConnectionException(e);
		} catch (SystemException e) {
			processConnectionException(e);
		}
	}

	private void processConnectionException(BaseException e) {
		String message = "Failed to setup connection with Rimage device, ip address: "
				+ _ipAddress + ", port number: " + _port;
		LOG.debug(message + ". Exception occured: ", e);
		throw new InvalidDefinitionException(
				message,
				OutputErrorCode.RUNTIME_ERROR);
	}
	
	/**
	 * This method will disconnect the listeners that are connected to rimage device,
	 * SystemListener, ServerListener, OrderListener and disconnects the actual connection.
	 * @throws MsgNotConnectedException
	 * @throws SystemException
	 */
	public void disconnect() throws MsgNotConnectedException, SystemException {
		if (!StringUtilities.isEmpty(_connectionId)) {
			
			LOG.info("Disconnecting the connection from the Rimage System: " + _connectionId);
			if(isConnected()) {
				
				// Remove listeners for System and Server listener
				try {
					
					SystemManager.getInstance().removeSystemListener(_connectionId);
					LOG.info("Removed System Listener for connection: " + _connectionId);
				} catch (Exception e) {
					LOG.info("Failed to remove system listener from the Rimage System , ConnectionId: " + _connectionId + "", e);
				}
				
				try {
					// Remove listeners for Server listener
					ServerManager.getInstance().removeServerEventListener(_connectionId);
					LOG.info("Removed Server Listener for connection: " + _connectionId);
				} catch (Exception e) {
					LOG.info("Failed to remove server listener from the Rimage System, ConnectionId: " + _connectionId + "", e);
				}
				
				try {
					// Remove all the order listeners for this connection
					SystemManager.getInstance().removeOrderListener(_connectionId);
					LOG.info("Removed Order Listener for connection: " + _connectionId);
				} catch (Exception e) {
					LOG.info("Failed to remove order listener from the Rimage System, ConnectionId: " + _connectionId + "", e);
				}
				
				try {
					// Disconnect the connection	
					SystemManager.getInstance().disconnect(_connectionId);
					LOG.info("Connection" + _connectionId + "is disconnected");
				} catch (MsgDisconnectFailedException e) {
					LOG.info("Failed to disconnect from the Rimage System, ConnectionId: " + _connectionId + "", e);
				}
			}
		}
	}
	
	/**
	 * This method sends the image order to the rimage.
	 * @param jobId
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	public OrderDescription  sendImageOrder(Integer jobId, String xml) throws Exception  {
		if (!isConnected()) {
			connect();
		}
		OrderManager manager = OrderManager.getInstance();
		OrderDescription description = manager.submitDurableOrder(_connectionId, xml, _ioListener);
		return description;
	}
	
	/**
	 * This method sends the production order to the rimage.
	 * @param jobId - jobId (ordersetId)  for the order
	 * @param orders - set of orders on same orderset.
	 * @return
	 * @throws Exception
	 */
	public List<OrderDescription> sendProductionOrder(Integer jobId, List<String> orders) throws Exception {
		if (!isConnected()) {
			connect();
		}
		OrderManager manager = OrderManager.getInstance();
		List<OrderDescription> descriptions = new ArrayList<OrderDescription>();
		for(String order : orders) {
			OrderDescription description = manager.submitDurableOrder(_connectionId, order, _poListener);
			descriptions.add(description);
		}
		return descriptions;
	}

	/**
	 * Recover production order during the startup.
	 * @param orderId - actual order Id that is submitted.
	 * @param clientId - unique id that recover all jobs to particular client the connected RIMAGE
	 * @throws Exception
	 */
	public void recoverProductionOrder(String orderId, String clientId, String originator) throws Exception {
		if (!isConnected()) {
			connect();
		}
		OrderDescription decription = getProductionOrderSetDescription(orderId, clientId, originator);
		OrderManager manager = OrderManager.getInstance();
    	manager.recoverOrder(decription, _poListener);
    	manager.receiveRecoveredStatuses();
	}
	
	private OrderDescription getProductionOrderSetDescription(String orderId, String clientId, String originator) {
		ProductionOrderDescription description = new ProductionOrderDescription();
		description.setOrderId(orderId);
		description.setAction("OrderSet");
		description.setOriginator(originator);
		description.setClientId(clientId);
		return description;
		
	}
}
