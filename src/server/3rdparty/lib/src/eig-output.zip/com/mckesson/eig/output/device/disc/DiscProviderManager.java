/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/


package com.mckesson.eig.output.device.disc;

import java.util.List;
import java.util.Map;

import com.mckesson.eig.output.local.device.disc.DiscDevice;
import com.mckesson.eig.output.local.device.disc.DiscDeviceStatusListener;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;

public interface DiscProviderManager {
    
    void initialize(List<EndpointDef> devices);
    void reconnect();
    void testConnection(int deviceId, String server, String port);
	String getServerStatus(DiscDevice device);
    boolean isConnected(String server, String port);
    boolean isConnected(DiscDevice device);
    String prepareDiscContent(OutputJob job);
    String burnDisc(OutputJob job);
    Map<StatusInfo, List<String>> checkPrepareDiscContentStatus(OutputJob job);
    StatusInfo checkBurnDiscStatus(OutputJob job);
    void shutdown();
    DiscDeviceStatusListener getDiscDeviceStatusListener();
    void setDiscDeviceStatusListener(DiscDeviceStatusListener listener);
}
