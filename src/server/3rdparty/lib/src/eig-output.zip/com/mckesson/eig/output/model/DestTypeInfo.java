/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.util.Arrays;
import java.util.Collection;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * <code>DestTypeInfo</code> defines a type or class of destinations for example FAX or PRINT would
 * represent unique types of destinations.
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "destTypeInfo")
@XmlType(name = "destTypeInfo")
public class DestTypeInfo extends DestTypeDef {

	private static final long serialVersionUID = 1L;

	private static final int HASH_MULTIPLY = 91;
	private static final int HASH_INIT = 13;

    private PropertyDef[] _propertyDefs;
	private String[] _contentTypes;
	private Collection<String> _deviceIDs;

	/**
	 * Constructor
	 */
	public DestTypeInfo() {
		super();
	}

	@Override
    public boolean equals(Object o) {

		if (!super.equals(o)) {
			return false;
		}

	    DestTypeInfo info = (DestTypeInfo) o;

        if (info._propertyDefs == null
        		|| !Arrays.equals(_propertyDefs, info._propertyDefs)) {
            return false;
        }
        if (info._contentTypes == null
        		|| !Arrays.equals(_contentTypes, info._contentTypes)) {
            return false;
        }
        if (!ObjectUtils.equals(_deviceIDs, info._deviceIDs)) {
            return false;
        }

        return true;
	}

	@Override
    public int hashCode() {

        HashCodeBuilder hcb = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
        hcb.appendSuper(super.hashCode());
        hcb.append(_propertyDefs);
        hcb.append(_contentTypes);
        hcb.append(_deviceIDs);

        return hcb.toHashCode();
	}

	/**
	 * Types of content which may be sent to _deviceIDs of this type.
	 *
	 * @return the _contentTypes
	 */
	public String[] getContentTypes() {
		return _contentTypes;
	}

	/**
	 * @param contentTypes the _contentTypes to set
	 */
	@XmlElementWrapper(name = "contentTypes")
	@XmlElement(name = "contentType", type = String.class)
	public void setContentTypes(String[] contentTypes) {
		_contentTypes = contentTypes;
	}

    /**
     * Returns the list devices available to the system for this type. These
     * devices may or may not be installed as destinations
     *
     * @return the _deviceIDs
     */
    public Collection <String> getDeviceIDs() {
        return _deviceIDs;
    }

    /**
     *
     * @param devices the _deviceIDs to set
     */
    @XmlElementWrapper(name = "deviceIDs")
    @XmlElement(name = "deviceId", type = String.class)
    public void setDeviceIDs(Collection <String> devices) {
        _deviceIDs = devices;
    }

    /**
     * Returns the definitions of the properties which may be set for the
     * type destination type as a whole
     *
     * @return the _propertyDefs
     */
    public PropertyDef[] getPropertyDefs() {
        return _propertyDefs;
    }

    /**
     *
     * @param propertyDefs the _propertyDefs to set
     */
    @XmlElementWrapper(name = "propertyDefs")
    @XmlElement(name = "propertyDef", type = PropertyDef.class)
    public void setPropertyDefs(PropertyDef[] propertyDefs) {
        _propertyDefs = propertyDefs;
    }

}
