package com.mckesson.eig.output.local.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.mckesson.eig.output.model.JobFileList;
import com.mckesson.eig.output.model.OutputLoV;

public interface OutputLovDAO {

	Serializable create(OutputLoV lov);
	OutputLoV merge(OutputLoV lov);
	OutputLoV retrieveLoV(String name, int parentId);
	OutputLoV retrieveOutputConfiguration();
	OutputLoV retrieveEndpointType(String name);
	List<OutputLoV> retrieveEndpoints(int parentId);
	OutputLoV retrieveEndpoint(int id);
    int getEndpointId(String endpointType, String endpointName);
    List<Integer> getAllEndpointIdsByType(String endpointType);
	List<OutputLoV> getAllEndpointsByType(String endpointType);
    void delete(Object object);
    int createFileInfoForDestination(JobFileList fileList, int destID);
    JobFileList readFileInfoForDestination(int destID);
    List<JobFileList> readAllFileInfoForDestination(int destID, Date toDate);
    void deleteAllFileInfoForDestination(int destID, Date toDate);
    void updateFileInfoForDestination(JobFileList fileList);
}
