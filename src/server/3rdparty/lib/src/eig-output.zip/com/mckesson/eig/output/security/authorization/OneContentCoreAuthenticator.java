/*
 * Copyright 2012 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.security.authorization;


import com.mckesson.eig.output.security.AbstractAuthenticator;



/**
 * @author Shahm Nattarshah
 * @date  Oct 2013
 * @since  HPF 16.1
 */
public class OneContentCoreAuthenticator extends AbstractAuthenticator {

    /**
     * Gets the application id to get <code>RecordsManagementAuthenticator</code>
     *
     */
    public String getAppID() {
        return "OneContentCore";
    }
}
