/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Corporation and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Corporation.
 */

package com.mckesson.eig.output.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @date   Apr 9, 2010
 * @since  Apr 9, 2010
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "outputJobs")
@XmlType(name = "outputJobs")
public class OutputJobs {

    private List<OutputJob> _outputJobList;
    private List<DestInfo> _destInfoList;

    /**
     *
     * @return List<OutputJob>
     */
    public List<OutputJob> getOutputJobList() {
        return _outputJobList;
    }

    /**
     *
     * @param outputJobList
     */
    @XmlElement (name = "outputJobList", type = OutputJob.class)
    public void setOutputJobList(List<OutputJob> outputJobList) {
        _outputJobList = outputJobList;
    }

    /**
     *
     * @return List<DestInfo>
     */
    public List<DestInfo> getDestInfoList() {
        return _destInfoList;
    }

    /**
     *
     * @param destInfoList
     */
    @XmlElement (name = "destInfoList", type = DestInfo.class)
    public void setDestInfoList(List<DestInfo> destInfoList) {
        _destInfoList = destInfoList;
    }
}
