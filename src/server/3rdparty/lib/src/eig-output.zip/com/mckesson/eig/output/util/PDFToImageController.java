package com.mckesson.eig.output.util;


import java.awt.print.PageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.concurrent.WorkerPool;
import com.mckesson.eig.utility.util.CollectionUtilities;


public class PDFToImageController {

    /* Verified for TIFF and PNG formats only */

    private static final int SLEEP_TIME = 1000;

    private static final String IMAGE_DIR_NAME      = "IMAGE";
    public static final String  PORTRAIT            = "PORTRAIT";
    public static final String  LANDSCAPE           = "LANDSCAPE";

    //PageFormat pf input parameter can be null.
    //Use pf when you are converting from portrait to landscape, etc.
    @SuppressWarnings("unchecked")
    public void convertJob(OutputJob job,
                                  String imageFormat,
                                  int resolution,
                                  PageFormat pf, int imageColor, int convertQueue,
                                  int imagesPerWorker) {

        if (pf.getOrientation() == PageFormat.LANDSCAPE) {
            //rotate PDF before processing
            for (JobPart tmpPart : job.getParts()) {
                PdfSupport.rotatePage(tmpPart.getCurrentLocation(),
                                      tmpPart.getSources());
            }
        }
        LocationSupport.setNextLocation(job, IMAGE_DIR_NAME);
        WorkerPool pool = new WorkerPool(convertQueue);
        HashMap map = new HashMap();
    	for (JobPart tmpPart : job.getParts()) {
    		List tasks = createConvertTask(tmpPart, imageFormat, resolution,
    		                               imageColor, imagesPerWorker, pf);
    		map.put(tmpPart, tasks);
    		Iterator i = tasks.iterator();
    		while (i.hasNext()) {
                while (!pool.isWorkerAvailable()) {
        			try {
        				// remove lock
        				Thread.sleep(SLEEP_TIME);
        			} catch (InterruptedException ie) {
        				// ignored
        			}
                }
   	        	pool.getWorkerForWorkload((PDFToImage) i.next());
    		}
    		updateTargetPath(map);
    	}
        boolean isFinished = false;
        while (!isFinished) {
        	if (pool.isAllWorkersAvailable()) {
        		isFinished = true;
        	} else {
 				try {
					// remove lock
					Thread.sleep(SLEEP_TIME);
				} catch (InterruptedException ie) {
					// ignored
				}
        	}
        }
		updateTargetPath(map);
        LocationSupport.setNextLocationAsCurrentLocation(job);
    }

    @SuppressWarnings("unchecked")
    private void updateTargetPath(HashMap map) {
    	Iterator i = map.keySet().iterator();
    	ArrayList removePart = new ArrayList();
    	while (i.hasNext()) {
    		JobPart part = (JobPart) i.next();
    		List tasks = (List) map.get(part);
    		if (isError(tasks)) {
				throw new OutputException(
						"Cannot generate an image writer.",
						OutputConstants.OutputErrorCode.RUNTIME_ERROR);
    		}
    		if (isFinished(tasks)) {
    			updatePath(part, tasks);
    			removePart.add(part);
    		}
    	}
    	if (!CollectionUtilities.isEmpty(removePart)) {
    		Iterator j = removePart.iterator();
    		while (j.hasNext()) {
    			map.remove(j.next());
    		}

    	}
    }

    @SuppressWarnings("unchecked")
    private void updatePath(JobPart part, List tasks) {
    	Iterator i = tasks.iterator();
        part.clearSources();
    	while (i.hasNext()) {
    		PDFToImage p = (PDFToImage) i.next();
            for (String generatedFilename : p.getGeneratedFiles()) {
                part.addSource(generatedFilename);
            }
    	}
    }

    @SuppressWarnings("unchecked")
    private boolean isFinished(List tasks) {
    	Iterator i = tasks.iterator();
    	while (i.hasNext()) {
    		PDFToImage p = (PDFToImage) i.next();
    		if (!p.isFinished()) {
    			return false;
    		}
    	}
    	return true;
    }

    @SuppressWarnings("unchecked")
    private boolean isError(List tasks) {
    	Iterator i = tasks.iterator();
    	while (i.hasNext()) {
    		PDFToImage p = (PDFToImage) i.next();
    		if (p.isError()) {
    			return true;
    		}
    	}
    	return false;
    }

    @SuppressWarnings("unchecked")
    private List<PDFToImage> createConvertTask(JobPart part,
                                   String imageFormat,
                                   int resolution,
                                   int imageColor,
                                   int imagesPerWorker,
                                   PageFormat pf) {
    	List<PDFToImage> result = new ArrayList<PDFToImage>();
    	List<List> fileList = createFileNameList(part, imagesPerWorker);
    	Iterator i = fileList.iterator();
    	while (i.hasNext()) {
    		PDFToImage task = new PDFToImage(part.getCurrentLocation(),
                    part.getNextLocation(),
                    (List) i.next(),
                    imageFormat,
                    resolution,
                    imageColor,
                    pf);
    		result.add(task);
    	}
    	return result;
    }

    @SuppressWarnings("unchecked")
    private List<List> createFileNameList(JobPart part, int imagesPerWorker) {
        Iterator <String> iter = part.getSourcesIterator();
        List<List>  result = new ArrayList<List>();
        List<String>  list = new ArrayList<String>();
        result.add(list);

        int idx = 1;
        while (iter.hasNext()) {
            String tmpFileName = iter.next();
            list.add(tmpFileName);
        	if (idx % imagesPerWorker == 0) {
        		list = new ArrayList<String>();
                result.add(list);
        	}
            idx++;
        }
        return result;
    }
}
