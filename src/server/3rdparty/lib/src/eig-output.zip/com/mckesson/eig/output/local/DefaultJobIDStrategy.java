/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;

/**
 * Strategy which creates ID's using a date string. The format of the generated
 * ID's is as follows <code>[J|P]dateString-sequence</code> where the [J|P]
 * represents either the letter <code>J</code> for Job ID's or the
 * letter <code>P</code> for Part ID's and <code>dateString</code> represents a
 * time stamp formated using the  class's <code>dateFormat</code> member.
 *
 * @author Jon Anderson
 */
public class DefaultJobIDStrategy implements JobIDStrategy  {

	/** "yyDDDHHmmssSSS" */
	public static final String DEFAULT_DATE_FORMAT = "yyDDDHHmmssSSS";

	private String _dateFormatString;
	private SimpleDateFormat _dateFormat;
	private long _sequence;

	/**
	 * TODO
	 */
	public DefaultJobIDStrategy() {
		setDateFormat(DEFAULT_DATE_FORMAT);
	}

	/**
	 * Returns the string used to form the dateFormat portion of the ID
	 *
	 * @return not <code>null</code>
	 */
	public String getDateFormat() {
		return _dateFormatString;
	}

	/**
	 * Sets the format for the date portion of generated ID's.
	 *
	 * @param dateFormat not <code>null</code>
	 */
	public void setDateFormat(String dateFormat) {
		if (dateFormat == null) {
			throw new IllegalArgumentException("dateFormat argument is null");
		}

		_dateFormatString = dateFormat;
		_dateFormat = new SimpleDateFormat(_dateFormatString);
	}

	/**
	 * @see com.mckesson.eig.output.local.JobIDStrategy#populateJobAndPartIDs(OutputJob)
	 */
	public void populateJobAndPartIDs(OutputJob job) {

		if (job != null) {

			String dateString = _dateFormat.format(new Date());
			String jobSequence = Long.toString(++_sequence);
			String jobID = "J" + dateString + "-" + jobSequence;
			job.setJobName(jobID);

			List<JobPart> parts = job.getParts();

			if (parts != null) {

				int partSequence = 0;
				for (JobPart part : parts) {

					String partID = "P" + dateString + "-" + (++partSequence);
					
					// TODO - Remove the ID Strategy completely as 
					//	it is not required.
//					part.setJobID(_sequence);
//					part.setPartID(partID);
				}
			}
		}
	}

}
