/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.dao;

import java.util.List;

import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.EndpointDefList;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.model.EndpointTypeDefList;

/**
 * DAO which loads destination definitions from a database
 *
 * TODO extend com.mckesson.common.orm.Dao
 *
 * @author Jon Anderson
 */
public interface EndpointDAO {

	/**
	 * Stores a new <code>EndpointDef</code>
	 *
	 * @param endpointDef
	 *            to store not <code>null</code>
	 * @return the persisted record
	 */
	EndpointDef createEndpointDef(EndpointDef endpointDef);

	/**
	 * Retrieve all persisted <code>EndpointDef</code> objects
	 *
	 * @return not null but maybe empty list of destinations
	 */
	EndpointDefList readAllEndpointDefs();

	/**
	 * Deletes the persisted <code>EndpointDef</code>
	 *
	 * @param endpointName
	 *            to delete. not <code>null</code>
	 */
	void deleteEndpointDef(EndpointDef endpointDef);

	EndpointDefList getEndpointDefByType(EndpointTypeDef endpointTypeDef);

	EndpointDef getEndpointDef(String name, String defType);

	EndpointDef getEndpointDef(int id);


	/**
	 * Updates the persisted <code>EndpointDef</code>
	 *
	 * @param endpointDef
	 *            to update. not <code>null</code>
	 * @return the updated record. not <code>null</code>
	 */
	EndpointDef updateEndpointDef(Integer userId, EndpointDef endpointDef);

	/**
	 * Stores a new <code>EndpointTypeDef</code>
	 *
	 * @param endpointTypeDef
	 *            to store not <code>null</code>
	 * @return the persisted record
	 */
	EndpointTypeDef updateEndpointTypeDef(Integer userId, EndpointTypeDef endpointTypeDef);

	/**
	 * Read all the stored EndpointTypeDef objects
	 *
	 * @return not <code>null</code>
	 */
	EndpointTypeDefList readAllEndpointTypeDefs();


	EndpointTypeDef getEndpointTypeDef(String name);
	
	List<Integer> getEndpointIds(List<String> endpointTypes);

	List<EndpointDef> getEndpoints(List<String> endpointTypes);
	
}
