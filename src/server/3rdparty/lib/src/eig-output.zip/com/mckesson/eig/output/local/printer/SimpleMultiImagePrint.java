/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * author: Latonia
 */


package com.mckesson.eig.output.local.printer;


import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ListIterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.FileImageInputStream;
import javax.imageio.stream.ImageInputStream;
import javax.print.Doc;
import javax.print.MultiDoc;

import com.mckesson.eig.output.util.PdfSupport;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 *
 * @author OFS
 * @author Latonia Howard
 */
public class SimpleMultiImagePrint implements Pageable, Printable, MultiDoc {

    private static final int SCALE_FACTOR = 100;
	private static final Log	LOG = LogFactory.getLogger(SimpleMultiImagePrint.class);
    private PageFormat   _format;
    private int                   _numPages;
    private ArrayList <String>    _fileList;
    private ListIterator <String> _fileListIter;
    private int                   _numPagesPrintedAtStartOfFile;
    private int                _scaleFactor;
    private ImageReader _reader = null;
	private boolean _reverseOrderFlag;

	public SimpleMultiImagePrint(Collection<String> pdfFileList,
					Collection <String> imageFileList, boolean reverseOrder, 
					int scaleFactor) {

        try {
            _fileList                     = new ArrayList <String>();
            _numPagesPrintedAtStartOfFile = 0;
            _scaleFactor = scaleFactor;

            _fileList.addAll(imageFileList);
            _numPages = PdfSupport.getPageCount(pdfFileList);

            // set file list iterator for processing
            _fileListIter = _fileList.listIterator(0);

            // setup first file for printing
            getNextFile();

			_reverseOrderFlag = reverseOrder;
        } catch (Exception e) {
            LOG.error("SimpleMultiImagePrint:" + e.getMessage());
        }
    }

	private boolean getNextFile() {

		boolean rtnBool = false;

		try {
			if (_fileListIter.hasNext()) {
				File file = new File(_fileListIter.next());
				ImageInputStream fis = new FileImageInputStream(file);
				_reader = ImageIO.getImageReaders(fis).next();
				_reader.setInput(fis);
				rtnBool = true;
			}
			return rtnBool;
		} catch (Exception e) {
			return false;
		}

	}

	public int getNumberOfPages() {

		return _numPages;
	}

	public void setPageFormat(PageFormat pageFormat) {

		_format = pageFormat;
	}

	public PageFormat getPageFormat(int pagenum) {

		return _format;
	}

	public Printable getPrintable(int pagenum) {

		return this;
	}

	public int print(Graphics g, PageFormat format, int index) throws PrinterException {

		try {
			int pagenum;
			if (_reverseOrderFlag) {
				pagenum = (getNumberOfPages() - 1) 
						- (index - _numPagesPrintedAtStartOfFile + 1);
			} else {
				pagenum = index - _numPagesPrintedAtStartOfFile + 1;
			}

			// don't bother if the page number is out of range.
			if ((pagenum >= 1) && (pagenum <= _reader.getNumImages(true))) {
				LOG.info("Start rendering page: " + (index + 1));
				processPage(g, format, pagenum);
				LOG.info("Finish rendering page: " + (index + 1));
				return PAGE_EXISTS;
			} else {
				// getNextFile
				if (getNextFile()) {
					_numPagesPrintedAtStartOfFile = index;
					pagenum = index - _numPagesPrintedAtStartOfFile + 1;
					LOG.info("Start rendering page: " + (index + 1));
					processPage(g, format, pagenum);
					LOG.info("Finish rendering page: " + (index + 1));
					return PAGE_EXISTS;
				}
				return NO_SUCH_PAGE;
			}
		} catch (Exception e) {
			LOG.error(e.toString());
			throw new RuntimeException();
		}
	}

    private void processPage(Graphics g, PageFormat pf, int pagenum) throws PrinterException {
        int imgWidth = 0, imgHeight = 0;
        int drawX = 0, drawY = 0;
        double scaleRatio = 1.0;
        RenderedImage image = null;

        try {
           image = _reader.read(pagenum - 1);
           imgWidth = image.getWidth();
           imgHeight = image.getHeight();
        } catch (Exception e) {
           LOG.error(e.toString());
           throw new RuntimeException();
        }

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, 
							RenderingHints.VALUE_RENDER_SPEED);
        g2.translate(pf.getImageableX(), pf.getImageableY());
        g2.setClip(0, 0, (int) pf.getImageableWidth(), (int) pf.getImageableHeight());

        double scaledPageWidth = pf.getImageableWidth() * ((double) _scaleFactor / SCALE_FACTOR);
        double scaledPageHeight = pf.getImageableHeight() * ((double) _scaleFactor / SCALE_FACTOR);

        scaleRatio =
           ((imgWidth > imgHeight)
              ? (scaledPageWidth / imgWidth)
              : (scaledPageHeight / imgHeight));

        //check the scale ratio to make sure that we will not write something off the page
        if ((imgWidth * scaleRatio) > scaledPageWidth) {
           scaleRatio = (scaledPageWidth / imgWidth);
        } else if ((imgHeight * scaleRatio) > scaledPageHeight) {
           scaleRatio = (scaledPageHeight / imgHeight);
        }

        //find the scaled width and height
        int scaledWidth = imgWidth, scaledHeight = imgHeight;

        //center image
        if (scaleRatio < 1) {
           drawX = (int) ((pf.getImageableWidth() - scaledPageWidth) / 2);
           drawY = (int) ((pf.getImageableHeight() - scaledPageHeight) / 2);

           //new code to set the scale
           scaledWidth = (int) (scaledWidth * scaleRatio);
           scaledHeight = (int) (scaledHeight * scaleRatio);

        } else {
           drawX = (int) (pf.getImageableWidth() - imgWidth) / 2;
           drawY = (int) (pf.getImageableHeight() - imgHeight) / 2;
        }

        //use scale instance of draw image
        g2.drawImage((BufferedImage) image, drawX, drawY, scaledWidth, scaledHeight, null);
        g2.dispose();
        g2 = null;
        image = null;
    }

    public Doc getDoc() {
        //NOOP not used in current implementation.
        //current implementation uses pageable definition
        return null;
    }

    public MultiDoc next() {
        //NOOP not used in current implementation.
        //current implementation uses pageable definition
        return null;
    }
}
