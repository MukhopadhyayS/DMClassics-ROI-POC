/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.device.disc.rimage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.device.disc.DiscBurnerOrder;
import com.mckesson.eig.output.device.disc.rimage.orderset.OrderReference;
import com.mckesson.eig.output.device.disc.rimage.orderset.OrderSet;
import com.mckesson.eig.output.device.disc.rimage.orderset.ProductionOrderSet;
import com.mckesson.eig.output.device.disc.rimage.productionorder.ActionFixate;
import com.mckesson.eig.output.device.disc.rimage.productionorder.ActionLabel;
import com.mckesson.eig.output.device.disc.rimage.productionorder.ActionWriteTrack;
import com.mckesson.eig.output.device.disc.rimage.productionorder.Label;
import com.mckesson.eig.output.device.disc.rimage.productionorder.Media;
import com.mckesson.eig.output.device.disc.rimage.productionorder.MergeFields;
import com.mckesson.eig.output.device.disc.rimage.productionorder.ProductionOrder;
import com.mckesson.eig.output.device.disc.rimage.productionorder.ProductionOrderTarget;
import com.mckesson.eig.output.device.disc.rimage.productionorder.RecordFixate;
import com.mckesson.eig.output.device.disc.rimage.productionorder.WriteTrack;
import com.mckesson.eig.output.device.disc.rimage.productionorder.WriteTrackRecord;
import com.mckesson.eig.output.local.device.disc.rimage.RimageDiscDevice;
import com.mckesson.eig.output.local.disc.DiscDestination;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputJobFiles;
import com.mckesson.eig.output.model.OutputJobResults;
import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * @author Iryna Politykina
 * @author Latonia Howard
 */

public class RimageDiscBurnerOrder implements DiscBurnerOrder {

    private OutputJob job;
    private String clientId;
    private OutputJobFiles jobFiles;
    private String destination;
    private String userName;
    private String orderId;
    private List<String> productionOrders;
    private String orderSetId;
    private String referenceJobId;
    //using the same ActionLabel for each production order
    private ActionLabel actionLabel;
    private String mediaType;
    
    private static final Log LOG = LogFactory.getLogger(RimageDiscBurnerOrder.class);
    
    public RimageDiscBurnerOrder(OutputJob job) throws Exception {
        LOG.info("Starting create order set and production order(s) for a job");
        if (job == null) {
            LOG.error("Job is Null");
            throw new OutputException("Job is NULL", OutputErrorCode.SERVICE_ERROR);
        }
        try {
            this.job = job;
            this.actionLabel = null;
            processJobParameters();
        } catch (Exception ex) {
            LOG.error(ex.getMessage());
            throw new OutputException(OutputErrorCode.SERVICE_ERROR, ex);
        }

    }

    /**
     * Method creates production order(s) and 
     * order set.
     * @return
     * @throws Exception
     */
    public List<String> getOrders() throws Exception {
        
        List<String> ordersProduction_And_Set = new ArrayList<String>();
        try {
            List<String> productionOrders = getProductionOrdersXML();
            String orderSet = getOrderSetXML();
            ordersProduction_And_Set.add(orderSet);
            ordersProduction_And_Set.addAll(productionOrders);
        } catch (Exception ex) {
            LOG.error(ex.getMessage());
            throw new Exception(ex);
        }
        return ordersProduction_And_Set;

    }
    
    public String getOrderSetId() {
    	return orderSetId;
    }

    /**method processes parameters from job
     * creates production order(s) ids, production 
     * order set id, etc.
     * @throws Exception
     */
    private void processJobParameters() throws Exception {
        
        LOG.info("Processing job parameters.");
        // client ID equals to Output service server name
        this.clientId = OutputUtil.getServerName();
        OutputJobResults results = this.job.getOutputJobResults();
        if(results != null){
        	this.jobFiles = results.getOutputJobFiles();
        }
        if(this.jobFiles != null){
        	this.destination = this.jobFiles.getJobDirectory();
        }
        this.userName = this.job.getUserName();
        this.orderId = createUniqueOrderId(RimageConstants.PRODUCTION_ORDER_JOB_SUFIX);
        this.orderSetId = createUniqueOrderId(RimageConstants.ORDER_SET_JOB_SUFIX);
        this.referenceJobId = createUniqueOrderId(RimageConstants.JOB_ID_PREFIX);
        this.productionOrders = new ArrayList<String>();
        String outputMediaType = this.job.getPropertyValue(OutputConstants.OUTPUT_DISC_MEDIA);
        this.mediaType = RimageConstants.MEDIA_TYPES.get(outputMediaType);
        processNoMediaTypeException(outputMediaType);
    }


	private void processNoMediaTypeException(String outputMediaType) {
		if(this.mediaType == null){
            Set<String> set = RimageConstants.MEDIA_TYPES.keySet();
            StringBuffer types_string = new StringBuffer();
            boolean first =  true;
            for (String aType: set){
                if(!first){
                    types_string.append(", ");
                }
                types_string.append(aType);
                first =  false;
            }
            
            String message =  new StringBuffer(RimageConstants.MEDIA_TYPE_NOT_FOUND).append("Output job id: ").append(job.getJobSeq()).
                    append(". ").append("Output job media type : ").append(outputMediaType).append(". Available device media types: ").append(types_string.toString()).toString();
            LOG.error(message);        
            throw new OutputException(message, OutputConstants.OutputErrorCode.DEVICE_ERROR);
        }
	}


	private String createUniqueOrderId(String suffix) {
		String result = "";
        // add random to make order ID unique
		String unique = UUID.randomUUID().toString();
		result = new StringBuffer().append(this.job.getJobSeq()).append("_").append(unique).append("_").append(suffix).toString();
		return result;
	}
    
    
    /**
     * Method creates an Order set object, transforms 
     * Order set object into String  
     * @return
     * @throws Exception
     */
    private String getOrderSetXML() throws Exception {
        
        LOG.info("Creating order set.");
        OrderSet orderSet = new OrderSet();
        orderSet.setClientId(this.clientId);
        orderSet.setOrderSetId(this.orderSetId);
        orderSet.setPriority(RimageConstants.NORMAL_PRIORITY);
        orderSet.setOriginator(this.userName);
        orderSet.setReferencedJobId(this.referenceJobId);
        List<OrderReference> listOfProductionOrders = new ArrayList<OrderReference>();
        if(this.productionOrders.size() == 0){
            String message = new StringBuffer(RimageConstants.PROD_ORDERS_NOT_POPULATED).append("Output job id: ").append(job.getJobSeq()).toString();
            LOG.error(message);
            throw new OutputException(message, OutputConstants.OutputErrorCode.DEVICE_ERROR);
        }
        for (String order : this.productionOrders) {
            OrderReference ref = new OrderReference(order);
            listOfProductionOrders.add(ref);
        }
        orderSet.setOrder_references(listOfProductionOrders);
        ProductionOrderSet productionOrderSet = new ProductionOrderSet();
        productionOrderSet.setNumberOfCopies(1);
        productionOrderSet.setOrdersHaveLabels(doesJobHaveLabels());
        productionOrderSet.setMediaSize(RimageConstants.MEDIA_SIZE_DEFAULT);
        productionOrderSet.setMediaType(this.mediaType);
        orderSet.setProd_orderSet(productionOrderSet);

        return ObjectMarshaller.marshalObject(orderSet, RimageConstants.ORDER_SET_DTD);
    }

    
    /**
     * Method creates a list of production orders, associated
     * with order set. 
     * @return
     * @throws Exception
     */
    private List<String> getProductionOrdersXML() throws Exception {
        
        LOG.info("Creating production order(s).");
        List<String> productionOrdersXML = new ArrayList<String>();
        int i = 0;
        // loop create production orders XMLs
        for (String aFileName : this.jobFiles.getFileNames()) {
            // create production order object and marshal it to an XML string;
            ProductionOrder order = createProductionOrder(aFileName, i);
            String orderXml = marshallProductionOrder(order);
            productionOrdersXML.add(orderXml);
            i++;
        }

        return productionOrdersXML;
    }

    
    /**
     * method creates production order object
     * @param fileName
     * @param i
     * @return
     */
    private ProductionOrder createProductionOrder(String fileName, int i) {

        String orderId = this.orderId + "_" + i;
        ProductionOrder order = new ProductionOrder();
        order.setNumberOfCopies(1);
        order.setOrder_Id(orderId);
        order.setClient_Id(this.clientId);
        order.setPriority(RimageConstants.NORMAL_PRIORITY);
        order.setOriginator(userName);
        // using order Id for the set name and job name
        order.setReferencedSet(this.orderSetId);
        order.setReferenced_job_Id(this.referenceJobId);
        setOrderMedia(order);
        order.setTarget(new ProductionOrderTarget());
        setWriteTrackRecord(fileName, order);
        order.setFixate(new ActionFixate(new RecordFixate()));
        processLabel(i, order);
        
        // add a production order to the list , will be used later.
        this.productionOrders.add(orderId);
        return order;

    }


	private void setWriteTrackRecord(String fileName, ProductionOrder order) {
	    LOG.info("Setting track file name.");
		WriteTrackRecord writeTrackRecord = new WriteTrackRecord();
      //  writeTrackRecord.setData(new RecordData());
        String trackFileName = new StringBuffer(this.destination).append(File.separator).append(fileName).toString();
        writeTrackRecord.setTrack(new WriteTrack(trackFileName));
        order.setWritetrack(new ActionWriteTrack(writeTrackRecord));
	}


	private void setOrderMedia(ProductionOrder order) {
	    LOG.info("Setting media type.");
		Media media = new Media();
        media.setType(this.mediaType);
        order.setMedia(media);
	}
    
	private void processLabel(int i, ProductionOrder order) {
	    LOG.info("Processing label.");
		if (doesJobHaveLabels()) {
	        // add Label Details
	        order.setLabel(createActionLabel(i));
        }
	}

    private ActionLabel createActionLabel(int i) {
    	/*
    	 * variable i is not used.  Current implementation
    	 * returns the same actionLabel for all orders
    	 * 
    	 */
    	if (actionLabel == null) {
    		Label label = new Label();
    		label.setFileName(getActionLabelFile());
    		actionLabel = new ActionLabel(label);	
    		label.getBtw().setMergeFields(getMergeFields());				
    	}
    	
    	return actionLabel;   	
    }
    	
    
    private String getActionLabelFile() {
        
	 	DiscDestination destination = (DiscDestination) job.getDestination();
		RimageDiscDevice rimageDevice = (RimageDiscDevice) destination.getDiscdevice();
		
		StringBuffer labelFileName = new StringBuffer();
        labelFileName.append(rimageDevice.getTemplateLocation());
        labelFileName.append(File.separator);
        labelFileName.append(job.getPropertyValue(OutputConstants.OUTPUT_DISC_LABEL_NAME));
        labelFileName.append(RimageConstants.LABEL_FILENAME_EXT);
      
		return labelFileName.toString();
    }
    
    private boolean doesJobHaveLabels() {    	
    	return (StringUtils.isNotBlank(job.getPropertyValue(OutputConstants.OUTPUT_DISC_LABEL_NAME)));
    }
    
    /**
     * method creates a header and a value
     * for MergeField object
     * @return
     */
    private MergeFields getMergeFields() {
        
        LOG.info("Processing merge fileds for a lable.");
    	MergeFields mergeFields = new MergeFields();
    	StringBuilder fieldHeader = new StringBuilder();
    	StringBuilder fieldValues = new StringBuilder();
    		
    	List<MapModel> labelData;     
    	labelData = job.getLabelData();
    	for (MapModel labelFieldValue : labelData) {
       		fieldHeader.append("\"").append(labelFieldValue.getName()).append("\",");
       		fieldValues.append("\"").append(labelFieldValue.getValue()).append("\",");
    	}
    	//remove the last comma from the fieldHeader
    	if (fieldHeader.length() > 0)  {
    		fieldHeader.deleteCharAt( fieldHeader.length() - 1 );
    	}
    	//remove the last comma from the fieldValues
    	if (fieldValues.length() > 0)  {
    		fieldValues.deleteCharAt( fieldValues.length() - 1 );
    	}    	
    
    	mergeFields.setHeader(fieldHeader.toString());
    	mergeFields.setLine(fieldValues.toString());
    	
    	return mergeFields;
    }
    
    /**
     * method marshals Production order object
     * @param order
     * @return
     * @throws Exception
     */
    private String marshallProductionOrder(ProductionOrder order) throws Exception {
        return ObjectMarshaller.marshalObject(order, RimageConstants.PRODUCTION_ORDER_DTD);
    }
    
}
