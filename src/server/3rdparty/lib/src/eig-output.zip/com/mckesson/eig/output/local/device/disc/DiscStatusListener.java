package com.mckesson.eig.output.local.device.disc;

import java.util.List;

import com.mckesson.eig.output.model.OutputJob;

public interface DiscStatusListener {

	void discPreparationSubmitted(OutputJob job, String orderId);
	void discPreparationCompleted(Integer jobId, List<String> fileNames);
	void discPreparationInProgress(Integer jobId, String info);
	void discPreparationFailed(Integer jobId, String errMsg);
	
	void discBurningSubmitted(OutputJob job, String orderId);
	void discBurningCompleted(Integer jobId);
	void discBurningInProgress(Integer jobId, String info);
	void discBurningFailed(Integer jobId, String errMsg);
}
