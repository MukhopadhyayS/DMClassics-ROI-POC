package com.mckesson.eig.output.ci;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mckesson.eig.Security;
import com.mckesson.eig.wsfw.model.authentication.AuthenticatedResult;
import com.mckesson.eig.wsfw.security.service.Authenticator;
import com.mckesson.eig.wsfw.session.WsSession;

public class PLAuthenticator  implements Authenticator {

	private static final String EIG_USER_SECURITY_RIGHTS = "EIG_USER_SECURITY_RIGHTS";
	
	private static Log _log = LogFactory.getLog(PLAuthenticator.class);
	
	
	public String getAppID() {
		// TODO Auto-generated method stub
		return null;
	}
	
	// Phase 1: allowing all for the admin user 
	// Phase two will implement security for clinicians as well.
	private void authorize() {
		
		// Named the variables to avoid check style warning
		final int authCodeOne = 6101;
		final int authCodeTwo = 6112;
		final int authCodeThree = 6113;
		final int authCodeFour = 6112;
		final int authCodeFive = 6112;
		final int authCodeSix = 6113;
		
		int[] authorizations = {authCodeOne, authCodeTwo, authCodeThree, 
				authCodeFour, authCodeFive, authCodeSix};
		Security security = new Security();
		security.setCodes(authorizations); 
        WsSession.setSessionData(EIG_USER_SECURITY_RIGHTS, security);
	}

	public void validate() {
		// TODO Auto-generated method stub
		authorize();
		
	   AuthenticatedResult result = new AuthenticatedResult();
	   result.setState(AuthenticatedResult.AUTHENTICATED);
       WsSession.setSessionData(WsSession.AUTHRESULT, result);
		_log.info("PL Authentication Successful !");
	}

}
