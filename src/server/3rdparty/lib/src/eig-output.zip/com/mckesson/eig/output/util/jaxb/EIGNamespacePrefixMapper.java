/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.util.jaxb;

import com.mckesson.eig.output.util.OutputConstants;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;


/**
 * @author Ghazni
 * 
 * The class is used to map the namespace prefix "eig", which will be used during 
 * the serialization/de-serialize of objects.
 */
public class EIGNamespacePrefixMapper extends NamespacePrefixMapper {

    @Override
    public String getPreferredPrefix(String nsUri, String suggestion, boolean requirePrefix) {
        return OutputConstants.NS_PREFIX;
    }
}
