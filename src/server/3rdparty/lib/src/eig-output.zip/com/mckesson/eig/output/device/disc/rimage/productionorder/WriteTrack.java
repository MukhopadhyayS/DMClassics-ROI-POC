/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage.productionorder;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "WriteTrack")
public class WriteTrack {
    
    private String fielName;
    private RecordData data;

    public WriteTrack() {
    }

    public WriteTrack(String fielName) {
        super();
        this.fielName = fielName;
        this.data = new RecordData();
    }

    public String getFielName() {
        return fielName;
    }

    @XmlAttribute(name = "Filename")
    public void setFielName(String fielName) {
        this.fielName = fielName;
    }
    
    public RecordData getData() {
        return data;
    }
    @XmlElement(name = "Data")
    public void setData(RecordData data) {
        this.data = data;
    }
    

}
