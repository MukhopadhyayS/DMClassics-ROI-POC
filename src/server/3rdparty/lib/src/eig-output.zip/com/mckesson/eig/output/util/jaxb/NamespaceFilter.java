/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util.jaxb;

/**
 * @author Ghazni
 *
 */
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import org.xml.sax.helpers.XMLFilterImpl;

import com.mckesson.eig.utility.util.StringUtilities;

public class NamespaceFilter extends XMLFilterImpl {

    private String _usedNamespaceUri;
    private boolean _addNamespace;

    //State variable
    private boolean _addedNamespace = false;

    public NamespaceFilter(String namespaceUri, boolean addNamespace) {

        super();

        _usedNamespaceUri = addNamespace ? namespaceUri : StringUtilities.EMPTYSTRING;
        _addNamespace     = addNamespace;
    }

    @Override
    public void startDocument() throws SAXException {

        super.startDocument();
        if (_addNamespace) {
            startControlledPrefixMapping();
        }
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts)
    throws SAXException {
        super.startElement(_usedNamespaceUri, localName, qName, atts);
    }

    @Override
    public void endElement(String uri, String localName, String qName)
    throws SAXException {
        super.endElement(_usedNamespaceUri, localName, qName);
    }

    @Override
    public void startPrefixMapping(String prefix, String url)
    throws SAXException {

        //do not call startPrefixMapping for parent, then it will remove the namespace prefix
        if (_addNamespace) {
            startControlledPrefixMapping();
        }
    }

    private void startControlledPrefixMapping()
    throws SAXException {

        if (_addNamespace && !_addedNamespace) {

            //We should add namespace since it is set and has not yet been done.
            super.startPrefixMapping(StringUtilities.EMPTYSTRING, _usedNamespaceUri);

            //Make sure we dont do it twice
            _addedNamespace = true;
        }
    }
}
