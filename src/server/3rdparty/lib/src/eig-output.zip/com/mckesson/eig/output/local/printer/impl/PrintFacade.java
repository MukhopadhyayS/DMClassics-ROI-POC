/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.printer.impl;

import java.io.IOException;

/**
 * Interface Facade for printing
 * 
 * @author Srini Paduri
 * 
 * @since 13.5.2
 * 
 */
public interface PrintFacade {

    void addFile(String fileName) throws IOException, InterruptedException;

    void donewithJob() throws IOException, InterruptedException;

    Thread getPrintThread();

}
