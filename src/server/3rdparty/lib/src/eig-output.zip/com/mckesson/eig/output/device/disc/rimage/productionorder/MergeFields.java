/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Latonia Howard
 *
 */

package com.mckesson.eig.output.device.disc.rimage.productionorder;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "MergeFields")
@XmlType( propOrder={"header","line" })
public class MergeFields {
	
	private String header;
	private String line;

    public MergeFields() {
    }
 
	public String getHeader() {
		return header;
	}

	@XmlElement(name = "Header")
	public void setHeader(String header) {
		this.header = header;
	}

	public String getLine() {
		return line;
	}

	@XmlElement(name = "Line")
	public void setLine(String line) {
		this.line = line;
	}    
}
