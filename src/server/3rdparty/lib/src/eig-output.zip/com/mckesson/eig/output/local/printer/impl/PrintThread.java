/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.printer.impl;

import java.io.PipedInputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.SimpleDoc;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.JobName;
import javax.print.attribute.standard.MultipleDocumentHandling;

import com.mckesson.eig.output.local.printer.PrintDestination;
import com.mckesson.eig.output.local.printer.PrintListener;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * PrintThread consumes stream of data from PipedInputStream and implements
 * printing functionality in background thread.
 * 
 * Works in conjunction with corresponding thread that produces a stream of
 * data.
 * 
 * @see MultiDocStreamingThread
 * 
 * @author Srini Paduri
 * 
 * @since 13.5.2
 */
public class PrintThread implements Runnable {

	private static final Log LOG = LogFactory.getLogger(PrintThread.class);
	private final PipedInputStream _pis;
	private final OutputJob _job;
	private final PrintListener _printListener;

	public PrintThread(PipedInputStream pis, OutputJob job,
			PrintListener printListener) {
		_pis = pis;
		_job = job;
		_printListener = printListener;
	}

	public void run() {
		long startTime = System.currentTimeMillis();
		pipedInputPrint(_pis, _job,	_printListener);
		long finishTime = System.currentTimeMillis();
		LOG.debug("Finished printing in: " + (finishTime - startTime)
				+ " milliseconds");
	}
	
	private void pipedInputPrint(PipedInputStream pis, OutputJob job,
			PrintListener printListener) {
		job.logMetric("Start Print Job");
		PrintDestination destination = (PrintDestination) job.getDestination();
		String jobName = Integer.toString(job.getJobSeq());
		Map<String, String> printProperties = job.getProperties();
		if (printProperties == null) {
			printProperties = new HashMap<String, String>();
		}
		printListener.printingStart(job.getJobSeq());
		try {
			PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
			DocFlavor flavor = null;
			String format = destination.getSupportedFlavor();
			if ((format != null) && format.equals("ps")) {
				flavor = DocFlavor.INPUT_STREAM.POSTSCRIPT;
			} else {
				flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
			}
			PrintService service = destination.getNamedPrintService(destination.getPrinterName());
            LOG.debug("Started Printing...");
			if (service != null) {
				DocPrintJob printJob = service.createPrintJob();
				printJob.addPrintJobListener(printListener);
				DocAttributeSet das = new HashDocAttributeSet();
				destination.setJobProperties(printProperties, pras);
				Doc doc1 = new SimpleDoc(pis, flavor, das);
				pras.add(MultipleDocumentHandling.SINGLE_DOCUMENT_NEW_SHEET);
				pras.add(new JobName(jobName, Locale.getDefault()));
				printJob.print(doc1, pras);
				job.logMetric("Finish print job");
			}
		} catch (Exception e) {
			LOG.error(destination.getPrinterName() + ":  error printing files for jobID: "
					+ jobName, e);
			throw new ApplicationException(e);
		} finally {
			IOUtilities.close(pis);
			job.printMetric();
		}
	}
	
}
