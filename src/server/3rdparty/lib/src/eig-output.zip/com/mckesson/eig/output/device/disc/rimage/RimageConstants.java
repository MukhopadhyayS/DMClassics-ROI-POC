/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

/**
 * @author Iryna Politykina
 *
 */


package com.mckesson.eig.output.device.disc.rimage;

import java.util.HashMap;
import java.util.Map;

public class RimageConstants {
    
    //priority for Image and Production Order 
    public static final String NORMAL_PRIORITY = "Normal";
    public static final String LOW_PRIORITY = "Low";
    public static final String HIGH_PRIORITY = "High";
    
   //DTDs 
    public static final String IMAGE_ORDER_DTD = "<!DOCTYPE ImageOrder SYSTEM \"ImageOrder_1.14.DTD\">";
    public static final String PRODUCTION_ORDER_DTD = "<!DOCTYPE ProductionOrder SYSTEM \"ProductionOrder_1.14.dtd\">";
    public static final String ORDER_SET_DTD = "<!DOCTYPE OrderSet SYSTEM \"OrderSet_1.2.dtd\">";
    
    
    
  //Media constants
    public static final String MEDIA_SIZE_DEFAULT = "120mm";
    public static final  Map<String,String> MEDIA_TYPES = new HashMap<String, String>();  
    
    static{
        
        MEDIA_TYPES.put("CD", "CDR");
        MEDIA_TYPES.put("DVD", "DVDR");
        
    }
    
   //Fixate constants 
    public static final String TYPE_SAO = "SAO";

    //Production Order Set
    public static final String DEFAULT_PRODUCTION_CLUSTER = "DefaultProductionCluster";
    
    public static final String IMAGE_ORDER_JOB_SUFIX = "IO";
    public static final String PRODUCTION_ORDER_JOB_SUFIX = "PO";
    public static final String ORDER_SET_JOB_SUFIX = "OS";
    public static final String JOB_ID_PREFIX = "JI";
    
    public static final String LABEL_FILENAME_EXT = ".BTW";
    
    
    //Rimage Exceptions
    
    public static final String MEDIA_TYPE_NOT_FOUND = "Rimage error. Can not find media type.";
    public static final String CAN_NOT_CREATE_XML_EDIT_LIST_FILE = "Rimage error. Can not create XMLEditList file.";
    public static final String PROD_ORDERS_NOT_POPULATED = "Rimage error. Production orders are not populated.";
   
}
