/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfSmartCopy;
import com.lowagie.text.pdf.SimpleBookmark;


public class PdfSplit {
    private static final String PDF_EXT = ".pdf";
    private static final String SPLIT_FILE_NAME = "split_";

    public List<String> splitFile(String fileName,
                                  String outputDirectory,
                                  long maxFileSize) {
        ArrayList<String> generatedFileNames = new ArrayList<String>();
        try {
            PdfReader pdfReader = new PdfReader(fileName);
            int n = pdfReader.getNumberOfPages();

            if (n == 1) {
                //do not process single page documents.  Even if page size > maxFileSize
                //we do not split single pages into multiple pages.
                generatedFileNames.add(fileName);
            } else {
                pdfReader.removeUnusedObjects();
                pdfReader.consolidateNamedDestinations();
                 int currentPage;
                Document currentDocument = new Document(pdfReader.getPageSizeWithRotation(1));
                PdfSmartCopy pdfWriter = null;
                PdfImportedPage importedPage;
                File tmpFile = null;
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                int startPage = 0;
                int relativeCurrentPage = 0;
                int estDocSize = 0;

                //Get size of first page in document
                ByteArrayOutputStream nextPagebaos = new ByteArrayOutputStream();
                Document nextPageDocument = new Document(pdfReader.getPageSizeWithRotation(1));
                PdfSmartCopy nextPageWriter = new PdfSmartCopy(nextPageDocument, nextPagebaos);
                nextPageDocument.open();
                PdfImportedPage nextimportedPage = nextPageWriter.getImportedPage(pdfReader, 1);
                nextPageWriter.addPage(nextPageWriter.getImportedPage(pdfReader, 1));
                nextPageDocument.close();
                nextPageWriter.flush();
                nextPageWriter.close();
                nextPagebaos.close();
                estDocSize += nextPageWriter.getCurrentDocumentSize();

                for (currentPage = 1; currentPage <= n; currentPage++) {
                    relativeCurrentPage++;
                    //time to open a new document?
                    if (relativeCurrentPage == 1) {
                        startPage = currentPage;
                        tmpFile = File.createTempFile(SPLIT_FILE_NAME, PDF_EXT,
                                                      new File(outputDirectory));
                        generatedFileNames.add(tmpFile.getAbsolutePath());
                        currentDocument = new Document(pdfReader.getPageSizeWithRotation(currentPage));
                        baos = new ByteArrayOutputStream();
                        pdfWriter = new PdfSmartCopy(currentDocument, baos);
                        currentDocument.open();
                    }
                    //TODO - TEST WITH PdfCopy -- PdfSmartCopy uses a lot of memory
                    //TODO - IF there is a single page larger than maxFileSize an error is
                    //       not generated.

                    //NOTE:  current size calculation does not include templates or fonts.

                    //check current doc size
                    //add book mark size
                    //check next page size
                    if (currentPage < n) {
                        nextPagebaos = new ByteArrayOutputStream();
                        nextPageDocument = new Document(
                                                pdfReader.getPageSizeWithRotation(currentPage + 1));
                        nextPageWriter = new PdfSmartCopy(nextPageDocument, nextPagebaos);
                        nextPageDocument.open();
                        nextimportedPage = nextPageWriter.getImportedPage(pdfReader, currentPage + 1);
                        nextPageWriter.addPage(
                                           nextPageWriter.getImportedPage(pdfReader, currentPage + 1));
                        nextPageDocument.close();
                        nextPageWriter.flush();
                        nextPageWriter.close();
                        nextPagebaos.close();
                        estDocSize = nextPageWriter.getCurrentDocumentSize();
                    }

                    importedPage = pdfWriter.getImportedPage(pdfReader, currentPage);
                    pdfWriter.addPage(importedPage);
                    pdfWriter.flush();

                    int metadataLength = 0;
                    if (pdfReader.getMetadata() != null) {
                        metadataLength = pdfReader.getMetadata().length;
                    }

                    if ((currentPage == n) || ((pdfWriter.getCurrentDocumentSize()
                         + estDocSize + metadataLength
                         + pdfReader.getXrefSize()
                         + pdfReader.getCatalog().size()) > maxFileSize)) {
                        ArrayList master = new ArrayList();
                        List thisBook = SimpleBookmark.getBookmark(pdfReader);

                        if (thisBook != null) {
                           SimpleBookmark.eliminatePages(thisBook, new int[]{currentPage + 1, n});
                           if (startPage > 1) {
                               SimpleBookmark.eliminatePages(thisBook, new int[]{1, startPage - 1});
                               SimpleBookmark.shiftPageNumbers(thisBook, -(startPage - 1), null);
                           }
                           master.addAll(thisBook);
                           pdfWriter.setOutlines(master);
                        }
                        relativeCurrentPage = 0;
                        currentDocument.close();
                        FileOutputStream fos = new FileOutputStream(tmpFile);
                        baos.writeTo(fos);
                        fos.close();
                        baos.close();
                        estDocSize = 0;
                    }
                }
            }
            pdfReader.close();
            return generatedFileNames;
        } catch (Exception e) {
            return new ArrayList<String>();
        }
    }

}
