package com.mckesson.eig.output.local.mediator.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.model.OutputJob;

public abstract class MediatorFaxJob extends AbstractMediatorJob {
	
	protected List<String> _faxList = new ArrayList<String>();

    public MediatorFaxJob(OutputJob job, Destination d, DestTypeHandler handler) {
		super(job, d, handler);
    }
    
	public void doneWithJob() throws IOException, InterruptedException {
		// TODO Auto-generated method stub

	}

	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void addFile(String fileName) throws IOException,
			InterruptedException {
		_faxList.add(fileName);
	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void initializeJob(Object listener) {
		// TODO Auto-generated method stub

	}

}
