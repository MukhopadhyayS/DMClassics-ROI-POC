/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.util.status;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Date;

import org.apache.commons.lang.ObjectUtils;

import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.OutputConstants.RunState;

/**
 * Utility methods for dealing with StatusInfo and related objects
 *
 * @author Jon Anderson
 */
public final class StatusUtils {

	/**
	 * Type of object for which an event is being published
	 */
	public static enum StatusObjectType {
		/** OutputEndpoint status change */
		ENDPOINT,
		/** OutputJob status change */
		JOB,
		/** Part status change */
		PART,
		/** OutputManager status change */
		MANAGER
	}

	private StatusUtils() {
		super();
	}

	/**
	 * Figures out what type of StatusObjectType <code>o</code> is
	 *
	 * @param o not <code>null</code>
	 * @return not <code>null</code>
	 */
	public static StatusUtils.StatusObjectType typeForObject(Object o) {

		if (o instanceof ActiveEndpoint) {
			return StatusUtils.StatusObjectType.ENDPOINT;
		} else if (o instanceof OutputJob) {
			return StatusUtils.StatusObjectType.JOB;
		} else if (o instanceof JobPart) {
			return StatusUtils.StatusObjectType.PART;
		} else if (o instanceof OutputManager) {
			return StatusUtils.StatusObjectType.MANAGER;
		}

		throw new IllegalArgumentException("Unsupported object type: " + o);
	}

	/**
	 * Creates a StatusInfo object for the given runState.
	 *
	 * @param runState not <code>null</code>
	 * @return not <code>null</code>
	 */
	public static StatusInfo createRunStateStatus(RunState runState) {

		if (runState == null) {
			throw new IllegalArgumentException("runState argument is null");
		}

		StatusInfo info = new StatusInfo();
		info.setStatus(runState.toString());
		info.setStatusCode(runState.statusCode());
		info.setStatusSource(StatusUtils.createStatusSourceFromThread());
		info.setStatusDate(new Date());
		return info;
	}

	/**
	 * Creates a StatusInfo object for the given requestStatus
	 *
	 * @param requestStatus not <code>null</code>
	 * @param detail detail portion for the statusInfo may be <code>null</code>
	 * @return not <code>null</code>
	 */
	public static StatusInfo createRequestStatus(
			RequestStatus requestStatus,
			String detail) {

		if (requestStatus == null) {
			throw new IllegalArgumentException("requestStatus argument is null");
		}
		StatusInfo info = new StatusInfo();
		info.setDetail(detail);
		info.setStatus(requestStatus.statusString());
		info.setStatusCode(requestStatus.statusCode());
		info.setStatusSource(StatusUtils.createStatusSourceFromThread());
		info.setStatusDate(new Date());
		return info;
	}

	/**
	 * Tests if the status represents a pause state
	 *
	 * @param info may  be <code>null</code>
	 * @return true if pause
	 */
	public static boolean isStatusPause(StatusInfo info) {

		if (info != null) {

			int statusCode = info.getStatusCode();
			return statusCode == RunState.PAUSE.statusCode()
				|| statusCode == RequestStatus.PAUSED.statusCode()
				|| statusCode == EndpointStatus.PAUSED.statusCode();

		}
		return false;
	}

	/**
	 * Tests if the status represents a stop state
	 *
	 * @param info may  be <code>null</code>
	 * @return true if stop
	 */
	public static boolean isStatusStop(StatusInfo info) {

		if (info != null) {

			int statusCode = info.getStatusCode();
			return statusCode == RunState.STOP.statusCode()
			    || statusCode == RunState.INIT.statusCode()
				|| statusCode == EndpointStatus.STOPPED.statusCode();
		}
		return false;
	}

	/**
	 * Used for RequestStatus's to determine if a job is complete or
	 * canceled
	 *
	 * @param info may be <code>null</code>
	 * @return true if done
	 */
	public static boolean isStatusDone(StatusInfo info) {

	    if (info != null) {

	        int statusCode = info.getStatusCode();
	        return statusCode == RequestStatus.CANCELED.statusCode()
	        || statusCode == RequestStatus.COMPLETED.statusCode();
	    }
	    return false;
	}

	/**
	 * Tests if the status represents a init state
	 *
	 * @param info may  be <code>null</code>
	 * @return true if stop
	 */
	public static boolean isStatusInit(StatusInfo info) {

		if (info == null) {
			return true;
		}
		return info.getStatusCode() == RunState.INIT.statusCode();
	}

	/**
	 * Tests if the status represents a run state
	 *
	 * @param info may  be <code>null</code>
	 * @return true if run
	 */
	public static boolean isStatusRun(StatusInfo info) {

		if (info != null) {
			return info.getStatusCode() == RunState.RUN.statusCode();
		}
		return false;
	}

	/**
	 * Creates a StatusInfo object for the given EndpointStatus
	 *
	 * @param status not <code>null</code>
	 * @param detail detail portion for the statusInfo may be <code>null</code>
	 * @return not <code>null</code>
	 */
	public static StatusInfo createEndpointStatus(
			EndpointStatus status,
			String detail) {

		if (status == null) {
			throw new IllegalArgumentException("status argument is null");
		}

		StatusInfo info = new StatusInfo();
		info.setStatus(status.statusString());
		info.setStatusCode(status.statusCode());
		info.setStatusSource(StatusUtils.createStatusSourceFromThread());
		info.setDetail(detail);
		info.setStatusDate(new Date());
		return info;
	}

	/**
	 * Looks up the calling method from a stack trace and formats with the
	 * thread name
	 *
	 * @return not <code>null</code>
	 */
	public static String createStatusSourceFromThread() {

		StackTraceElement[] stack = Thread.currentThread().getStackTrace();

		String myClassName = StatusUtils.class.getName();
		String methodName = null;

		for (StackTraceElement element : stack) {

			String elemClassName = element.getClassName();
			if (!elemClassName.equals(myClassName)
					&& elemClassName.startsWith("com.mckesson.eig")) {
				methodName = element.getMethodName();
				break;
			}
		}

		if (methodName == null) {
			methodName = "unknown method";
		}

		StringBuffer sb = new StringBuffer();
		sb.append(methodName);
		sb.append("-");
		sb.append(Thread.currentThread().getName());

		return sb.toString();
	}

	/**
	 * Is the StatusEvent's objectType one of the given objectTypes
	 *
	 * @param event not <code>null</code>
	 * @param objectTypes if <code>null</code> returns true
	 * @return <code>true</code> if <code>objectTypes</code> is <code>null</code>
	 * or contains the object type of the event
	 */
	public static boolean isEventForTypes(
			StatusEvent event,
			StatusUtils.StatusObjectType[] objectTypes) {

		if (event == null) {
			throw new IllegalArgumentException("event argument is null");
		}
		if (objectTypes == null) {
			return true;
		}

		StatusUtils.StatusObjectType eventType = event.getObjectType();
		for (StatusUtils.StatusObjectType typesType : objectTypes) {

			if (typesType == eventType) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Is the StatusEvent's source one of the given objects
	 *
	 * @param event not <code>null</code>
	 * @param objects if <code>null</code> returns true
	 * @return <code>true</code> if <code>objects</code> is <code>null</code>
	 * or contains the source of the event
	 */
	public static boolean isEventForObjects(StatusEvent event, Object[] objects) {

		if (event == null) {
			throw new IllegalArgumentException("event argument is null");
		}
		if (objects == null) {
			return true;
		}

		Object eventObject = event.getSource();
		long jobID;
		if (event.getObjectType() == StatusObjectType.PART) {
			jobID = ((JobPart) eventObject).getJobID();
		} else {
			jobID = 0;
		}

		for (Object object : objects) {

			if (object == eventObject) {
				return true;
			}
			if (object instanceof OutputJob && jobID != 0) {

				if (ObjectUtils.equals(((OutputJob) object).getJobName(), jobID)) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Tests if the statusInfo means OK as some status'es have various meanings
	 * for OK
	 *
	 * @param currentStatus may be <code>null</code>
	 * @return true if ok
	 */
	public static boolean isStatusOK(StatusInfo currentStatus) {
		if (currentStatus != null) {

		    int code = currentStatus.getStatusCode();
		    return code == RunState.RUN.statusCode()
		        || code == RunState.INIT.statusCode()
		        || code == EndpointStatus.OK.statusCode()
		        || code == RequestStatus.SENT.statusCode()
		        || code == RequestStatus.PROCESSING.statusCode()
		        || code == EndpointStatus.ERR_HELP.statusCode()
		        || code == EndpointStatus.ERR_RECOVERABLE.statusCode();
		}

		return false;
	}
	
	public static boolean isSameStatus(StatusInfo currentStatus, RequestStatus requestStatus) {
	    return currentStatus.getStatusCode() == requestStatus.statusCode();
	}
	

	/**
	 * Null safe, Do the two statusInfos have the same statusCode
	 *
	 * @param statusInfo1 may be <code>null</code>
	 * @param statusInfo2 may be <code>null</code>
	 * @return true if equals
	 */
	public static boolean logicallyEquals(
	        StatusInfo statusInfo1,
			StatusInfo statusInfo2) {

		if (statusInfo1 == null) {
			if (statusInfo2 == null) {
				return true;
			}
			return false;
		} else if (statusInfo2 == null) {
			return false;
		}

		return statusInfo1.getStatusCode() == statusInfo2.getStatusCode();
	}

	/**
	 * Tests if the statusInfo means error as some status'es have various meanings
	 * for error
	 *
	 * @param statusInfo may be <code>null</code>
	 * @return true if error
	 */
	public static boolean isStatusError(StatusInfo statusInfo) {
		if (statusInfo != null) {

		    int code = statusInfo.getStatusCode();
		    return code == EndpointStatus.ERR_HELP.statusCode()
		    	|| code == EndpointStatus.ERR_RECOVERABLE.statusCode()
		    	|| code == EndpointStatus.ERR_UNKNOWN.statusCode()
		        || code == RequestStatus.ERROR.statusCode();
		}
		return false;
	}

	/**
	 * Dumps the contents of a StatusEvent to the writer
	 *
	 * @param statusEvent may be <code>null</code>
	 * @param writer not <code>null</code>
	 */
	public static void dumpStatusEvent(
	        StatusEvent statusEvent,
	        Writer writer) {

	    if (writer == null) {
	        throw new IllegalArgumentException("writer argument is null");
	    }

	    PrintWriter printWriter = OutputUtil.toPrintWriter(writer);
	    if (statusEvent == null) {
	        printWriter.append("null");
	        return;
	    }

	    printWriter.print("objectType: ");
	    printWriter.println(statusEvent.getObjectType());
        printWriter.print("source: ");
        printWriter.println(statusEvent.getSource());
        printWriter.print("newStatus: ");
        OutputUtil.dumpStatusInfo(statusEvent.getNewStatus(), printWriter);
        printWriter.print("previousStatus: ");
        OutputUtil.dumpStatusInfo(statusEvent.getPreviousStatus(), printWriter);
	}

    /**
     * Dumps the contents of the StatusEvent to a string
     *
     * @param statusEvent may be <code>null</code>
     * @return not null dump of contents
     */
    public static String dumpStatusEvent(StatusEvent statusEvent) {
        StringWriter writer = new StringWriter();
        dumpStatusEvent(statusEvent, writer);
        return writer.getBuffer().toString();
    }

}
