/*
 * Copyright 2008-2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.StringTokenizer;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.OutputTransforms;
import com.mckesson.eig.utility.metric.AccumulateTimedMetric;
import com.mckesson.eig.utility.metric.Metric;
import com.mckesson.eig.utility.util.BooleanUtilities;
import com.mckesson.eig.utility.util.CollectionUtilities;

/**
 * <code>OutputJob</code> represents an <code>AbstractOutputRequest</code> that
 * is being actively processed by the OutputService.
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "outputJob")
@XmlType(name = "outputJob")
public class OutputJob extends AbstractOutputRequest<JobPart> {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 11;
	private static final int HASH_INIT = 9;
	private static final String JOB_DETAILS_DELIMITER = "|";
	private static final String JOB_DETAILS_PROPERTY_DELIMITER = "}";
	private static final String JOB_DETAILS_TRANSFORM = "transform.";
	private static final String CONTINUE_IF_SOURCE_FAIL = "onSourceFailContinue";
	private static final String DOCUMENT_SEPERATOR = "document.seperator";

	private int _jobSeq;
	private int _orgSeq;
	private String _jobName;
	private int _pages;
	private StatusInfo _statusInfo;
	private int _statusID;
	private String _userName;
	private String _baseLocation;
	private String _currentLocation;
	private String _nextLocation;
	private List<JobPart> _parts;
	private String _requestXML;
	private String _resultsXML;
	private int _createdBy;
	private int _modifiedBy;
	private Date _createdDate;
	private Date _modifiedDate;
	private int _recordVersion;
	private int _totalPages;
	private String _jobDetails;
	private String _processingServer;
	private transient Destination _destination;
	private transient Metric _performanceMetric;
	private String _statusDetail;

	
	//15.2 - added return results for Output Job - File Destination
	private OutputJobResults _outputJobResults;

	/**
	 * default constructor
	 */
	public OutputJob() {
		super();
	}

	@Override
	public boolean equals(Object o) {

		if (!super.equals(o)) {
			return false;
		}

		OutputJob job = (OutputJob) o;

		if (_jobSeq != job._jobSeq) {
			return false;
		}
		if (!ObjectUtils.equals(job._jobName, _jobName)) {
			return false;
		}
		if (!ObjectUtils.equals(job._statusInfo, _statusInfo)) {
			return false;
		}
		if (!ObjectUtils.equals(job._currentLocation, _currentLocation)) {
			return false;
		}
		if (!ObjectUtils.equals(job._parts, _parts)) {
			return false;
		}

		return true;
	}

	@Override
	public int hashCode() {

		HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
		builder.appendSuper(super.hashCode());
		builder.append(_jobName);
		builder.append(_statusInfo);
		builder.append(_currentLocation);
		builder.append(_parts);
		return builder.toHashCode();
	}

	/**
	 * Holds the primary key of the job.
	 *
	 * @return
	 */
	public int getJobSeq() {
		return _jobSeq;
	}

	/**
	 * @param jobSeq
	 */
	@XmlElement(name = "jobSeq")
	public void setJobSeq(int jobSeq) {
		_jobSeq = jobSeq;
	}

	@Override
	public List<JobPart> getParts() {
		return _parts;
	}

	@Override
	@XmlElementWrapper(name = "parts")
	@XmlElement(name = "jobPart", type = JobPart.class)
	public void setParts(List<JobPart> parts) {
		_parts = parts;
	}

	/**
	 * @return may be <code>null</code>
	 */
	public String getJobName() {
		return _jobName;
	}

	/**
	 * @param id
	 */
	@XmlElement(name = "jobName")
	public void setJobName(String name) {
		_jobName = name;
	}

	/**
	 * StatusInfo represents the current status of the job as a whole.
	 * Individual parts may have their own status.
	 *
	 * @return status info object for the job.
	 */
	public StatusInfo getStatusInfo() {

		if (_statusInfo == null) {
			_statusInfo = new StatusInfo();
		}
		return _statusInfo;
	}

	/**
	 * @param statusInfo
	 */
	@XmlElement(name = "statusInfo", type = StatusInfo.class)
	public void setStatusInfo(StatusInfo statusInfo) {
		_statusInfo = statusInfo;
	}

	/**
	 * Description of the current location of the part or job. Most likely a URN
	 *
	 * @return the _currentLocation member
	 */
	public String getCurrentLocation() {
		return _currentLocation;
	}

	/**
	 * @param currentLocation
	 */
	@XmlElement(name = "currentLocation")
	public void setCurrentLocation(String currentLocation) {
		_currentLocation = currentLocation;
	}

	/**
	 * Description of the base location of the part or job. Most likely a URN
	 *
	 * @return the _baseLocation member
	 */
	public String getBaseLocation() {
		return _baseLocation;
	}

	/**
	 * @param baseLocation
	 */
	public void setBaseLocation(String baseLocation) {
		_baseLocation = baseLocation;
	}

	/**
	 * ID of the organization which submitted the job.
	 *
	 * TODO - This will be defaulted to zero for now. Added to accomplish future
	 * enhancements.
	 *
	 * @return
	 */
	public int getOrgSeq() {
		return _orgSeq;
	}

	/**
	 * @param orgSeq
	 */
	public void setOrgSeq(int orgSeq) {
		_orgSeq = orgSeq;
	}

	/**
	 * Represents the number of pages for the job.
	 *
	 * TODO - This will be defaulted to zero for now. Added to accomplish future
	 * enhancements.
	 *
	 * @return number of pages in the job.
	 */
	public int getPages() {
		return _pages;
	}

	/**
	 * @param pages
	 */
	public void setPages(int pages) {
		_pages = pages;
	}

	/**
	 * This field holds the request xml representation of the output request.
	 *
	 * @return the xml representation of the output request
	 */
	public String getRequestXML() {
		return _requestXML;
	}

	/**
	 * @param requestxml
	 */
	public void setRequestXML(String requestxml) {
		_requestXML = requestxml;
	}

	/**
	 * This field holds the request xml representation of the output results.
	 *
	 * @return the xml representation of the output results
	 */
	public String getResultsXML() {
		return _resultsXML;
	}

	/**
	 * @param resultsxml
	 */
	public void setResultsXML(String resultsxml) {
		_resultsXML = resultsxml;
		//15.2 load resultsObject
		OutputJobResults outputJobResults = new OutputJobResults();
		if (_resultsXML != null) {
			outputJobResults.loadResults(_resultsXML);
		} 
		setOutputJobResults(outputJobResults);
	}	
	
	/**
	 * TODO
	 *
	 * @return the _nextLocation
	 */
	public String getNextLocation() {
		return _nextLocation;
	}

	/**
	 * TODO
	 *
	 * @param nextLocation
	 *            the _nextLocation to set
	 */
	public void setNextLocation(String nextLocation) {
		_nextLocation = nextLocation;
	}

	/**
	 * Represents the user who created the job.
	 *
	 * @return the job creator id
	 */
	public int getCreatedBy() {
		return _createdBy;
	}

	/**
	 * @param createdBy
	 */
	public void setCreatedBy(int createdBy) {
		_createdBy = createdBy;
	}

	/**
	 * Represents the user who modified the job.
	 *
	 * @return the id of the user who modified the job
	 */
	public int getModifiedBy() {
		return _modifiedBy;
	}

	/**
	 * @param modifiedBy
	 */
	public void setModifiedBy(int modifiedBy) {
		_modifiedBy = modifiedBy;
	}

	/**
	 * Represents the job creation date.
	 *
	 * @return job creation date
	 */
	public Date getCreatedDate() {
		return _createdDate;
	}

	/**
	 * @param createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		_createdDate = createdDate;
	}

	/**
	 * Represents the job modification date.
	 *
	 * @return
	 */
	public Date getModifiedDate() {
		return _modifiedDate;
	}

	/**
	 * @param modifiedDate
	 */
	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	/**
	 * Represents the record version which is used to avoid concurrent
	 * modification in hiberanate
	 *
	 * @return
	 */
	public int getRecordVersion() {
		return _recordVersion;
	}

	/**
	 * @param recordVersion
	 */
	public void setRecordVersion(int recordVersion) {
		_recordVersion = recordVersion;
	}

	/**
	 * This holds the status ID. This will not passed to the client. This is
	 * used only for the hibernate mapping as the status code is embedded within
	 * a StatusInfo object, which is not accepted by hibernate in the given
	 * scenario.
	 *
	 * @return status id of the job
	 */
	public int getStatusID() {
		return _statusID;
	}

	/**
	 * @param statusID
	 */
	public void setStatusID(int statusID) {

		getStatusInfo().setStatusCode(statusID);
		_statusID = statusID;
	}

	/**
	 * This holds the user name who submits the job. This will not passed to the
	 * client as it is. This is used only for the hibernate mapping as the
	 * status code is embedded within a SubmitInfo object, which is not accepted
	 * by hibernate in the given scenario.
	 *
	 * @return status id of the job
	 */
	public String getUserName() {

		if (_userName == null) {
			_userName = getSubmitInfo().getUser();
		}
		return _userName;
	}

	/**
	 * @param userName
	 */
	public void setUserName(String userName) {

		_userName = userName;
	}

	public String getJobDetails() {
		return _jobDetails;
	}

	@XmlElement(name = "jobDetails")
	public void setJobDetails(String jobDetails) {
		_jobDetails = jobDetails;
		if (getProperties() == null) {
			setProperties(new HashMap<String, String>());
		}

		// SAVE DESTTYPE,DESTNAME

		StringTokenizer st = new StringTokenizer(_jobDetails,
				JOB_DETAILS_DELIMITER);
		while (st.hasMoreTokens()) {
			StringTokenizer propertyST = new StringTokenizer(st.nextToken(),
					JOB_DETAILS_PROPERTY_DELIMITER);
			String key = "UNKNOWN";
			String value = "UNKNOWN";

			if (propertyST.hasMoreTokens()) {
				key = propertyST.nextToken();
			}

			if (propertyST.hasMoreTokens()) {
				value = propertyST.nextToken();
			}
			getProperties().put(key, value);
		}

		String destName = getPropertyValue(OutputConstants.DEST_NAME);
		String destType = getPropertyValue(OutputConstants.DEST_TYPE);
		if (destName == null) {
			destName = "UNKNOWN";
		}
		if (destType == null) {
			destType = "UNKNOWN";
		}
		setDestName(destName);
		setDestType(destType);

	}

	/*
	 * This method sets jobDetails needed for Output Monitor Job Details view
	 * jobDetails will be added as a property and stored with the original
	 * request details. This value of this property contains a delimited string
	 * with the properties required for monitor job details view
	 *
	 * TODO: set default properties from DESTINATION TYPE AND THEN OVERRIDE WITH
	 * properties set from JOB.
	 */
	public String getRequestJobDetails(OutputRequest request) {
		// copy destName and destType - set in OutputManager createJob: always
		// exists
		// copy all current job properties
		// add properties for applied transforms
		StringBuilder jobDetailsStr = new StringBuilder();

		jobDetailsStr.append(OutputConstants.DEST_NAME
				+ JOB_DETAILS_PROPERTY_DELIMITER + getDestName());
		jobDetailsStr.append(JOB_DETAILS_DELIMITER);
		jobDetailsStr.append(OutputConstants.DEST_TYPE
				+ JOB_DETAILS_PROPERTY_DELIMITER + getDestType());
		jobDetailsStr.append(JOB_DETAILS_DELIMITER);

		Iterator<Entry<String, String>> iter = getProperties().entrySet()
				.iterator();
		while (iter.hasNext()) {
			Entry<String, String> property = iter.next();
			jobDetailsStr.append(property.getKey()
					+ JOB_DETAILS_PROPERTY_DELIMITER + property.getValue());
			if (iter.hasNext()) {
				jobDetailsStr.append(JOB_DETAILS_DELIMITER);
			}
		}

		// Add properties for transforms
		HashMap<String, String> tmpTransformProp = new HashMap<String, String>();
		// default transforms setting to NO
		if (jobDetailsStr.length() > 0) {
			jobDetailsStr.append(JOB_DETAILS_DELIMITER);
		}
		for (OutputTransforms transforms : OutputTransforms.values()) {
			tmpTransformProp.put(JOB_DETAILS_TRANSFORM + transforms.toString(),
					OutputConstants.NO);
		}

		for (OutputTransform trans : getJobAndPartTransforms(request)) {
			tmpTransformProp.put(JOB_DETAILS_TRANSFORM
					+ trans.getTransformType(), OutputConstants.YES);
			if (trans.getProperties() != null) {
				tmpTransformProp.putAll(trans.getProperties());
			}
		}
	
		iter = tmpTransformProp.entrySet().iterator();
		while (iter.hasNext()) {
			Entry<String, String> property = iter.next();
			jobDetailsStr.append(property.getKey()
					+ JOB_DETAILS_PROPERTY_DELIMITER + property.getValue());
			if (iter.hasNext()) {
				jobDetailsStr.append(JOB_DETAILS_DELIMITER);
			}
		}

		return jobDetailsStr.toString();

	}
	
	private List<OutputTransform>  getJobAndPartTransforms(OutputRequest req) {
		ArrayList<OutputTransform> transformList = new ArrayList<OutputTransform> ();
		
		//get job transforms
		if (getTransforms() != null) {
				for (OutputTransform trans : getTransforms()) {
				transformList.add(trans);
			}
		}
		
		if (req != null) {
			
			List<RequestPart> reqParts = req.getParts();
			if (reqParts != null) {
				
				//Only need to look at the first part (transforms for all parts are the same)
				//We only want the transform type not the details for part transforms (ie. HEADER_FOOTER)
				if (CollectionUtilities.hasContent(reqParts) 
						&& CollectionUtilities.hasContent(reqParts.get(0).getTransforms())) {
					
					for (OutputTransform partTrans : reqParts.get(0).getTransforms()) {
						
						OutputTransform tmpPartTrans = new OutputTransform();
						tmpPartTrans.setTransformName(partTrans.getTransformName());
						tmpPartTrans.setTransformType(partTrans.getTransformType());
						transformList.add(tmpPartTrans);
					}
				}
			}
				
		}
		
		return transformList;
	}

	@XmlTransient
	public void setTotalPages(int totalPages) {
		_totalPages = totalPages;
	}

	public int getTotalPages() {
		return _totalPages;
	}

	public Destination getDestination() {
		return _destination;
	}

	@XmlTransient
	public void setDestination(Destination destination) {
		_destination = destination;
	}

	public String getProcessingServer() {
		return _processingServer;
	}

	public void setProcessingServer(String processingServer) {
		_processingServer = processingServer;
	}

	public void logMetric(String message) {
		if (_performanceMetric == null) {
			_performanceMetric = AccumulateTimedMetric.start();
		}
		_performanceMetric.logMetric(message);
	}

	public Metric getMetric() {
		if (_performanceMetric == null) {
			_performanceMetric = AccumulateTimedMetric.start();
		}
		return _performanceMetric;
	}

	public void printMetric() {
		_performanceMetric.printMetric();
	}
	
	public boolean haveDocumentSeperator() {
		String s = getPropertyValue(OutputJob.DOCUMENT_SEPERATOR);
		return BooleanUtilities.valueOf(s, false);
	}

	public boolean isContinueIfFail() {
		String s = getPropertyValue(OutputJob.CONTINUE_IF_SOURCE_FAIL);
		return BooleanUtilities.valueOf(s, false);
	}
	
	@XmlElement(name = "outputJobResults", type = OutputJobResults.class)	
	public void setOutputJobResults(OutputJobResults outputJobResults) {
		_outputJobResults = outputJobResults;
	}
	
	public OutputJobResults getOutputJobResults() {
		return _outputJobResults;
	}

	public String getStatusDetail() {
		return _statusDetail;
	}

	public void setStatusDetail(String statusDetail) {
		_statusDetail = statusDetail;
	}
	
 
}
