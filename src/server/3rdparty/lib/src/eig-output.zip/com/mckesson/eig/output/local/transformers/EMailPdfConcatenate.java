/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.transformers;

import java.util.List;

import com.mckesson.eig.output.model.OutputJob;

public class EMailPdfConcatenate extends ROIPdfConcatenate {
	private static String EMAIL_DIR = "EMAILCONCAT";

	public EMailPdfConcatenate() {
		super();
	}

	public List<String> concatenate(OutputJob job, long size) {
		List<String> allDocs = super.concatenate(job, size);
		return generateMailAttachments(job, allDocs, size);
	}

	private List<String> generateMailAttachments(OutputJob job, List<String> attachmentPdfs, long size)	{
		String location = getTempDirectory(job, EMAIL_DIR);
		String baseFileName = _nameStrategy.createJobCollectionName(job);
		List<String> result = addFilesToPdfAsContainer(location, baseFileName, attachmentPdfs, size, true, true);
		return result;
	}
}
