package com.mckesson.eig.output.local.transformers;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class RMHeaderFooterProcessor {

	private static final int MARGIN_10 = 10;
	private static final int FONT_SIZE_10 = 10;
	private static final Font FONT_10 = FontFactory.getFont(
			FontFactory.COURIER_BOLD, FONT_SIZE_10);
	private static final float RIGHT_CELL_SIZE = 0.20f;
	private static final float LEFT_CELL_SIZE = 0.20f;
	private static final float CENTER_CELL_SIZE = 0.60f;
	private static final float CENTER_CELL_FULL_SIZE = 1.00f;

	private static final Log LOGGER = LogFactory.getLogger("RMHeaderFooterProcessor.class");

	public void addHeaderFooter(InputStream in, OutputStream out,
			Map<String, String> properties) {
		try {
			float pageHeight = 0;
			float pageWidth = 0;
			PdfPCell defaultEmptyCell;
			defaultEmptyCell = new PdfPCell();
			defaultEmptyCell.setBorder(0);
			PdfReader reader = new PdfReader(in);

			int jobTotalPage = getIntProperty(properties,
					OutputConstants.JOB_TOTAL_PAGES);
			int currJobPage = getIntProperty(properties,
					OutputConstants.JOB_CURRENT_PAGE_NUM);
			int partTotalPage = getIntProperty(properties,
					OutputConstants.PART_TOTAL_PAGES);
			int currPartPage = getIntProperty(properties,
					OutputConstants.PART_CURRENT_PAGE_NUM);

			// does not support documents with interactive content
			float[] widths3 = { RIGHT_CELL_SIZE, CENTER_CELL_SIZE, LEFT_CELL_SIZE };
			float[] widths1 = { CENTER_CELL_FULL_SIZE };
			int totalPages = reader.getNumberOfPages();
			pageHeight = reader.getPageSize(1).getHeight();
			pageWidth = reader.getPageSize(1).getWidth();
			Rectangle documentSize = new Rectangle(0, 0, pageWidth, pageHeight);
			Document document = new Document(documentSize);
			PdfWriter writer = PdfWriter.getInstance(document, out);
			document.open();
			PdfContentByte directcontent = writer.getDirectContent();
			PdfImportedPage page;
			Image image;
			for (int i = 1; i <= totalPages; i++) {
				page = writer.getImportedPage(reader, i);

				PdfPTable header = new PdfPTable(widths1);
				// 20: 20 pixels 10 on either side - maximum allowed for print
				// area
				header.setTotalWidth(page.getWidth() - document.leftMargin()
						- document.rightMargin());
				header.setSpacingAfter(MARGIN_10);

				PdfPTable footer = new PdfPTable(widths3);
				footer.setTotalWidth(page.getWidth() - document.leftMargin()
						- document.rightMargin());
				footer.setSpacingBefore(MARGIN_10);

				setCenterCell(header,
						properties.get(OutputConstants.HEADER_CENTER),
						defaultEmptyCell);

				setRelativePage(footer,
						properties.get(OutputConstants.FOOTER_RIGHT),
						currPartPage + i - 1,
						partTotalPage, defaultEmptyCell);

				setCenterCell(footer,
					getStringProperty(properties,
							OutputConstants.FOOTER_CENTER),
							defaultEmptyCell);

				setAbsolutePage(footer,
						properties.get(OutputConstants.FOOTER_LEFT),
						currJobPage + i - 1,
						jobTotalPage, defaultEmptyCell);

				if (header.getTotalHeight() > 0) {
					header.writeSelectedRows(0, -1,
							document.leftMargin(),
							page.getHeight() - document.topMargin(),
							directcontent);
				}

				if (footer.getTotalHeight() > 0) {
					footer.writeSelectedRows(0, -1,
						document.leftMargin(),
						document.bottomMargin()
						+ footer.getTotalHeight(),
						directcontent);
				}

				image = Image.getInstance(page);
				image.scaleAbsolute(pageWidth,
					pageHeight - (document.topMargin()
					+ document.bottomMargin()
					+ footer.getTotalHeight()
					+ header.getTotalHeight()));
				image.setAbsolutePosition(0,
					(document.bottomMargin()
					+ footer.getTotalHeight()));
				directcontent.addImage(image);
				document.newPage();
			}
			document.close();
			if (reader != null) {
				reader.close();
			}
		} catch (Exception e) {
			throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
		}
	}

	private int getIntProperty(Map<String, String> properties, String key) {
		return Integer.parseInt(properties.get(key));
	}

	private String getStringProperty(Map<String, String> properties, String key) {
		return properties.get(key);
	}
    //content is the key.  if this key is not present this item will
    //not appear in the header
    private void setCenterCell(PdfPTable pTable,
                               String content,
                               PdfPCell defaultEmptyCell) {
        if (content == null) {
            pTable.addCell(defaultEmptyCell);

        } else {

            Phrase tmpPhrase = new Phrase(content, FONT_10);
            PdfPCell cell = new PdfPCell(tmpPhrase);
            cell.setBorder(0);
            cell.setVerticalAlignment(Element.ALIGN_TOP);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            pTable.addCell(cell);
        }
    }

    private void setRelativePage(PdfPTable pTable,
                                 String content,
                                 int currentPage,
                                 int totalPages,
                                 PdfPCell defaultEmptyCell) {
        if (content == null || totalPages <= 0) {
            pTable.addCell(defaultEmptyCell);
        } else {
           Phrase tmpPhrase = new Phrase("Page "
                                           + currentPage
                                           + " of "
                                           + totalPages, FONT_10);
            PdfPCell cell = new PdfPCell(tmpPhrase);
            cell.setBorder(0);
            cell.setVerticalAlignment(Element.ALIGN_TOP);
            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            pTable.addCell(cell);
        }
    }

    private void setAbsolutePage(PdfPTable pTable,
								String content,
                                int currentPage,
                                int totalPages,
								PdfPCell defaultEmptyCell) {
        if (content == null || totalPages <= 0) {
            pTable.addCell(defaultEmptyCell);
        } else {
            Phrase tmpPhrase = new Phrase(currentPage
                                           + " of "
                                           + totalPages, FONT_10);
            PdfPCell cell = new PdfPCell(tmpPhrase);
            cell.setBorder(0);
            cell.setVerticalAlignment(Element.ALIGN_TOP);
            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            pTable.addCell(cell);
        }
    }

}
