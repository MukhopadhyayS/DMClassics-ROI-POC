/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util.status;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map.Entry;

import com.mckesson.eig.output.util.status.StatusUtils.StatusObjectType;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * Support class for managing StatusEvent listeners and publishing StatusEvents.
 * Listeners added to this class will only be added once regardless of how
 * many times addStatusChangeListener is called for the listener
 *
 * @author Jon Anderson
 */
public class StatusChangeSupport {
    private static final Log LOG =
    	LogFactory.getLogger(StatusChangeSupport.class);

	private HashMap<StatusChangeListener, ListenerOptions> _listeners =
		new HashMap<StatusChangeListener, ListenerOptions>();
	private Object _semaphore = new Object();

	/**
	 * Simple constructor
	 */
	public StatusChangeSupport() {
		super();
	}

	/**
	 * Adds a change listener which listens to all <code>StatusEvent</code>
	 * if the listener has previously been added with an StatusObjectType or
	 * a specific object, it will be overwritten.
	 *
	 * @param changeListener not <code>null</code>
	 */
	public void addStatusChangeListener(StatusChangeListener changeListener) {

		if (changeListener == null) {
			throw new IllegalArgumentException(
					"changeListener argument is null");
		}

		synchronized (_semaphore) {
			_listeners.put(changeListener, new ListenerOptions());
		}
	}

	/**
	 * Returns all the listeners added to this object
	 *
	 * @return not <code>null</code>
	 */
	public Collection<StatusChangeListener> getStatusChangeListeners()  {
		synchronized (_semaphore) {
			return _listeners.keySet();
		}
	}

	/**
	 * Add a listener which will only receive events for the given objectType
	 *
	 * @param objectType not <code>null</code> type of objects for which to
	 * receive events
	 * @param changeListener not <code>null</code> listener
	 */
	public void addStatusChangeListener(
			StatusObjectType objectType,
			StatusChangeListener changeListener) {

		if (objectType == null) {
			throw new IllegalArgumentException("objectType argument is null");
		}
		if (changeListener == null) {
			throw new IllegalArgumentException(
					"changeListener argument is null");
		}

		ListenerOptions options;
		synchronized (_semaphore) {

			options = _listeners.get(changeListener);

			if (options == null) {
				options = new ListenerOptions();
				_listeners.put(changeListener, options);
			}
		}

		StatusUtils.StatusObjectType[] types = options.getTypes();
		if (types == null) {

			types = new StatusUtils.StatusObjectType[] { objectType };

		} else {

			StatusUtils.StatusObjectType[] newTypes =
				new StatusUtils.StatusObjectType[types.length + 1 ];
			System.arraycopy(types, 0, newTypes, 0, types.length);
			newTypes[newTypes.length - 1] = objectType;
			types = newTypes;
		}

		options.setTypes(types);
	}

	/**
	 * Adds a listener which will only receive events for the given object
	 *
	 * @param statusObject not <code>null</code> object to listen for
	 * @param changeListener not <code>null</code> listener
	 */
	public void addStatusChangeListener(
			Object statusObject,
			StatusChangeListener changeListener) {

		if (statusObject == null) {
			throw new IllegalArgumentException("statusObject argument is null");
		}
		if (changeListener == null) {
			throw new IllegalArgumentException(
					"changeListener argument is null");
		}

		// validate the object can be listened to
		StatusUtils.typeForObject(statusObject);

		ListenerOptions options;
		synchronized (_semaphore) {
			options = _listeners.get(changeListener);
			if (options == null) {
				options = new ListenerOptions();
				_listeners.put(changeListener, options);
			}
		}

		Object[] objects = options.getStatusObjects();
		if (objects == null) {
			objects = new Object[] { statusObject };
		} else {
			Object[] newObjects =
				new Object[objects.length + 1 ];
			System.arraycopy(objects, 0, newObjects, 0, objects.length);
			newObjects[newObjects.length - 1] = statusObject;
			objects = newObjects;
		}
		options.setStatusObjects(objects);
	}

	/**
	 * Fires a collection of events
	 *
	 * @param events not <code>null</code>
	 */
	public void fireStatusEvents(Collection<StatusEvent> events) {

	    if (events == null) {
	        throw new IllegalArgumentException("events argument is null");
	    }

       Collection<Entry<StatusChangeListener, ListenerOptions>> entries;
        synchronized (_semaphore) {
            entries =
                new ArrayList<Entry<StatusChangeListener, ListenerOptions>>(
                        _listeners.entrySet());
        }

        for (StatusEvent event : events) {
            fireEventToListeners(event, entries);
        }
	}

	private void fireEventToListeners(
	        StatusEvent event,
	        Collection<Entry<StatusChangeListener, ListenerOptions>> entries) {

        for (Entry<StatusChangeListener, ListenerOptions> entry : entries) {

            ListenerOptions options = entry.getValue();

            StatusUtils.StatusObjectType[] objectTypes = options.getTypes();
            if (!StatusUtils.isEventForTypes(event, objectTypes)) {
                continue;
            }

            Object[] statusObjects = options.getStatusObjects();
            if (!StatusUtils.isEventForObjects(event, statusObjects)) {
                continue;
            }

            StatusChangeListener listener = entry.getKey();
            try {
                listener.statusChanged(event);
            } catch (Exception ex) {
                LOG.error("error posting status: "
                        + event.getNewStatus().getStatus()
                        + " to listener:  " + listener, ex);
            }
        }

        LOG.debug("fired status change: " + event.getNewStatus().getStatus()
                + " for " + event.getSource());
	}

	/**
	 * Publishes the given event to all interested listeners
	 *
	 * @param event not <code>null</code>
	 */
	public void fireStatusEvent(StatusEvent event) {

		if (event == null) {
			throw new IllegalArgumentException("event argument is null");
		}

		Collection<Entry<StatusChangeListener, ListenerOptions>> entries;
		synchronized (_semaphore) {
			entries =
				new ArrayList<Entry<StatusChangeListener, ListenerOptions>>(
						_listeners.entrySet());
		}

		fireEventToListeners(event, entries);
	}

	/**
	 * Removes a registered listener
	 *
	 * @param changeListener not <code>null</code>
	 */
	public void removeStatusChangeListener(
			StatusChangeListener changeListener) {

		if (changeListener == null) {
			throw new IllegalArgumentException(
					"changeListener argument is null");
		}

		_listeners.remove(changeListener);
	}

	static class ListenerOptions {

		private StatusUtils.StatusObjectType[] _types;
		private Object[] _statusObjects;

		StatusUtils.StatusObjectType[] getTypes() {
			return _types;
		}

		void setTypes(StatusUtils.StatusObjectType[] types) {
			this._types = types;
		}

		Object[] getStatusObjects() {
			return _statusObjects;
		}

		void setStatusObjects(Object[] statusObjects) {
			this._statusObjects = statusObjects;
		}

	}

}
