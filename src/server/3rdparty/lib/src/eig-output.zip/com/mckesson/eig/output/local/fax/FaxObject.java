/*
 * Copyright 2008-2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.fax;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.List;

import com.mckesson.eig.utility.util.StringUtilities;

public class FaxObject implements Serializable {
	
    private static final long serialVersionUID = 1L;
    
    private static final String HEADER = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	private static final String FAXOBJECT = "<FaxObject "
			+ " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
			+ " xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">{0}</FaxObject>";
	private static final String FAX_NUMBER = "<toFaxNumber>{0}</toFaxNumber>";
	private static final String TO_NAME = "<toName>{0}</toName>";
	private static final String JOB_ID = "<jobId>{0}</jobId>";
	private static final String FAX_HANDLER = "<faxHandle>{0}</faxHandle>";
	private static final String DOC_LIST = "<docList>{0}</docList>";
	private static final String QUEUE_NAME = "<queueName>{0}</queueName>";
	private static final String QUEUE_PASSWORD = "<queuePassword>{0}</queuePassword>";
	private static final String DOC = "<anyType xsi:type=\"xsd:string\">{0}</anyType>";
	
	private String _toFaxNumber;
	private String _toName;
	private long _jobId;
	private String _jobName;
	private String _faxHandle;
	private List<String> _faxList;
	private String _queueName;
	private String _queuePassword;

    public String getToFaxNumber() {
		return _toFaxNumber;
	}

	public void setToFaxNumber(String toFaxNumber) {
		_toFaxNumber = toFaxNumber;
	}

	public String getToName() {
		return _toName;
	}

	public void setToName(String toName) {
		_toName = toName;
	}

	public long getJobId() {
		return _jobId;
	}

	public void setJobId(long jobId) {
		_jobId = jobId;
	}

	public String getFaxHandle() {
		return _faxHandle;
	}

	public void setFaxHandle(String faxHandle) {
		_faxHandle = faxHandle;
	}

	public List <String> getFaxList() {
		return _faxList;
	}

	public void setFaxList(List<String> faxList) {
		_faxList = faxList;
	}

	public String toXml() {
		StringBuffer params = new StringBuffer();
		if (_toFaxNumber != null) {
			params.append(toXml(FAX_NUMBER, _toFaxNumber));
		}
		if (_toName != null) {
			params.append(toXml(TO_NAME, _toName));
		}
		if (_jobId != 0) {
			params.append(toXml(JOB_ID, new Long(_jobId).toString()));
		}
		if (_faxHandle != null) {
			params.append(toXml(FAX_HANDLER, _faxHandle));
		}
		if (_queueName != null) {
			params.append(toXml(QUEUE_NAME, _queueName));
		}
		if (_queuePassword != null) {
			params.append(toXml(QUEUE_PASSWORD, _queuePassword));
		}
		params.append(getFaxListXml());
		StringBuffer result = new StringBuffer(HEADER);
		result.append(toXml(FAXOBJECT, params.toString()));
		return result.toString();
	}

	private String getFaxListXml() {
		if (_faxList == null) {
			return "";
		}
		StringBuffer result = new StringBuffer();
		for (String str : _faxList) {
			String value = toXml(DOC, str);
			result.append(convertFaxFile(value, str.startsWith("\\\\")));
		}
		if (result.length() > 0) {
			return toXml(DOC_LIST, result.toString());
		}
		return "";
	}

	private String convertFaxFile(String file, boolean noConvert) {
		if (file == null) {
			return null;
		}
		if (noConvert) {
			return file;
		}
		return StringUtilities.replace(file, "\\", "\\\\");
	}

	private String toXml(String tag, String value) {
		Object[] args = { value };
		MessageFormat mf = new MessageFormat(tag);
		return mf.format(args);
	}

	public String getQueueName() {
		return _queueName;
	}

	public void setQueueName(String queueName) {
		_queueName = queueName;
	}

	public String getQueuePassword() {
		return _queuePassword;
	}

	public void setQueuePassword(String queuePassword) {
		_queuePassword = queuePassword;
	}

	public String getJobName() {
		return _jobName;
	}

	public void setJobName(String jobName) {
		_jobName = jobName;
	}	
}
