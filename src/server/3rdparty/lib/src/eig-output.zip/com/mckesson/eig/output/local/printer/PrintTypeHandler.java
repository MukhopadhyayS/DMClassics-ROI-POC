/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * author: Latonia
 */

package com.mckesson.eig.output.local.printer;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.attribute.Attribute;
import javax.print.attribute.standard.PrinterIsAcceptingJobs;

import com.mckesson.eig.output.local.AbstractTypeHandler;
import com.mckesson.eig.output.local.BaseComponent;
import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.OutputManagerAware;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.utility.exception.ApplicationException;


/**
 * This class provides the business methods implementations for printer destination type handlers
 */
public class PrintTypeHandler extends AbstractTypeHandler {

    private final Collection <String> _deviceIDs;
    private final HashMap <String, Map <String, Object>> _deviceProperties;
    /**
     * TODO
     */
    public PrintTypeHandler() {
        _deviceProperties = new HashMap <String, Map <String, Object>>();
        _deviceIDs = new ArrayList <String>();
    }

    public PrintTypeHandler(String enabled) {
        this();
    	setEnabled(enabled);
    }

    public void cleanUp() {

        // TODO Auto-generated method stub

        // destroyDestinations
    }

    public OutputEndpoint createEndpoint(EndpointDef destDef) {

        String name = destDef.getName();
        if (destDef.getProperties() != null) {
            name = (String) destDef.getProperties().get("printerName");
        }
        PrintDestination tmpDestination = new PrintDestination(this, name);
        HashMap <String, Object> tmpDevicePropertyMap = new HashMap <String, Object>();
        _deviceIDs.add(destDef.getName());
        tmpDevicePropertyMap.put("destinationImpl", tmpDestination);
        _deviceProperties.put(destDef.getName(), tmpDevicePropertyMap);
        return tmpDestination;
    }

    public void destroyEndpoint(OutputEndpoint destination) {

    }

    public String[] getEndpointContentTypes() {

        // TODO Auto-generated method stub
        return OutputConstants.ANY_CONTENT_TYPE;
    }

    @Override
    public PropertyDef[] getPropertyDefs() {

    	String[] printers = PrintUtilities.getAvailablePrinters();
    	PropertyDef[] propDef =
    		PropertySupport.extractAnnotatedProperties(PrintDestination.class);

    	for (PropertyDef element : propDef)
		{
			if (element.getPropertyName().equals("availablePrinters")) {
				element.setPossibleValues(printers);
			}
		}

        return propDef;
    }

 	public PropertyDef[] getDevicePropertyDefs(String deviceID) {

        // TODO Auto-generated method stub
        return null;
    }

    public Collection <String> queryDeviceIDs() {
    	PrintUtilities.clearSystemPrinterList();

        ArrayList <String> tmpCollection = new ArrayList <String>();
        try {
            PrintService[] prnSvcs;
            prnSvcs = PrintServiceLookup.lookupPrintServices(null, null);
            for (PrintService tmpPrinter : prnSvcs) {
                tmpCollection.add(tmpPrinter.getName());
            }
        } catch (Exception e) {
            throw new ApplicationException(e);
        }
        return tmpCollection;
    }

    public Map <String, Object> queryDeviceProperties(String deviceID) {
    	PrintUtilities.clearSystemPrinterList();

        HashMap <String, Object> tmpMap = new HashMap <String, Object>();
        try {
            PrintService[] prnSvcs;
            PrintService prnSvc = null; // get all print services for this machine
            prnSvcs = PrintServiceLookup.lookupPrintServices(null, null);
            for (PrintService tmpPrinter : prnSvcs) {
                if (tmpPrinter.getName().equalsIgnoreCase(deviceID)) {
                    prnSvc = tmpPrinter;
                    Class < ? >[] supportedAttr = prnSvc.getSupportedAttributeCategories();
                    Attribute[] tmpattr = prnSvc.getAttributes().toArray();
                    for (Attribute attr : tmpattr) {
                        tmpMap.put(attr.getName(), attr.toString());
                    }
                    for (Class < ? > tmpSupportedAttr : supportedAttr) {
                        tmpMap.put(tmpSupportedAttr.getName(), tmpSupportedAttr.toString());
                    }
                    break;
                }
            }
        } catch (Exception e) {
            throw new ApplicationException(e);
        }
        return tmpMap;
    }

    public StatusInfo queryDeviceStatus(String deviceID) {

    	PrintUtilities.clearSystemPrinterList();

        StatusInfo tmpStatus = new StatusInfo();
        tmpStatus.setStatus("Unknown");
        tmpStatus.setStatusDate(Calendar.getInstance().getTime());
        try {
            PrintService[] prnSvcs;
            prnSvcs = PrintServiceLookup.lookupPrintServices(null, null);

            for (PrintService tmpPrinter : prnSvcs) {
                if (tmpPrinter.getName().equalsIgnoreCase(deviceID)) {
                    tmpStatus.setStatus(tmpPrinter.getAttribute(PrinterIsAcceptingJobs.class)
                    .toString());
                    break;
                }
            }

        } catch (Exception e) {
            throw new ApplicationException(e);
        }
        return tmpStatus;
    }

    public EndpointCategory getEndpointCategory() {

        return EndpointCategory.DESTINATION;
    }
}
