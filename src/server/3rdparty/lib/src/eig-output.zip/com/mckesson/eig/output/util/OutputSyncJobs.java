package com.mckesson.eig.output.util;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.StatefulJob;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

//TODO :  implement trigger to run sync jobs at a pre-defined schedule to support
//       sync jobs that are in the processing state for an extended period of time

public class OutputSyncJobs extends QuartzJobBean implements StatefulJob {


    /**
     * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
     */

    private static final Log LOG = LogFactory.getLogger(OutputSyncJobs.class);


    @Override
    public void executeInternal(JobExecutionContext context) {

        if (context == null) {
            throw new IllegalArgumentException("context argument is null");
        }

        JobDataMap map = context.getMergedJobDataMap();

        OutputManager outputManager =
            (OutputManager) map.get(OutputConstants.OUTPUT_MANAGER_BEAN_NAME_PROP);

        outputManager.syncJobs();

        LOG.info("Completed job sync");

    }
}
