/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import org.apache.commons.lang.ObjectUtils;

import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.utility.util.BeanUtilities;

/**
 * TODO
 * @author Jon Anderson
 *
 */
public class OutputPropertyBeanWrapper implements PropertyChangeListener {
	private Object _bean;
	private PropertyDef[] _propertyDefs;

	/**
	 * TODO
	 * @param bean
	 */
	public OutputPropertyBeanWrapper(Object bean) {
		if (bean == null) {
			throw new IllegalArgumentException("bean argument is null");
		}

		_bean = bean;
		_propertyDefs =
			PropertySupport.extractAnnotatedProperties(_bean.getClass());
	}

	/**
	 * TODO
	 * @return
	 */
	public PropertyDef[] getPropertyDefs() {
		return _propertyDefs;
	}

	/**
	 * @see java.beans.PropertyChangeListener#propertyChange(java.beans.PropertyChangeEvent)
	 */
	public void propertyChange(PropertyChangeEvent evt) {

		if (evt == null) {
			throw new IllegalArgumentException("evt argument is null");
		}

		String propertyName = evt.getPropertyName();
		for (PropertyDef propertyDef : _propertyDefs) {

			if (ObjectUtils.equals(
					propertyDef.getPropertyName(),
					propertyName)) {

				BeanUtilities.setProperty(
						_bean,
						propertyName,
						evt.getNewValue());
				break;
			}
		}
	}
}
