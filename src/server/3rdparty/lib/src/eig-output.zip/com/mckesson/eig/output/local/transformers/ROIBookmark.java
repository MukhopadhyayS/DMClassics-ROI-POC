/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfAction;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfDestination;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfOutline;
import com.lowagie.text.pdf.PdfReader;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.SourceType;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.PdfSupport;
import com.mckesson.eig.utility.util.CollectionUtilities;

//TODO :  Bookmark should be implemented as another transform type.

public class ROIBookmark implements PdfBookmark {
	public ROIBookmark() {
	}

	public void createJobBookmark(OutputJob job, long maxSize) {
		for (JobPart part : job.getParts()) {
			createSubBookmark(part, maxSize);
		}
	}

	protected List<List<String>> divideFileBySize(JobPart part, long fileMaxSize) {
		
		if (CollectionUtilities.isEmpty(part.getSources())) {
			return null;
		}
		List<List<String>> result = new ArrayList<List<String>>();
		List<String> parts = new ArrayList<String>();
		long currDocSize = 0;
		for (String tmpFileName : part.getSources()) {
			long nextDocSize = PdfSupport.getFileSize(tmpFileName);
			if (nextDocSize > fileMaxSize && fileMaxSize > 0) {
				throw new OutputException(
						"Part size is greater than permissed",
						OutputErrorCode.RUNTIME_ERROR);
			}
			if ((currDocSize + nextDocSize) >= fileMaxSize && fileMaxSize > 0) {
				result.add(parts);
				parts = new ArrayList<String>();
				currDocSize = 0;
			}
			currDocSize += nextDocSize;
			parts.add(tmpFileName);
		}
		result.add(parts);
		return result;
	}

	public void createSubBookmark(JobPart part, long fileMaxSize) {
		if (part.getContentSourceType() != null) {
			if (part.getContentSourceType().equalsIgnoreCase(SourceType.HPF.toString())) {
				List<List<String>> srcs = divideFileBySize(part, fileMaxSize);
				if (!CollectionUtilities.isEmpty(srcs)) {
					part.clearSources();
					int startPageNumber = 0;
					for(List<String> src : srcs) {
						String bookmarkFileName = createSubBookmark(part, src, startPageNumber);
						part.addSource(bookmarkFileName);
						startPageNumber += src.size();
					}
				}
			}
		}
	}

	public String createSubBookmark(JobPart part, List<String> src, int pageNumber) {
		try {
			// ROI bookmarks HPF documents
			int bookmarkNo = 1;
			String bookmarkFileName = null;
			Document document = null;
			PdfCopy writer = null;
			PdfOutline outline1 = null;
			PdfOutline outline2 = null;
			PdfOutline outline3 = null;
			for (String currFileName : src) {
				if (bookmarkFileName == null) {
					bookmarkFileName = currFileName + "_BOOKMARK.pdf";
					document = new Document();
					writer = new PdfCopy(document, new FileOutputStream(
							bookmarkFileName));
					document.open();
				}
				PdfReader reader = new PdfReader(currFileName);
				PdfImportedPage page;
				for (int i = 1; i <= reader.getNumberOfPages(); i++) {
					page = writer.getImportedPage(reader, i);
					writer.addPage(page);
				}

				Map<String, String> map = part.getProperties();
				PdfOutline root = writer.getRootOutline();
				for (int i = 1; i <= reader.getNumberOfPages(); i++) {
					if (bookmarkNo == 1) {
						outline1 = setOutline(root, reader, writer, getPatientTitle(map), bookmarkNo);
						outline2 = setOutline(outline1, reader, writer, getEncounterTitle(map), bookmarkNo);
						outline3 = setOutline(outline2, reader, writer, getDocumentTitle(map), bookmarkNo);
					}
					setOutline(outline3, reader, writer, getPageTitle(bookmarkNo + pageNumber), bookmarkNo);
					bookmarkNo++;
				}
			}
			if (document != null) {
				document.close();
			}
			return bookmarkFileName;
		} catch (Exception e) {
			throw new OutputException();
		}
	}

	private PdfOutline setOutline(PdfOutline parent, PdfReader reader,
			PdfCopy writer, String text, int pageNumber) {
		return new PdfOutline(parent, PdfAction.gotoLocalPage(pageNumber,
				new PdfDestination(PdfDestination.XYZ, 0, reader.getPageSize(1)
						.getHeight(), 0), writer), text);
	}

	private String getPatientTitle(Map<String, String> map) {
		return map.get(OutputConstants.FACILITY) + "-"
				+ map.get(OutputConstants.MRN) + "-"
				+ map.get(OutputConstants.PATIENT_NAME);
	}

	private String getEncounterTitle(Map<String, String> map) {
		return map.get(OutputConstants.ENCOUNTER);
	}

	private String getDocumentTitle(Map<String, String> map) {
		String result = map.get(OutputConstants.DOCNAME);
		String subtitle = map.get(OutputConstants.DOCNAME_SUBTITLE);
	    // CR# 365589
		String dateTime = map.get(OutputConstants.DOC_DATE_TIME);  // contains document dateTime
//		String docId = map.get(OutputConstants.DOC_ID);   // contains documentId-documentTypeId-charter no
		if (!StringUtils.isBlank(subtitle)) {
			result += "-" + subtitle;
		}
		
		if (!StringUtils.isBlank(dateTime)) {
			result += "-" + dateTime;
		}
	    // CR# 365589
		// added for uniqueness, removed when displaying the bookmark.
//		result += OutputConstants.DELIMITER + docId;
		return result;
	}
	
	private String getPageTitle(int pageNumber) {
		return "Page " + pageNumber;
	}
}
