/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * SubmitInfo represents data about who submitted an OutputRequest
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "submitInfo")
@XmlType(name = "submitInfo")
public class SubmitInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 11;
	private static final int HASH_INIT = 7;

	private String _submitterData;
    private String _application;
    private Date _submitDate;
    private String _user;
    private String _submitMachine;

    /**
     *
     */
    public SubmitInfo() {
        super();
    }
    @Override
    public boolean equals(Object obj) {

        SubmitInfo info = (SubmitInfo) obj;
        if (!ObjectUtils.equals(_application, info._application)) {
            return false;
        }
        if (!ObjectUtils.equals(_submitDate, info._submitDate)) {
            return false;
        }
        if (!ObjectUtils.equals(_submitMachine, info._submitMachine)) {
            return false;
        }
        if (!ObjectUtils.equals(_submitterData, info._submitterData)) {
            return false;
        }
        if (!ObjectUtils.equals(_user, info._user)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        HashCodeBuilder hcb = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
        hcb.append(_application);
        hcb.append(_submitDate);
        hcb.append(_submitMachine);
        hcb.append(_submitterData);
        hcb.append(_user);
        return hcb.toHashCode();
    }

    /**
     * SubmitterData is some descriptive data the submitting application may provide to identify
     * an OutputRequest and later query for the OutputJob representing the request.
     *
     * @return may be <code>null</code>
     */
    public String getSubmitterData() {
        return _submitterData;
    }

    /**
     * @param data
     */
    @XmlElement (name = "submitterData")
    public void setSubmitterData(String data) {
        _submitterData = data;
    }

    /**
     * Application represents the name of the application which submitted the OutputRequest
     *
     * @return may be <code>null</code>
     */
    public String getApplication() {
        return _application;
    }

    /**
     * @param application
     */
    @XmlElement (name = "application")
    public void setApplication(String application) {
        _application = application;
    }

    /**
     * SubmitDate represents the date and time the OutputRequest was submitted to the Output
     * Service. This value will be set by the OutputService regardless of what value is
     * presented when the request is made
     *
     * @return the _submitDate member
     */
    public Date getSubmitDate() {
        return _submitDate;
    }

    /**
     * @param submitDate
     */
    @XmlElement (name = "submitDate")
    public void setSubmitDate(Date submitDate) {
        _submitDate = submitDate;
    }

    /**
     * The name of the user who submitted the OutputRequest. The OutputService will attempt
     * to set this value if it is not set when the request is submitted.
     *
     * @return the _user member
     */
    public String getUser() {
        return _user;
    }

    /**
     * @param submitUser
     */
    @XmlElement (name = "user")
    public void setUser(String submitUser) {
        _user = submitUser;
    }

    /**
     * The machine name or IP Address from which an OutputRequest originated. The OutputService
     * will only attempt to set this value if it is null when the request is submitted.
     *
     * @return the _submitMachine member
     */
    public String getSubmitMachine() {
        return _submitMachine;
    }

    /**
     * @param submitMachine
     */
    @XmlElement (name = "submitMachine")
    public void setSubmitMachine(String submitMachine) {
        _submitMachine = submitMachine;
    }

}
