package com.mckesson.eig.output.local.file;



public class FileConstants {

    public static final String FILE_TYPE_HANDLER_KEY = "file_type_handler";
    public static final String FILE_PURGE_TIME = "purgeTime";
    public static final String FILE_LOCATION = "directoryName";
	public static final int GB_TO_MB = 1024;
	public static final String PDF_EXT ="pdf";
	public static final String HASH_EXT =".hash";

    public static final int    MB_SIZE = 1024 * 1024;
    public static final int    FILE_BUFFER_SIZE = 5;
    public static final int    DEFAULT_CD_SIZE = 620;
    public static final int    DEFAULT_DVD_SIZE = 4;
}
