package com.mckesson.eig.output.local.file;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;



public class DefaultFileNameStrategy implements FileNameStrategy {

    private static final int    PAD_LEN = 3;
    private String _fileNameExpr;
    private String _supplementalFileNameExpr = "%output.file.requestId%-Supplementary-v%ouput.file.releaseNum,0,3%";
    private String _otherFileNameExpr ="%output.file.requestId%-Source-v%ouput.file.releaseNum,0,3%";;
    private String _attachmentNameExpr;
    private String _attachmentCollectionPdfExpr;
    private String _jobCollectionPdfExpr;
    public static final String REPLACE_CHAR = "-";

    /**
     * TODO
     * @param job
     * @param part
     * @return
     */
    public String createHPFPartFileName(OutputJob job, JobPart part) {
        String fileName = "";
        Map<String, String> combinedProperties = new HashMap<String, String>();
        combinedProperties.putAll(job.getProperties());
        combinedProperties.putAll(part.getProperties());
        fileName = generateFileName(combinedProperties);

        return fileName;
    }

    public String createROIFileName(OutputJob job) {
        return generateNameUsingExpr(_supplementalFileNameExpr, job.getProperties());
    }    
    
    public String createOtherSourceFileName(OutputJob job) {
        return generateNameUsingExpr(_otherFileNameExpr, job.getProperties());
	}
	
    public String createPartAttachmentCollectionName(OutputJob job, JobPart part) {
        String fileName = "";
        Map<String, String> combinedProperties = new HashMap<String, String>();
        combinedProperties.putAll(job.getProperties());
        combinedProperties.putAll(part.getProperties());
        fileName = generateAttachmentCollectionFileName(combinedProperties);

        return fileName;

    }     
    
    public String createPartAttachmentName(OutputJob job, JobPart part) {
        String fileName = "";
        Map<String, String> combinedProperties = new HashMap<String, String>();
        combinedProperties.putAll(job.getProperties());
        combinedProperties.putAll(part.getProperties());
        fileName = generateAttachmentFileName(combinedProperties);

        return fileName;
    }    
    
       
    public String createJobCollectionName(OutputJob job) {
        String fileName = "";
        fileName = generateJobCollectionFileName(job.getProperties());
        return fileName;
    }    
    
    public void setFileNameExpr(String fileNameExpr) {
        _fileNameExpr = fileNameExpr;
    }
    
    public void setAttachmentNameExpr(String attachmentNameExpr) {
        _attachmentNameExpr = attachmentNameExpr;
    }

    public void setAttachmentCollectionPdfExpr(String attachmentCollectionPdfExpr) {
    	_attachmentCollectionPdfExpr = attachmentCollectionPdfExpr;
    }
    
    public void setJobCollectionPdfExpr(String jobCollectionPdfExpr) {
    	_jobCollectionPdfExpr = jobCollectionPdfExpr;
    }    
 
    public void setSupplementalFileNameExpr(String supplementalFileNameExpr) {
    	_supplementalFileNameExpr = supplementalFileNameExpr;
    }    
    
	public String getOtherFileNameExpr() {
		return _otherFileNameExpr;
	}

	public void setOtherFileNameExpr(String otherFileNameExpr) {
		_otherFileNameExpr = otherFileNameExpr;
	}

    private String generateAttachmentCollectionFileName(Map<String, String> properties) {

        String fileNameExpr = properties.get(OutputConstants.OUTPUT_ATTACHMENT_COLLECTION_NAME_EXPR);
        if (StringUtils.isBlank(fileNameExpr)) {
            fileNameExpr = _attachmentCollectionPdfExpr;
        }
        return generateNameUsingExpr(fileNameExpr, properties);

    }  
    
    private String generateAttachmentFileName(Map<String, String> properties) {

        String fileNameExpr = properties.get(OutputConstants.OUTPUT_ATTACHMENT_NAME_EXPR);
        if (StringUtils.isBlank(fileNameExpr)) {
            fileNameExpr = _attachmentNameExpr;
        }
        return generateNameUsingExpr(fileNameExpr, properties);

    }  
    
    private String generateJobCollectionFileName(Map<String, String> properties) {

        String fileNameExpr = properties.get(OutputConstants.OUTPUT_JOB_COLLECTION_NAME_EXPR);
        if (StringUtils.isBlank(fileNameExpr)) {
            fileNameExpr = _jobCollectionPdfExpr;
            
        }
        return generateNameUsingExpr(fileNameExpr, properties);

    }    
    
    private String generateFileName(Map<String, String> properties) {

        String fileNameExpr = properties.get(OutputConstants.OUTPUT_FILE_NAME_EXPR);
        if (StringUtils.isBlank(fileNameExpr)) {
            fileNameExpr = _fileNameExpr;
        }
        return generateNameUsingExpr(fileNameExpr, properties);
    }
    
    private String generateNameUsingExpr(String nameExpr, Map<String, String> properties) {

        Pattern p = Pattern.compile("%[\\w._, ]+%");
        Matcher m = p.matcher(nameExpr);
        StringBuffer sb = new StringBuffer();
        boolean resultb = m.find();
        // Loop through and create a new String with the replacements
        while (resultb) {
            String key = m.group().replaceAll("%", "");
            if (StringUtils.isNotBlank(key)) {
                if (!(key.equalsIgnoreCase(OutputConstants.OUTPUT_FILE_NAME_VER)
                     || key.equalsIgnoreCase(OutputConstants.OUTPUT_FILE_NAME_PART)
                     || key.equalsIgnoreCase(OutputConstants.OUTPUT_DISC_NAME_PART))) {
                    String[] keyValues = key.split(",");
                    String value = properties.get(keyValues[0]);
                    if (value != null) {
                       value = getValue(value, keyValues);
                       m.appendReplacement(sb, value);
                    } else {
                        throw new OutputException("Invalid value for filename key: " + key ,
                                                  OutputConstants.OutputErrorCode.MISSING_DATA);
                    }
                }
            } else {
                throw new OutputException("Invalid FileName key",
                                          OutputConstants.OutputErrorCode.MISSING_DATA);
            }
            resultb = m.find();
        }
        // Add the last segment of input to the new String
        m.appendTail(sb);

        return sb.toString();

   }
    
    private static String getValue(String value, String[] keyValues) {
        String tmpValue = value;

        if (keyValues.length > 1) {
            if (keyValues.length != PAD_LEN) {
                return tmpValue;
            }

            int padding = Integer.valueOf(keyValues[2]);
            tmpValue = StringUtils.leftPad(value, padding, keyValues[1]);
        }
        tmpValue = replaceInvalidChars(tmpValue);
        tmpValue = tmpValue.trim();
        return tmpValue;
    }

    private static String replaceInvalidChars(String tmpString) {
    //make sure filenames do not have these characters:  \ / : * ? " < > | =+

        tmpString = tmpString.replaceAll("\\\\", REPLACE_CHAR);
        tmpString = tmpString.replaceAll("/", REPLACE_CHAR);
        tmpString = tmpString.replaceAll(":", REPLACE_CHAR);
        tmpString = tmpString.replaceAll("\\*", REPLACE_CHAR);
        tmpString = tmpString.replaceAll("\\?", REPLACE_CHAR);
        tmpString = tmpString.replaceAll("\"", REPLACE_CHAR);
        tmpString = tmpString.replaceAll("<", REPLACE_CHAR);
        tmpString = tmpString.replaceAll(">", REPLACE_CHAR);
        tmpString = tmpString.replaceAll("\\|", REPLACE_CHAR);
        tmpString = tmpString.replaceAll("=", REPLACE_CHAR);
        tmpString = tmpString.replaceAll("\\+", REPLACE_CHAR);
        tmpString = tmpString.replaceAll(",", REPLACE_CHAR);
        tmpString = StringUtils.deleteWhitespace(tmpString);

        return tmpString;
    }
    
    private String getExpress(String value) {
    	return "%" + value + "%";
    }
    
     public String generateFileNameWithPartNumber(String generatedFileName, int partNumber, int totalNumber) {
    	 String tmpFileName = generatedFileName;
    	 String express = getExpress(OutputConstants.OUTPUT_FILE_NAME_PART);
        if (totalNumber <= 1) {
            tmpFileName = tmpFileName.replace(express, "");
        } else {
            String partNumberStr = "-" + StringUtils.leftPad(Integer.toString(partNumber),
                    PAD_LEN,
                    '0');
        	if (tmpFileName.contains(express)) {
                tmpFileName = tmpFileName.replace(express, partNumberStr);
        	} else {
        		tmpFileName +=  partNumberStr;
        	}
        }
        return tmpFileName;
    }

	public String generateFileNameWithDiscNumberTotalNumber(String generatedFileName, int partNumber, int totalNumber) {
	 	 String tmpFileName = generatedFileName;
		 String express = getExpress(OutputConstants.OUTPUT_DISC_NAME_PART);
	     if (totalNumber < 1) {
	        tmpFileName = tmpFileName.replace(express, "");
	    } else {
	        String partNumberStr = StringUtils.leftPad(Integer.toString(partNumber), PAD_LEN, '0');
	        String totalNumberStr = StringUtils.leftPad(Integer.toString(totalNumber), PAD_LEN, '0');
	        String finalStr = "-DISC-" + partNumberStr + "-OF-" + totalNumberStr;
	    	if (tmpFileName.contains(express)) {
	            tmpFileName = tmpFileName.replace(express, finalStr);
	    	} else {
	    		tmpFileName += finalStr;
	    	}
	    }
	    return tmpFileName;
	}

    
    public String generateFileNameWithPartNumberTotalNumber(String generatedFileName, int partNumber, int totalNumber) {
     	 String tmpFileName = generatedFileName;
    	 String express = getExpress(OutputConstants.OUTPUT_FILE_NAME_PART);
         if (totalNumber <= 1) {
            tmpFileName = tmpFileName.replace(express, "");
         } else {
            String partNumberStr = StringUtils.leftPad(Integer.toString(partNumber), PAD_LEN, '0');
            String totalNumberStr = StringUtils.leftPad(Integer.toString(totalNumber), PAD_LEN, '0');
            String finalStr = "-PART-" + partNumberStr + "-OF-" + totalNumberStr;
        	if (tmpFileName.contains(express)) {
                tmpFileName = tmpFileName.replace(express, finalStr);
        	} else {
        		tmpFileName += finalStr;
        	}
        }
        return tmpFileName;
    }

    public String generateFileNameWithVersionNumber(String generatedFileName, String ext, List<String> files) {
    	int i = 0;
    	boolean isExists = true;
    	String fileName = null;
    	while (isExists) {
    		fileName = generateFileNameWithVersionNumber(generatedFileName, i);
    		if (!files.contains(fileName + "." + ext)) {
    			isExists = false;
    		} else {
    			i ++;
    		}
     	}
    	return fileName;
    }
    
    private String generateFileNameWithVersionNumber(String generatedFileName, int i) {
    	 String result = generatedFileName;
    	 String express = getExpress(OutputConstants.OUTPUT_FILE_NAME_VER);
        if (i == 0) {
        	result = result.replace(express, "");
        } else {
	    	String version = "-" + StringUtils.leftPad(Integer.toString(i), PAD_LEN, '0');
	        if (generatedFileName.contains(express)) {
	        	result = result.replace(express, version);
	        } else {
	        	result += version;
	        }
        }
        return result;
    }


    
}
