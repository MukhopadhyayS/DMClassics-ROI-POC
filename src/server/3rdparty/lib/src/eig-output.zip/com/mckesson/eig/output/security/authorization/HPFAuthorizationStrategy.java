/*
 * Copyright 2009-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.security.authorization;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.mckesson.eig.Security;
import com.mckesson.eig.output.security.authorization.OutputACL.RIGHTS;
import com.mckesson.eig.wsfw.session.WsSession;

/**
 * @author OFS
 * @date   Jun 24, 2009
 * @since  HPF 13.1; Jun 24, 2009
 */
public class HPFAuthorizationStrategy
extends OutputAuthorizationStrategy {

    private static final String EIG_USER_SECURITY_RIGHTS = "EIG_USER_SECURITY_RIGHTS";
    private static final String KEY_USERNAME = "USERNAME";
    private static final int ROI_ADMINISTRATION = 6101;
    private static final int ROI_PRINT_FAX      = 6112;
    private static final int ROI_EXPORT_TO_PDF  = 6113;
    private static final int ROI_EMAIL  = 6117;
    private static final int ROI_DISC = 6118;

    @Override
    public OutputACL initializeOutputACL() {

        if (WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY) == null) {

            //ROIAuthenticator sets Security model during authentication
            Security security = (Security) WsSession.getSessionData(EIG_USER_SECURITY_RIGHTS);
            int[] codes = security.getCodes();
            Arrays.sort(codes);

            OutputACL acl = new OutputACL();
            Map<RIGHTS, Boolean> rightsMap = new HashMap <RIGHTS, Boolean>();

            if (Arrays.binarySearch(codes, ROI_ADMINISTRATION) >= 0) {

                rightsMap.put(RIGHTS.SubmitOutputJob, true);
                rightsMap.put(RIGHTS.ConfigureOutputSettings, true);
                rightsMap.put(RIGHTS.MonitorAllJobs, true);
                rightsMap.put(RIGHTS.MonitorMyJobs, true);
            } else if ((Arrays.binarySearch(codes, ROI_PRINT_FAX) >= 0)
                       || (Arrays.binarySearch(codes, ROI_EXPORT_TO_PDF) >= 0)
                       || (Arrays.binarySearch(codes, ROI_EMAIL) >= 0)
                       || (Arrays.binarySearch(codes, ROI_DISC) >=0)) {

                rightsMap.put(RIGHTS.ConfigureOutputSettings, true);
                rightsMap.put(RIGHTS.SubmitOutputJob, true);
                rightsMap.put(RIGHTS.MonitorMyJobs, true);
            } else {

                rightsMap.put(RIGHTS.SubmitOutputJob, true);
                rightsMap.put(RIGHTS.MonitorMyJobs, true);
            }
            acl.setOutputRights(rightsMap);
            String userName = (String) WsSession.getSessionData(KEY_USERNAME);
            acl.setActorId("roi." + userName);
            WsSession.setSessionData(OutputACL.OUTPUT_ACL_KEY, acl);
        }

        return (OutputACL) WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY);
    }
}
