/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.HashCodeBuilder;


/**
 * <code>DeviceInfo</code>s provide data about device available to the system to married
 * to a destination to which <code>OutputJob</code>s may be routed.
 *
 * @author OFS
 * @author Jon Anderson
 * @date   Nov 3, 2008
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "deviceInfo")
public class DeviceInfo extends EndpointDef {

	private static final long serialVersionUID = 5L;
	private static final int HASH_MULTIPLY = 15;
    private static final int HASH_INIT = 3;

    private String _deviceID;
    private String _vendor;
    private String _description;



    /**
     * Constructor
     */
    public DeviceInfo() {
        super();
    }

    @Override
    public int hashCode() {

        HashCodeBuilder hcb = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
        hcb.append(_deviceID);
        hcb.append(getType());


        return hcb.toHashCode();
    }

    /**
     * Name of the device. This ID should be unique for the type.
     *
     * @return the _deviceID
     */
    public String getDeviceID() {
        return _deviceID;
    }

    /**
     *
     * @param deviceID the _deviceID to set
     */
    @XmlElement(name = "deviceId")
    public void setDeviceID(String deviceID) {
        _deviceID = deviceID;
    }

    @XmlElement( name = "description" )
	public String getDescription() { return _description; }
	public void setDescription(String description) { _description = description; }

	@XmlElement( name = "vendor" )
	public String getVendor() { return _vendor; }
	public void setVendor(String vendor) { _vendor = vendor; }


}
