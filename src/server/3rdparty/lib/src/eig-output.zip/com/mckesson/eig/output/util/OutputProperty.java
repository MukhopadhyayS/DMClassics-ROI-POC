/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.apache.commons.lang.StringUtils;

/**
 * TODO
 * @author Jon Anderson
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface OutputProperty {

	/**
	 * TODO
	 */
	public static enum PropertyFlag {
		JOB_DEFAULT
	}

	/** TODO */
	String description() default StringUtils.EMPTY;
	/** TODO */
	String label() default StringUtils.EMPTY;
	/** TODO */
	String defaultValue() default StringUtils.EMPTY;
	String required() default "false";
	String bindingProperty() default StringUtils.EMPTY;
	/** TODO */
	String[] possibleValues() default { };
	/** TODO */
	PropertyFlag[] flags() default { };
	String index() default StringUtils.EMPTY;
	String pairPropertyName() default StringUtils.EMPTY;
	String rowCount() default "1";
	String[] contextMenu() default { };
	
	/**
	 * custom javascript action to be defined for different property
	 * jsActoin should be specified along with the arguments and braces
	 * sample jsAction property value is given below
	 * <br/>
	 * <code>onAddPropertyChange(this)<br/>
	 * onAddPropertyChange()<br/>
	 * onAddPropertyChange('sampleText')</code>
	 * @return javascriptAction
	 */
	String jsAction() default  StringUtils.EMPTY;
	
	/**
	 * set the custom size of the text box/text area 
	 * <br/>
	 * 
	 * @return
	 */
	String size() default  StringUtils.EMPTY;
	
	/**
	 * set the length of the input text box 
	 * 
	 * @return
	 */
	String maxLength() default  StringUtils.EMPTY;
	
}
