/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.mckesson.eig.output.device.disc.DiscProviderFactory;
import com.mckesson.eig.output.device.disc.DiscProviderManager;
import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.local.device.disc.DiscDevice;
import com.mckesson.eig.output.local.device.disc.DiscDeviceStatusListener;
import com.mckesson.eig.output.local.device.disc.DiscStatusListener;
import com.mckesson.eig.output.local.file.FileConstants;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputJobFiles;
import com.mckesson.eig.output.model.OutputJobResults;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.output.util.OutputConstants.DestinationType;
import com.mckesson.eig.output.util.OutputConstants.DeviceType;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.OutputSettingConstants;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;
import com.mckesson.eig.utility.util.SpringUtilities;

public class DiscJobProcessor extends  AbstractJobProcessor implements DiscStatusListener, DiscDeviceStatusListener {

    private static final int DEFAULT_JOB_SIZE = 3;
    private static final int DEFAULT_CD_SIZE = 620; 		// CD size
    private static final int DEFAULT_DVD_SIZE = 4 * FileConstants.GB_TO_MB;		// DVD size

    private static final int DEFAULT_IDLE_IN_MINUTE = 60;		// 60 minutes idle time
	private static final Log LOG = LogFactory.getLogger(DiscJobProcessor.class);
	private static final String DISC_QUEUE = DestinationType.DISC.toString();
	private final List<Integer> _avaiableQueues = new ArrayList<Integer>();
    private static final int CHECK_PROCESSING_JOB_TIME = 60 * 1000;
	private long _previousCheckingPreparationTime = 0;
	private long _previousCheckingBurningTime = 0;
	private int _dvdSize = DEFAULT_DVD_SIZE;
	private int _cdSize = DEFAULT_CD_SIZE;
	private int _idleInMinutes = DEFAULT_IDLE_IN_MINUTE;
	private List<Integer> _cleanupJob = new ArrayList<Integer>();
	private Object _semaphore;
	protected String _idleErrorMsg = "reset Idle disc job";

	public DiscJobProcessor(DefaultTypeHandlerFactory factory,
			OutputManager outputManger, EndpointDAO dao, OutputJobDAO jobDao, JobProcessorHelper helper) {
		super(factory, outputManger, dao, jobDao, helper);
		setExecutorSize(DEFAULT_JOB_SIZE);
		_semaphore = new Object();
	}

	public void setProperties(Properties p) {
		super.setProperties(p);
		try {
			String value = p.getProperty(OutputSettingConstants.CONCURRENT_DICS_JOB);
			if (value != null) {
				setExecutorSize(Integer.parseInt(value));
			}
			value = p.getProperty(OutputSettingConstants.DISC_DVD_SIZE);
			if (value != null) {
				setDvdSize(Integer.parseInt(value));
			}
			value = p.getProperty(OutputSettingConstants.DISC_CD_SIZE);
			if (value != null) {
				setCdSize(Integer.parseInt(value));
			}
			value = p.getProperty(OutputSettingConstants.IDLE_IN_MINUTES);
			if (value != null) {
				setIdleInMinutes(Integer.parseInt(value));
			}
	    } catch (Exception e) {
	    	LOG.info("Fail to set Disc processor properties. Use Default. Msg: " + e.getMessage());
	    }
	}

	/**
	 * This method is used to pre-process before the processor start processing
	 *
	 */
	public void preStartupProcess() {
		establishConnectionsToDiscProvider();
	}

	protected void preStartProcessing() {
		configQueueList();
		resetProcessingJobStatuses();
	}
	
	private void establishConnectionsToDiscProvider() {
		//input queue type
		getDiscProviderFactory().setDiscDeviceStatusListener(this);

		List<String> queues = new ArrayList<String>();
		queues.add(DeviceType.DISC_DEVICE.toString());
		
		//Get all the Disc queues
		List<EndpointDef> discQueues = _dao.getEndpoints(queues);
		
		// Map of Vendors, and each vendors has set of devices.
		Map<String, List<EndpointDef>> vendorsDevices = new HashMap<String, List<EndpointDef>>();
		DiscDevice device = null;
		List<EndpointDef> vendorDevice = null;
		
		// Get all the Endpointdef for getting deviceId.
		for (EndpointDef deviceEndpoint : discQueues) {
			//Create disc device
			device = new DiscDevice(deviceEndpoint);
			String vendor = device.getVendorName();
			
			// Split up the devices based on vendor specific.
			if (!vendorsDevices.containsKey(vendor)) {
				vendorDevice = new ArrayList<EndpointDef>();
				vendorsDevices.put(vendor, vendorDevice);
			}				
			vendorDevice.add(deviceEndpoint);
		}
		Set<String> vendors = vendorsDevices.keySet();
		for (String vendor: vendors) {
			//Initializing Disc Provider Manager for each vendor only once.
			getDiscProviderFactory().getDiscProviderManager(vendor).initialize(vendorsDevices.get(vendor));
		}
	}

	protected void preShutdownProcess() {
		resetProcessingJobStatuses();
		Map<String, DiscProviderManager> mapProviderManagers = getDiscProviderFactory().getDiscProviderManagerMap();
		Collection<DiscProviderManager> providerManagers = mapProviderManagers.values();
		for (DiscProviderManager providerManager : providerManagers) {
			providerManager.shutdown();
		}
	}

	private void resetProcessingJobStatuses() {
		String serverName = getProcessingServer();
		_jobDao.updateAllJobsStatusForServer(serverName,
			RequestStatus.PROCESSING.statusCode(),
			RequestStatus.READY.statusCode(), _avaiableQueues);
		_jobDao.updateAllJobsStatusForServer(serverName,
			RequestStatus.DISC_PREPARING_PROCESSING.statusCode(),
			RequestStatus.DISC_PREPARING_READY.statusCode(), _avaiableQueues);
	}
	
	/**
	 * This method is used to refresh the queue
	 *
	 */
	public void refreshQueueList() {
		configQueueList();
	}

	/**
	 * This method is used to process the output job
	 *
	 */
	public boolean processJob() {
		boolean hasJob = false;
		if(isExecutorAvaiable(_executor)) {
			hasJob = processIdleJob(getIdleInMinutes());
		}
		if(isExecutorAvaiable(_executor)) {
			hasJob = processDiscBurningJob();
		}
		if(isExecutorAvaiable(_executor)) {
			hasJob = processReadyForDiscBurningJob();
		}
		if(isExecutorAvaiable(_executor)) {
			hasJob = processDiscContentPreparationJob();
		}
		if(isExecutorAvaiable(_executor)) {
			hasJob = processReadyForDiscContentPreparationJob();
		}
		if(isExecutorAvaiable(_executor)) {
			hasJob = processNewJob();
		}
		if(isExecutorAvaiable(_executor)) {
			hasJob = processCleanupJob();
		}
		return hasJob;
	}
	
	protected void reconnectDiscProviderifNeeded() {
		for(DiscProviderManager manager : getDiscProviderFactory().getDiscProviderManagerMap().values()) {
			manager.reconnect();
		}
	}

	protected void configQueueList() {
		LOG.debug("Update Disc Queue List");
		_avaiableQueues.clear();
		List<String> queues = new ArrayList<String>();
		queues.add(DISC_QUEUE);
		List<Integer> result =  _dao.getEndpointIds(queues);
		if (!CollectionUtilities.isEmpty(result)) {
			_avaiableQueues.addAll(result);
		}
		reconnectDiscProviderifNeeded();
	}
	
	protected boolean processNewJob() {
		return processJob(RequestStatus.READY, 
	        	RequestStatus.PROCESSING, RequestStatus.PROCESSING);
	}
	
	protected boolean processReadyForDiscBurningJob() {
		return processJob(RequestStatus.DISC_BURNING_READY, 
	        	RequestStatus.DISC_BURNING_PROCESSING, RequestStatus.DISC_BURNING_READY);
	}
	
	protected boolean processReadyForDiscContentPreparationJob() {
		return processJob(RequestStatus.DISC_PREPARING_READY, 
	        	RequestStatus.DISC_PREPARING_PROCESSING, RequestStatus.DISC_PREPARING_READY);
	}
	
	protected boolean processDiscBurningJob() {
		long current = System.currentTimeMillis();
		if (current - _previousCheckingBurningTime > CHECK_PROCESSING_JOB_TIME) {
			LOG.info("Start processing disc content burning job");
			boolean b =  processCurrentJob(RequestStatus.DISC_BURNING_PROCESSING, false);
			_previousCheckingBurningTime = current;
			return b;
		}
		return false;
	}
	
	protected boolean processDiscContentPreparationJob() {
		long current = System.currentTimeMillis();
		if (current - _previousCheckingPreparationTime > CHECK_PROCESSING_JOB_TIME) {
			LOG.info("Start processing disc content burning job");
			boolean b =  processCurrentJob(RequestStatus.DISC_PREPARING_PROCESSING, true);
			_previousCheckingPreparationTime = current;
			return b;
		}
		return false;
	}
	
	protected boolean processCleanupJob() {
		if(!CollectionUtilities.isEmpty(_cleanupJob)) {
			Integer jobId = _cleanupJob.get(0);
			_cleanupJob.remove(0);
			LOG.info("Start process clean up disc job: " + jobId);
			OutputJob job = createJob(jobId);
			DiscCleanupJobProcessRunnable processor = new DiscCleanupJobProcessRunnable(_factory,
					_dao, _outputManger, job);
			job.logMetric("Start Processing Job:" + jobId);
    		_executor.execute(processor);
     		return true;
		}
		return false;
	}
	
	protected boolean processJob(RequestStatus checkStatus, RequestStatus setStatus, RequestStatus processStatus) {
    	try {
	        Integer jobId = getNextAvailableJob(_avaiableQueues, checkStatus, setStatus);
        	if (jobId != null) {
        		DiscJobProcessRunnable p = createJobProcessorTask(jobId, processStatus, this);
        		_executor.execute(p);
        		return true;
        	}
    	} catch (Exception e) {
    		LOG.error("DiscJobProcessor-start-Exception: " + e.getMessage());
    	}
       	return false;
	}
	
	protected boolean processIdleJob(int idleInMin) {
		long current = System.currentTimeMillis();
		if (current - _previousCheckingIdleTime > CHECK_PROCESSING_IDLE_TIME) {
			LOG.info("Start processing idle job");
			boolean ab = processIdleJobByChangeStatus(_avaiableQueues, RequestStatus.PROCESSING,  RequestStatus.READY, idleInMin, _idleErrorMsg);
			boolean bb = processIdleJobByChangeStatus(_avaiableQueues, RequestStatus.DISC_PREPARING_PROCESSING,  RequestStatus.DISC_PREPARING_READY, idleInMin, _idleErrorMsg);
			boolean cc = processIdleJobByRemoveServerName(_avaiableQueues, RequestStatus.DISC_BURNING_PROCESSING, idleInMin, _idleErrorMsg);
			_previousCheckingIdleTime = current;
			return (ab || bb || cc);
		}
		return false;
	}
	
	protected boolean processCurrentJob(RequestStatus checkStatus, boolean hostNameOnly) {
		try {
   			Integer jobId = getCurrentProcessingJob(_avaiableQueues, checkStatus, hostNameOnly);
        	if (jobId != null) {
        		DiscJobProcessRunnable p = createJobProcessorTask(jobId, checkStatus, this);
        		_executor.execute(p);
        		return true;
        	}
    	} catch (Exception e) {
    		LOG.error("DiscJobProcessor-start-Exception: " + e.getMessage());
    	}
       	return false;
	}
	
	private DiscJobProcessRunnable createJobProcessorTask(Integer jobId, RequestStatus requestStatus, DiscStatusListener listener) {
		OutputJob job = createJob(jobId);
		DiscJobProcessRunnable processor = new DiscJobProcessRunnable(_factory,
				_dao, _outputManger, job, requestStatus, getDiscProviderFactory(), getCdSize(), getDvdSize(), listener);
		job.logMetric("Start Processing Job:" + jobId);
		return processor;
	}
	
	private DiscProviderFactory getDiscProviderFactory() {
		return (DiscProviderFactory) SpringUtilities.getInstance().getBeanFactory()
				.getBean("com.mckesson.eig.output.device.disc.DiscProviderFactory");
	}

	public int getDvdSize() {
		return _dvdSize;
	}

	public void setDvdSize(int dvdSize) {
		_dvdSize = dvdSize * FileConstants.GB_TO_MB;
	}

	public int getCdSize() {
		return _cdSize;
	}

	public void setCdSize(int cdSize) {
		_cdSize = cdSize;
	}

	public void discPreparationCompleted(Integer jobId, List<String> fileNames) {
		ArrayList<String> fileNamesNoPath = new ArrayList<String>();
		File jobDirectory = null;
		for (String tmpFileName : fileNames) {
			File tmpFile = new File(tmpFileName);
			fileNamesNoPath.add(tmpFile.getName());
			if (jobDirectory == null) {
				jobDirectory = tmpFile.getParentFile();
			}
		}
		
		OutputJobFiles jobFiles = new OutputJobFiles();
		jobFiles.setFileNames(fileNamesNoPath);
		jobFiles.setJobID(jobId);
		jobFiles.setJobDirectory(jobDirectory.getAbsolutePath());

		updateJobResults(jobId, RequestStatus.DISC_BURNING_READY, "Disc Burning Ready", jobFiles.getXML());
	}
	
	public void discPreparationInProgress(Integer jobId, String info) {
		updateStatus(jobId, RequestStatus.DISC_PREPARING_PROCESSING, info);
	}
	
	public void discPreparationFailed(Integer jobId, String errMsg) {
		updateStatus(jobId, RequestStatus.ERROR, errMsg);
		cleanup(jobId);
	}
	
	public void discBurningCompleted(Integer jobId) {
		updateStatus(jobId, RequestStatus.COMPLETED, "Disc Job Completed");
		cleanup(jobId);
	}
	
	public void discBurningInProgress(Integer jobId, String info) {
		updateStatus(jobId, RequestStatus.DISC_BURNING_PROCESSING, info);
	}
	
	public void discBurningFailed(Integer jobId, String errMsg) {
		updateStatus(jobId, RequestStatus.ERROR, errMsg);
		cleanup(jobId);
	}

	protected void updateStatus(int jobId, RequestStatus status, String detail) {
		StatusInfo statusInfo = StatusUtils.createRequestStatus(status, detail);
		getOutputManager().updateJobStatus(jobId, statusInfo);
	}

	protected void updateJobResults(int jobId, RequestStatus status, String detail, String fileInfo) {
		StatusInfo statusInfo = StatusUtils.createRequestStatus(status, detail);
		getOutputManager().updateJobResults(jobId, statusInfo, fileInfo);
	}

    public int getIdleInMinutes() {
		return _idleInMinutes;
	}
		
	public void setIdleInMinutes(int idleInMinutes) {
		_idleInMinutes = idleInMinutes;
	}
	
	private void cleanup(Integer jobId) {
		_cleanupJob.add(jobId);	
	}

	/*
	 * (non-Javadoc)
	 * @see com.mckesson.eig.output.local.device.disc.DiscDeviceStatusListener#deviceStatusChanged(java.util.List, com.mckesson.eig.output.model.StatusInfo)
	 * update the statusInfo for the deviceInfo object(s) in output_listofvalue table whenever 
	 * a message is received from the host system
	 */
	@Override
	public void deviceStatusChanged(List<Integer> deviceIds, StatusInfo status) {
		// TODO check if this status is already in the database because another instance of OutputService already placed it there
		// TODO save device status into the database if it was not there yet
		// TODO make sure that you lock the device row while updating status. Possible issue: multiple OutputServices updating the same record with the same data multiple times.
		/*
		 * Initial implementation will allow database to handle update of status
		 */
		LOG.debug("Device(s):" + deviceIds.toString() + ": status updated: Status code:" + status.getStatusCode()
					+ " Status:" + status.getStatus() + " Status detail:" + status.getDetail());
		
		for (int deviceId : deviceIds) {
			synchronized (_semaphore) {
				try {
					EndpointDef device = this._dao.getEndpointDef(deviceId);
					device.setStatusInfo(status);
					this._dao.updateEndpointDef(0, device); 
				}catch(Exception e) {
					LOG.warn("Device status updated: " + e.getMessage() );
				}
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.mckesson.eig.output.local.device.disc.DiscDeviceStatusListener#deviceStatusPropertyChanged(java.util.List, java.lang.String, java.lang.String)
	 * update the statusdata property map of the deviceInfo statusInfo with alert or error messages received from the host system
	 * As alert/error messages are acknowledged by a user, remove the alert/error message from the statusdata property map
	 */
	@Override
	public void deviceStatusPropertyChanged(List<Integer> deviceIds, String key, String value)	{
		LOG.debug("Device(s):" + deviceIds.toString() + ": property updated: Key:" + key + " Value:" + value);
		for (int deviceId : deviceIds) {
			synchronized (_semaphore) {
				updateDeviceStatusData(key, value, deviceId);
			}
		}	
	}

	private void updateDeviceStatusData(String key, String value, int deviceId) {
		try {
			EndpointDef device = this._dao.getEndpointDef(deviceId);
			StatusInfo statusInfo = device.getStatusInfo();
			List<MapModel> statusData = statusInfo.getStatusData();
			if (updateStatusDataElement(key, value, statusData)) {
				this._dao.updateEndpointDef(0, device); 
			}
		} catch (Exception e) {
			LOG.warn("Device status property updated error: " + e.getMessage() );
		}
	}

	private boolean updateStatusDataElement(String key, String value, List<MapModel> statusData) {
		boolean result = false;
		if (value == null) {
			result = removeStatusDataElement(key, statusData);
		}else {
			result = addStatusDataElement(key, value, statusData);										
		}
		return result;
	}

	private boolean addStatusDataElement(String key, String value, List<MapModel> statusData) {
		boolean result = false;
		if (!containsKey(key, statusData)) {
			MapModel newProperty = new MapModel(key,value);
			statusData.add(newProperty);
			result = true;
		}
		return result;
	}

	private boolean containsKey(String key, List<MapModel> statusData) {
		boolean result = false;
		for (MapModel property : statusData) {
			if (property.getKey().equals(key)) {
				result = true;
				continue;
			}
		}
		return result;
	}

	/**
	 * remove key from list if it exists and save
	 * @param key
	 * @param statusData
	 * @return
	 */
	private boolean removeStatusDataElement(String key, List<MapModel> statusData) {
		boolean result = false;
		Iterator<MapModel> dataIter  = statusData.iterator();
		while (dataIter.hasNext()) {
		    MapModel tmpModel = dataIter.next();
		    if (tmpModel.getKey().equals(key)) {
		    	dataIter.remove();
		    	result = true;
		    	continue;
		    }
		}
		return result;
	}

	@Override
	public void discPreparationSubmitted(OutputJob job, String orderId) {
		Integer jobId = job.getJobSeq();
		OutputJobFiles jobFiles = new OutputJobFiles();
		OutputJobResults jobResult = job.getOutputJobResults();
		String hostName = OutputUtil.getServerName();
		if (jobResult != null && jobResult.getOutputJobFiles() != null) {
			jobFiles = job.getOutputJobResults().getOutputJobFiles();
		}
		jobFiles.setOrderId(orderId);
		jobFiles.setJobID(jobId);
		jobFiles.setClientId(hostName);
		updateJobResults(jobId, RequestStatus.DISC_PREPARING_PROCESSING, "Disc preparation request Submitted", jobFiles.getXML());
	}

	@Override
	public void discBurningSubmitted(OutputJob job, String orderId) {
		Integer jobId = job.getJobSeq();
		OutputJobFiles jobFiles = new OutputJobFiles();
		OutputJobResults jobResult = job.getOutputJobResults();
		String hostName = OutputUtil.getServerName();
		if (jobResult != null && jobResult.getOutputJobFiles() != null) {
			jobFiles = job.getOutputJobResults().getOutputJobFiles();
		}
		jobFiles.setOrderId(orderId);
		jobFiles.setJobID(jobId);
		jobFiles.setClientId(hostName);
		updateJobResults(jobId, RequestStatus.DISC_BURNING_PROCESSING, "Disc burning request Submitted", jobFiles.getXML());
	}
}
