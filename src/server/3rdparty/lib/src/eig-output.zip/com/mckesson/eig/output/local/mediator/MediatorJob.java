/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.mediator;

import java.io.IOException;

/**
 * This interface encapsulates any data regarding an output job.
 * 
 * @author Michael Macaluso
 * @author Srini Paduri
 * @since 13.5.2
 */
public interface MediatorJob {

    /**
     * Mark that this job will no long receive another file as input. This
     * should only need to be called if the number of files was not known ahead
     * of time.
     * 
     * @see #createJobPart()
     * @since 13.5.2
     */
    void doneWithJob() throws IOException, InterruptedException;

    /**
     * Return the id of this job.
     * 
     * @return The id given to this job.
     * @since 13.5.2
     */
    int getId();

    void addFile(String fileName) throws IOException, InterruptedException;

    /**
     * Return the name of this job.
     * 
     * @return The name given to this job.
     * @since 13.5.2
     */
    String getName();

    void initializeJob(Object listener);


}
