/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local;


import java.util.List;
import java.util.Map;

import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;

/**
 * TODO
 * @author Jon Anderson
 *
 */
public class ReflectiveTypeHandler
	extends BaseComponent implements EndpointTypeHandler {

	private Class<OutputEndpoint> _endpointClass;
	private EndpointCategory _endpointCategory;
	private String[] _endpointContentTypes;

	/**
	 * TODO
	 * @param endpointClass
	 * @param endpointCategory
	 */
	public ReflectiveTypeHandler(
			Class<OutputEndpoint> endpointClass,
			EndpointCategory endpointCategory) {

		if (endpointClass == null) {
			throw new IllegalArgumentException(
					"endpointClass argument is null");
		}

		_endpointClass = endpointClass;
		_endpointCategory = endpointCategory;
	}

	/**
	 * TODO
	 * @param endpointClass
	 * @param endpointCategory
	 */
	public ReflectiveTypeHandler(
			String enabled,
			String endpointClass,
			String endpointCategory) {

		if (endpointClass == null) {
			throw new IllegalArgumentException(
					"endpointClass argument is null");
		}
		if (endpointCategory == null) {
			throw new IllegalArgumentException(
					"endpointCategory argument is null");
		}
		setEnabled(enabled);
		setEndpointClass(endpointClass);
		setEndpointCategory(endpointCategory);
	}

	/**
	 * @see com.mckesson.eig.output.local.EndpointTypeHandler#cleanUp()
	 */
	public void cleanUp() {
		/** TODO Add support for Annotations */
	}

	/**
	 * @see com.mckesson.eig.output.local.EndpointTypeHandler#createEndpoint(EndpointDef)
	 */
	public OutputEndpoint createEndpoint(EndpointDef endpointDef) {
		try {
			return _endpointClass.newInstance();
		} catch (Exception e) {
			throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
		}
	}

	/**
	 * @see com.mckesson.eig.output.local.EndpointTypeHandler#destroyEndpoint(OutputEndpoint)
	 */
	public void destroyEndpoint(OutputEndpoint endpoint) {
		/** TODO Add support for Annotations */
	}

	/**
	 * @see com.mckesson.eig.output.local.EndpointTypeHandler#getEndpointCategory()
	 */
	public EndpointCategory getEndpointCategory() {
		return _endpointCategory;
	}

	/**
	 * TODO
	 * @param endpointCategory
	 */
	public void setEndpointCategory(EndpointCategory endpointCategory) {
		_endpointCategory = endpointCategory;
	}

	/**
	 * TODO
	 * @param endpointCategory
	 */
	public void setEndpointCategory(String endpointCategory) {
		_endpointCategory = EndpointCategory.valueOf(endpointCategory);
	}

	/**
	 * @see com.mckesson.eig.output.local.EndpointTypeHandler#getEndpointContentTypes()
	 */
	public String[] getEndpointContentTypes() {
		return _endpointContentTypes;
	}

	/**
	 * TODO
	 * @param endpointContentTypes
	 */
	public void setEndpointContentTypes(String[] endpointContentTypes) {
		_endpointContentTypes = endpointContentTypes;
	}

	/**
	 * TODO
	 * @return
	 */
	public Class<OutputEndpoint> getEndpointClass() {
		return _endpointClass;
	}

	/**
	 * TODO
	 * @param endpointClass
	 */
	public void setEndpointClass(Class<OutputEndpoint> endpointClass) {
		if (endpointClass == null) {
			throw new IllegalArgumentException(
					"endpointClass argument is null");
		}
		_endpointClass = endpointClass;
	}

	/**
	 * TODO
	 * @param endpointClass
	 */
	@SuppressWarnings("unchecked")
	public void setEndpointClass(String endpointClass) {
		if (endpointClass == null) {
			throw new IllegalArgumentException(
					"endpointClass argument is null");
		}

		try {
			_endpointClass =
				(Class<OutputEndpoint>) Class.forName(endpointClass);

		} catch (ClassNotFoundException e) {
			throw new InvalidDefinitionException(
					"endpointClass: " + endpointClass,
					OutputErrorCode.REFERENCE_INVALID);
		}

	}

	@Override
	public Map<String, EndpointTypeHandler> getSubHandlers() {
		return null;
	}
	
	 @Override
		public PropertyDef[] getPropertyDefs() {
			return PropertySupport
					.extractAnnotatedProperties(getEndpointClass());
		}

	@Override
	public void updateEndpoints(List<ActiveEndpoint> endpointArr) {
		//do noting
	}	
}
