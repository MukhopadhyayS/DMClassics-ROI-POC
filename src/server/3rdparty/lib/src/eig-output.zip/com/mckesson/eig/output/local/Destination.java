package com.mckesson.eig.output.local;

import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants;

public abstract class Destination extends BaseComponent implements OutputJobEndpoint {

	public Destination() {
		super();
	}

	public void processJob(OutputJob job) {
		// TODO Auto-generated method stub
	}

    /**
     * @see com.mckesson.eig.output.local.OutputEndpoint#queryEndpointStatus()
     */
    public StatusInfo queryEndpointStatus(boolean validEndPoint) {
		return queryEndpointStatus();
	}
    
    /**
     * 
     * @param job
     * @return
     */
    public boolean isPasswordEncrypted(OutputJob job) {
		
		// Check whether the password is encrypted or not for outputjob.
		String isEncrypted = job.getPropertyValue(OutputConstants.OUTPUT_PASSWORD_ENCRYPTED);
		return Boolean.valueOf(isEncrypted);
	}
    
}
