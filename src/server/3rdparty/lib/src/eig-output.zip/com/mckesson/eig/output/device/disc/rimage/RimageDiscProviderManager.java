/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.device.disc.rimage;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.mckesson.eig.output.device.disc.DiscProviderManager;
import com.mckesson.eig.output.local.device.disc.DiscDevice;
import com.mckesson.eig.output.local.device.disc.DiscDeviceStatusListener;
import com.mckesson.eig.output.local.device.disc.DiscStatusListener;
import com.mckesson.eig.output.local.device.disc.rimage.RimageDiscDevice;
import com.mckesson.eig.output.local.disc.DiscDestination;
import com.mckesson.eig.output.local.processor.IdleJobProcessor;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputJobFiles;
import com.mckesson.eig.output.model.OutputJobResults;
import com.mckesson.eig.output.model.ShutdownHook;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;
import com.rimage.client.api.exception.SystemException;
import com.rimage.msg.exception.MsgNotConnectedException;

public class RimageDiscProviderManager implements ShutdownHook,
		DiscProviderManager, DiscStatusListener {

	// String DeviceId, RimageConnection.
	private Map<String, RimageConnection> _connections = new HashMap<String, RimageConnection>();

	// Job status map.
	private Map<Integer, Map<StatusInfo, List<String>>> _jobsStatus = new ConcurrentHashMap<Integer, Map<StatusInfo, List<String>>>();

	private Map<Integer, Integer> _recoverJobStatus = new ConcurrentHashMap<Integer, Integer>();

	private DiscDeviceStatusListener _deviceStatusListener;//DiscJobProcessor
	private static final Log LOG = LogFactory.getLogger(RimageDiscProviderManager.class);

	private static final int RETRY = 3;
	private static final int RECOVER_PENDING_STATUS_IN_MINUTES = 5;

	@Override
	public void initialize(List<EndpointDef> devices) { 
		
		if (!CollectionUtilities.isEmpty(devices)) { 
			for (EndpointDef endpointDef : devices) {

				DeviceInfo rimageDevice = (DeviceInfo) endpointDef;
				String ipAddress = (String) rimageDevice.getProperties().get(RimageDiscDevice.HOSTADDRESS);
				String port = (String) rimageDevice.getProperties().get(RimageDiscDevice.PORT);
				String deviceKey = getDeviceKey(ipAddress, port);

				if(!_connections.containsKey(deviceKey)) {
					RimageConnection conn = new RimageConnection(rimageDevice.getId(), ipAddress, port, this, _deviceStatusListener);
					if (!conn.isConnected()) {
						try {
							if (conn.connect()) {
								_connections.put(deviceKey, conn);
							}
						} catch (Exception e) {
							LOG.error("Faild to initialize RimageDiscProviderManager. Exception occured while creating connection, ip address=" 
									+ ipAddress + ", port=" + port + ": " + e.getMessage());
							e.printStackTrace();
						}
					}
				}else {
					//retrieve connection and update device id list
					RimageConnection tmpConn = _connections.get(deviceKey);
					if (tmpConn != null) {
						tmpConn.addDevice(rimageDevice.getId());
					}
				}
			}
		}
	}

	@Override
	public void reconnect() {
		if(!CollectionUtilities.isEmpty(_connections)) {
			for(RimageConnection conn : _connections.values()) {
				if (!conn.isConnected()) {
					try {
						conn.connect();
					} catch (Exception e) {
						LOG.error("Faild to reconnect connection, ip address=" 
								+ conn.getIpAddress() + ", port=" + conn.getPort() + ": " + e.getMessage());
					}
				}
			}
		}
	}
	
	private String getDeviceKey(String ipAddress, String port) {
		return (ipAddress.toLowerCase() + OutputConstants.COLON_DELIMETER + port).toLowerCase();
	}

	private RimageConnection getRimageConnection(int deviceId, String server, String port, DiscDeviceStatusListener deviceStatusListener) {
		String key = getDeviceKey(server, port);
		if (!_connections.containsKey(key)) {
			establishConnectionWithDevice(deviceId, server, port, deviceStatusListener, key);
		} else {
			//retrieve connection and update device id list
			RimageConnection conn = _connections.get(key);
			if (conn != null) {				
				conn.addDevice(deviceId);
				if (!conn.isConnected()) {
					conn.connect();
				}
			} else {
				_connections.remove(key);
				establishConnectionWithDevice(deviceId, server, port, deviceStatusListener, key);
			}
		}
		return _connections.get(key);
	}

	private void establishConnectionWithDevice(int deviceId, String server,
			String port, DiscDeviceStatusListener deviceStatusListener,
			String key) {
		RimageConnection conn = new RimageConnection(deviceId, server, port, this, deviceStatusListener);
		if (conn.connect()) {
			_connections.put(key, conn);
		}
	}

	@Override
	public boolean isConnected(String server, String port) {
		RimageConnection conn =_connections.get(getDeviceKey(server,port)); 
		return (conn == null) ? false : conn.isConnected();
	}
	
	@Override
	public String getServerStatus(DiscDevice device) {
		return null;
	}
	
	@Override
	public boolean isConnected(DiscDevice device) {
		RimageDiscDevice rimageDevice = (RimageDiscDevice) device;
		return isConnected(rimageDevice.getIpAddress(),rimageDevice.getPortNumber());
	}
	
	@Override
	public void testConnection(int deviceId, String server, String port) {
		RimageConnection conn = getRimageConnection(deviceId, server, port, _deviceStatusListener);
		if (!conn.isConnected()) {
			throw new InvalidDefinitionException(
					"Failed to setup connection with " + server + " at port " + port,OutputErrorCode.RUNTIME_ERROR);
		}
	}
	
	@Override
	public String prepareDiscContent(OutputJob job) {
		String result = null;
		try {
			RimageDiscContentPreparationOrder order = new RimageDiscContentPreparationOrder(job);
			String xml = new RimageDiscContentPreparationOrder(job).getXML();
			String orderId = order.getOrderId();
			DiscDestination destination = (DiscDestination) job.getDestination();
			RimageDiscDevice rimageDevice = (RimageDiscDevice) destination.getDiscdevice();
			
			Integer jobId = job.getJobSeq();
			RimageConnection conn = getRimageConnection(rimageDevice.getDeviceId(),
								rimageDevice.getIpAddress(),
								rimageDevice.getPortNumber(), _deviceStatusListener);
			if(conn != null) {
				conn.sendImageOrder(jobId, xml);
				addJob(jobId, RequestStatus.DISC_PREPARING_PROCESSING);
				result = orderId;
			} else {
				updateStatus(jobId,RequestStatus.ERROR,
						"Cannot connect to RimageServer: "
								+ rimageDevice.getIpAddress() + ":"
								+ rimageDevice.getPortNumber());
			}
		} catch (Exception e) {
			LOG.error(e.getMessage());
			throw new OutputException(OutputErrorCode.SERVICE_ERROR, e);
		}
		
		return result;
	}

	@Override
	public String burnDisc(OutputJob job) {
		try {
			RimageDiscBurnerOrder order = new RimageDiscBurnerOrder(job);
			List<String> orders = order.getOrders();
			String orderSetId = order.getOrderSetId();
			DiscDestination destination = (DiscDestination) job.getDestination();
			RimageDiscDevice rimageDevice = (RimageDiscDevice) destination.getDiscdevice();
			Integer jobId = job.getJobSeq();
			RimageConnection conn = getRimageConnection(rimageDevice.getDeviceId(),
					rimageDevice.getIpAddress(),
					rimageDevice.getPortNumber(),
					_deviceStatusListener);
			if(conn != null) {
				conn.sendProductionOrder(jobId, orders);
				addJob(jobId, RequestStatus.DISC_BURNING_PROCESSING);
				return orderSetId;
			} else {
				updateStatus(jobId,RequestStatus.ERROR,
						"Cannot connect to RimageServer: "
								+ rimageDevice.getIpAddress() + ":"
								+ rimageDevice.getPortNumber());
			} 
			return null;
		} catch(Exception e) {
			throw new OutputException(OutputErrorCode.SERVICE_ERROR, e);
		}
	}

	@Override
	public Map<StatusInfo, List<String>> checkPrepareDiscContentStatus(OutputJob job) {
		int jobId = job.getJobSeq();
		Map<StatusInfo, List<String>> map = _jobsStatus.get(jobId);
		if (CollectionUtilities.isEmpty(map)) {
			return null;
		}
		Iterator<StatusInfo> i = map.keySet().iterator();
		StatusInfo info = i.next();
		if (isDoneOrder(info)) {
			_jobsStatus.remove(jobId);
		}
		return map;
	}

	@Override
	public StatusInfo checkBurnDiscStatus(OutputJob job) {
		int jobId = job.getJobSeq();
		Map<StatusInfo, List<String>> map = _jobsStatus.get(jobId);
		if (CollectionUtilities.isEmpty(map)) {
			recoverProductionOrder(job);
			return null;
		}
		Iterator<StatusInfo> i = map.keySet().iterator();
		StatusInfo info = i.next();
		if(!isIdleProductionOrder(info)) {
			if(isDoneOrder(info)) {
				_jobsStatus.remove(jobId);
			}
			return info;
		} else {
			_jobsStatus.remove(jobId);
			recoverProductionOrder(job);
			return null;
		}
	}
	
	private boolean isDoneOrder(StatusInfo status) {
	    if (StatusUtils.isSameStatus(status, RequestStatus.COMPLETED) || (StatusUtils.isSameStatus(status, RequestStatus.ERROR)) || (StatusUtils.isSameStatus(status, RequestStatus.DISC_BURNING_READY))) {
			return true;
		}
	    return false;
	}
	
	private boolean isIdleProductionOrder(StatusInfo status) {
	    if (StatusUtils.isSameStatus(status, RequestStatus.COMPLETED) || (StatusUtils.isSameStatus(status, RequestStatus.ERROR))) {
			return false;
		}
		Date now  = new Date();
		Date statusDate = status.getStatusDate();
		long diff = now.getTime() - statusDate.getTime();
		long diffMinutes = diff / (60 * 1000);	
		if (diffMinutes > RECOVER_PENDING_STATUS_IN_MINUTES) {
			return true;
		}
		return false;
	}
	
	
	private void recoverProductionOrder(OutputJob job) {
		if (canRecoverProductionOrder(job)) {
			OutputJobResults jobResult = job.getOutputJobResults();
			if (jobResult != null && jobResult.getOutputJobFiles() != null) {
				OutputJobFiles jobFiles = jobResult.getOutputJobFiles();
				String clientId = jobFiles.getClientId();
				String orderId = jobFiles.getOrderId();
				DiscDestination destination = (DiscDestination) job.getDestination();
				RimageDiscDevice rimageDevice = (RimageDiscDevice) destination.getDiscdevice();
				RimageConnection conn = getRimageConnection(
						rimageDevice.getDeviceId(), rimageDevice.getIpAddress(),
						rimageDevice.getPortNumber(), _deviceStatusListener);
				
				if (conn != null) {
					try {
						conn.recoverProductionOrder(orderId, clientId, job.getUserName());
						LOG.debug("Send to recover Production Order:"	+ job.getJobSeq());
					} catch (Exception e) {
						LOG.error("Failed to recover Production Order:"	+ e.getMessage());
						discBurningFailed(job.getJobSeq(), "Failed to recover Production Order:" + e.getMessage());
						_recoverJobStatus.remove(job.getJobSeq());
					}
				}
			}
		} else {
			discBurningFailed(job.getJobSeq(), IdleJobProcessor.getIdleErrorMsg());
			_recoverJobStatus.remove(job.getJobSeq());
		}
		
	}
	
	private boolean canRecoverProductionOrder(OutputJob job) {
		int jobId = job.getJobSeq();
		Integer count = _recoverJobStatus.get(jobId);
		if (count == null) {
			_recoverJobStatus.put(jobId, 1);
			return true;
		} else if (count < RETRY) {
			_recoverJobStatus.put(jobId, count + 1);
			return true;
		} 
		return false; 
	}

	public void discPreparationCompleted(Integer jobId, List<String> fileNames) {
		updateJobResults(jobId, RequestStatus.DISC_BURNING_READY, OutputConstants.MSG_DISC_READY_TO_WRITE, fileNames);
	}
	
	public void discPreparationInProgress(Integer jobId, String info) {
		updateStatus(jobId, RequestStatus.DISC_PREPARING_PROCESSING, info);
	}
	
	public void discPreparationFailed(Integer jobId, String errMsg) {
		updateStatus(jobId, RequestStatus.ERROR, errMsg);
	}
	
	public void discBurningCompleted(Integer jobId) {
		updateStatus(jobId, RequestStatus.COMPLETED, OutputConstants.MSG_DISC_COMPLETED);
	}
	
	public void discBurningInProgress(Integer jobId, String info) {
		updateStatus(jobId, RequestStatus.DISC_BURNING_PROCESSING, info);
	}
	
	public void discBurningFailed(Integer jobId, String errMsg) {
		updateStatus(jobId, RequestStatus.ERROR, errMsg);
	}

	protected synchronized void updateStatus(int jobId, RequestStatus status, String detail) {
		StatusInfo statusInfo = StatusUtils.createRequestStatus(status, detail);
		Map<StatusInfo, List<String>>  map = new HashMap<StatusInfo, List<String>>();
		map.put(statusInfo, null);
		_jobsStatus.put(jobId, map);
	}

	protected synchronized void updateJobResults(int jobId, RequestStatus status, String detail, List<String> fileNames) {
		StatusInfo statusInfo = StatusUtils.createRequestStatus(status, detail);
		Map<StatusInfo, List<String>>  map = new HashMap<StatusInfo, List<String>>();
		map.put(statusInfo, fileNames);
		_jobsStatus.put(jobId, map);
	}
	
	public synchronized void addJob(int jobId, RequestStatus status){
		Map<StatusInfo, List<String>>  map = new HashMap<StatusInfo, List<String>>();
		map.put(StatusUtils.createRequestStatus(status, ""), null);
		_jobsStatus.put(jobId, map);
	}

    public void shutdown() {
    	// Disconnect all the connections on shutdown
    	List<RimageConnection> connections = (List<RimageConnection>) _connections.values();
    	for (RimageConnection conn: connections) {
    		try {
				conn.disconnect();
			} catch (MsgNotConnectedException e) {
				LOG.error("MsgNotConnectedException occured during shutdown. " + e.getMessage());
				e.printStackTrace();
			} catch (SystemException e) {
				LOG.error("SystemException occured during shutdown. " + e.getMessage());
				e.printStackTrace();
			}
    	}
	}

	public synchronized void removeJob(int jobId){
		_jobsStatus.remove(jobId);
	}

	@Override
	public void discPreparationSubmitted(OutputJob job, String orderId) {
		// nothing to do
	}

	@Override
	public void discBurningSubmitted(OutputJob job, String orderId) {
		// nothing to do
	}
	
	@Override
	public	DiscDeviceStatusListener getDiscDeviceStatusListener() {
		return _deviceStatusListener;
	}

	@Override
	public	void setDiscDeviceStatusListener(DiscDeviceStatusListener listener) {
		_deviceStatusListener = listener;
	}
}
