/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage.productionorder;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Label {
    
    private String fileName;
    private BTW btw;
    
    public Label() {
        super();
        this.btw = new BTW();
   }

    public Label(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    @XmlAttribute(name = "Filename")
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    public BTW getBtw() {
        return btw;
    }
    
    @XmlElement(name = "BTW")
    public void setBtw(BTW btw) {
        this.btw = btw;
    }    

 }
