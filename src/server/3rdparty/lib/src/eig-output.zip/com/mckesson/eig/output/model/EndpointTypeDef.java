/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.util.CollectionUtilities;

/**
 * @author OFS
 * @author Jon Anderson
 *
 */

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "endpointTypeDef")
@XmlType (name = "endpointTypeDef")
public abstract class EndpointTypeDef implements Serializable, Cloneable {


	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 99;
	private static final int HASH_INIT = 13;
	private EndpointCategory _endpointCategory;
	private String _type;
	private Map<String, ? extends Object> _properties;
	private String _description;
	private boolean _enabled;
	private transient OutputLoV _lov;
	private int _id;
    private List<MapModel> _propertyList;

	public EndpointTypeDef() {
    }

	/**
	 * @param endpointCategory
	 */
	public EndpointTypeDef(EndpointCategory endpointCategory) {
		_endpointCategory = endpointCategory;
	}

	/**
	 * @return
	 */
	public EndpointCategory getEndpointCategory() {
		return _endpointCategory;
	}

	@Override
	public boolean equals(Object o) {

	    EndpointTypeDef typeDef = (EndpointTypeDef) o;

	    if (typeDef.getEndpointCategory() != _endpointCategory) {
	    	return false;
	    }
	    if (!ObjectUtils.equals(typeDef._properties, _properties)) {
	        return false;
	    }
	    if (!ObjectUtils.equals(typeDef._type, _type)) {
	        return false;
	    }
	    if (!ObjectUtils.equals(typeDef._description, _description)) {
	        return false;
	    }
	    if (typeDef._enabled != _enabled) {
	    	return false;
	    }

	    return true;
	}

	@Override
	public int hashCode() {

	    HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
	    builder.append(_endpointCategory);
	    builder.append(_properties);
	    builder.append(_type);
	    builder.append(_description);
	    builder.append(_enabled);

	    return builder.toHashCode();
	}

	@Override
	public EndpointTypeDef clone() {

		try {

			EndpointTypeDef endpointTypeDef = (EndpointTypeDef) super.clone();
			if (endpointTypeDef._properties != null) {
			    endpointTypeDef._properties =
			        new HashMap<String, Object>(endpointTypeDef._properties);
			}

			return endpointTypeDef;

		} catch (CloneNotSupportedException e) {
			throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
		}
	}

	/**
	 * The type of the destination
	 *
	 * @return the type
	 */
	public String getType() {
		return _type;
	}

	/**
	 * @param type the _type to set
	 */
	@XmlElement(name = "type")
	public void setType(String type) {
		_type = type;
	}

	/**
	 * The properties which are used to define the specifics of the destination
	 *
	 * @return the _properties
	 */
	public Map<String, ? extends Object> getProperties() {

        if (CollectionUtilities.hasContent(_properties)) {
            return _properties;
        }

        if (CollectionUtilities.hasContent(_propertyList)) {

            Map<String, Object> prop = new HashMap<String, Object>();
            for (MapModel mapModel : _propertyList) {
                prop.put(mapModel.getKey().toString(), mapModel.getValue());
            }
            setProperties(prop);
        }
        return _properties;
	}

	/**
	 * @param properties the _properties to set
	 */
    @XmlTransient
	public void setProperties(Map<String, ? extends Object> properties) {

        if (properties != null) {

            if (CollectionUtilities.hasContent(_propertyList)) {
                _propertyList.clear();
            } else {
                _propertyList = new ArrayList<MapModel>();
            }

            for (Map.Entry<String, ? extends Object> e : properties.entrySet()) {
                _propertyList.add(new MapModel(e.getKey(), e.getValue()));
            }
            _properties = properties;
        }
	}

	/**
	 * TODO
	 *
	 * @return the _description
	 */
	public String getDescription() {

	    return _description;
	}

	/**
	 * @param description the _description to set
	 */
	@XmlElement(name = "description")
	public void setDescription(String description) {
	    _description = description;
	}

	/**
	 * @return the enabled
	 */
	public boolean isEnabled() {
		return _enabled;
	}

	/**
	 * @param enabled the enabled to set
	 */
	@XmlElement(name = "enabled")
	public void setEnabled(boolean enabled) {
		_enabled = enabled;
	}

	public OutputLoV getLov() {
		return _lov;
	}

	@XmlTransient
	public void setLov(OutputLoV lov) {
		_lov = lov;
	}

	public int getId() {
		return _id;
	}

	@XmlTransient
	public void setId(int id) {
		_id = id;
	}

    @XmlElementWrapper(name = "properties")
    @XmlElement(name = "property", type = MapModel.class)
    public void setPropertiesList(List<MapModel> propertyList) {
        _propertyList = propertyList;
    }

    public List<MapModel> getPropertiesList() {

        if (_properties != null) {
            _propertyList = new ArrayList<MapModel>();
            for (Map.Entry<String, ? extends Object> e : _properties.entrySet()) {
                _propertyList.add(new MapModel(e.getKey(), e.getValue()));
            }
        }
        return _propertyList;
    }
}
