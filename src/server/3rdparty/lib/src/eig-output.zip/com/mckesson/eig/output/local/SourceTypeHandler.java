/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local;

import com.mckesson.eig.output.local.source.Source;
import com.mckesson.eig.output.local.transformers.DefaultHeaderFooter;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;

/**
 * @author Pranav Amarasekaran
 * @date   Jul 23, 2009
 * @since  Output 1.0; Jul 23, 2009
 */
public class SourceTypeHandler extends ReflectiveTypeHandler {

	private String _headFooterClass
		= "com.mckesson.eig.output.local.transformers.DefaultHeaderFooter";

	public SourceTypeHandler(Class<OutputEndpoint> endpointClass,
			EndpointCategory endpointCategory) {
		super(endpointClass, endpointCategory);
	}

	public SourceTypeHandler(String enabled,
			String endpointClass,
			String endpointCategory) {
		super(enabled, endpointClass, endpointCategory);
	}

	public SourceTypeHandler(String enabled,
			String endpointClass,
			String endpointCategory,
			String headFooterClass) {
		super(enabled, endpointClass, endpointCategory);
		_headFooterClass = headFooterClass;
	}

	/**
	 * @see com.mckesson.eig.output.local.EndpointTypeHandler#createEndpoint(EndpointDef)
	 */
	public OutputEndpoint createEndpoint(EndpointDef endpointDef) {
		try {
			Source endpoint = (Source) getEndpointClass().newInstance();
			DefaultHeaderFooter headerFooter = (DefaultHeaderFooter)
					Class.forName(_headFooterClass).newInstance();
			endpoint.setHeaderFooter(headerFooter);

			if (endpointDef.getProperties() != null
					&& endpointDef.getProperties().size() > 0) {
				endpoint.getProperties().setProperties(endpointDef.getProperties());
			}

			return endpoint;
		} catch (Exception e) {
			throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
		}
	}
}
