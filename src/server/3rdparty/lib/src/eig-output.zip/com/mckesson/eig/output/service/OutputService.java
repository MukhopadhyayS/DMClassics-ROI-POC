    /*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.service;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.Use;

import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputJobs;
import com.mckesson.eig.output.model.OutputRequest;
import com.mckesson.eig.output.model.OutputServicePropertySet;
import com.mckesson.eig.output.model.PropertyDefList;
import com.mckesson.eig.output.util.MapModel;

/**
 * Interface for the EIG OutputService object. The OutputService receives requests to
 * retrieve, transform and deliver content to configured destinations.
 *
 * @author OFS
 * @author Jon Anderson
 */
@WebService(name            = "OutputPortType_v1_0",
            targetNamespace = "http://eig.mckesson.com/wsdl/output-v1")
@SOAPBinding(style          = Style.DOCUMENT,
             use            = Use.LITERAL,
             parameterStyle = SOAPBinding.ParameterStyle.WRAPPED)
public interface OutputService {

	/**
	 * Queries the service for the current state of a job
	 *
	 * @param jobID unique id assigned to the job when it was created. not <code>null</code>
	 * @return <code>null</code> if a job identified by <code>jobID</code> can not be found
	 */
    @WebMethod (operationName = "queryOutputJob",
                action        = "http://eig.mckesson.com/wsdl/output-v1/queryOutputJob")
    @WebResult (name          = "outputJob")
	OutputJob queryOutputJob(@WebParam(name = "jobID") int jobID);

	/**
	 * Queries the service for OutputJob's that match the identifiers in
	 * <code>queryOptions</code>
	 *
	 * @param queryOptions service specific options. may be <code>null</code>
	 * @return not <code>null</code> but maybe empty
	 */
    @WebMethod (operationName = "queryOutputJobs",
                action        = "http://eig.mckesson.com/wsdl/output-v1/queryOutputJobs")
    @WebResult (name          = "outputJobs")
    List<OutputJob> queryOutputJobs(List<MapModel> queryOptions);


	/**
	 * Returns a list of property definitions for properties that may be set on the service
	 * at runtime using setServiceProperty
	 *
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "getServicePropertyDefs",
                action        = "http://eig.mckesson.com/wsdl/output-v1/getServicePropertyDefs",
                exclude       = true)
    @WebResult (name          = "propertyDefs")
	PropertyDefList getServicePropertyDefs();

	/**
	 * Returns the current values for all configurable properties for the service
	 *
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "getServiceProperties",
                action        = "http://eig.mckesson.com/wsdl/output-v1/getServiceProperties")
    @WebResult (name          = "outputServicePropertySet")
	OutputServicePropertySet getServiceProperties();

	/**
	 * Set the value of service property
	 *
	 * @param property property to set. not <code>null</code>
	 * @param value new value for the property
	 */
    @WebMethod (operationName = "setServiceProperty",
                action        = "http://eig.mckesson.com/wsdl/output-v1/setServiceProperty",
                exclude       = true)
	void setServiceProperty(int userId, String property, String value);

	/**
	 * Return the current value for a service property
	 *
	 * @param property not <code>null</code>
	 * @return may be <code>null</code>
	 */
    @WebMethod (operationName = "getServiceProperty",
                action        = "http://eig.mckesson.com/wsdl/output-v1/getServiceProperty",
                exclude       = true)
	String getServiceProperty(String property);

	/**
	 * Submits an OutputRequest for processing and returns the new OutputJob
	 *
	 * @param request
	 * @return not <code>null</code>, exceptions will be thrown if there are errors
	 */
    @WebMethod (operationName = "submitOutputRequest",
                action        = "http://eig.mckesson.com/wsdl/output-v1/submitOutputRequest")
    @WebResult (name          = "outputJob")
    OutputJob submitOutputRequest(@WebParam(name = "outputRequest")OutputRequest request);
    
    /**
     * Create an OutputRequest and returns the new OutputJob
     *
     * @param request
     * @return not <code>null</code>, exceptions will be thrown if there are errors
     */
    @WebMethod (operationName = "postAndPause",
                action        = "http://eig.mckesson.com/wsdl/output-v1/postAndPause")
    @WebResult (name          = "outputJob")
    List<OutputJob> postAndPause(@WebParam(name = "request")List<OutputRequest> request);    

	/**
	 * This method is used to resubmit a failed output job.
	 *
	 * @param jobID
	 * 		the jobId
	 */
    @WebMethod (operationName = "resubmitOutputJob",
                action        = "http://eig.mckesson.com/wsdl/output-v1/resubmitOutputJob")
    void resubmitOutputJob(@WebParam(name = "jobID")int jobID);

	/**
	 * Cancels an active OutputJob.
	 *
	 * @param jobID not <code>null</code> identification of a Job
	 * @return not <code>null</code> job with updated status.
	 */
    @WebMethod (operationName = "cancelOutputJob",
                action        = "http://eig.mckesson.com/wsdl/output-v1/cancelOutputJob")
    @WebResult (name          = "outputJob")
	OutputJob cancelOutputJob(@WebParam(name = "jobID")int jobID);

	/**
	 * Sets the service properties.
	 * 
	 * @param properties the properties
	 * @param userId the user id
	 */
    @WebMethod (operationName = "setServiceProperties",
                action        = "http://eig.mckesson.com/wsdl/output-v1/setServiceProperties",
                exclude       = true)
	void setServiceProperties(int userId, OutputServicePropertySet properties);

	/**
	 * Pause output job.
	 * 
	 * @param jobID the job id
	 * 
	 * @return the output job
	 */
    @WebMethod (operationName = "pauseOutputJob",
                action        = "http://eig.mckesson.com/wsdl/output-v1/pauseOutputJob")
    @WebResult (name          = "outputJob")
	OutputJob pauseOutputJob(@WebParam(name = "jobID")int jobID);

	/**
	 * Restart output job.
	 * 
	 * @param jobID the job id
	 * 
	 * @return the output job
	 */
    @WebMethod (operationName = "restartOutputJob",
                action        = "http://eig.mckesson.com/wsdl/output-v1/restartOutputJob")
    @WebResult (name          = "outputJob")
	OutputJob restartOutputJob(@WebParam(name = "jobID")int jobID);

	/**
	 * This method is used to redirect an output job.
	 * 
	 * @param jobID The unique id of the job that should be redirected
	 * @param request This request holds the overridden destination and output
	 * preferences that should be applied when the job is redirected
	 */
     @WebMethod (operationName = "redirectOutputJob",
                 action        = "http://eig.mckesson.com/wsdl/output-v1/redirectOutputJob")
     void redirectOutputJob(@WebParam(name = "jobID")int jobID,
    		 			    @WebParam(name = "outputRequest")OutputRequest request);

     /**
      * Re-submitting the output Job As a new Job.
      * 
      * When an archived job is to be reprinted, the original job details 
      * should not be modified in order to maintain audit trail. 
      * So a new job is created during a resubmit of output job.
      * @param jobID The unique id of the job that should be redirected
	  * @param request This request holds the overridden destination and output
	  * preferences that should be applied when the job is redirected
	  * @return OutputJob - Newly constructed output job object will be returned 
      */
     @WebMethod (operationName = "resubmitAsNewOutputJob",
    		 	 action = "http://eig.mckesson.com/wsdl/output-v1/resubmitAsNewOutputJob")
     OutputJob resubmitAsNewOutputJob(int jobID, OutputRequest request); 
     
     /**
 	 * Method to retrieve the output request information for a given jobID and 
     * store the document info in the filepath argument.
 	 * 
 	 * @param jobID The unique id of the job that should be redirected
 	 * @param filePath This filePath holds the location where the PDF is available
 	 */
      @WebMethod (operationName = "retrieveOutputRequestInfo",
              	  action = "http://eig.mckesson.com/wsdl/output-v1/retrieveOutputRequestInfo")
      void retrieveOutputRequestInfo(@WebParam(name = "jobID")int jobID,
     		 			    @WebParam(name = "filePath")String filePath);
      
      /**
       * Queries the service for OutputJob's that match the identifiers in
       * <code>queryOptions</code>
       *
       * @param queryOptions service specific options. may be <code>null</code>
       * @return not <code>null</code> but maybe empty
       */
      @WebMethod (operationName = "queryOutputJobsWithDeviceInfo",
                  action = "http://eig.mckesson.com/wsdl/output-v1/queryOutputJobsWithDeviceInfo")
      @WebResult (name          = "outputJobs")
      OutputJobs queryOutputJobsWithDeviceInfo(
            @WebParam(name = "queryOptions") List<MapModel> queryOptions);
}
