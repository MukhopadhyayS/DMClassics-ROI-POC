/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage.orderset;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.mckesson.eig.output.device.disc.rimage.RimageConstants;


@XmlRootElement(name = "OrderSet")
@XmlType( propOrder={"order_references","prod_orderSet"})
public class OrderSet {
    
    private String orderSetId;
    private  String clientId;
    private String priority;
    private String originator;
    private String referencedJobId;
    //required field
    private String targetCluster;
    
    private List<OrderReference> order_references;
    
    private ProductionOrderSet prod_orderSet;

    public OrderSet() {
        super();
        this.targetCluster = RimageConstants.DEFAULT_PRODUCTION_CLUSTER;
    }

    public String getOrderSetId() {
        return orderSetId;
    }

    @XmlAttribute(name = "OrderSetId")
    public void setOrderSetId(String orderSetId) {
        this.orderSetId = orderSetId;
    }

    public String getClientId() {
        return clientId;
    }

    @XmlAttribute(name = "ClientId")
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getPriority() {
        return priority;
    }

    @XmlAttribute(name = "Priority")
    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getOriginator() {
        return originator;
    }

    @XmlAttribute(name = "Originator")
    public void setOriginator(String originator) {
        this.originator = originator;
    }

    public String getReferencedJobId() {
        return referencedJobId;
    }

    @XmlAttribute(name = "ReferencedJobId")
    public void setReferencedJobId(String referencedJobId) {
        this.referencedJobId = referencedJobId;
    }

    public String getTargetCluster() {
        return targetCluster;
    }

    @XmlAttribute(name = "TargetCluster")
    public void setTargetCluster(String targetCluster) {
        this.targetCluster = targetCluster;
    }

    public List<OrderReference> getOrder_references() {
        return order_references;
    }
    
    @XmlElement(name = "OrderReference")
    public void setOrder_references(List<OrderReference> order_references) {
        this.order_references = order_references;
    }

    public ProductionOrderSet getProd_orderSet() {
        return prod_orderSet;
    }

    @XmlElement(name = "ProductionOrderSet")
    public void setProd_orderSet(ProductionOrderSet prod_orderSet) {
        this.prod_orderSet = prod_orderSet;
    }
    

}
