package com.mckesson.eig.output.service;

import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.local.dao.OutputLovDAO;
import com.mckesson.eig.output.local.dao.OutputSearchLoVDAO;
import com.mckesson.eig.utility.util.SpringUtilities;

public class OutputBaseService {

	public OutputBaseService() {
	}

	public enum DAOName {

		Output_LOV_DAO("OutputLovDAO"),
		Output_JOB_DAO("OutputJobDAO"),
		Output_SEARCH_LOV("OutputSearchLoVDAO");

		private final String _daoName;

		private DAOName(String name) {
			_daoName = name;
		}

		@Override
		public String toString() {
			return _daoName;
		}
	}

	public OutputLovDAO getOutputLovDAO() {
		return (OutputLovDAO) SpringUtilities.getInstance()
				.getBeanFactory().getBean(DAOName.Output_LOV_DAO.toString());
	}

	/**
	 * Returns the OutputJobDAO.
	 * 
	 * @return the output job dao
	 */
	public OutputJobDAO getOutputJobDAO() {
		return (OutputJobDAO) SpringUtilities.getInstance()
				.getBeanFactory().getBean(DAOName.Output_JOB_DAO.toString());
	}	

	/**
	 * This method returns an OutputSearchLoVDAO.
	 * 
	 * @return OutputSearchLoVDAO
	 */
	public OutputSearchLoVDAO getOutputSearchLoVDAO() {
		return (OutputSearchLoVDAO) SpringUtilities.getInstance()
				.getBeanFactory().getBean(DAOName.Output_SEARCH_LOV.toString());
	}
}
