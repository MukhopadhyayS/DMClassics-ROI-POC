/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.mediator;

import com.mckesson.eig.utility.exception.ApplicationException;

/**
 * 
 * 
 * @author Michael Macaluso
 * @author Srini Paduri
 * @since 13.5.2
 */
public class OutputJobException extends ApplicationException {

	/**
	 * Default Serialization UID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Construct a Job exception with no detail message.
	 */
	public OutputJobException() {
		super();
	}

	/**
	 * Construct a Job exception chaining the supplied exception.
	 * 
	 * @param e
	 *            Chained exception.
	 */
	public OutputJobException(Exception e) {
		super(e);
	}

	/**
	 * Construct a Job exception with the given detail message.
	 * 
	 * @param s
	 *            Detail message, or null if no detail message.
	 */
	public OutputJobException(String s) {
		super(s);
	}

	/**
	 * Construct a Job exception with the given detail message and chained
	 * exception.
	 * 
	 * @param s
	 *            Detail message, or null if no detail message.
	 * @param e
	 *            Chained exception.
	 */
	public OutputJobException(String s, Exception e) {
		super(s, e);
	}

}
