/**
 * Copyright � 2010 McKesson Corporation and/or one of its subsidiaries.
 * All rights reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.roi;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.MessageFormat;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletResponse;

import com.mckesson.eig.output.local.source.Source;
import com.mckesson.eig.output.local.source.SourceListener;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.FileUtilities;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * @author OFS
 * @date Feb 3, 2009
 * @since HPF 13.1; Feb 3, 2009
 */
public class ROISource extends Source {

	private static final Log LOG = LogFactory.getLogger(ROISource.class);

	private static final String URL_LOC = "{0}://{1}:{2}/roi/filedownload/BaseFileDownloader"
			+ "?"
			+ ROIRequest.USER_NAME
			+ "={3}"
			+ "&"
			+ ROIRequest.PASSWORD
			+ "={4}"
			+ "&OWNER_TYPE="
			+ "{5}"
			+ "&SOURCE"
			+ "={6}"
			+ "&"
			+ "{7}" + "={8}";

	private static final String OWNER_TYPE = "FileDownloader";
	private static final String SOURCE = "Output";
	private static final String ATTACHMENT_SOURCE = "attachment";
	private static final int BUFFER_SIZE = 8192;

	private String _server;
	private String _port;
	private String _protocol;
	private final ROIRequest _request = new ROIRequest();
	private final ThreadLocal<byte[]> _bufferRef = new ThreadLocal<byte[]>() {
		@Override
		protected byte[] initialValue() {
			return new byte[BUFFER_SIZE];
		}
	};

	public ROISource() {
	}

	@Override
	protected void processPart(JobPart part) throws Exception {
		if (part != null) {
			ROIContent content = _request.getContent(part);
			File f = null;
			if (content.getContentType().equalsIgnoreCase(ATTACHMENT_SOURCE)) {
				f = getAttachment(part, 1);
			} else {
				f = getFile(part, 1);		
			}
			getContentToFile(content, f);
			LOG.info("processed part: " + part.getPartID());
		}
	}

	private byte[] getBuffer() {
		return _bufferRef.get();
	}

	@Override
	protected void processPart(OutputJob job, JobPart part, FileUtilities f,
			SourceListener listener) throws Exception {
		if (part != null) {
			ROIContent content = _request.getContent(part);
			File file = f.getFile();
			getContentToFile(content, file);
			if (content.getContentType().equalsIgnoreCase(ATTACHMENT_SOURCE)) {
				
				/* TODO:
				 * add property called printable - if printable property is set save attachment
				 * currently checking if extension property is pdf - if yes print
				 */
				// CR 356981, we should not output any attachement file format. 
				String ext = part.getProperties().get(OutputConstants.ATTACHMENT_EXTENSION);
				if (ext != null) {
					saveAttachmentFile(file, job, part, listener); 					
				}
			} else {
				saveSourceFile(file, job, part, listener); 			
			}
			LOG.info("processed part: " + part.getPartID());
		}
	}

	public void getContentToFile(ROIContent content, File f) throws Exception {
		OutputStream os = null;
		long contentCount = 0;
		try {
			os = IOUtilities.createFileOutputStream(f);
			contentCount = getContent(getServletUrl(content), os);
		} finally {
			IOUtilities.close(os);
		}
		if (contentCount <= 0) {
			if (f.exists()) {
				f.delete();
			}
			throw new OutputException("Cannot retrieve content: "
					+ content.getFileIds(), OutputErrorCode.MISSING_DATA);
		}
	}

	protected long getContent(String urlPath, OutputStream os)
			throws IOException {
		HttpURLConnection huc = null;
		InputStream is = null;
		long data = 0;

		try {
			URL url = new URL(urlPath);
			if (url.getProtocol().equalsIgnoreCase("https")) {
				huc = (HttpsURLConnection) url.openConnection();
			} else {
				huc = (HttpURLConnection) url.openConnection();
			}
			// Trust all hosts.
			// huc.setHostnameVerifier(new MyVerifier());

			huc.setRequestMethod("GET");
			huc.connect();
			is = huc.getInputStream();
			int returnCode = huc.getResponseCode();

			int contentLength = huc.getContentLength();
			LOG.debug("Content Length =" + contentLength);
			if (returnCode == HttpServletResponse.SC_OK) {
				data = IOUtilities.write(is, getBuffer(), os);
			}
		} catch (MalformedURLException e) {
			LOG.debug("Invalid Servlet URL : " + urlPath);
		} catch (Exception e) {

			LOG.debug("Unable to retrieve content from url, [" + urlPath + "] "
					+ e.getMessage());
		} finally {
			IOUtilities.close(is);
			if (huc != null) {
				huc.disconnect();
			}
		}
		return data;
	}

	/**
	 * @return server
	 */
	@OutputProperty(label = "Host Name", description = "Name of the host for the ROI web service", defaultValue = "localhost", index = "2")
	public String getServer() {
		return _server;
	}

	/**
	 * @param server
	 */
	public void setServer(String server) {
		_server = server;
	}

	/**
	 * @return port
	 */
	@OutputProperty(label = "Port", description = "TCP port for the host for the ROI web service", defaultValue = "8888", index = "3")
	public String getPort() {
		return _port;
	}

	/**
	 * @param port
	 */
	public void setPort(String port) {
		_port = port;
	}

	/**
	 * @return protocol
	 */
	@OutputProperty(label = "Protocol", description = "Protocol to communicate with the ROI web service", defaultValue = "http", possibleValues = {
			"http", "https" }, index = "1")
	public String getProtocol() {
		return _protocol;
	}

	/**
	 * @param protocol
	 */
	public void setProtocol(String protocol) {
		_protocol = protocol;
	}

	private String getServletUrl(ROIContent content) {
		//set ROI source:  if content type is 'attachment' use ATTACHMENT_SOURCE : default SOURCE
		String tmpSource = SOURCE;
		String tmpFileIdKey = ROIRequest.FILE_IDS;
		if (content.getContentType().equalsIgnoreCase(ATTACHMENT_SOURCE)) {
			tmpSource = ATTACHMENT_SOURCE;
			tmpFileIdKey = ROIRequest.FILE_NAME;
		}

		Object[] args = { getProtocol(), getServer(), getPort(),
				content.getUserName(), content.getPassword(), OWNER_TYPE,
				tmpSource, tmpFileIdKey, content.getFileIds() };

		MessageFormat mf = new MessageFormat(URL_LOC);
		return mf.format(args);
	}
}
