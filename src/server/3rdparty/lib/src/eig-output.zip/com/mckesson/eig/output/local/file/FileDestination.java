/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 */

package com.mckesson.eig.output.local.file;

import java.io.File;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.OutputJobEndpoint;
import com.mckesson.eig.output.model.DestDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.OutputProperty.PropertyFlag;
import com.mckesson.eig.output.util.status.StatusUtils;

/**
 * TODO
 *
 * @author Jon Anderson
 */
public class FileDestination extends Destination {

	/** TODO */
	public static final String DEFAULT_DIRECTORY_NAME = "";


	private String _directoryName;
	private File _directory;
	private long _purgeTime;
	private String _filePassword;
	private boolean _filePasswordRequired;
	private String _mediaType;
	private long _cdSizeMb;
	private long _dvdSizeMb;
	private FileTypeHandler _typeHandler;
    private StatusInfo _status;

	/**
     * TODO
     *
     * @param handler
     * @param baseDir
     */
	public FileDestination(FileTypeHandler handler, DestDef destDef) {
        super();

        _status = StatusUtils.createEndpointStatus(EndpointStatus.OK, null);

		if (handler == null) {
			throw new IllegalArgumentException("handler argument is null");
		}

        _typeHandler = handler;

		Map<String, ? extends Object> properties = destDef.getProperties();
		setDirectoryName((String) properties.get("directoryName"));

		//HPF 15.2 - requires destDef settings for purgeTime
		//File destination does not set the property overrides so property must be set now
		setPurgeTime(Integer.valueOf((String)properties.get(FileConstants.FILE_PURGE_TIME)));
	}

	/**
     * @see OutputJobEndpoint#processJob(com.mckesson.eig.output.model.OutputJob)
     */
	@Override
    public void processJob(OutputJob job) {
	}


	/**
	 * This method is used to get the queue password.
	 * @param job - outputjob
	 * @return
	 */
	public String getQueuePassword(OutputJob job) {

		// Default queue password
		String qPassword = job.getPropertyValue(OutputConstants.OUTPUT_FILE_PASSWORD);
		// custom queue password from output job
		boolean isNotBlank = StringUtils.isNotBlank(qPassword);
	    qPassword = (isNotBlank) ? qPassword : getPassword();

	    return (StringUtils.isNotBlank(qPassword) || getPasswordRequired()) ?
	    		StringUtils.trim(qPassword) : null;
	}

	/**
	 * This method is used to return the request level password in output job.
	 * @param job - outputjob
	 * @return if exists request level password it returns, otherwise null
	 */
	public String getRequestPassword(OutputJob job) {

		// Check whether the Request level password is available in outputjob.
		String reqPassword = job.getPropertyValue(OutputConstants.OUTPUT_FILE_REQUEST_PASSWORD);
		return !StringUtils.isNotBlank(reqPassword) ? null : reqPassword;
	}

	//FilePurgeScheduler is dependent on this property
	@OutputProperty(
			defaultValue = DEFAULT_DIRECTORY_NAME,
			description = "Released PDF file location",
			label = "PDF Enterprise Location",
			possibleValues = {"(\\\\\\\\(\\d{1,3}\\.){3,3}(\\d{1,3})|"
					   + "(\\\\\\\\)[^\\/:*|<>?\"]+)(\\\\[^\\/:*|<>?\"])*" },
			required = "true",
			index = "1")
	public String getDirectoryName() {
		return _directoryName;
	}

	/**
     * TODO
     *
     * @param directoryName
     *            the _directoryName to set
     */
	public void setDirectoryName(String directoryName) {
		if (directoryName == null) {
			throw new IllegalArgumentException("directoryName argument is null");
		}

		// get the absolute file directory
		File dir = new File(directoryName);
		directoryName = dir.getAbsolutePath();

		File newDir = new File(dir.getAbsolutePath());
		_directory  = newDir;
		_directoryName = directoryName;

		try {
		    FileTypeHandler.validateDirectory(newDir);
		} catch (InvalidDefinitionException e) {
		    _status = StatusUtils.createEndpointStatus(
		                                     EndpointStatus.ERR_HELP, "Invalid Directory");
		}
	}


	//FilePurgeScheduler is dependent on this property
    @OutputProperty(
                    defaultValue = "8",
                    description = "Enter the number of hours that a PDF"
                    + " should be saved for the user to access",
                    label = "Auto-purge of PDF Files",
                    possibleValues = { "[1-9]\\d*" },
                    required = "true",
                    index = "2")
	public long getPurgeTime() {
	    return _purgeTime;
	}

	public void setPurgeTime(long purgeTime) {
	    _purgeTime = purgeTime;
	}

    @OutputProperty(
                    defaultValue = "Yes",
                    description = "Is a password required to open PDF file",
                    label = "Password Required for PDF Files",
                    possibleValues = {"Yes", "No" },
                    bindingProperty = "password",
                    index = "3")
	public boolean getPasswordRequired() {
	    return _filePasswordRequired;
	}

	public void setPasswordRequired(boolean passwordRequired) {
	    _filePasswordRequired = passwordRequired;
	}

    @OutputProperty(
                    defaultValue = "",
                    description = "Enter a password to be used as a default whenever "
                		          +  "any user outputs a job as Save as File (PDF).",
                    label = "Default Password",
                    flags = PropertyFlag.JOB_DEFAULT,
                    index = "4",
                    maxLength = "50")
	public String getPassword() {
	    return _filePassword;
	}

	public void setPassword(String password) {
	    _filePassword = password;
	}

    @OutputProperty(
                    defaultValue = "Other/Unlimited Size",
                    description = "Select the media type to display as the default when "
                    		         + "the user elects to use Save as File to output.",
                    label = "Default PDF Media",
                    possibleValues = { "CD", "DVD", "Other/Unlimited Size" },
                    flags = PropertyFlag.JOB_DEFAULT,
                    index = "5")
	public String getMediaType() {
	    return _mediaType;
	}

	public void setMediaType(String mediaType) {
	    _mediaType = mediaType;
	}

    @OutputProperty(defaultValue = "620",
                    description = "Enter the maximum limit a PDF can be created when CD"
                    		      + " is selected as the media type.",
                    possibleValues = { "\\d+" },
                    label = "CD Size Limit",
                    index = "6")
    public long getCdSizeMb() {

    	// CR# 353,939 - Queue Configuration
    	// Returns the Default value if the cdsize is less the 1
    	if (1 > _cdSizeMb) {
    		return OutputConstants.OUTPUT_DEFAULT_CD_SIZE_MB;
    	}
        return _cdSizeMb;
    }
   /**
     * TODO
     * @param cdSizeMb the _cdSizeMb to set
     */
    public void setCdSizeMb(long cdSizeMb) {
        _cdSizeMb = cdSizeMb;
    }

    /**
     * TODO
     * @return the _dvdSizeMb
     */
    @OutputProperty(defaultValue = "4",
                    description = "Enter the maximum limit a PDF can be created when DVD"
                    		      + " is selected as the media type.",
                    possibleValues = { "\\d+" },
                    label = "DVD Size Limit" ,
                    index = "6")
    public long getDvdSizeMb() {

    	// CR# 353,939 - Queue Configuration
    	// Returns the Default value if the cdsize is less the 1
    	if (1 > _dvdSizeMb) {
    		return OutputConstants.OUTPUT_DEFAULT_DVD_SIZE_MB;
    	}
        return _dvdSizeMb;
    }

    /**
     * TODO
     * @param dvdSizeMb the _dvdSizeMb to set
     */
    public void setDvdSizeMb(long dvdSizeGb) {
        _dvdSizeMb = dvdSizeGb * FileConstants.GB_TO_MB;
    }


	/**
     * TODO
     *
     * @return
     */
	public FileTypeHandler getTypeHandler() {
		return _typeHandler;
	}


    public StatusInfo queryEndpointStatus() {
        return _status;
    }

    public long getFileMaxSizeInByte(OutputJob job) {
    	long result = -1;
        if (job.getPropertyValue(OutputConstants.OUTPUT_FILE_MEDIA) != null) {

            if (job.getPropertyValue(OutputConstants.OUTPUT_FILE_MEDIA).equalsIgnoreCase("CD")) {
            	result = getCdSizeMb();
            }
            if (job.getPropertyValue(OutputConstants.OUTPUT_FILE_MEDIA).equalsIgnoreCase("DVD")) {
            	result = getDvdSizeMb();
            }
        }
        return result * FileConstants.MB_SIZE;
    }
}
