package com.mckesson.eig.output.local.source;

import com.mckesson.eig.output.model.OutputJob;

public interface SourceListener {

	void start(OutputJob job);

	void addFile(OutputJob job, String path);

	void finish(OutputJob job);

	void error(OutputJob job, String errorMessage);

}
