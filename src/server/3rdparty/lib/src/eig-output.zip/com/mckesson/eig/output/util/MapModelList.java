/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.util;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * List of mapModels
 *
 * @author OFS
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement (name = "mapModels")
@XmlType(name = "mapModels")
public class MapModelList extends GetSetList<MapModel> implements Serializable {

	/** The _map model. */
	private List<MapModel> _mapModel;

	public MapModelList() {
		super();
	}

	/**
	 * Instantiates a new map model list.
	 *
	 * @param mapModel
	 *            the map model
	 */
	public MapModelList(List<MapModel> mapModel) {
		super(mapModel);
	}
}
