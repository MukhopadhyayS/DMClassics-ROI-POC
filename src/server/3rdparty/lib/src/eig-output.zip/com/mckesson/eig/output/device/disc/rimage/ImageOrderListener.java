package com.mckesson.eig.output.device.disc.rimage;

import java.util.List;

import org.w3c.dom.Document;

import com.mckesson.eig.output.local.device.disc.DiscStatusListener;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.utility.util.StringUtilities;


/**
 * @author Eric Yu
 * @author Shahm Nattarshah
 * @date  Sep 2013
 * @since  MPF 16.1
 *
 * This class is used as a Listener for getting the ImageOrderStatus that are submitted
 * to RIMAGE device. Used in RImageConnection class.
 *
 */
public class ImageOrderListener extends AbstractOrderListener {

	public ImageOrderListener(DiscStatusListener listener) {
		super(listener);
	}
	
	/**
	 * This method will get the notificaiton from RIMAGe whenever there is 
	 * a status update for a order in RIAMGE device.
	 */
	@Override
	public void onStatus(String receivedXmlOrderStatus) {
		String errMsg;
		String errCode;
		String state;
		
		String orderId;
		int jobId;

		// Replace the base URI in the XML string
		String xmlOrderStatus = receivedXmlOrderStatus;
		Document document = parseXML(xmlOrderStatus);
		// Check for the state of your order here, using an XML parser.
		// This code will run in a different thread from the one
		// that submitted the order
		if (document != null) {
			orderId = getElementAtt(document, "ImageOrderStatus", "OrderId");
			jobId = new Integer(orderId.substring(0, orderId.indexOf(OutputConstants.UNDERSCORE)));			
			state = getElementAtt(document, "Status", "State");
			
			if (state.equals("COMPLETED")) {
				List<String> imageFiles = getImageFiles(document);
				getDiscStatusListener().discPreparationCompleted(jobId, imageFiles);
				return;
			}
			errMsg = getElementAtt(document, "Status", "ErrorMessage");
			errCode = getElementAtt(document, "Status", "ErrorCode");

			if (errMsg.length() > 0 || (errCode.length() > 0 && errCode != "0")) {
				getDiscStatusListener().discPreparationFailed(jobId, errCode + ":" + errMsg);
				return;
			}
			if (state.equals("FAILED")) {
				if(StringUtilities.isEmpty(errMsg) && (StringUtilities.isEmpty(errCode))) {
					errCode = "Failed preparating the image ";
				}
				getDiscStatusListener().discPreparationFailed(jobId, errCode + ":" + errMsg);
				return;
			}
			String message = "Imaging " + state.toLowerCase() + ": " + getElementAtt(document, "Status", "PercentCompleted") + "% completed.";
			getDiscStatusListener().discPreparationInProgress(jobId, message);
		}
	}
	
	private List<String> getImageFiles(Document document) {
		List<String> result = getElementsAtt(document, "VolumeNameListEntry", "VolumeName");
		return result;
	}

}
