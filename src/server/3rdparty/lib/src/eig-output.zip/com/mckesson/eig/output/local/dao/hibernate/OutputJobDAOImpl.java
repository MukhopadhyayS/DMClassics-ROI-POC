/*
 * Copyright 2009-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.dao.hibernate;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.orm.hibernate3.HibernateCallback;

import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.local.dao.OutputSearchLoVDAO;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputSearchLoV;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.util.CollectionUtilities;

/**
 * @author Pranav Amarasekaran
 * @date   Apr 3, 2009
 * @since  Output 1.0; Apr 3, 2009
 *
 * This class holds the data access implementation of all the methods defined
 * in the OutputDAO. This implementation stores and retrieves data from the
 * database using hibernate.
 *
 */
public class OutputJobDAOImpl extends AbstractHibernateOutputDAO
implements OutputJobDAO {

    private static final String CSV_DELIM  = ",";
    private OutputSearchLoVDAO _outputSearchLoVDAO;

    public OutputJobDAOImpl() {
    }

    public OutputJobDAOImpl(OutputSearchLoVDAO outputSearchLoVDAO) {
        _outputSearchLoVDAO = outputSearchLoVDAO;
    }

	public OutputSearchLoVDAO getOutputSearchLoVDAO() {
        return _outputSearchLoVDAO;
    }

    public void setOutputSearchLoVDAO(OutputSearchLoVDAO outputSearchLoVDAO) {
        _outputSearchLoVDAO = outputSearchLoVDAO;
    }

    /**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#createOutputJob(com.mckesson.eig.output.model.OutputJob)
	 */
	public OutputJob createOutputJob(OutputJob job) {

		job.setCreatedDate(getDate());
		job.setModifiedDate(getDate());

		create(job);
		return job;
	}

    public OutputJob updateOutputJob(OutputJob job) {

        job.setModifiedDate(getDate());

        update(job);
        getSession().refresh(job);
        return job;
    }

	/**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#deleteOutputJobParts(int)
	 */
	public OutputJob deleteOutputJobParts(int jobID) {

		OutputJob job = readOutputJob(jobID);

		job.getParts().clear();
        return job;
	}

	public OutputJob syncResetOutputJobParts(int jobID) {
        OutputJob job = readOutputJob(jobID);
        update(job);
		return job;
	}

    public OutputJob resubmitResetOutputJobParts(int jobID) {
        OutputJob job = readOutputJob(jobID);
        merge(job);
        return job;
    }

    public OutputJob resubmitOutputJob(OutputJob job) {
        OutputJob djob = readOutputJob(job.getJobSeq());
        djob.setTransforms(job.getTransforms());
        djob.setDestID(job.getDestID());
        djob.setSubmitInfo(job.getSubmitInfo());
        djob.getStatusInfo().setStatusCode(job.getStatusInfo().getStatusCode());
        djob.setStatusID(job.getStatusID());
        djob.setLabelData(job.getLabelData());
        merge(djob);
        return job;
    }

	/**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#readAllOutputJobs()
	 */
	@SuppressWarnings("unchecked")
	public Collection<OutputJob> readAllOutputJobs() {

	    List<OutputJob> jobs = (List<OutputJob>) getHibernateTemplate().execute(
                new HibernateCallback() {
                    public Object doInHibernate(Session s) {
                        //retrieve sql query statement for hbm
                        Query hibQuery =
                            s.createSQLQuery(s.getNamedQuery("retrieveAllJobsWithDetails")
                                             .getQueryString())
                             .addScalar("jobSeq", Hibernate.INTEGER)
                             .addScalar("jobDetails", Hibernate.STRING)
                             .addScalar("destID", Hibernate.INTEGER)
                             .addScalar("userName", Hibernate.STRING)
                             .addScalar("jobName", Hibernate.STRING)
                             .addScalar("destID", Hibernate.INTEGER)
                             .addScalar("orgSeq", Hibernate.INTEGER)
                             .addScalar("recordVersion", Hibernate.INTEGER)
                             .addScalar("createdBy", Hibernate.INTEGER)
                             .addScalar("createdDate", Hibernate.TIMESTAMP)
                             .addScalar("modifiedDate", Hibernate.TIMESTAMP)
                             .addScalar("modifiedBy", Hibernate.INTEGER)
                             .addScalar("statusID", Hibernate.INTEGER)
                             .addScalar("pages", Hibernate.INTEGER)
                             .addScalar("resultsXML", Hibernate.STRING)
                             .addScalar("statusDetail", Hibernate.STRING)
                             .setResultTransformer(Transformers.aliasToBean(OutputJob.class));
                        return hibQuery.list();
                }
               });
	    return jobs;
	}

	/**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#readOutputJob(long)
	 */
	@SuppressWarnings("unchecked")
	public OutputJob readOutputJob(int jobID) {

		List<OutputJob> result  = getHibernateTemplate()
			.findByNamedQuery("retrieveJobByID", new Integer(jobID));
		if (!CollectionUtilities.isEmpty(result)) {
			return result.get(0);
		}
		return null;
	}

	/**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#updateJobStatus(long, com.mckesson.eig.output.model.StatusInfo)
	 */
	public void updateJobStatus(int jobID, StatusInfo info) {

		OutputJob job = readOutputJob(jobID);
		if (job != null) {
    		job.setStatusID(info.getStatusCode());
    		job.setModifiedDate(getDate());
    		job.setStatusDetail(info.getDetail());
    		update(job);
		}
	}

    public void updateJobStatus(final List<Integer> jobSeq, final int statusId) {

        if (jobSeq.size() < 1) {
            return;
        }
        getHibernateTemplate().execute(new HibernateCallback() {
              public Object doInHibernate(Session s) {
                  String hqlUpdate = "update com.mckesson.eig.output.model.OutputJob as job "
                                     + " set job.statusID = :statusID "
                                     + " where job.jobSeq in (:jobID)";
                  int updatedEntities = s.createQuery(hqlUpdate)
                                      .setInteger("statusID", statusId)
                                      .setParameterList("jobID", jobSeq)
                                      .executeUpdate();
                  return new Integer(updatedEntities);
                }
              }
              );
    }


	public void updateJobPageCount(final int jobID, final int pageCount) {

        getHibernateTemplate().execute(new HibernateCallback() {
              public Object doInHibernate(Session s) {
                  String hqlUpdate = "update com.mckesson.eig.output.model.OutputJob as job "
                                     + " set job.pages = :pages "
                                     + " where job.jobSeq = :jobID ";
                  int updatedEntities = s.createQuery(hqlUpdate)
                                      .setInteger("pages", pageCount)
                                      .setInteger("jobID", jobID)
                                      .executeUpdate();
                  return new Integer(updatedEntities);
                }
              }
              );
	}

    /**
     * This method is used to get the job status id
     *
     * @param jobID
     */
    public int fetchJobStatus(int jobID) {

    	List list =
    		getHibernateTemplate().findByNamedQuery("retrieveJobStatus",
									 new Integer(jobID));

    	if (list.size() == 0) {
    		throw new OutputException("Job not found",
                    				   OutputErrorCode.INVALID_DATA);
    	}

       return ((Integer) list.get(0)).intValue();
    }


	/**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#readOutputJobPart(long)
	 */
	public JobPart readOutputJobPart(int partID) {

		JobPart part = (JobPart) getHibernateTemplate()
			.findByNamedQuery("retrievePartByID", new Integer(partID)).get(0);
		return part;
	}

	/**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#updateJobPart(long, com.mckesson.eig.output.model.StatusInfo)
	 */
	public void updateJobPart(JobPart jobPart) {
		update(jobPart);
	}

	/**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#fetchJobsByStatus(com.mckesson.eig.output.model.StatusInfo,
	 * 					   java.util.Date, java.util.Date)
	 */
	@SuppressWarnings("unchecked")
	public Collection<OutputJob> fetchJobsByStatus(StatusInfo status,
			Date fromDate, Date toDate) {

		List<OutputJob> jobs = new ArrayList<OutputJob>();

		if ((fromDate != null) && (toDate != null)) {

			Object[] values = new Object[] {new Integer(status.getStatusCode()),
											fromDate,
											toDate};
			jobs = getHibernateTemplate().findByNamedQuery(
					"retrieveJobsByStatusAndUpdatedTimePeriod", values);
		} else if (toDate != null) {
            Object[] values = new Object[] {new Integer(status.getStatusCode()),
                                            toDate};
            jobs = getHibernateTemplate()
                    .findByNamedQuery("retrieveJobsByStatusAndUpdatedTime",
                                       values);
		} else {
			jobs = getHibernateTemplate().findByNamedQuery("retrieveJobsByStatus",
						new Integer(status.getStatusCode()));
		}

		return jobs;
	}

	/**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#queryJobs(java.util.Date Map)
	 *
	 * @param queryOptions
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Collection<OutputJob> queryJobs(final Map<String, String> queryOptions) {

		if ((queryOptions == null) || (queryOptions.size() == 0)) {
			throw new OutputException("Query Paramters cannot be empty",
					OutputErrorCode.MISSING_DATA);
		}


        List<OutputJob> jobs = new ArrayList<OutputJob>();

        jobs = (List<OutputJob>) getHibernateTemplate().execute(
                new HibernateCallback() {
                    public Object doInHibernate(Session s) {
                        //retrieve sql query statement for hbm
                        String tmpSqlStr = s.getNamedQuery("retrieveJobsWithDetails")
                                            .getQueryString();
                        final String query = buildHQLQueryFromOptions(tmpSqlStr, queryOptions);                        

                    	Query hibQuery =
                    	    s.createSQLQuery(query)
                             .addScalar("jobSeq", Hibernate.INTEGER)
                             .addScalar("jobDetails", Hibernate.STRING)
                    	     .addScalar("destID", Hibernate.INTEGER)
                    	     .addScalar("userName", Hibernate.STRING)
                    	     .addScalar("jobName", Hibernate.STRING)
                    	     .addScalar("destID", Hibernate.INTEGER)
                    	     .addScalar("orgSeq", Hibernate.INTEGER)
                    	     .addScalar("recordVersion", Hibernate.INTEGER)
                    	     .addScalar("createdBy", Hibernate.INTEGER)
                    	     .addScalar("createdDate", Hibernate.TIMESTAMP)
                    	     .addScalar("modifiedDate", Hibernate.TIMESTAMP)
                    	     .addScalar("modifiedBy", Hibernate.INTEGER)
                    	     .addScalar("statusID", Hibernate.INTEGER)
                    	     .addScalar("pages", Hibernate.INTEGER)
                    	     .addScalar("resultsXML", Hibernate.STRING)
                    	     .addScalar("statusDetail", Hibernate.STRING)
                    	     .setResultTransformer(Transformers.aliasToBean(OutputJob.class));

                        if (queryOptions.get(OutputConstants.KEY_JOB_ID) != null) {
                        	hibQuery.setParameterList("T_JOB_ID",
                        			convertCSVtoIntParamArray(
                        			queryOptions.get(OutputConstants.KEY_JOB_ID)));
                        }

                        if (queryOptions.get(OutputConstants.KEY_JOB_NAME) != null) {
                        	hibQuery.setParameterList("T_JOB_NAME",
                        			convertCSVtoStringArray(
                        			queryOptions.get(OutputConstants.KEY_JOB_NAME)));
                        }

                        if (queryOptions.get(OutputConstants.KEY_DEST_ID) != null) {
                        	hibQuery.setParameterList("T_DEST_ID",
                        			convertCSVtoIntParamArray(
                                	queryOptions.get(OutputConstants.KEY_DEST_ID)));
                        }

                        if (queryOptions.get(OutputConstants.KEY_JOB_USERID) != null) {
                        	hibQuery.setParameterList("T_USER_ID",
                                	convertCSVtoStringArray(
                                	queryOptions.get(OutputConstants.KEY_JOB_USERID)));
                        }

                        if (queryOptions.get(OutputConstants.KEY_JOB_STATUS) != null) {
                        	hibQuery.setParameterList("T_STATUS_ID",
                        			convertCSVtoIntParamArray(
                                	queryOptions.get(OutputConstants.KEY_JOB_STATUS)));
                        }

                        if (queryOptions.get(OutputConstants.KEY_DEST_TYPE_ID) != null) {
                        	hibQuery.setParameterList("T_DEST_TYPE_ID",
                        			convertCSVtoIntParamArray(
                                	queryOptions.get(OutputConstants.KEY_DEST_TYPE_ID)));
                        }
                        
                        if (queryOptions.get(OutputConstants.KEY_FROM_DATE) != null &&
                                queryOptions.get(OutputConstants.KEY_TO_DATE) != null) {
                            
                            hibQuery.setParameter("T_FROM_DATE",
                                    queryOptions.get(OutputConstants.KEY_FROM_DATE));
                            
                            hibQuery.setParameter("T_TO_DATE",
                                    queryOptions.get(OutputConstants.KEY_TO_DATE));                            
                        }
                        return hibQuery.list();
                    }
                });

        return appendSearchLovs(jobs);
    }

	private List<OutputJob> appendSearchLovs(List<OutputJob> jobs) {

	    for (OutputJob outputJob : jobs) {

            List<OutputSearchLoV> lovList =
                    _outputSearchLoVDAO.readOutputSearchLoVs(outputJob.getJobSeq());

            List<JobPart> jobPartList = readOutputJobParts(outputJob.getJobSeq());
            outputJob.setParts(jobPartList);

	        List<MapModel> searchableData = new ArrayList<MapModel>();
	        MapModel mapModel;

	        for (OutputSearchLoV lov : lovList) {

	            mapModel = new MapModel();
	            mapModel.setKey(lov.getName());
	            mapModel.setValue(lov.getValue());
	            searchableData.add(mapModel);
	        }

	        outputJob.setSearchableData(searchableData);
	    }

        return jobs;
    }

	@SuppressWarnings("unchecked")
	public List<JobPart> readOutputJobParts(int jobId) {

        List<JobPart> result =
               getHibernateTemplate().findByNamedQuery("retrievePartByJobID", new Integer(jobId));

        return result;
    }

    /**
     * @see com.mckesson.eig.output.local.dao.OutputJobDAO#deleteJob(java.util.List)
     */
    public void deleteJob(final List<Integer> jobSeq) {

        if (jobSeq.size() < 1) {
            return;
        }

        for (int jobID : jobSeq) {
            OutputJob job = readOutputJob(jobID);
            System.out.println("Deleting Job:" + jobID);

            delete(job);
        }
	}

	/**
	 * This method is used to build the hql query dynamically by using the
	 * query options
	 *
	 * @param queryOptions
	 *
	 * @return the built hql query
	 */
	private String buildHQLQueryFromOptions(String query, Map<String, String> queryOptions) {

        final StringBuffer sqlQuery = new StringBuffer(query);

        if ((queryOptions == null) || (queryOptions.size() == 0)) {
            throw new OutputException("Query options cannot be null",
                OutputErrorCode.MISSING_DATA);
        }
        
        if (queryOptions.get(OutputConstants.KEY_FROM_DATE) == null || 
                queryOptions.get(OutputConstants.KEY_TO_DATE) == null) {
            //remove from query
            sqlQuery.delete(sqlQuery.indexOf("where"), sqlQuery.length());
        }
            
        if (queryOptions.get(OutputConstants.KEY_JOB_ID) != null) {
            
            if (sqlQuery.indexOf("where") == -1) {
                sqlQuery.append("where job.Output_Service_Job_Seq in (:T_JOB_ID)");
            } else {
                sqlQuery.append("and job.Output_Service_Job_Seq in (:T_JOB_ID)");
            }
        }

        if (queryOptions.get(OutputConstants.KEY_JOB_NAME) != null) {
        	if (sqlQuery.indexOf("where") == -1) {
        		sqlQuery.append("where job.osj_job_id in (:T_JOB_NAME)");
        	} else {
        		sqlQuery.append(" and job.osj_job_id in (:T_JOB_NAME)");
        	}
        }

        if (queryOptions.get(OutputConstants.KEY_DEST_ID) != null) {
        	if (sqlQuery.indexOf("where") == -1) {
        		sqlQuery.append("where job.osj_queue_seq in (:T_DEST_ID)");
        	} else {
        		sqlQuery.append(" and job.osj_queue_seq in (:T_DEST_ID)");
        	}
        }

        appendQueryOptions(sqlQuery, queryOptions);
        // Newly added for refactor COS service params
        appendLoVQueryOptions(sqlQuery, queryOptions);
        return sqlQuery.toString();
	}

	/**
	 * This method is used to append query options to avoid cyclomatic
	 * complexity.
	 *
	 * @param sqlQuery
	 * @param queryOptions
	 */
    private void appendQueryOptions(StringBuffer sqlQuery,
			Map<String, String> queryOptions) {

        if (queryOptions.get(OutputConstants.KEY_JOB_USERID) != null) {
        	if (sqlQuery.indexOf("where") == -1) {
        		sqlQuery.append("where job.osj_submitted_by in (:T_USER_ID)");
        	} else {
        		sqlQuery.append(" and job.osj_submitted_by in (:T_USER_ID)");
        	}
        }

        if (queryOptions.get(OutputConstants.KEY_JOB_STATUS) != null) {
        	if (sqlQuery.indexOf("where") == -1) {
        		sqlQuery.append("where job.osj_status_seq in (:T_STATUS_ID)");
        	} else {
        		sqlQuery.append(" and job.osj_status_seq in (:T_STATUS_ID)");
        	}
        }

        if (queryOptions.get(OutputConstants.KEY_DEST_TYPE_ID) != null) {
        	if (sqlQuery.indexOf("where") == -1) {
        		sqlQuery.append("where osj_queue_seq IN (select oslov_seq from ");
        		sqlQuery.append(
    				"Output_ListOfValue where oslov_parent_seq in (:T_DEST_TYPE_ID))");
        	} else {
        	    sqlQuery.append(" and osj_queue_seq IN (select oslov_seq from ");
                sqlQuery.append("Output_ListOfValue where oslov_parent_seq in (:T_DEST_TYPE_ID))");
        	}
        }
	}

    /**
     * This method converts the comma separated string value to a string array.
     *
     * @param commaSeparatedIDs
     *          IDs separated by comma
     *
     * @return Parameter Array
     *          Array of parameters
     */
	private Integer[] convertCSVtoIntParamArray(String commaSeparatedIDs) {

        if (commaSeparatedIDs.indexOf(CSV_DELIM) == -1) {

            String[] returnVal = {commaSeparatedIDs};
            return convertStrArrayToInt(returnVal);
        }

        return convertStrArrayToInt(commaSeparatedIDs.split(CSV_DELIM));
    }

    /**
     * This method converts the comma separated string value to a string array.
     *
     * @param commaSeparatedIDs
     *          IDs separated by comma
     *
     * @return Parameter Array
     *          Array of parameters
     */
	private String[] convertCSVtoStringArray(String commaSeparatedIDs) {

        if ((commaSeparatedIDs == null) || (commaSeparatedIDs.trim().length() == 0)) {
            return null;
        }

        if (commaSeparatedIDs.indexOf(CSV_DELIM) == -1) {
            return new String[] {commaSeparatedIDs};
        }

        return commaSeparatedIDs.split(CSV_DELIM);
    }

    /**
     * This method is used to convert String array to Integer array
     *
     * @param String Array
     *          String Array
     *
     * @return Integer Array
     *          Long Array
     */
	private Integer[] convertStrArrayToInt(String[] strArray) {

        if (strArray == null) {
            return null;
        }

        Integer[] intArray = new Integer[strArray.length];
        for (int i = 0; i < strArray.length; i++) {
            intArray[i] = new Integer(strArray[i]);
        }

        return intArray;
    }

	/**
	 * This method is used to append searchLov to query options.
	 * @param hql
	 * 		  the hql
	 * @param options
	 * 		  the options
	 */
	private void appendLoVQueryOptions(StringBuffer  hql, Map<String, String> queryOptions) {

		Map<String, String> tempOptions = new HashMap<String, String>();
		tempOptions.putAll(queryOptions);
		tempOptions.remove(OutputConstants.KEY_DEST_TYPE_ID);
		tempOptions.remove(OutputConstants.KEY_JOB_ID);
		tempOptions.remove(OutputConstants.KEY_JOB_NAME);
		tempOptions.remove(OutputConstants.KEY_DEST_ID);
		tempOptions.remove(OutputConstants.KEY_JOB_USERID);
		tempOptions.remove(OutputConstants.KEY_JOB_STATUS);
		tempOptions.remove(OutputConstants.KEY_FROM_DATE);
		tempOptions.remove(OutputConstants.KEY_TO_DATE);

		if (tempOptions.size() != 0) {

			for (Entry<String, String> entry : tempOptions.entrySet()) {

			   if (hql.indexOf("where") == -1) {
    				
			        hql.append(" where job.Output_Service_Job_Seq IN (SELECT parent_seq FROM ")
        				   .append(" Output_Search_Lov lov ")
        				   .append(" where lov.name='").append(entry.getKey())
        				   .append("' AND lov.value='").append(entry.getValue())
        				   .append("' ) ");
			    } else {
			        
			        hql.append(" AND job.Output_Service_Job_Seq IN (SELECT parent_seq FROM ")
                           .append(" Output_Search_Lov lov ")
                           .append(" where lov.name='").append(entry.getKey())
                           .append("' AND lov.value='").append(entry.getValue())
                           .append("' ) ");
			    }
			}
		}
	}

	/**
	 * This method is used to get the next available print job based on the input list.
	 * if found, update to processing.
	 * @param queues
	 * 		  the queues list
	 */
	@SuppressWarnings("unchecked")
	public Integer getNextAvailableJobForOnePerQueue(final List queues, final RequestStatus requestStatus, final RequestStatus processingStatus) {
		if (CollectionUtilities.isEmpty(queues)) {
			return null;
		}
        List<Integer> jobIds = new ArrayList<Integer>();

        jobIds = (List<Integer>) getHibernateTemplate().execute(
                new HibernateCallback() {
                    public Object doInHibernate(Session s) {
                        Query hibQuery =
                                s.createSQLQuery(s.getNamedQuery("retrieveNextAvailableJobForOnePerQueues")
                                                 .getQueryString());
                    	hibQuery.setInteger("readyStatus", requestStatus.statusCode());
                    	hibQuery.setInteger("processStatus", processingStatus.statusCode());
                    	hibQuery.setParameterList("destIds", queues);
                        return hibQuery.list();
                    }
                });
		if (CollectionUtilities.isEmpty(jobIds)) {
			return null;
		}
		Integer jobId = jobIds.get(0);
		String hostName = OutputUtil.getUniqueServerName();
		updateJobStatusWithHostName(jobId.intValue(),
				StatusUtils.createRequestStatus(processingStatus, null),
				hostName);
		return jobId;
	}

	/**
	 * This method is used to get the next available job based on the input list.
	 * if found, update to processing.
	 * @param queues
	 * 		  the queues list
	 */
	@SuppressWarnings("unchecked")
	public Integer getNextAvailableJob(final List queues, final RequestStatus requestStatus, final RequestStatus processingStatus) {
		if (CollectionUtilities.isEmpty(queues)) {
			return null;
		}
        List<Integer> jobIds = new ArrayList<Integer>();
        jobIds = (List<Integer>) getHibernateTemplate().execute(
                new HibernateCallback() {
                    public Object doInHibernate(Session s) {
                        Query hibQuery =
                                s.createSQLQuery(s.getNamedQuery("retrieveNextJobQueue")
                                                 .getQueryString());
                     	hibQuery.setParameter("status", requestStatus.statusCode());
                    	hibQuery.setParameterList("destIds", queues);
                        return hibQuery.list();
                    }
                });
		if (CollectionUtilities.isEmpty(jobIds)) {
			return null;
		}
		Integer jobId = jobIds.get(0);
		String hostName = OutputUtil.getUniqueServerName();
		updateJobStatusWithHostName(jobId.intValue(),
				StatusUtils.createRequestStatus(processingStatus, null),
				hostName);
		return jobId;
	}

	/**
	 * This method is used to get the next available job based on the input list.
	 * if found, update to processing.
	 * @param queues
	 * 		  the queues list
	 */
	@SuppressWarnings("unchecked")
	public Integer getCurrentProcessingJob(final List queues, final RequestStatus requestStatus, boolean hostNameOnly) {
		if (CollectionUtilities.isEmpty(queues)) {
			return null;
		}
		String sql = "retrieveCurrentProcessingJob";
		if (hostNameOnly) {
			sql = "retrieveCurrentProcessingJobForServer";
		}
        List<Integer> jobIds = new ArrayList<Integer>();
		final String hostName = OutputUtil.getUniqueServerName();
		final String finalSql = sql;
        jobIds = (List<Integer>) getHibernateTemplate().execute(
                new HibernateCallback() {
                    public Object doInHibernate(Session s) {
                        Query hibQuery =
                                s.createSQLQuery(s.getNamedQuery(finalSql)
                                                 .getQueryString());
                    	hibQuery.setParameter("status", requestStatus.statusCode());
                    	hibQuery.setParameterList("destIds", queues);
                    	hibQuery.setParameter("hostname", hostName);
                        return hibQuery.list();
                    }
                });
		if (CollectionUtilities.isEmpty(jobIds)) {
			return null;
		}
		Integer jobId = jobIds.get(0);
		updateJobStatusWithHostName(jobIds,
				StatusUtils.createRequestStatus(requestStatus, null),
				hostName);
		return jobId;
	}
	
	/**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#updateJobStatus(long, com.mckesson.eig.output.model.StatusInfo)
	 */
	public void updateJobStatusWithHostName(final List<Integer> jobIds, final StatusInfo info, final String hostName) {
        getHibernateTemplate().execute(new HibernateCallback() {
            public Object doInHibernate(Session s) {
                Query hibQuery =
                        s.createSQLQuery(s.getNamedQuery("setJobStatusByJobIds")
                                         .getQueryString());
            	hibQuery.setInteger("status", info.getStatusCode());
            	hibQuery.setParameterList("jobIds", jobIds);
            	hibQuery.setParameter("hostname", hostName);
            	int updatedEntities = hibQuery.executeUpdate();
            	return new Integer(updatedEntities);
             }
            }
       );		
	}

	/**
	 * @see com.mckesson.eig.output.local.dao.OutputJobDAO
	 * 	#updateJobStatus(long, com.mckesson.eig.output.model.StatusInfo)
	 */
	public void updateJobStatusWithHostName(int jobID, StatusInfo info, String hostName) {

		OutputJob job = readOutputJob(jobID);
		if (job != null) {
    		job.setStatusID(info.getStatusCode());
    		job.setModifiedDate(getDate());
    		job.setProcessingServer(hostName);
    		update(job);
		}
	}

	@SuppressWarnings("unchecked")
	public void updateAllJobsStatusForServer(final String processingServer,
			final int origStatus, final int newStatus, final List queues) {
		if (!CollectionUtilities.isEmpty(queues)) {
	       getHibernateTemplate().execute(new HibernateCallback() {
		            public Object doInHibernate(Session s) {
		                String hqlUpdate = "update com.mckesson.eig.output.model.OutputJob as job "
		                    + " set job.statusID = :newStatusID "
		                    + " where job.statusID = :origStatusID and"
		                    + " job.processingServer = :processingServer and"
	                    	+ " job.destID in (:destIds)";
		                	int updatedEntities = s.createQuery(hqlUpdate)
		                     		.setInteger("newStatusID", newStatus)
		                    		.setInteger("origStatusID", origStatus)
		                    		.setString("processingServer", processingServer)
		                    		.setParameterList("destIds", queues)
		                    		.executeUpdate();
		                return new Integer(updatedEntities);
		            }
	        	}
	        );
		}
	}

	public void updateJobResults(final int jobID, final String results) {
        getHibernateTemplate().execute(new HibernateCallback() {
            public Object doInHibernate(Session s) {
                String hqlUpdate = "update com.mckesson.eig.output.model.OutputJob as job "
                                   + " set job.resultsXML = :results "
                                   + " where job.jobSeq = :jobID ";
                int updatedEntities = s.createQuery(hqlUpdate)
                                    .setString("results", results)
                                    .setInteger("jobID", jobID)
                                    .executeUpdate();
                return new Integer(updatedEntities);
              }
            }
       );		
	}

	public void updateJobResults(final int jobID, final StatusInfo status, final String results) {
        getHibernateTemplate().execute(new HibernateCallback() {
            public Object doInHibernate(Session s) {
                String hqlUpdate = "update com.mckesson.eig.output.model.OutputJob as job "
	                    		   + " set job.statusID = :status,"
	                    		   + " job.statusDetail = :statusDetail,"
                                   + " job.resultsXML = :results "
                                   + " where job.jobSeq = :jobID ";
                int updatedEntities = s.createQuery(hqlUpdate)
 		                     		.setInteger("status", status.getStatusCode())
                                    .setString("statusDetail", status.getDetail())
                                    .setString("results", results)
                                    .setInteger("jobID", jobID)
                                    .executeUpdate();
                return new Integer(updatedEntities);
              }
            }
       );		
	}
	
	@SuppressWarnings("unchecked")
	public 	boolean processIdleJobByChangeStatus(final List queues, final RequestStatus checkStatus, final RequestStatus resetStatus, final int idleInMin, final String errorMsg) {
		if (CollectionUtilities.isEmpty(queues)) {
			return false;
		}
		final int absIdleInMin = Math.abs(idleInMin);
		Integer result = (Integer) getHibernateTemplate().execute(new HibernateCallback() {
				public Object doInHibernate(Session s) {
				    Query hibQuery =
				            s.createSQLQuery(s.getNamedQuery("resetIdleJobToStatus")
				                             .getQueryString());
					hibQuery.setInteger("checkStatus", checkStatus.statusCode());
					hibQuery.setInteger("setStatus", resetStatus.statusCode());
					hibQuery.setParameterList("destIds", queues);
					hibQuery.setParameter("minute", -absIdleInMin);
					hibQuery.setString("statusDetail", errorMsg);
					int updatedEntities = hibQuery.executeUpdate();
					return updatedEntities;
				}
			}
       );		
		return result > 0;
	}

	@SuppressWarnings("unchecked")
	public 	boolean processIdleJobInDaysByChangeStatus(final List<RequestStatus> checkStatuses, final RequestStatus resetStatus, final int idleInDay, final String errorMsg) {
		final int absIdleInDay = Math.abs(idleInDay);
		Integer result = (Integer) getHibernateTemplate().execute(new HibernateCallback() {
				public Object doInHibernate(Session s) {
				    Query hibQuery =
				            s.createSQLQuery(s.getNamedQuery("resetIdleJobToStatusByDay")
				                             .getQueryString());
					hibQuery.setParameterList("checkStatus", getRequestStatusCode(checkStatuses));
					hibQuery.setInteger("setStatus", resetStatus.statusCode());
					hibQuery.setParameter("day", -absIdleInDay);
					hibQuery.setString("statusDetail", errorMsg);
					int updatedEntities = hibQuery.executeUpdate();
					return updatedEntities;
				}
			}
       );		
	   return result > 0;
	}
	
	private List<Integer> getRequestStatusCode(List<RequestStatus> checkStatuses) {
		List<Integer> result = new ArrayList<Integer>();
		for(RequestStatus status : checkStatuses) {
			result.add(status.statusCode());
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public 	boolean processIdleJobByRemoveServerName(final List queues, final RequestStatus checkStatus, final int idleInMin, final String errorMsg) {
		if (CollectionUtilities.isEmpty(queues)) {
			return false;
		}
		final int absIdleInMin = Math.abs(idleInMin);
		Integer result = (Integer) getHibernateTemplate().execute(new HibernateCallback() {
				public Object doInHibernate(Session s) {
				    Query hibQuery =
				            s.createSQLQuery(s.getNamedQuery("resetIdleJobByRemoveServerName")
				                         .getQueryString());
					hibQuery.setInteger("checkStatus", checkStatus.statusCode());
					hibQuery.setParameterList("destIds", queues);
					hibQuery.setParameter("minute", -absIdleInMin);
					hibQuery.setString("statusDetail", errorMsg);
					int updatedEntities = hibQuery.executeUpdate();
					return updatedEntities;
				}
            }
		);		
		return result > 0;
	}
}

