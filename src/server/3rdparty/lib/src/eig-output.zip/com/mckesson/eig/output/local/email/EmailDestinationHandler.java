package com.mckesson.eig.output.local.email;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.mckesson.eig.output.local.AbstractTypeHandler;
import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.local.transformers.Concatenate;
import com.mckesson.eig.output.local.transformers.PdfBookmark;
import com.mckesson.eig.output.local.transformers.PdfConcatenate;
import com.mckesson.eig.output.local.transformers.ROIPdfConcatenate;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.PdfUtils;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.utility.util.BooleanUtilities;

public class EmailDestinationHandler extends AbstractTypeHandler {

    private final Map<String, EmailDestination> _emailDestMap = new HashMap<String, EmailDestination>();
    private Concatenate _pdfConcatenate;
    private PdfBookmark _pdfBookmark;
    private Properties _cryptoProperties;
    private boolean _sendHash = true;

	public EmailDestinationHandler() {
        _pdfConcatenate = new PdfConcatenate();  //default PDF Concatenate
 	}

	public EmailDestinationHandler(String enabled) {
		this();
		setEnabled(enabled);
	}

	public PropertyDef[] getDevicePropertyDefs(String deviceID) {
		EmailDestination dest = _emailDestMap.get(deviceID);
		if (dest != null) {
			return dest.getPropertyDefs();
		}
		return null;
	}

	public Collection<String> queryDeviceIDs() {
		// TODO Auto-generated method stub
		return _emailDestMap.keySet();
	}

	public Map<String, Object> queryDeviceProperties(String deviceID) {
		EmailDestination dest = _emailDestMap.get(deviceID);
		if (dest != null) {
			return 	PropertySupport.createDefaultValuesMap(dest.getPropertyDefs());
		}
		return null;
	}

	public StatusInfo queryDeviceStatus(String deviceID) {
		EmailDestination dest = _emailDestMap.get(deviceID);
		if (dest != null) {
			return 	dest.queryEndpointStatus();
		}
		return null;
	}

	public void cleanUp() {
	}

	public OutputEndpoint createEndpoint(EndpointDef endpointDef) {
		EmailDestination dest = new EmailDestination(this, endpointDef.getName());
        if (endpointDef.getProperties() != null && endpointDef.getProperties().size() > 0) {
        	dest.getProperties().setProperties(endpointDef.getProperties());
        }
		_emailDestMap.put(endpointDef.getName(), dest);
		return dest;
	}

	public void destroyEndpoint(OutputEndpoint endpoint) {
		if (_emailDestMap.containsValue(endpoint)) {
			EmailDestination dest = (EmailDestination) endpoint;
			String name  = dest.getName();
			_emailDestMap.remove(name);
		}
	}

	public String[] getEndpointContentTypes() {
		return OutputConstants.ANY_CONTENT_TYPE;
	}

	public EndpointCategory getEndpointCategory() {
		return EndpointCategory.DESTINATION;
	}

	 @Override
	public PropertyDef[] getPropertyDefs() {
		return PropertySupport
				.extractAnnotatedProperties(EmailDestination.class);
	}

	public String getConfigProperty(String key) {
		return (String) _outputManager.getProperty(key);
	}

	public void setBookmarkStrategy(PdfBookmark bookmark) {
		_pdfBookmark = bookmark;
	}

	public void setConcatenateStrategy(Concatenate pdfConcatenate) {
		_pdfConcatenate = pdfConcatenate;
	}

	public PdfBookmark getBookmarkStrategy() {
		return _pdfBookmark;
	}

	public Concatenate getConcatenateStrategy() {
		return _pdfConcatenate;
	}

    public Properties getCryptoProperties() {
    	return _cryptoProperties;
    }
    
	public void setPropertiesFile(String properties) {
		_cryptoProperties = PdfUtils.loadProperties(properties);
	}

	public boolean isSendHash() {
		return _sendHash;
	}

	public void setSendHash(boolean send) {
		_sendHash = send;
	}

}
