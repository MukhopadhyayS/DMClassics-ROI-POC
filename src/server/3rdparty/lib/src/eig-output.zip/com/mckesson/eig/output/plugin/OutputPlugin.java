/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.plugin;

import java.util.List;

import com.mckesson.eig.output.model.OutputUser;

/**
 * @author Pranav Amarasekaran
 * @date   Jul 28, 2009
 * @since  Output 1.0; Jul 28, 2009
 *
 * This interface defines the set of methods which all the applications using
 * the output service needs to implement.
 */
public interface OutputPlugin {
	
	/**
	 * This method returns the list of users who can submit the jobs to output 
	 * service
	 * 
	 * @return list of output users.
	 */
	List<OutputUser> getAllOutputUsers();
}
