/**
 * Copyright � 2010 McKesson Corporation and/or one of its subsidiaries.
 * All rights reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.hpf.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.MessageFormat;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletResponse;

import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.StringUtilities;

/**
 * @author Eric Yu
 */
public class ContentWebServiceCaller extends WebServiceCaller {
	private static final String CONTENT_URL = "{0}://{1}:{2}/portal/icontent";

	private static final String DEFAULT_URL_PARAMETERS = "?user={0}&password={1}&Time={2}"
			+ "&key={3}&imnet={4}&page={5}"
			+ "&convert=hl7,pdf&convert=tiff,pdf&convert=imnet-ascii,pdf&convert=pdf,pdf";

	private static final String DEFAULT_URL_PARAMETERS_WITHOUTKEY = "?user={0}&password={1}"
			+ "&imnet={2}&page={3}"
			+ "&convert=hl7,pdf&convert=tiff,pdf&convert=imnet-ascii,pdf&convert=pdf,pdf";

	private static final Log LOG = LogFactory.getLogger(ContentWebServiceCaller.class);
	private static final int TOTAL_RETRIES = 4;
	private static final int BUFFER_SIZE = 8192;

	private String _cookie = null;
	private String _privateKey;
	private boolean _isSecurityToken;

	private final ThreadLocal<byte[]> _bufferRef = new ThreadLocal<byte[]>() {
		@Override
		protected byte[] initialValue() {
			return new byte[BUFFER_SIZE];
		}
	};

	public ContentWebServiceCaller(Boolean useLeveler, String levelerURL) {
		super(useLeveler, levelerURL);
	}

	public ContentWebServiceCaller() {
		this(false, null);
	}

	private byte[] getBuffer() {
		return _bufferRef.get();
	}

	/**
	 * @param contentServiceURL
	 * @param userID
	 * @param password
	 * @param imnet
	 * @param pageNumber
	 * @param privateKey
	 */
	public void getContentToFile(WebServiceSetting setting, String imnet,
			String pageNum, File f, boolean continueWithError) {
		getContent(setting, imnet, pageNum, f, continueWithError);
	}

	public void getContent(WebServiceSetting setting, String imnet, String pageNum, File f, boolean continueWithError) {
		long startTime = System.currentTimeMillis();
		long data = 0;
		int retries = 0;
		while ((data <= 0) && (retries < TOTAL_RETRIES)) {
			retries++;
			String contentURL = buildContentServiceURL(setting, imnet, pageNum);
			OutputStream os = null;
			try {
				os = IOUtilities.createFileOutputStream(f);
				data = getData(contentURL, os);
			} catch (Exception e) {
				IOUtilities.close(os);
				if (f.exists()) {
					f.delete();
				}
				LOG.info(" Unable to retrive content. Duid = [" + imnet
						+ "], pageNumber = [" + pageNum + "] ");
				LOG.info("retries = [" + retries + "], " + "URL = [" + contentURL + "]");
			} finally {
				IOUtilities.close(os);
			}
		}
		long finishTime = System.currentTimeMillis();
		LOG.debug("Finish getContent: imnet [" + imnet + "], "
				+ "pageNumber = [" + pageNum + "] " + (finishTime - startTime)
				+ " milliseconds");
		if (data <= 0) {
			if (f.exists()) {
				f.delete();
			}
			if(!continueWithError ) {
				throw new OutputException("Cannot retrieve content: " + imnet
						+ " page:" + pageNum, OutputErrorCode.MISSING_DATA);
			}
		}
	}

	private long getData(String urlPath, OutputStream os) throws IOException {
		HttpURLConnection huc = null;
		InputStream is = null;
		long data = 0;
		try {
			URL url = new URL(urlPath);
			if (url.getProtocol().equalsIgnoreCase("https")) {
				huc = (HttpsURLConnection) url.openConnection();
			} else {
				huc = (HttpURLConnection) url.openConnection();
			}
			// Trust all hosts.
			// huc.setHostnameVerifier(new MyVerifier());

			huc.setRequestMethod("GET");
			huc.setRequestProperty("Cookie", _cookie);
			huc.connect();
			is = huc.getInputStream();
			int returnCode = huc.getResponseCode();
			String cookie = huc.getHeaderField("Set-Cookie");
			if (cookie != null) {
				_cookie = cookie;
			}

			int contentLength = huc.getContentLength();
			LOG.debug("Content Length=" + contentLength);
			if (returnCode == HttpServletResponse.SC_OK) {
				data = IOUtilities.write(is, getBuffer(), os);
			}
		} finally {
			IOUtilities.close(is);
			if (huc != null) {
				huc.disconnect();
			}
		}
		return data;
	}

	private String getParameters(WebServiceSetting setting, String time,
			String token, String imnet, String pageNumber) {
		String str = replaceSpace(imnet);
		Object[] args = { setting.getUserName(), setting.getPassword(), time,
				token, str, pageNumber };
		MessageFormat mf = new MessageFormat(DEFAULT_URL_PARAMETERS);
		return mf.format(args);
	}

	private String getParameters(WebServiceSetting setting, String imnet,
			String pageNumber) {
		String str = replaceSpace(imnet);
		Object[] args = { setting.getUserName(), setting.getPassword(), str, pageNumber };
		MessageFormat mf = new MessageFormat(DEFAULT_URL_PARAMETERS_WITHOUTKEY);
		return mf.format(args);
	}

	private String getContentWebUrl(WebServiceSetting setting) {
		String server = setting.getServer();
		String protocel = setting.getProtocol();
		String port = setting.getPort();

		Object[] args = { protocel, server, port };
		MessageFormat mf = new MessageFormat(CONTENT_URL);
		return mf.format(args);
	}

	private String buildContentServiceURL(WebServiceSetting setting,
			String imnet, String pageNum) {
		String contentServiceUrl = getContentWebUrl(setting);
		StringBuffer buffer = new StringBuffer(contentServiceUrl);
		String parameter = null;
		if (_isSecurityToken && (!StringUtilities.isEmpty(_privateKey))) {
			String timeStamp = createTime(contentServiceUrl);
			String token = SecureToken.createToken(
				new String[] { setting.getUserName(), setting.getPassword(), imnet, pageNum },
				timeStamp,
				_privateKey
			);
			parameter = getParameters(setting, timeStamp, token, imnet, pageNum);
		} else {
			parameter = getParameters(setting, imnet, pageNum);
		}
		buffer.append(parameter);
		LOG.debug("ContentService URL: [" + buffer.toString() + "]");
		return buffer.toString();
	}

	private String replaceSpace(String imnet) {
		if (imnet != null) {
			return StringUtilities.replace(imnet, " ", "+");
		}
		return imnet;
	}

	public String getPrivateKey() {
		return _privateKey;
	}

	public void setPrivateKey(String privateKey) {
		_privateKey = privateKey;
	}

	public boolean isSecurityToken() {
		return _isSecurityToken;
	}

	public void setSecurityToken(boolean isSecurityToken) {
		_isSecurityToken = isSecurityToken;
	}
}
