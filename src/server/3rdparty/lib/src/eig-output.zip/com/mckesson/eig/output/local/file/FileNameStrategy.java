/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.file;

import java.util.List;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;

/**
 * TODO
 * 
 * @author Jon Anderson
 * 
 */
public interface FileNameStrategy {

	String createHPFPartFileName(OutputJob job, JobPart part);

	String createROIFileName(OutputJob job);
	
	String createOtherSourceFileName(OutputJob job);
	
	String createPartAttachmentName(OutputJob job, JobPart part);

	String createPartAttachmentCollectionName(OutputJob job, JobPart part);

	String createJobCollectionName(OutputJob job);

	String generateFileNameWithPartNumber (
			String generatedFileName, int partNumber, int totalNumber);

	String generateFileNameWithPartNumberTotalNumber(
			String generatedFileName, int partNumber, int totalNumber);
	
    String generateFileNameWithDiscNumberTotalNumber(String generatedFileName, int partNumber, int totalNumber);

    String generateFileNameWithVersionNumber(String generatedFileName, String ext, List<String> files);

}
