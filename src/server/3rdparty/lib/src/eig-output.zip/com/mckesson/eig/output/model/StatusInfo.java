/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;

/**
 * Object which stores status information about either an RequestPart or an OutputRequest.
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "statusInfo")
@XmlType(name = "statusInfo")
public class StatusInfo implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 3;
	private static final int HASH_INIT = 17;

	private int _statusCode;
    private String _status;
    private String _detail;
    private Date _statusDate;
    private String _statusSource;
    private List<MapModel> _statusData; 

    /**
     *
     */
    public StatusInfo() {
       super();
    }

    @Override
    public boolean equals(Object obj) {
        StatusInfo info = (StatusInfo) obj;

        if (_statusCode != info._statusCode) {
            return false;
        }
        if (!ObjectUtils.equals(_status, info._status)) {
            return false;
        }
        if (!ObjectUtils.equals(_detail, info._detail)) {
            return false;
        }
        if (!ObjectUtils.equals(_statusDate, info._statusDate)) {
            return false;
        }
        if (!ObjectUtils.equals(_statusSource, info._statusSource)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        HashCodeBuilder hcb = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
        hcb.append(_statusCode);
        hcb.append(_status);
        hcb.append(_detail);
        hcb.append(_statusDate);
        hcb.append(_statusSource);

        return hcb.toHashCode();
    }

    @Override
	public StatusInfo clone() {
    	try {
			return (StatusInfo) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
		}
    }

    /**
     * Returns the descriptive text of the status
     *
     * @return the _status member
     */
    public String getStatus() {
        return _status;
    }

    /**
     * @param status
     */
    @XmlElement (name = "status")
    public void setStatus(String status) {
        _status = status;
    }

    /**
     * The last modified time for this status
     *
     * @return the _statusDate member
     */
    public Date getStatusDate() {
        return _statusDate;
    }

    /**
     * @param statusDate
     */
    @XmlElement (name = "statusDate")
    public void setStatusDate(Date statusDate) {
        _statusDate = statusDate;
    }

    /**
     * Name of the application component which set this status
     *
     * @return _statusSource
     */
    public String getStatusSource() {
        return _statusSource;
    }

    /**
     * @param statusUpdater
     */
    @XmlElement (name = "statusSource")
    public void setStatusSource(String statusUpdater) {
        _statusSource = statusUpdater;
    }

    /**
     * @return the statusCode
     */
    public int getStatusCode() {
        return _statusCode;
    }

    /**
     * @param statusCode the statusCode to set
     */
    @XmlElement (name = "statusCode")
    public void setStatusCode(int statusCode) {
        _statusCode = statusCode;
    }

	/**
	 * @return the _detail
	 */
	public String getDetail() {
		return _detail;
	}
	
	public String getDataInfoText() {
		String info = "";
		
		if (_statusData != null) {
			for (MapModel data : _statusData) {
				info += " " + data.getValue();
			}
		}
			
	    return info;
	}

	/**
	 * @param detail the _detail to set
	 */
	@XmlElement (name = "detail")
	public void setDetail(String detail) {
		_detail = detail;
	}
	
    /**
     * Get status data.
     * 
     * @return the _statusData
     */
	public List<MapModel> getStatusData() {
		if (_statusData == null) {
			_statusData = new ArrayList<MapModel>();
		}
		return _statusData;
	}

	/**
	 * Set status data.
	 * 
	 * @param statusData the _statusData to set
	 */
	@XmlElementWrapper(name = "statusData")
    @XmlElement(name = "property", type = MapModel.class)
	public void setStatusData(List<MapModel> statusData) {
		_statusData = statusData;
	} 	
}
