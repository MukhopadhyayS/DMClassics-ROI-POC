package com.mckesson.eig.output.local.email;

import java.io.Serializable;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public class EmailBean implements Serializable {

	private String	_mimeType;

	private String _smtpHost;
	private String _smtpPort;
	private String _toEmail;
	private String _fromEmail;
    private String _fromName;   // Added to display from name
	
	private String 	_cc;		// Comma separated values in a String
	private String 	_bcc;		// Comma separated values in a String
	private String 	_message;
	private String 	_subject;


	private int		_jobId;
	private String  _jobName;


	// List of locations including the file name to be attached.
	// we support multiple attachments
	private List<String> _attachments;


	public String getCc() {
		return _cc;
	}

	public void setCc(String cc) {
		_cc = cc;
	}

	public String getBcc() {
		return _bcc;
	}

	public void setBcc(String bcc) {
		_bcc = bcc;
	}

	public String getMessage() {
		if (StringUtils.isBlank(_message)) {
	        return "";
	    }
		return _message;
	}

	public void setMessage(String message) {
	    _message = "";
	    if (!StringUtils.isBlank(message)) {
	        _message = message.replaceAll("\n", "<br/>");
	    }
	}

	public String getSmtpHost() {
		return _smtpHost;
	}

	public void setSmtpHost(String smtpHost) {
		_smtpHost = smtpHost;
	}

	public String getSmtpPort() {
		return _smtpPort;
	}

	public void setSmtpPort(String smtpPort) {
		_smtpPort = smtpPort;
	}

	public String getToEmail() {
		return _toEmail;
	}

	public void setToEmail(String toEmail) {
		_toEmail = toEmail;
	}

	public String getFromEmail() {
		return _fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		_fromEmail = fromEmail;
	}

    public String getFromName() {
        return _fromName;
    }

    public void setFromName(String fromName) {
        _fromName = fromName;
    }
	
	public int getJobId() {
		return _jobId;
	}

	public void setJobId(int jobId) {
		_jobId = jobId;
	}

	public String getJobName() {
		return _jobName;
	}

	public void setJobName(String jobName) {
		_jobName = jobName;
	}

	public String getSubject() {
		return _subject;
	}

	public void setSubject(String subject) {
		_subject = subject;
	}

	public String getMimeType() {
		return _mimeType;
	}

	public void setMimeType(String mimeType) {
		_mimeType = mimeType;
	}

	public List<String> getAttachments() {
		return _attachments;
	}

	public void setAttachments(List<String> attachments) {
		_attachments = attachments;
	}

}
