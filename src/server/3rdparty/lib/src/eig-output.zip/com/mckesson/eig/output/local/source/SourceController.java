package com.mckesson.eig.output.local.source;

import java.util.HashMap;
import java.util.Map;

import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.EndpointTypeHandler;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.model.EndpointDefList;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.FileUtilities;
import com.mckesson.eig.output.util.UnknownObjectException;
import com.mckesson.eig.utility.util.CollectionUtilities;

public class SourceController {
	private Map<String, Source> _sources = new HashMap<String, Source>();

	private DefaultTypeHandlerFactory _factory;
	private EndpointDAO _dao;
	private OutputManager _outputManger;

	public SourceController(DefaultTypeHandlerFactory factory,
			OutputManager outputManger, EndpointDAO dao) {
		_factory = factory;
		_dao = dao;
		_outputManger = outputManger;
	}

	public void process(String sourceName, OutputJob job, JobPart part,
			FileUtilities f, SourceListener listener) throws Exception {
		Source s = getSource(sourceName);
		if (s != null) {
			s.processPart(job, part, f, listener);
		}
	}

	private Source getSource(String sourceName) {
		Source source = _sources.get(sourceName);
		if (source == null) {
			try {
				source = initSource(sourceName);
				if (source == null) {
					throw new UnknownObjectException(sourceName);
				}
				source.setOutputManager(_outputManger);
				_sources.put(sourceName, source);
			} catch (Exception e) {
				return null;
			}
		}
		return source;
	}

	private Source initSource(String sourceName) throws Exception {
		EndpointTypeDef def = _dao.getEndpointTypeDef(sourceName);
		EndpointDefList list = _dao.getEndpointDefByType(def);
		if (CollectionUtilities.isEmpty(list) || list.isEmpty()) {
			return null;
		}
		EndpointTypeHandler handler = getSourceHandler(sourceName);
		return (Source) handler.createEndpoint(list.get(0));
	}

	private EndpointTypeHandler getSourceHandler(String sourceName) {
		return _factory.getHandlerMapping(sourceName);
	}
}
