/*
 * Copyright 2008-2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.fax;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class FaxStatusListener implements MessageListener {

	private  static final String PROCESSING = "PROCESSING";
	private  static final String COMPLETE = "COMPLETE";
	private  static final String ERROR = "ERROR";
	private  static final int THREE = 3;

	private static final Log LOG = LogFactory.getLogger(FaxStatusListener.class);
	private FaxTypeHandler _handler;

	public FaxStatusListener(FaxTypeHandler handler, String statusQueueName) {
		_handler = handler;
		setupStatusQueueConsumer(statusQueueName);
	}

    private void setupStatusQueueConsumer(String statusQueueName) {
	    ActiveMQConnectionFactory connectionFactory = (ActiveMQConnectionFactory)
	    	RightFaxImpl.getActiveMQConnectionFactory();
        try {
            Connection connection = connectionFactory.createConnection();
            connection.start();
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Destination statusQueue = session.createQueue(statusQueueName);

            MessageConsumer consumer = session.createConsumer(statusQueue);
            consumer.setMessageListener(this);
        } catch (JMSException e) {
			LOG.error("Error setting up Status Queue: " + e);
        }
    }

    public void onMessage(Message message) {
        try {
            if (message instanceof TextMessage) {
                TextMessage txtMsg = (TextMessage) message;
                String messageText = txtMsg.getText();
                sendStatus(messageText);
            }
        } catch (JMSException e) {
 			LOG.error("Error getting message: " + e);
        }
    }

    public void sendStatus(String message) {
    	if (message != null) {
    		String[] msg = message.split("=");
    		if (msg.length == THREE) {
    	   		int jobId = Integer.parseInt(msg[0]);
    	   		String status = msg[1];
    	   		String detail = msg[2];
    	   		if (status.equals(COMPLETE)) {
    	   			sendCompletedStatus(jobId, detail);
    	   		} else if (status.equals(PROCESSING)) {
    	   			sendFaxingStatus(jobId, detail);
    	   		} else if (status.equals(ERROR)) {
    	   			sendErrorStatus(jobId, detail);
    	   		}
    		}
    	}
    }

    public void sendFaxingStatus(int jobId, String detail) {
        _handler.updateJobStatus(jobId,
      		  StatusUtils.createRequestStatus(RequestStatus.FAXING,
      		  "Process sending the fax:" + detail));
      }

    public void sendCompletedStatus(int jobId, String detail) {
      _handler.updateJobStatus(jobId,
    		  StatusUtils.createRequestStatus(RequestStatus.COMPLETED,
    		  "Completed sending the fax:" + detail));
    }

    public void sendErrorStatus(int jobId, String detail) {
      _handler.updateJobStatus(jobId,
    		  StatusUtils.createRequestStatus(RequestStatus.ERROR,
    		  "Error sending the fax:" + detail));
   }
}
