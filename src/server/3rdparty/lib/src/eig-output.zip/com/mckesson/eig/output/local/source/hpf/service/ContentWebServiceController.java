/**
 * Copyright � 2010 McKesson Corporation and/or one of its subsidiaries.
 * All rights reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.hpf.service;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.mckesson.eig.output.util.OutputConstants.SourceType;
import com.mckesson.eig.output.util.OutputSettingConstants;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.BooleanUtilities;
import com.mckesson.eig.utility.util.StringUtilities;

public class ContentWebServiceController {
	private static final String HPFSOURCE = SourceType.HPF.toString();
	private static final String CONFIG_URL = "{0}://{1}:{2}/portal/eig/iservices/configuration";
	private static final String PRIVATE_KEY = "ci.security.privateKey";
	private static final String TOKEN_KEY = "ci.security.token";
	
	private static final String PROTOCOL_KEY = "cws.server.protocol";
	private static final String SERVER_KEY = "cws.server.server";
	private static final String PORT_KEY = "cws.server.port";
	private static final String USER_KEY = "cws.server.user";
	private static final String PASSWORD_KEY = "cws.server.password";

	private static final int DEFAULT_POOL_SIZE = 10;
	private static final int DEFAULT_THREAD_PER_POOL = 2;

	private final List<ContentWebServiceExecutor> _executors
		= new ArrayList<ContentWebServiceExecutor>();

	private static final Log LOG = LogFactory.getLogger(ContentWebServiceController.class);
	private final List<WebServiceSetting> _settings = new ArrayList<WebServiceSetting>();
	private int _threadPerPoolSize = DEFAULT_THREAD_PER_POOL;
	private int _poolSize = DEFAULT_POOL_SIZE;
	private boolean _init = false;

	public ContentWebServiceExecutor getContentWebServiceExecutor() {
		if(!_init) {
			initConfiguration();
			_init = false;
		}
		if (_executors.size() == 0) {
			ContentWebServiceExecutor executor
				= new ContentWebServiceExecutor(_threadPerPoolSize, _settings);
			_executors.add(executor);
			return executor;
		}
		for (int i = 0; i < _executors.size(); i++) {
			ContentWebServiceExecutor executor = _executors.get(i);
			if (executor.isAvailable()) {
				executor.setAvailable(false);
				return executor;
			}
		}
		if (_executors.size() < _poolSize) {
			ContentWebServiceExecutor executor
				= new ContentWebServiceExecutor(_threadPerPoolSize, _settings);
			_executors.add(executor);
			return executor;
		}
		return null;
	}

	public void setProperties(Properties p) {
		try {
			String value = p.getProperty(OutputSettingConstants.HPF_CONTENT_WEB_POOL_SIZE);
			if (value != null) {
				setPoolSize(Integer.parseInt(value));
			}
	    } catch (Exception e) {
	    	LOG.info("Fail to set content web service pool size. Use Default. Msg: "
	    		+ e.getMessage());
	    }
		try {
			String value = p.getProperty(OutputSettingConstants.HPF_CONTENT_WEB_THREAD_PER_POOL);
			if (value != null) {
				setThreadPerPool(Integer.parseInt(value));
			}
	    } catch (Exception e) {
	    	LOG.info("Fail to set content web service thread per pool size. Use Default. Msg: "
	    		+ e.getMessage());
	    }
		initWebSetting(p);
	}

	private void initWebSetting(Properties p) {
		_settings.clear();
		String protocol = getProperty(p, PROTOCOL_KEY);
		String server = getProperty(p, SERVER_KEY);
		String port = getProperty(p, PORT_KEY);
		String user = getProperty(p, USER_KEY);
		String password = getProperty(p, PASSWORD_KEY);
		WebServiceSetting setting = new WebServiceSetting();
		setting.setServer(server);
		setting.setPort(port);
		setting.setProtocol(protocol);
		setting.setUserName(user);
		setting.setPassword(password);
		_settings.add(setting);
	}
	
    private String getProperty(Properties outputSettings, String key) {
        String result = outputSettings.getProperty(key);
        if (StringUtilities.isEmpty(result)) {
        	LOG.error("Properties of " + key + " is null or empty.");
        }
        return result;
    }
    
	private String getConfigurationUrl(String protocol, String server,
			String port) {
		Object[] args = { protocol, server, port };
		MessageFormat mf = new MessageFormat(CONFIG_URL);
		return mf.format(args);
	}

	private void initConfiguration() {
		WebServiceSetting setting = _settings.get(0);
		ConfigurationWebServiceCaller caller = new ConfigurationWebServiceCaller();
		String url = getConfigurationUrl(setting.getProtocol(), setting
				.getServer(), setting.getPort());
		try {
			Map<String, String> map = caller.getConfiguration(url, setting
					.getUserName(), setting.getPassword());

			String privateKey = map.get(PRIVATE_KEY);
			boolean isNeedToken = BooleanUtilities.valueOf(map.get(TOKEN_KEY), false);
			setWebServiceOption(privateKey, isNeedToken);
		} catch (Exception e) {
			LOG.error("getConfiguration" + e.getMessage());
		}
	}

	private void setWebServiceOption(String privateKey, boolean isNeedToken) {
		for (WebServiceSetting setting : _settings) {
			setting.setWebServiceOption(privateKey, isNeedToken);
		}
	}

	public int getThreadPerPool() {
		return _threadPerPoolSize;
	}

	public void setThreadPerPool(int threadSize) {
		_threadPerPoolSize = threadSize;
	}

	public int getPoolSize() {
		return _poolSize;
	}

	public void setPoolSize(int poolSize) {
		_poolSize = poolSize;
	}

	public void shutdown() {
		for (ContentWebServiceExecutor executor : _executors) {
			executor.shutdown();
		}
	}
}
