/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local;

import java.util.Collection;

import com.mckesson.eig.output.model.EndpointTypeDef;

/**
 * EndpointTypeHandlerFactory is a "factory of factories" for creating
 * EndpointTypeHandlers. The Type Handlers are responsible for creating the
 * actual endpoints that are used in output processing as well as managing
 * certain life cycle events, etc. The system has a single
 * EndpointTypeHandlerFactory responsible for creating all the
 * EndpointTypeHandlers used.
 *
 * @author Jon Anderson
 */
public interface EndpointTypeHandlerFactory {

	/**
	 * Return the list of type names for which this factory knows how to create
	 * a EndpointTypeHandler.
	 *
	 * @return should not <code>null</code>
	 */
	Collection<String> getSupportedTypes();

	/**
	 * Create a single instance of the EndpointTypeHandler for <code>type</code>
	 *
	 * @param type not <code>null</code> type for which to create a handler
	 * @return not <code>null</code>
	 */
	EndpointTypeHandler createEndpointTypeHandler(EndpointTypeDef type);

	/**
	 * Create the default definition for the given type.
	 *
	 * @param type name of type for which to create a default definition
	 * @return not <code>null</code>
	 */
	EndpointTypeDef createDefaultTypeDef(String type);
}
