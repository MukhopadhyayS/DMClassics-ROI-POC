/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.mckesson.eig.output.model.EndpointTypeDef;

import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.UnknownObjectException;


/**
 * Simple Type Handler Factory which uses a map
 * @author Jon Anderson
 */
public class DefaultTypeHandlerFactory
	implements EndpointTypeHandlerFactory {

	private HashMap<String, EndpointTypeHandler> _handlerMap =
	    new HashMap<String, EndpointTypeHandler>();

	/**
	 * Simple constructor with no mappings
	 */
	public DefaultTypeHandlerFactory() {
	    super();
	}

	/**
	 * Constructor with the mappings defined
	 *
	 * @param handlerMap not <code>null</code>
	 */
	public DefaultTypeHandlerFactory(
			Map<String, EndpointTypeHandler> handlerMap) {
		setHandlerMappings(handlerMap);
	}

	/**
	 * @see EndpointTypeHandlerFactory#createEndpointTypeHandler(EndpointTypeDef)
	 */
	public EndpointTypeHandler createEndpointTypeHandler(
	        EndpointTypeDef endpointTypeDef) {

	    if (endpointTypeDef == null) {
	        throw new IllegalArgumentException(
	                "endpointTypeDef argument is null");
	    }

	    String typeName = endpointTypeDef.getType();
		EndpointTypeHandler handler = _handlerMap.get(typeName);
		return handler;
	}

	/**
	 * @see com.mckesson.eig.output.local.EndpointTypeHandlerFactory#getSupportedTypes()
	 */
	public Collection<String> getSupportedTypes() {
		return _handlerMap.keySet();
	}

	/**
	 * Returns the set of mappings defined for this factory
	 *
	 * @return not <code>null</code>
	 */
	@SuppressWarnings("unchecked")
    public Map<String, EndpointTypeHandler> getHandlerMappings() {
	    return (Map<String, EndpointTypeHandler>) _handlerMap.clone();
	}

    /**
     * Sets the set of mappings defined for this factory
     *
     * @param handlerMappings may be <code>null</code>
     */
    public void setHandlerMappings(
            Map<String, EndpointTypeHandler> handlerMappings) {

        _handlerMap.clear();

        if (handlerMappings != null) {
            _handlerMap.putAll(handlerMappings);
        }
    }

	/**
	 * Adds or replaces a Endpoint Type Handler Mapping
	 *
	 * @param type not <code>null</code>
	 * @param endpointTypeHandler not <code>null</code>
	 */
	public void putHandlerMapping(
	        String type,
	        EndpointTypeHandler endpointTypeHandler) {

	    if (type == null) {
	        throw new IllegalArgumentException("type argument is null");
	    }
	    if (endpointTypeHandler == null) {
	        throw new IllegalArgumentException("endpointTypeHandler is null");
	    }

	    _handlerMap.put(type, endpointTypeHandler);
	}

	/**
	 * Returns the current handler mapped for <code>type</code>
	 *
	 * @param type not <code>null</code>
	 * @return <code>null</code> if type is not mapped
	 */
	public EndpointTypeHandler getHandlerMapping(String type) {

	    if (type == null) {
	        throw new IllegalArgumentException("type argument is null");
	    }

	    return _handlerMap.get(type);
	}


    /**
     * Remove the current handler mapped for <code>type</code>
     *
     * @param type not <code>null</code>
     * @return <code>null</code> if type is not mapped otherwise the handler
     * that was mapped
     */
	public EndpointTypeHandler removeHandlerMapping(String type) {
        if (type == null) {
            throw new IllegalArgumentException("type argument is null");
        }

        return _handlerMap.remove(type);

	}

    /**
     * @see EndpointTypeHandlerFactory#createDefaultTypeDef(java.lang.String)
     */
    public EndpointTypeDef createDefaultTypeDef(String type) {
        if (type == null) {
            throw new IllegalArgumentException("type argument is null");
        }

        EndpointTypeHandler typeHandler = _handlerMap.get(type);
        if (typeHandler == null) {
            throw new UnknownObjectException("type: " + type);
        }

        EndpointTypeDef typeDef = OutputUtil.createEndpointTypeDef(
                typeHandler.getEndpointCategory());
        typeDef.setType(type);
        typeDef.setEnabled(true);
        typeDef.setProperties(typeHandler.getProperties());
        return typeDef;
    }
}
