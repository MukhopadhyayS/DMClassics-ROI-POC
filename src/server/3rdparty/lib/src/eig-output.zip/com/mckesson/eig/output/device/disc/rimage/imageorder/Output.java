/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage.imageorder;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAttribute;

@XmlRootElement(name = "Output")
public class Output {
    
    private static final String TYPE_DEFAULT = "PowerImage"; 
    private static final String INCLUDE_SPAN_FILES_DEFAULT = "false";
    private static final String POWER_SPAN_DEFAULT = "true";
    
    private String imageFile;
    private String type;
    private String includeSpanFiles;
    private String powerSpan;
    
    public Output() {
        super();
    }

    public Output( String imageFile) {
        this.imageFile = imageFile;
        this.type = TYPE_DEFAULT;
        this.includeSpanFiles = INCLUDE_SPAN_FILES_DEFAULT;
        this.powerSpan = POWER_SPAN_DEFAULT;
    }
    
    public String getImageFile() {
        return imageFile;
    }

    @XmlAttribute(name = "ImageFile")
    public void setImageFile(String imageFile) {
        this.imageFile = imageFile;
    }

    public String getType() {
        return type;
    }

    @XmlAttribute(name = "Type")
    public void setType(String type) {
        this.type = type;
    }

    public String getIncludeSpanFiles() {
        return includeSpanFiles;
    }

    @XmlAttribute(name = "IncludeSpanFiles")
    public void setIncludeSpanFiles(String includeSpanFiles) {
        this.includeSpanFiles = includeSpanFiles;
    }

    public String getPowerSpan() {
        return powerSpan;
    }

    @XmlAttribute(name = "PowerSpan")
    public void setPowerSpan(String powerSpan) {
        this.powerSpan = powerSpan;
    }
}
