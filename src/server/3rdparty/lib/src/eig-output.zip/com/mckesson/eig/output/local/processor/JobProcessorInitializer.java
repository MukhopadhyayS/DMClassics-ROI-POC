/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.model.ShutdownHook;
import com.mckesson.eig.output.util.OutputConstants.DestinationType;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;
import com.mckesson.eig.utility.util.SpringUtilities;

public class JobProcessorInitializer implements ShutdownHook {
	private static final Log LOG = LogFactory.getLogger(JobProcessorInitializer.class);
    private static final int SLEEP_TIME = 10 * 1000;

	private static DefaultJobProcessor _jobProcessor;
    private static PrintJobProcessor _printJobProcessor;
    private static DiscJobProcessor _discJobProcessor;
    private static IdleJobProcessor _idleJobProcessor;
    private ExecutorService _threadPool = Executors.newScheduledThreadPool(4);
    private boolean _enableDefaultJobProcessor = false;
    private boolean _enablePrintJobProcessor = false;
    private boolean _enableDiscJobProcessor = false;
    
	private static final String FILE_QUEUE = DestinationType.FILE.toString();
	private static final String FAX_QUEUE = DestinationType.FAX.toString();
	private static final String EMAIL_QUEUE = DestinationType.EMAIL.toString();
	private static final String SOCKET_QUEUE = DestinationType.SOCKET.toString();
	private static final String PRINT_QUEUE = DestinationType.PRINT.toString();
	private static final String DISC_QUEUE = DestinationType.DISC.toString();

    private static final int REFRESH_QUEUE_LIST_TIME = 300 * 1000;

	private EndpointDAO _dao;
	
	public JobProcessorInitializer(DefaultTypeHandlerFactory factory,
			OutputManager outputManger, EndpointDAO dao, OutputJobDAO jobDao, JobProcessorHelper helper) {
		_dao = dao;
		_jobProcessor = new DefaultJobProcessor(factory, outputManger, dao, jobDao, helper);
		_printJobProcessor = new PrintJobProcessor(factory, outputManger, dao, jobDao, helper);
		_discJobProcessor = new DiscJobProcessor(factory, outputManger, dao, jobDao, helper);
		_idleJobProcessor = new IdleJobProcessor(factory, outputManger, dao, jobDao, helper);
    }

	/**
	 * This method is used to set the properties for all the processors
	 *
	 */
	public void setProperties(Properties p) {
		_jobProcessor.setProperties(p);
		_printJobProcessor.setProperties(p);
		_discJobProcessor.setProperties(p);
		_idleJobProcessor.setProperties(p);
	}
    
    
	/**
	 * This method is used to start the threads for all the processors
	 *
	 */
	public void start() {
		checkForStart();
		_jobProcessor.preStartupProcess();
		_printJobProcessor.preStartupProcess();
		_discJobProcessor.preStartupProcess();
		_threadPool.submit(_idleJobProcessor);
		while (!_enableDefaultJobProcessor || !_enableDiscJobProcessor || !_enablePrintJobProcessor) {
			if (!_enableDefaultJobProcessor) {
				_enableDefaultJobProcessor = isDefaultQueuesAvailable();
				if (_enableDefaultJobProcessor) {
					_threadPool.submit(_jobProcessor);
				}
			}
			if (!_enablePrintJobProcessor) {
				_enablePrintJobProcessor = isPrintQueuesAvailable();
				if (_enablePrintJobProcessor) {
					_threadPool.submit(_printJobProcessor);
				}
			}
			if (!_enableDiscJobProcessor) {
				_enableDiscJobProcessor = isDiscQueuesAvailable();
				if (_enableDiscJobProcessor) {
					_threadPool.submit(_discJobProcessor);
				}
			}
			sleepTime(REFRESH_QUEUE_LIST_TIME);
		}
	}
	
	
	
	private void checkForStart() {
		while (SpringUtilities.getInstance().getBeanFactory() == null) {
			LOG.debug("Waiting for spring configure finish");
			sleepTime(SLEEP_TIME);
		}
	}
	
	private void sleepTime(int sleeptime) {
		try {
			// remove lock
			Thread.sleep(sleeptime);
		} catch (InterruptedException ie) {
			// ignored
		}
	}

	/**
	 * This method is used to procoess before the server is shut down
	 *
	 */
	public void shutdown() {
		if (_enableDefaultJobProcessor) {
			_jobProcessor.shutdown();
		}
		if (_enablePrintJobProcessor) {
			_printJobProcessor.shutdown();
		}
		if (_enableDiscJobProcessor) {
			_discJobProcessor.shutdown();
		}
		_idleJobProcessor.shutdown();
		_threadPool.shutdown();
	}
	
	private boolean isPrintQueuesAvailable() {
		List<String> queues = new ArrayList<String>();
		queues.add(PRINT_QUEUE);
		return isAvailable(queues);
	}
	
	private boolean isDiscQueuesAvailable() {
		List<String> queues = new ArrayList<String>();
		queues.add(DISC_QUEUE);
		return isAvailable(queues);
	}
	
	private boolean isDefaultQueuesAvailable() {
		List<String> queues = new ArrayList<String>();
		queues.add(EMAIL_QUEUE);
		queues.add(FAX_QUEUE);
		queues.add(FILE_QUEUE);
		queues.add(SOCKET_QUEUE);
		return isAvailable(queues);
	}
	
	private boolean isAvailable (List<String> queuesType) {
		List<Integer> result =  _dao.getEndpointIds(queuesType);
		return !CollectionUtilities.isEmpty(result);
	}
}
