package com.mckesson.eig.output.local.source.hpf.service;


public class WebServiceSetting {
	private String _server;
	private String _port;
	private String _userName;
	private String _password;
	private String _protocol;
	private ContentWebServiceCaller _caller = new ContentWebServiceCaller();

	public String getServer() {
		return _server;
	}

	public void setServer(String server) {
		_server = server;
	}

	public String getPort() {
		return _port;
	}

	public void setPort(String port) {
		_port = port;
	}

	public String getUserName() {
		return _userName;
	}

	public void setUserName(String userName) {
		_userName = userName;
	}

	public String getPassword() {
		return _password;
	}

	public void setPassword(String password) {
		_password = password;
	}

	public String getProtocol() {
		return _protocol;
	}

	public void setProtocol(String protocol) {
		_protocol = protocol;
	}

	public void setWebServiceOption(String privateKey, boolean isSecurityToken) {
		_caller.setPrivateKey(privateKey);
		_caller.setSecurityToken(isSecurityToken);
	}

	public ContentWebServiceCaller getContentWebServiceCaller() {
		return _caller;
	}
}
