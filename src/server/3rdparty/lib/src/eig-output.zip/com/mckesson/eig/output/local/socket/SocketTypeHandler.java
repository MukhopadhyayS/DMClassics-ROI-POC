/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries. 
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material 
 * contains confidential, proprietary and trade secret information of 
 * McKesson Corporation and is protected under United States and 
 * international copyright and other intellectual property laws. Use, 
 * disclosure, reproduction, modification, distribution, or storage 
 * in a retrieval system in any form or by any means is prohibited without 
 * the prior express written permission of McKesson Corporation.
 */
package com.mckesson.eig.output.local.socket;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.mckesson.eig.output.local.AbstractTypeHandler;
import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.PropertySupport;


/**
 * This class provides the business methods implementations for printer destination type handlers
 * @author OFS
 */
public class SocketTypeHandler extends AbstractTypeHandler {

    private final Map<String, SocketDestination> _socketDestMap =
            new HashMap<String, SocketDestination>();
    
    public SocketTypeHandler() {
        super();

    }

    public SocketTypeHandler(String enabled) {
        this();
    	setEnabled(enabled);
    }

    public void cleanUp() {
        // destroyDestinations
    }

    public OutputEndpoint createEndpoint(EndpointDef endpointDef) {

        try {
            
            SocketDestination endPoint = new SocketDestination(this);
            
            if (endpointDef.getProperties() != null && endpointDef.getProperties().size() > 0) {
                endPoint.getProperties().setProperties(endpointDef.getProperties());
            }
            _socketDestMap.put(endpointDef.getName(), endPoint);
            return endPoint;
        } catch (Exception e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e); 
        }
        
    }
    
    public void destroyEndpoint(OutputEndpoint destination) {
    }

    public String[] getEndpointContentTypes() {
        return OutputConstants.ANY_CONTENT_TYPE;
    }

	public PropertyDef[] getDevicePropertyDefs(String deviceID) {
	    
	    SocketDestination dest = _socketDestMap.get(deviceID);
        if (dest != null) {
            return dest.getPropertyDefs();
        }
        return null;
    }

    public EndpointCategory getEndpointCategory() {
        return EndpointCategory.DESTINATION;
    }

    public Collection<String> queryDeviceIDs() {
        return _socketDestMap.keySet();
    }

    public Map<String, Object> queryDeviceProperties(String deviceID) {
        SocketDestination dest = _socketDestMap.get(deviceID);
        if (dest != null) {
            return PropertySupport.createDefaultValuesMap(dest.getPropertyDefs());
        }
        return null;
    }

    public StatusInfo queryDeviceStatus(String deviceID) {
        SocketDestination dest = _socketDestMap.get(deviceID);
        if (dest != null) {
            return dest.queryEndpointStatus();
        }
        return null;
    }

    public PropertyDef[] getPropertyDefs() {
        return PropertySupport.extractAnnotatedProperties(SocketDestination.class);
    }
    
}
