/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.local.printer.PrintListener;
import com.mckesson.eig.output.local.printer.PrintUtilities;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants.DestinationType;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.OutputSettingConstants;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;
import com.mckesson.eig.utility.util.StringUtilities;

public class PrintJobProcessor  extends  AbstractJobProcessor  {

	private static final String PRINT_QUEUE = DestinationType.PRINT.toString();
	private static final String PRINT_NAME = "printerName";
    private static final int DEFAULT_JOB_SIZE = 4;
	private static final Log LOG = LogFactory.getLogger(PrintJobProcessor.class);

	private final List<Integer> _avaiablePrinters = new ArrayList<Integer>();
	private final PrintListener _printListener;

	public PrintJobProcessor(DefaultTypeHandlerFactory factory,
			OutputManager outputManger, EndpointDAO dao, OutputJobDAO jobDao, JobProcessorHelper helper) {
		super(factory, outputManger, dao, jobDao, helper);
		_printListener = new PrintListener(_outputManger);
		setExecutorSize(DEFAULT_JOB_SIZE);
	}
	
	/**
	 * This method is used to set the properties
	 *
	 */
	public void setProperties(Properties p) {
		super.setProperties(p);
		try {
			String value = p.getProperty(
				OutputSettingConstants.CONCURRENT_PRINT_JOB);
			if (value != null) {
				setExecutorSize(Integer.parseInt(value));
			}
	    } catch (Exception e) {
	    	LOG.info("Fail to set print processor properties. Use Default. Msg: " + e.getMessage());
	    }
	}

	/**
	 * This method is used to process the output job
	 *
	 */
	public boolean processJob() {
    	try {
        	Integer jobId = getNextAvailableJobForOnePerQueue(_avaiablePrinters, RequestStatus.READY, RequestStatus.PROCESSING);
        	if (jobId != null) {
    			LOG.debug("Start retieveing source for Job:" + jobId);
        		PrintProcessRunnable p = creatPrintProcessorTask(jobId);
        		_executor.execute(p);
        		return true;
        	}
    	} catch (Exception e) {
    		LOG.error("PrintJobProcessor-start-Exception: " + e.getMessage());
    	}
    	return false;
	}
	
	/**
	 * This method is used to refresh the queue
	 *
	 */
	public void refreshQueueList() {
		configPrinterList();
	}

	public void configPrinterList() {
		LOG.debug("Update Printer List");
		_avaiablePrinters.clear();
		List<String> queues = new ArrayList<String>();
		queues.add(PRINT_QUEUE);
		List<EndpointDef> list =  _dao.getEndpoints(queues);
		if (!CollectionUtilities.isEmpty(list)) {
			String[] availablePrinters = PrintUtilities.getAvailablePrinters();
			Iterator<EndpointDef> i = list.iterator();
			while (i.hasNext()) {
				EndpointDef def = i.next();
				if (isPrinterInList(def, availablePrinters)) {
					_avaiablePrinters.add(def.getId());
				}
			}
		}
	}

	private boolean isPrinterInList(EndpointDef def, String[] printers) {
        if (def.getProperties() != null) {
	        String printerName = (String) def.getProperties().get(PRINT_NAME);
	        if (!StringUtilities.isEmpty(printerName)) {
	        	for (String printer : printers) {
	        		if (printerName.equals(printer)) {
	        			return true;
	        		}
	        	}
	        }
        }
        return false;
	}

	private PrintProcessRunnable creatPrintProcessorTask(Integer jobId) {
		OutputJob job = createJob(jobId);
		PrintProcessRunnable processor = new PrintProcessRunnable(_factory,
				_dao, _outputManger, _printListener, job);
		job.logMetric("Start Processing Job:" + jobId);
		return processor;
	}
	
	protected void preStartProcessing() {
		preShutdownProcess();
	}

	protected void preShutdownProcess() {
		String serverName = getProcessingServer();
		_jobDao.updateAllJobsStatusForServer(serverName,
			RequestStatus.PRINTING.statusCode(),
			RequestStatus.ERROR.statusCode(), _avaiablePrinters);
	}

}
