/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.Arrays;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.util.OutputProperty.PropertyFlag;
import com.mckesson.eig.output.util.PropertySupport;


/**
 * Class which defines attributes of a property particularly useful for dynamic UI's which
 * may or may not know what values are valid.
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "propertyDef")
@XmlType(name = "propertyDef")
public class PropertyDef implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 59;
	private static final int HASH_INIT = 53;

	private String _propertyName;
	private String _label;
    private String _description;
    private String _dataType;
    private String _defaultValue;
    private String _required;
    private String _bindingProperty;
    private String[] _possibleValues;
    private PropertyFlag[] _propertyFlags;
    private String _index;
    private String _pairPropertyName;
    private String _rowCount;
    private String[] _contextMenu;
    private String _jsAction;
    private String _size;
    private String _maxLength;

    /**
     * @param name
     * @param label
     * @param description
     * @param type
     * @param defaultValue
     * @param possibleValues
     * @param propertyFlags
     */
    public PropertyDef(
    		String name,
    		String label,
    		String description,
    		String type,
			String defaultValue,
			String[] possibleValues,
			PropertyFlag[] propertyFlags) {
		super();
		_propertyName = name;
		_label = label;
		_description = description;
		_dataType = type;
		_defaultValue = defaultValue;
		_possibleValues = possibleValues;
		_propertyFlags = propertyFlags;
	}

	/**
     *
     */
    public PropertyDef() {
        super();
    }

    /**
     * @return the propertyName
     */
    public String getPropertyName() {
        return _propertyName;
    }

    /**
     * @param propertyName the propertyName to set
     */
    @XmlElement (name = "propertyName")
    public void setPropertyName(String propertyName) {
        this._propertyName = propertyName;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return _description;
    }

    /**
     * @param description the description to set
     */
    @XmlElement (name = "description")
    public void setDescription(String description) {
        this._description = description;
    }

    /**
     * @return the type
     */
    public String getDataType() {
        return _dataType;
    }

    /**
     * @param type the type to set
     */
    @XmlElement (name = "dataType")
    public void setDataType(String type) {
        this._dataType = type;
    }

    /**
     * @return the defaultValue
     */
    public String getDefaultValue() {
        return _defaultValue;
    }

    /**
     * @param defaultValue the defaultValue to set
     */
    @XmlElement (name = "defaultValue")
    public void setDefaultValue(String defaultValue) {
        this._defaultValue = defaultValue;
    }

    /**
     * @return required/not
     */
    public String getRequired() {
        return _required;
    }

    /**
     * @param required to set if this property is required or not
     */
    @XmlElement (name = "required")
    public void setRequired(String required) {
        this._required = required;
    }

    /**
     * @return binding property
     */
    public String getBindingProperty() {
        return _bindingProperty;
    }

    /**
     * @param required to set if this property is required or not
     */
    public void setBindingProperty(String bindingProperty) {
        this._bindingProperty = bindingProperty;
    }

    /**
     * Decorator method which converts getPropertyFlags() to a string array
     *
     * @return the flags as strings may be null
     */
    public String[] getFlags() {

        PropertyFlag[] propertyFlags = getPropertyFlags();
        if (propertyFlags == null) {
            return null;
        }

        String[] flags = new String[propertyFlags.length];
        for (int i = 0; i < flags.length; ++i) {
            flags[i] = propertyFlags[i].name();
        }

        return flags;
    }


    /**
     * Decorator method over setPropertyFlags() which converts <code>flags</code>
     * to a PropertyFlag array
     *
     * @param flags may be <code>null</code>
     */
    @XmlElement (name = "flags")
    public void setFlags(String[] flags) {

        PropertyFlag[] propertyFlags;
        if (flags == null) {
            propertyFlags = null;
        } else {
            propertyFlags = new PropertyFlag[flags.length];
            for (int i = 0; i < flags.length; ++i)  {
                propertyFlags[i] = PropertyFlag.valueOf(flags[i]);
            }
        }

        setPropertyFlags(propertyFlags);
    }

    /**
     * Returns the flags which define how this property is used
     *
     * @return may be <code>null</code>
     */
    public PropertyFlag[] getPropertyFlags() {
        return _propertyFlags;
    }

    /**
     * Sets the flags which define how this property is used
     *
     * @param propertyFlags may be <code>null</code>
     */
    public void setPropertyFlags(PropertyFlag[] propertyFlags) {
        _propertyFlags = propertyFlags;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return _label;
    }

    /**
     * @param label the label to set
     */
    @XmlElement (name = "label")
    public void setLabel(String label) {
        this._label = label;
    }

    /**
     * @return the possibleValues
     */
    public String[] getPossibleValues() {
        return _possibleValues;
    }

    /**
     * @param possibleValues the possibleValues to set
     */
    @XmlElement (name = "possibleValues")
    public void setPossibleValues(String[] possibleValues) {
        this._possibleValues = possibleValues;
    }
    
    /*
     * returns -1 if _index is not an Integer
     */
    public Integer getIndexValue() {
    	try {
    		return Integer.valueOf(_index);
    	}
    	catch (Exception e){
    		return Integer.valueOf(-1);
    	}
    }

	public String getIndex() {
		return _index;
	}

	@XmlElement (name = "index")
	public void setIndex(String index) {
		_index = index;
	}

    /**
     * @return the propertyName
     */
    public String getPairPropertyName() {
        return _pairPropertyName;
    }

    /**
     * @param propertyName the propertyName to set
     */
    @XmlTransient
    public void setPairPropertyName(String pairPropertyName) {
        this._pairPropertyName = pairPropertyName;
    }

    /**
     * @return the rowCount
     */
    public String getRowCount() {
        return _rowCount;
    }

    /**
     * @param rowCount set the rowCount
     */
    @XmlElement (name = "rowCount")
    public void setRowCount(String rowCount) {
        this._rowCount = rowCount;
    }    
    
    /**
     * @return the context menu
     */
    public String[] getContextMenu() {
        return _contextMenu;
    }

    /**
     * @param contextMenu the contextMenu to set
     */
    @XmlElement (name = "contextMenu")
    public void setContextMenu(String[] contextMenu) {
        this._contextMenu = contextMenu;
    }        
    
    /**
     * defines the java script action to be used on Queue UI
     * @return
     */
    @XmlElement (name = "jsAction")
	public String getJsAction() { return _jsAction; }
	public void setJsAction(String jsAction) { _jsAction = jsAction; }

	/**
     * defines the Length
     * @return
     */
    @XmlElement (name = "size")
	public String getSize() { return _size; }
	public void setSize(String size) { _size = size; }

    /**
     * defines the Length
     * @return
     */
    @XmlElement (name = "maxLength")
	public String getMaxLength() { return _maxLength; }
	public void setMaxLength(String maxLength) { _maxLength = maxLength; }

	@Override
	public boolean equals(Object obj) {

		PropertyDef propertyDef = (PropertyDef) obj;
		if (!ObjectUtils.equals(_propertyName, propertyDef._propertyName)) {
			return false;
		}
        if (!ObjectUtils.equals(_label, propertyDef._label)) {
            return false;
        }
		if (!ObjectUtils.equals(_description, propertyDef._description)) {
			return false;
		}
		if (!ObjectUtils.equals(_dataType, propertyDef._dataType)) {
			return false;
		}
		if (!ObjectUtils.equals(_defaultValue, propertyDef._defaultValue)) {
			return false;
		}
        if (!Arrays.equals(_possibleValues, propertyDef._possibleValues)) {
            return false;
        }
        if (!PropertySupport.propertyFlagsEqual(
                _propertyFlags,
                propertyDef._propertyFlags)) {
            return false;
        }

		return true;
	}

	@Override
	public int hashCode() {
		HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
		builder.append(_propertyName);
        builder.append(_label);
		builder.append(_description);
		builder.append(_dataType);
		builder.append(_defaultValue);
        builder.append(_possibleValues);
		builder.append(_propertyFlags);
		builder.append(_contextMenu);		
		return builder.toHashCode();
	}
}
