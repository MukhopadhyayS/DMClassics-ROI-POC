/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/


package com.mckesson.eig.output.local.device.disc.rimage;


import com.mckesson.eig.output.local.device.disc.DiscDevice;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


/**
 * @author Karthik, Easwaran
 * @date Aug 30, 2013
 * @since Aug 30, 2013
 *
 */
public class RimageDiscDevice extends DiscDevice {
	
	private static final String RIMAGE = "Rimage";
	private static final Log LOG = LogFactory.getLogger(RimageDiscDevice.class);

	private String _ipAddress;
	private String _portNumber;
	private String _templateLocation;
	private RimageTypeHandler _typeHandler;
	
	public static String HOSTADDRESS = "ipAddress";
	public static String PORT = "portNumber";
	public static String LABEL_TMPL_DIR = "templateLocation";
	public static String TMP_FILE_DIR = "temporaryLocation";
	
	RimageDiscDevice(RimageTypeHandler handler, DeviceInfo deviceInfo) {
        super(deviceInfo);

		if (handler == null) {
			throw new IllegalArgumentException("handler argument is null");
		}
        _typeHandler = handler;	
        setVendorName(RIMAGE);
	}
	
	 @OutputProperty(
	            defaultValue = "",
	            description = "IP Address or hostName of the External Disc Device",
	            label = "Host Name/IP",
				possibleValues = { "[a-zA-Z0-9.\\-]+[a-zA-Z0-9]*" },
	            required = "true",
	            index = "0")
	public String getIpAddress() { return _ipAddress; }
	public void setIpAddress(String ipAddress) { _ipAddress = ipAddress; }
	
	@OutputProperty(
            defaultValue = "",
            description = "Messaging Port Number of the External Disc System",
            label = "Port",
			possibleValues = { "[0-9]+" },
            required = "true",
            index = "1",
            size = "10")
	public String getPortNumber() { return _portNumber; }
	public void setPortNumber(String portNumber) { _portNumber = portNumber; }
	
	@OutputProperty(
            defaultValue = "",
            description = "Share Location of the Label templates",
            label = "Label Location",
			possibleValues = { "(\\\\\\\\(\\d{1,3}\\.){3,3}(\\d{1,3})|"
					   + "(\\\\\\\\)[^\\/:*|<>?\"]+)(\\\\[^\\/:*|<>?\"])*" },
            required = "true",
            index = "2")
	public String getTemplateLocation() { return _templateLocation; }
	public void setTemplateLocation(String templateLocation) { _templateLocation = templateLocation; }
	
	@Override
	public StatusInfo queryEndpointStatus() {
		return StatusUtils.createEndpointStatus(EndpointStatus.OK, null);
	}
	
	@Override
	public StatusInfo queryEndpointStatus(boolean validEndPoint) {
		if (validEndPoint) {

			//validate Connection and directory accessible
			try {
				_typeHandler.validateDestination(this);
			} catch (Exception e) {
				LOG.debug(e.toString());
				return StatusUtils.createEndpointStatus(EndpointStatus.ERR_HELP, e.getMessage());
			}
		}
		return queryEndpointStatus();
	}
	
	public RimageTypeHandler getTypeHandler() {
		return _typeHandler;
	}
	
}
