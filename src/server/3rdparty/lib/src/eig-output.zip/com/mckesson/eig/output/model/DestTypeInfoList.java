/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.mckesson.eig.output.util.GetSetList;

/**
 * @author tlsplh4
 *
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "destTypeInfos")
@XmlType(name = "destTypeInfos")
public class DestTypeInfoList extends GetSetList<DestTypeInfo>
	implements Serializable {


	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public DestTypeInfoList() {
		super();
	}

	/**
	 * @param delegate
	 */
	public DestTypeInfoList(List<DestTypeInfo> delegate) {
		super(delegate);
	}


}
