/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeListenerProxy;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.ObjectUtils;

import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.local.dao.OutputSearchLoVDAO;
import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputRequest;
import com.mckesson.eig.output.model.OutputSearchLoV;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.RequestPart;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.security.authorization.OutputACL;
import com.mckesson.eig.output.service.OutputBaseService;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.OutputConstants.RunState;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.output.util.UnknownObjectException;
import com.mckesson.eig.output.util.status.StatusChangeListener;
import com.mckesson.eig.output.util.status.StatusChangeSupport;
import com.mckesson.eig.output.util.status.StatusEvent;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.output.util.status.StatusUtils.StatusObjectType;
import com.mckesson.eig.utility.io.FileLoader;
import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.wsfw.session.WsSession;

/**
 * Base implementation of the <code>OutputManager</code> interface which
 * delegates management of Endpoints to a <code>EndpointManager</code> and uses
 * strategy implementations to handle cache querying, jobID generation and
 * location management. The class also handle thread safety around service state
 * and job management.
 * 
 * @author Jon Anderson
 * @author Eric Yu
 */
public class OutputManagerImpl implements OutputManager {

	private static final Log LOG = LogFactory
			.getLogger(OutputManagerImpl.class);

	private Object _semaphore = new Object();
	private LocationStrategy _locationStrategy;
	private EndpointManager _endpointManager;
	private JobIDStrategy _jobIDStrategy;
	private StatusInfo _runStatus;
	private StatusChangeSupport _statusChangeSupport;
	private HashMap<String, String> _properties;
	private PropertyChangeSupport _propertyChangeSupport;
	private String _configureFile;

	/**
	 * Constructs the object with a required EndpointManager. Creates the
	 * default strategy objects as well.
	 * 
	 * @param endpointManager
	 *            not <code>null</code>
	 */
	protected OutputManagerImpl(EndpointManager endpointManager) {

		if (endpointManager == null) {
			throw new IllegalArgumentException(
					"endpointManager argument is null");
		}

		_runStatus = StatusUtils.createRunStateStatus(RunState.INIT);
		_statusChangeSupport = new StatusChangeSupport();
		_propertyChangeSupport = new PropertyChangeSupport(this);
		_properties = new HashMap<String, String>();

		_endpointManager = endpointManager;

		setLocationStrategy(createDefaultLocationStrategy());
		OutputUtil.setOutputManager(endpointManager, this);
	}

	/**
	 * Required implementation method to do any work necessary to kick an
	 * OutputJob off
	 * 
	 * @param job
	 *            will not <code>null</code>
	 */
	protected void startOutputJob(OutputJob job) {

	}

	/**
	 * Required implementation method to do any cleanup necessary after a job is
	 * completed.
	 * 
	 * @param job
	 *            not <code>null</code>
	 */
	protected void cleanUpOutputJob(OutputJob job) {

	}

	/**
	 * @see OutputManager#submitOutputRequest(OutputRequest)
	 */
	public OutputJob submitOutputRequest(OutputRequest request) {

		OutputJob job;
		if (StatusUtils.isStatusStop(_runStatus)) {
			throw new OutputException("Output is not running ",
					OutputErrorCode.STATE_ERROR);
		}

		job = createOutputJob(request);
		_locationStrategy.setJobLocations(job);
		startOutputJob(job);

		return job;
	}

	/**
	 * @see OutputManager#postAndPause(OutputRequest)
	 */
	public List<OutputJob> postAndPause(List<OutputRequest> request) {

		if (StatusUtils.isStatusStop(_runStatus)) {
			throw new OutputException("Output is not running ",
					OutputErrorCode.STATE_ERROR);
		}

		List<OutputJob> newOutputJob = new ArrayList<OutputJob>();

		for (OutputRequest outputRequest : request) {

			OutputJob job = createOutputJob(outputRequest);
			_locationStrategy.setJobLocations(job);

			newOutputJob.add(job);
		}
		return newOutputJob;
	}

	public OutputJob syncResubmitOutputJob(int jobID) {

		OutputJob job = getOutputJobDAO().readOutputJob(jobID);
		OutputRequest req = new OutputRequest();
		req = (OutputRequest) OutputUtil.getObject(new StringReader(job
				.getRequestXML()));

		lookupActiveEndpoint(req);

		mapOutputRequestToOutputJob(job, req, RequestStatus.READY);
		mapOutputRequestToJobPart(job, req);

		job.setPages(0);

		getOutputJobDAO().updateOutputJob(job);
		job.setProperties(req.getProperties());
		job.setTransforms(req.getTransforms());
		job.setDestID(req.getDestID());
		job.setDestName(req.getDestName());
		job.setDestType(req.getDestType());
		job.setSubmitInfo(req.getSubmitInfo());
		job.setLabelData(req.getLabelData());
		job.getStatusInfo().setStatusCode(RequestStatus.READY.statusCode());

		_locationStrategy.setJobLocations(job);
		// cleanup job directory

		startOutputJob(job);
		return job;
	}

	/**
	 * Re-Submits an OutputJob for processing.
	 * 
	 * @see com.mckesson.eig.output.local.OutputManager#resubmitOutputJob(int)
	 */
	public OutputJob resubmitOutputJob(int jobID) {

		OutputJob job = getOutputJobDAO().readOutputJob(jobID);
		OutputRequest req = new OutputRequest();
		try {
			req = (OutputRequest) OutputUtil.getObject(new StringReader(job
					.getRequestXML()));
		} catch (Exception e) {
			throw new OutputException("Error converting the object to XML ",
					OutputErrorCode.RUNTIME_ERROR);
		}

		lookupActiveEndpoint(req);

		mapOutputRequestToOutputJob(job, req, RequestStatus.READY);
		mapOutputRequestToJobPart(job, req);

		job.setPages(0);
		job = getOutputJobDAO().resubmitResetOutputJobParts(jobID);

		_locationStrategy.setJobLocations(job);
		// cleanup job directory

		startOutputJob(job);
		return job;
	}

	public List<OutputJob> resubmitOutputJob(Map<String, String> queryOptions) {
		ArrayList<OutputJob> outputJobList = new ArrayList<OutputJob>();
		ArrayList<OutputJob> resubmitedList = new ArrayList<OutputJob>();
		OutputJobDAO jobDAO = getOutputJobDAO();
		Collection<OutputJob> queryJobs = jobDAO.queryJobs(queryOptions);

		for (OutputJob outputJob : outputJobList) {
			resubmitedList.add(resubmitOutputJob(outputJob.getJobSeq()));
		}

		return resubmitedList;
	}

	/**
	 * Method called during submitOutputRequest to create a valid job from a
	 * request. This method validates the contents of the request.
	 * 
	 * @param outputRequest
	 *            not <code>null</code>
	 * @return valid OutputJob
	 */
	protected OutputJob createOutputJob(OutputRequest outputRequest) {

		if (outputRequest == null) {
			throw new IllegalArgumentException("outputRequest argument is null");
		}

		lookupActiveEndpoint(outputRequest);

		OutputJob job = new OutputJob();
		mapOutputRequestToOutputJob(job, outputRequest, RequestStatus.READY);
		mapOutputRequestToJobPart(job, outputRequest);

		OutputJob createdJob = getOutputJobDAO().createOutputJob(job);
		job.setJobSeq(createdJob.getJobSeq());

		// Newly added for refactor COS service params
		createOutputSearchLoVs(outputRequest, createdJob.getJobSeq());
		return job;
	}

	/**
	 * This method returns an OutputJobDAO
	 * 
	 * @return
	 */
	private OutputJobDAO getOutputJobDAO() {

		OutputBaseService baseService = new OutputBaseService();
		return baseService.getOutputJobDAO();
	}

	/*
	 * This method is used to retrieve the end point Id and to validate end
	 * point exists
	 */
	private int retrieveEndpointId(String endpointType, String endpointName,
			EndpointCategory endpointCategory, String variableName) {

		if (endpointName == null) {
			throw new InvalidDefinitionException(variableName + ": "
					+ endpointName, OutputErrorCode.MISSING_DATA);
		}

		ActiveEndpoint activeEndpoint = _endpointManager.getActiveEndpoint(
				endpointType, endpointName);
		if ((activeEndpoint == null)
				|| (activeEndpoint.getEndpointDef().getEndpointCategory() != endpointCategory)) {
			throw new InvalidDefinitionException(
					endpointName + " of type " + endpointCategory.name()
							+ " is disabled or not available",
					OutputErrorCode.DESTINATION_INVALID);
		}

		return activeEndpoint.getEndpointDef().getId();
	}

	/**
	 * This method is used to retrieve and validate whether end point exists
	 * 
	 * @param outputRequest
	 *            the output request
	 */
	private void lookupActiveEndpoint(OutputRequest outputRequest) {

		ActiveEndpoint endpoint = _endpointManager
				.getActiveEndpoint(outputRequest);

		EndpointDef endpointDef = endpoint.getEndpointDef();

		// Check for invalid location if FILE Destination is processed
		if (OutputConstants.DestinationType.FILE.toString().equals(
				endpointDef.getType())) {

			String destLoc = (String) endpoint.getEndpoint().getProperty(
					OutputConstants.FILE_PROPS_DIRECTORY_NAME);
			File location = new File(destLoc);
			if (!location.canExecute() && !location.canWrite()) {

				throw new InvalidDefinitionException(endpoint.getEndpointDef()
						.getName()
						+ " of type "
						+ endpoint.getEndpointDef().getType()
						+ " has invalid location or access denied",
						OutputErrorCode.INVALID_DIRECTORY);
			}
		}

		// check if the destination is inactive
		if (endpoint.getEndpoint().queryEndpointStatus().getStatusCode() != OutputConstants.EndpointStatus.OK
				.statusCode()) {
			
			// throws exception specific to disc queue if the selected disc queue is invalid
			OutputErrorCode errorCode = OutputErrorCode.DESTINATION_INVALID;
			if (OutputConstants.DestinationType.DISC.toString().equals(endpointDef.getType())) {
				errorCode = OutputErrorCode.INVALID_DISC_DEVICE;
			}

			throw new InvalidDefinitionException(endpoint.getEndpointDef()
					.getName()
					+ " of type "
					+ endpoint.getEndpointDef().getType()
					+ " is disabled or not available",
					errorCode);
		}

		// CR # 346,831
		// Check whether the sources available in the OutputRequest.requestparts
		// are enabled or not.
		checkRequestSourceEnabled(outputRequest);
	}

	/**
	 * This method check whether the Sources for the OutputRequest is enabled.
	 * If sources is not enabled for the given request throws a
	 * InvalidDefinitionException
	 * 
	 * @param OutputRequest
	 */
	private void checkRequestSourceEnabled(OutputRequest outputRequest) {

		List<RequestPart> requestParts = outputRequest.getParts();

		String sourceType = null;
		boolean sourceEnabled = false;
		for (RequestPart reqPart : requestParts) {

			sourceType = reqPart.getContentSourceType();
			sourceEnabled = _endpointManager.getActiveEndpointType(sourceType)
					.getEndpointTypeDef().isEnabled();
			if (!sourceEnabled) {

				throw new InvalidDefinitionException("Output Source of type "
						+ sourceType + " is disabled or not available",
						OutputErrorCode.SOURCE_INVALID);
			}
		}
	}

	/**
	 * @see OutputManager#getOutputJob(java.lang.String)
	 */
	public OutputJob getOutputJob(int jobID) {
		OutputJob job;
		job = lookupJob(jobID);
		if (job == null) {
			throw new UnknownObjectException("jobID: " + jobID);
		}
		return job;
	}

	/**
	 * Not synchronized method to look up a job by ID and will not throw if not
	 * found
	 * 
	 * @param jobID
	 *            not <code>null</code>
	 * @return <code>null</code> if not found.
	 */
	protected OutputJob lookupJob(int jobID) {
		OutputJobDAO jobDAO = getOutputJobDAO();
		return jobDAO.readOutputJob(jobID);
	}

	/**
	 * @see OutputManager#updateJobPartStatus(String, String, StatusInfo)
	 */
	public JobPart updateJobPartStatus(int jobSeq, int partID,
			StatusInfo statusInfo) {

		OutputBaseService baseService = new OutputBaseService();
		OutputJobDAO jobDAO = baseService.getOutputJobDAO();
		JobPart part = jobDAO.readOutputJobPart(partID);
		part.getStatusInfo().setStatusCode(statusInfo.getStatusCode());
		jobDAO.updateJobPart(part);

		StatusEvent event = updatePartStatus(part, statusInfo);
		if (event != null) {
			_statusChangeSupport.fireStatusEvent(event);
		}
		return part;
	}

	public int getJobStatus(int jobID) {
		OutputJobDAO jobDAO = getOutputJobDAO();

		return jobDAO.fetchJobStatus(jobID);
	}

	/**
	 * @see OutputManager#updateJobStatus(String, StatusInfo)
	 */
	public OutputJob updateJobStatus(int jobID, StatusInfo statusInfo) {
		OutputJobDAO jobDAO = getOutputJobDAO();
		jobDAO.updateJobStatus(jobID, statusInfo);
		return jobDAO.readOutputJob(jobID);
	}

	private StatusEvent updatePartStatus(JobPart part, StatusInfo statusInfo) {

		StatusInfo oldStatus = part.getStatusInfo();
		part.setStatusInfo(statusInfo);
		if (StatusUtils.logicallyEquals(statusInfo, oldStatus)) {
			return null;
		}

		return new StatusEvent(oldStatus, statusInfo, part);
	}

	/**
	 * @see OutputManager#pause()
	 */
	public void pause() {

		StatusEvent event;
		synchronized (_semaphore) {

			if (StatusUtils.isStatusPause(_runStatus)) {
				return;
			}
			if (!StatusUtils.isStatusRun(_runStatus)) {
				throw new OutputException("runState: " + _runStatus,
						OutputErrorCode.STATE_ERROR);
			}

			event = updateRunState(RunState.PAUSE);

			StatusInfo statusInfo = StatusUtils.createEndpointStatus(
					EndpointStatus.PAUSED, "OutputManager Paused");

			setEndpointStatuses(statusInfo);
			doPause();
		}

		_statusChangeSupport.fireStatusEvent(event);
	}

	private void setEndpointStatuses(StatusInfo statusInfo) {
		for (ActiveEndpoint activeEndpoint : _endpointManager
				.getActiveEndpoints()) {

			EndpointDef endpointDef = activeEndpoint.getEndpointDef();
			_endpointManager.updateEndpointStatus(endpointDef.getId(),
					statusInfo);
		}
	}

	/**
	 * Method which gets called inside pause's synchronized block after the
	 * endpoints have been paused and after the service state is set to pause to
	 * allow implementors to perform any work they may need to do. This
	 * implementation is a noop.
	 */
	protected void doPause() { /* noop */
	}

	/**
	 * @see OutputManager#restart()
	 */
	public void restart() {

		StatusEvent event;

		synchronized (_semaphore) {

			if (StatusUtils.isStatusRun(_runStatus)) {
				return;
			}
			if (!StatusUtils.isStatusPause(_runStatus)) {
				throw new OutputException("runState: " + _runStatus,
						OutputErrorCode.STATE_ERROR);
			}

			doRestart();
			setEndpointStatuses(null); // null means query the endpoint
			event = updateRunState(RunState.RUN);
		}

		_statusChangeSupport.fireStatusEvent(event);
	}

	/**
	 * Method which gets called inside restart's synchronized block before the
	 * endpoints have are restarted and before the service state is set to run
	 * to allow implementors to perform any work they may need to do. This
	 * implementation is a noop.
	 */
	protected void doRestart() { /* noop */
	}

	/**
	 * @see OutputManager#shutdown(boolean)
	 */
	public void shutdown(boolean force) {

		StatusEvent event;

		synchronized (_semaphore) {
			if (StatusUtils.isStatusStop(_runStatus)) {
				return;
			}

			event = updateRunState(RunState.STOP);

			for (ActiveEndpoint activeEndpoint : _endpointManager
					.getActiveEndpoints()) {

				EndpointDef endpointDef = activeEndpoint.getEndpointDef();
				try {

					_endpointManager.cleanUpActiveEndpoint(endpointDef.getId());

				} catch (Exception ex) {
					LOG.error(
							"error cleaning up endpoint: "
									+ endpointDef.getName(), ex);
				}
			}

			doShutdown(force);
		}

		_statusChangeSupport.fireStatusEvent(event);
	}

	/**
	 * Method which gets called inside shutdown's synchronized block after the
	 * endpoints have been stop and after the service state is set to stop to
	 * allow implementors to perform any work they may need to do. This
	 * implementation is a noop.
	 * 
	 * @param force
	 *            shutdown should be forced.
	 */
	protected void doShutdown(boolean force) { /* noop */
	}

	/**
	 * @see com.mckesson.eig.output.local.OutputManager#start()
	 */
	public void start() {

		StatusEvent event;

		synchronized (_semaphore) {

			if (StatusUtils.isStatusRun(_runStatus)) {
				return;
			} else if (StatusUtils.isStatusStop(_runStatus)) {
				_runStatus = StatusUtils.createRunStateStatus(RunState.INIT);
			}

			if (!StatusUtils.isStatusInit(_runStatus)) {
				throw new OutputException("runState: " + _runStatus,
						OutputErrorCode.STATE_ERROR);
			}

			doStart();

			event = updateRunState(RunState.RUN);
		}

		_statusChangeSupport.fireStatusEvent(event);
	}

	/**
	 * Method which gets called inside start's synchronized block before the
	 * endpoints have been queried and before the service state is set to run to
	 * allow implementors to perform any work they may need to do. This
	 * implementation is a noop.
	 */
	protected void doStart() { /* noop */
	}

	private StatusEvent updateRunState(RunState runState) {

		StatusInfo currentRunState = _runStatus;
		_runStatus = StatusUtils.createRunStateStatus(runState);

		return new StatusEvent(currentRunState, _runStatus, this);
	}

	/**
	 * Returns the current LocationStrategy
	 * 
	 * @return will not be <code>null</code>.
	 */
	public LocationStrategy getLocationStrategy() {
		return _locationStrategy;
	}

	/**
	 * Sets the current LocationStrategy. This method cannot be called while the
	 * service is running.
	 * 
	 * @param locationStrategy
	 *            not <code>null</code>
	 */
	public void setLocationStrategy(LocationStrategy locationStrategy) {
		if (locationStrategy == null) {
			throw new IllegalArgumentException(
					"locationStrategy argument is null");
		}

		synchronized (_semaphore) {
			validateStateInitOrStop("must not be running to set LocationStrategy");

			OutputUtil.setOutputManager(_locationStrategy, null);

			_locationStrategy = locationStrategy;

			OutputUtil.setOutputManager(_locationStrategy, this);
		}
	}

	private void validateStateInitOrStop(String errorMsg) {
		if (StatusUtils.isStatusInit(_runStatus)
				|| StatusUtils.isStatusStop(_runStatus)) {
			return;
		}
		throw new OutputException(errorMsg, OutputErrorCode.STATE_ERROR);
	}

	/**
	 * Returns the current JobIDStrategy
	 * 
	 * @return not <code>null</code>
	 */
	public JobIDStrategy getJobIDStrategy() {
		return _jobIDStrategy;
	}

	/**
	 * @see OutputManager#getStatusInfo()
	 */
	public StatusInfo getStatusInfo() {
		synchronized (_semaphore) {
			return _runStatus.clone();
		}
	}

	/**
	 * @see OutputManager#getRunState()
	 */
	public RunState getRunState() {
		return RunState.valueOf(_runStatus.getStatus());
	}

	/**
	 * Method to allow implementors to provide their own LocationStrategy as
	 * opposed to DefaultLocationStrategy
	 * 
	 * @return not <code>null</code>
	 */
	protected LocationStrategy createDefaultLocationStrategy() {
		return new DefaultLocationStrategy();
	}

	/**
	 * @see OutputManager#addPropertyChangeListener(PropertyChangeListener)
	 */
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		if (listener == null) {
			throw new IllegalArgumentException("listener argument is null");
		}
		_propertyChangeSupport.addPropertyChangeListener(listener);
		OutputUtil.setOutputManager(listener, this);
	}

	/**
	 * @see OutputManager#addPropertyChangeListener(String,
	 *      PropertyChangeListener)
	 */
	public void addPropertyChangeListener(String property,
			PropertyChangeListener listener) {
		if (property == null) {
			throw new IllegalArgumentException("property argument is null");
		}
		if (listener == null) {
			throw new IllegalArgumentException("listener argument is null");
		}
		_propertyChangeSupport.addPropertyChangeListener(property, listener);
		OutputUtil.setOutputManager(listener, this);
	}

	/**
	 * @see OutputManager#addStatusChangeListener(Object, StatusChangeListener)
	 */
	public void addStatusChangeListener(Object object,
			StatusChangeListener statusChangeListener) {
		_statusChangeSupport.addStatusChangeListener(object,
				statusChangeListener);
	}

	/**
	 * @see OutputManager#addStatusChangeListener(StatusChangeListener)
	 */
	public void addStatusChangeListener(
			StatusChangeListener statusChangeListener) {
		_statusChangeSupport.addStatusChangeListener(statusChangeListener);
	}

	/**
	 * @see OutputManager#addStatusChangeListener(StatusObjectType,
	 *      StatusChangeListener)
	 */
	public void addStatusChangeListener(StatusObjectType objectType,
			StatusChangeListener statusChangeListener) {
		_statusChangeSupport.addStatusChangeListener(objectType,
				statusChangeListener);
	}

	/**
	 * @see OutputManager#getPropertyChangeListeners()
	 */
	public Collection<PropertyChangeListener> getPropertyChangeListeners() {
		return Arrays.asList(_propertyChangeSupport
				.getPropertyChangeListeners());
	}

	/**
	 * @see OutputManager#getStatusChangeListeners()
	 */
	public Collection<StatusChangeListener> getStatusChangeListeners() {
		return _statusChangeSupport.getStatusChangeListeners();
	}

	/**
	 * @see OutputManager#removePropertyChangeListener(PropertyChangeListener)
	 */
	public void removePropertyChangeListener(PropertyChangeListener listener) {
		if (listener == null) {
			throw new IllegalArgumentException("listener argument is null");
		}

		boolean found = false;

		for (PropertyChangeListener pcl : _propertyChangeSupport
				.getPropertyChangeListeners()) {

			found = pcl == listener;
			if (found) {
				_propertyChangeSupport.removePropertyChangeListener(listener);
				break;

			} else if (pcl instanceof PropertyChangeListenerProxy) {

				PropertyChangeListenerProxy proxy = (PropertyChangeListenerProxy) pcl;

				found = (proxy.getListener() == listener);
				if (found) {
					_propertyChangeSupport.removePropertyChangeListener(
							proxy.getPropertyName(), listener);
					break;
				}
			}
		}

		if (found) {
			OutputUtil.setOutputManager(listener, null);
		}
	}

	/**
	 * @see OutputManager#removeStatusChangeListener(StatusChangeListener)
	 */
	public void removeStatusChangeListener(
			StatusChangeListener statusChangeListener) {
		_statusChangeSupport.removeStatusChangeListener(statusChangeListener);
	}

	void saveProperties() {

		if (_configureFile != null) {
			FileOutputStream stream = null;

			try {
				Properties systemConfig = new Properties();
				systemConfig.putAll(_properties);

				File file = FileLoader.getResourceAsFile(_configureFile);
				stream = IOUtilities.createFileOutputStream(file);
				systemConfig.store(stream, "");

			} catch (Exception e) {

				LOG.error("saveProperties ", e);

			} finally {
				if (stream != null) {
					IOUtilities.close(stream);
				}
			}
		}
	}

	/**
	 * Returns the name of the file to which service level properties may be
	 * persisted
	 * 
	 * @return may <code>null</code> if not configured
	 */
	public String getConfigureFile() {
		return _configureFile;
	}

	/**
	 * Sets the file that will be used to persist service properties, as a
	 * result of this call, the persisted properties will be loaded if the file
	 * already exists
	 * 
	 * @param configureFile
	 */
	public void setConfigureFile(String configureFile) {

		List<PropertyChangeEvent> events = null;

		synchronized (_semaphore) {

			String oldConfigureFile = _configureFile;
			_configureFile = configureFile;

			if (!ObjectUtils.equals(oldConfigureFile, _configureFile)
					&& (_configureFile != null)) {
				events = loadProperties();
			}
		}

		if (events != null) {

			for (PropertyChangeEvent event : events) {
				try {
					_propertyChangeSupport.firePropertyChange(event);
				} catch (Exception ex) {
					LOG.error(
							"error in property change: "
									+ event.getPropertyName(), ex);
				}
			}
		}
	}

	private List<PropertyChangeEvent> loadProperties() {

		List<PropertyChangeEvent> events = new ArrayList<PropertyChangeEvent>();

		if (_configureFile != null) {

			InputStream in = null;
			Properties systemConfig = new Properties();

			try {

				in = FileLoader.getResourceAsInputStream(_configureFile);
				if (in != null) {

					systemConfig.load(in);
				}

			} catch (Exception e) {
				LOG.error("loadProperties:" + e.getMessage());
			} finally {
				if (in != null) {
					IOUtilities.close(in);
				}
			}

			Enumeration<?> propertyNames = systemConfig.propertyNames();
			while (propertyNames.hasMoreElements()) {

				String propertyName = (String) propertyNames.nextElement();
				PropertyChangeEvent event = putProperty(propertyName,
						(String) systemConfig.get(propertyName));
				if (event != null) {
					events.add(event);
				}
			}
		}

		return events;
	}

	/**
	 * @see OutputComponent#getProperties()
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getProperties() {

		synchronized (_semaphore) {
			return (Map<String, String>) _properties.clone();
		}
	}

	/**
	 * @see OutputComponent#getProperty(String)
	 */
	public String getProperty(String propertyName) {
		synchronized (_semaphore) {
			return _properties.get(propertyName);
		}
	}

	/**
	 * @see OutputComponent#getPropertyDefs()
	 */
	public PropertyDef[] getPropertyDefs() {
		return PropertySupport.EMPTY_PROPERTY_DEFS;
	}

	/**
	 * @see OutputComponent#setProperty(String, Object)
	 */
	public void setProperty(String propertyName, Object value) {

		if (!(value instanceof String)) {
			throw new IllegalArgumentException(
					"only string values are supported");
		}

		PropertyChangeEvent event;
		synchronized (_semaphore) {

			event = putProperty(propertyName, (String) value);
			if (event != null) {
				saveProperties();
			}
		}

		if (event != null) {
			_propertyChangeSupport.firePropertyChange(event);
		}
	}

	private PropertyChangeEvent putProperty(String propertyName, String value) {

		if (propertyName == null) {
			throw new IllegalArgumentException("propertyName argument is null");
		}

		Object curValue = _properties.get(propertyName);
		if (!ObjectUtils.equals(value, curValue)) {

			_properties.put(propertyName, value);
			return new PropertyChangeEvent(this, propertyName, curValue, value);
		}

		return null;
	}

	protected EndpointManager getEndpointManger() {
		return _endpointManager;
	}

	/**
	 * This method is used to update the job page count
	 * 
	 * @param jobID
	 * @param pageCount
	 */
	public void updateJobPageCount(int jobID, int pageCount) {
		OutputJobDAO dao = getOutputJobDAO();
		dao.updateJobPageCount(jobID, pageCount);
	}

	/**
	 * This method is used to update the job part page count and status
	 * 
	 * @param partID
	 * @param pageCount
	 */

	public void updateJobPart(JobPart part) {
		OutputJobDAO dao = getOutputJobDAO();
		dao.updateJobPart(part);
	}

	public void syncJobs() {
		OutputJobDAO jobDAO = getOutputJobDAO();
		// Update the status of jobs in canceling state to CANCELED
		Collection<OutputJob> canceledJobs = jobDAO.fetchJobsByStatus(
				StatusUtils.createRequestStatus(RequestStatus.CANCELING, null),
				null, null);

		for (OutputJob job : canceledJobs) {
			jobDAO.updateJobStatus(job.getJobSeq(), StatusUtils
					.createRequestStatus(RequestStatus.CANCELED, null));
		}

		// Update the status of jobs in pausing state to PAUSED
		Collection<OutputJob> pausedJobs = jobDAO.fetchJobsByStatus(
				StatusUtils.createRequestStatus(RequestStatus.PAUSING, null),
				null, null);

		for (OutputJob job : pausedJobs) {
			jobDAO.updateJobStatus(job.getJobSeq(),
					StatusUtils.createRequestStatus(RequestStatus.PAUSED, null));
		}

		Collection<OutputJob> jobs = jobDAO.fetchJobsByStatus(
				StatusUtils.createRequestStatus(RequestStatus.READY, null),
				null, null);

		for (OutputJob job : jobs) {
			try {
				syncResubmitOutputJob(job.getJobSeq());
			} catch (Exception e) {
				jobDAO.updateJobStatus(job.getJobSeq(), StatusUtils
						.createRequestStatus(RequestStatus.ERROR, null));
			}
		}
	}

	public void setStagingDirectory(String tmpDirectory) {
		_locationStrategy
				.setProperty(OutputConstants.STAGING_DIR, tmpDirectory);
	}

	/**
	 * Method called during submitOutputRequest to create OutputSearchLoVs for
	 * the searchable data.
	 * 
	 * @param request
	 *            submitted output request
	 * @param jobID
	 *            The unique sequence of the newly created job
	 */
	protected void createOutputSearchLoVs(OutputRequest request, int jobID) {

		List<MapModel> searchData = request.getSearchableData();
		if (searchData == null) {
			return;
		}

		Set<OutputSearchLoV> lovs = new HashSet<OutputSearchLoV>();
		OutputSearchLoV lov;
		for (MapModel mapModel : searchData) {

			lov = new OutputSearchLoV();
			lov.setName(mapModel.getKey().toString());
			lov.setValue(mapModel.getValue().toString());
			lov.setParentId(jobID);
			lov.setCreatedBy(request.getCreatedBy());
			lovs.add(lov);
		}

		getOutputSearchLovDAO().createOutputSearchLoVs(lovs);
	}

	/**
	 * This method is invoked during resubmit or redirect job to override the
	 * job properties and preferences.
	 * 
	 * @param job
	 *            The actual OutputJob
	 * 
	 * @param newRequest
	 *            The request which holds the new destination and output
	 *            preferences to be applied to the actual job
	 */
	protected void overrideJobProperties(OutputJob job, OutputRequest newRequest) {

		job.setProperties(newRequest.getProperties());
		job.setDestID(newRequest.getDestID());
		job.setDestName(newRequest.getDestName());
		job.setDestType(newRequest.getDestType());
		job.setLabelData(newRequest.getLabelData());
	}

	/**
	 * Re-Directs an OutputJob for processing.
	 * 
	 * @param jobID
	 *            The unique job id to be redirected
	 * @param request
	 *            The new output properties and preferences that needs to be
	 *            applied prior to redirecting
	 * @return outputJob
	 */
	public OutputJob redirectOutputJob(int jobID, OutputRequest request) {

		OutputJob job = getOutputJobDAO().readOutputJob(jobID);
		if (job == null) {
			return null;
		}

		lookupActiveEndpoint(request);

		OutputRequest req = new OutputRequest();
		req = (OutputRequest) OutputUtil.getObject(new StringReader(job
				.getRequestXML()));

		mapOutputRequestToOutputJob(job, req, RequestStatus.READY);
		overrideJobProperties(job, request);
		mapOutputRequestToJobPart(job, req);

		job.setPages(0);
		job = getOutputJobDAO().resubmitOutputJob(job);

		_locationStrategy.setJobLocations(job);
		// cleanup job directory

		startOutputJob(job);
		return job;
	}

	/**
	 * Re-Submits an OutputJob for processing.
	 * 
	 * @param jobID
	 *            The unique job id that should be resubmitted
	 * @param request
	 *            The request holds the new output properties and preferences
	 *            that needs to be applied prior to resubmitting
	 * @return outputJob
	 */
	public OutputJob resubmitOutputJob(int jobID, OutputRequest request) {

		OutputJob job = getOutputJobDAO().readOutputJob(jobID);
		if (job == null) {
			return null;
		}

		lookupActiveEndpoint(request);

		overrideJobProperties(job, request);
		OutputRequest req = new OutputRequest();
		req = (OutputRequest) OutputUtil.getObject(new StringReader(job
				.getRequestXML()));

		mapOutputRequestToOutputJob(job, req, RequestStatus.READY);
		mapOutputRequestToJobPart(job, req);

		job.setPages(0);
		job = getOutputJobDAO().resubmitResetOutputJobParts(jobID);

		_locationStrategy.setJobLocations(job);
		// cleanup job directory

		startOutputJob(job);
		return job;
	}

	/**
	 * This method returns an OutputSearchLoVDAO.
	 * 
	 * @return outputSearchLovDAO
	 */
	private OutputSearchLoVDAO getOutputSearchLovDAO() {

		OutputBaseService baseService = new OutputBaseService();
		return baseService.getOutputSearchLoVDAO();
	}

	/**
	 * Re-submitting the output Job As a new Job.
	 * 
	 * When an archived job is to be reprinted, the original job details should
	 * not be modified in order to maintain audit trail. So a new job is created
	 * during a resubmit of output job.
	 * 
	 * @param jobID
	 *            The unique id of the job that should be redirected
	 * @param request
	 *            This request holds the overridden destination and output
	 *            preferences that should be applied when the job is redirected
	 */
	public OutputJob resubmitAsNewOutputJob(int jobID, OutputRequest request) {

		OutputJob oldJob = getOutputJobDAO().readOutputJob(jobID);
		if (oldJob == null) {
			return null;
		}

		OutputRequest newRequest = constructOutputRequestForResubmit(oldJob,
				request);
		return submitOutputRequest(newRequest);
	}

	private OutputRequest constructOutputRequestForResubmit(OutputJob oldJob,
			OutputRequest request) {

		OutputRequest newRequest = new OutputRequest();
		newRequest.setDestID(request.getDestID());
		newRequest.setDestName(request.getDestName());
		newRequest.setDestType(request.getDestType());
		newRequest.setProperties(request.getProperties());
		newRequest.setSubmitInfo(request.getSubmitInfo());
		newRequest.setCreatedBy(request.getCreatedBy());
		newRequest.setModifiedBy(request.getModifiedBy());
		newRequest.setSearchableData(request.getSearchableData());
		newRequest.setLabelData(request.getLabelData());

		if (oldJob.getStatusInfo().getStatusCode() == RequestStatus.COMPLETED
				.statusCode()) {
			_locationStrategy.setJobLocations(oldJob);
		}

		OutputRequest oldReq = (OutputRequest) OutputUtil
				.getObject(new StringReader(oldJob.getRequestXML()));

		List<OutputTransform> transforms = oldReq.getTransforms();
		if (transforms != null) {
			for (OutputTransform transform : transforms) {
				retrieveEndpointId(transform.getTransformType()
						+ OutputConstants.JOB_SUFFIX,
						transform.getTransformName()
								+ OutputConstants.JOB_SUFFIX,
						EndpointCategory.JOB_TRANSFORM, "request transforms");
			}
			request.setTransforms(transforms);
		}

		List<RequestPart> requestParts = oldReq.getParts();
		if ((requestParts == null) || (requestParts.size() == 0)) {
			throw new InvalidDefinitionException("requestParts: "
					+ requestParts, OutputErrorCode.MISSING_DATA);
		}

		List<JobPart> oldJobParts = oldJob.getParts();
		List<RequestPart> parts = new ArrayList<RequestPart>();
		newRequest.setParts(parts);
		int i = 0;

		for (JobPart oldJobPart : oldJobParts) {

			RequestPart requestPart = requestParts.get(i++);
			if (oldJob.getStatusInfo().getStatusCode() == RequestStatus.COMPLETED
					.statusCode()) {

				String newFilePath = oldJobPart.getBaseLocation()
						+ File.separator + i + ".pdf";
				requestPart.getProperties().put(
						OutputConstants.FILEPATHS.toString(), newFilePath);
			}
			newRequest.getParts().add(requestPart);
		}

		return newRequest;
	}

	/**
	 * Method to retrieve the output request information for a given jobID and
	 * store the document info in the filepath argument.
	 * 
	 * @param jobID
	 *            The unique id of the job that should be redirected
	 * @param filePath
	 *            This filePath holds the location where the PDF is available
	 */
	public void retrieveOutputRequestInfo(int jobID, String filePath) {

		OutputJob outputJob = getOutputJobDAO().readOutputJob(jobID);

		if (outputJob == null) {
			throw new UnknownObjectException("jobID: " + jobID);
		}

		_locationStrategy.setJobLocations(outputJob);

		ArrayList<String> fileNames = getFileNames(outputJob.getParts());
		if (fileNames.size() == 1) {

			try {
				FileUtils.copyFile(new File(fileNames.get(0)), new File(
						filePath));
			} catch (IOException e) {

				LOG.debug(e.getMessage());
				throw new OutputException(e.getMessage(),
						OutputErrorCode.INVALID_DATA);
			}
			return;
		}

//		Concatenate pdfConcatenate = (Concatenate) SpringUtilities
//				.getInstance().getBeanFactory()
//				.getBean("emailPdfConcatenateStrategy");

//		pdfConcatenate.concatenateListOfFiles(jobID, fileNames, filePath,
//				outputJob.getProperties());
	}

	/**
	 * This method is used to get the list of file names from job parts.
	 * 
	 * @param jobParts
	 * @return
	 */
	private ArrayList<String> getFileNames(List<JobPart> jobParts) {

		ArrayList<String> fileNames = new ArrayList<String>();
		for (JobPart jobPart : jobParts) {

			String currentLocation = jobPart.getCurrentLocation();

			File baseDir = new File(currentLocation);
			String[] files = baseDir.list();

			for (String fileName : files) {

				String filePath = currentLocation + File.separatorChar
						+ fileName;

				if (new File(filePath).isFile()) {
					fileNames.add(filePath);
				}
			}

		}
		return fileNames;
	}

	/**
	 * A utility method to map the output request to outputjob.
	 * 
	 * @param job
	 * @param req
	 */
	private void mapOutputRequestToOutputJob(OutputJob job, OutputRequest req,
			RequestStatus reqStatus) {

		job.setDestID(req.getDestID());
		job.setDestName(req.getDestName());
		job.setDestType(req.getDestType());
		job.setJobName(req.getRequestId());
		job.setRequestId(req.getRequestId());
		job.setProperties(req.getProperties());

		job.getStatusInfo().setStatusCode(reqStatus.statusCode());
		job.setStatusID(reqStatus.statusCode());

		job.setSubmitInfo(req.getSubmitInfo());
		job.setLabelData(req.getLabelData());
		job.setCreatedBy(req.getCreatedBy());
		job.setModifiedBy(req.getModifiedBy());

		OutputACL acl = ((OutputACL) WsSession
				.getSessionData(OutputACL.OUTPUT_ACL_KEY));
		if (acl != null) {
			job.setUserName(acl.getActorId());
		}
	}

	/**
	 * A utility method for mapping the outputRequest to the outputJob jobPart.
	 * 
	 * @param job
	 * @param req
	 */
	private List<JobPart> mapOutputRequestToJobPart(OutputJob job,
			OutputRequest req) {

		List<OutputTransform> transforms = req.getTransforms();

		job.setTransforms(transforms);

		List<RequestPart> requestParts = req.getParts();
		if ((requestParts == null) || (requestParts.size() == 0)) {
			throw new InvalidDefinitionException("requestParts: "
					+ requestParts, OutputErrorCode.MISSING_DATA);
		}

		if (job.getParts() != null) {
			job.getParts().clear();
		} else {
			job.setParts(new ArrayList<JobPart>());
		}

		for (RequestPart part : requestParts) {

			JobPart jobPart = new JobPart();
			jobPart.setOutputJob(job);
			jobPart.setContentID(part.getContentID());
			jobPart.getStatusInfo().setStatusCode(
					job.getStatusInfo().getStatusCode());

			String contentSourceName = part.getContentSourceName();
			String contentSourceType = part.getContentSourceType();

			jobPart.setContentSourceName(contentSourceName);
			jobPart.setContentSourceType(contentSourceType);
			jobPart.setProperties(part.getProperties());
			jobPart.setPages(0);

			transforms = part.getTransforms();
			jobPart.setTransforms(part.getTransforms());
			job.getParts().add(jobPart);
		}

		req.getProperties().put(OutputConstants.OUTPUT_JOB_DETAILS,
				job.getRequestJobDetails(req));
		job.setRequestXML(req.getXML());

		return job.getParts();
	}

	public void restartOutputJob(Integer jobSeq) {
		syncResubmitOutputJob(jobSeq);
	}

	public void cancelOutputJob(Integer jobSeq) {

		// no op
	}

	public OutputJob updateJobResults(int jobID, String results) {
		OutputJobDAO jobDAO = getOutputJobDAO();
		jobDAO.updateJobResults(jobID, results);
		return jobDAO.readOutputJob(jobID);
	}

	public OutputJob updateJobResults(int jobID, StatusInfo newstatus, String results) {
		OutputJobDAO jobDAO = getOutputJobDAO();
		jobDAO.updateJobResults(jobID, newstatus, results);
		return jobDAO.readOutputJob(jobID);
	}

 	/**
 	 * Method to update the outputjob in the outputJobs collection with
 	 * typehandler specific additional details.  calls the endpoint manager to iterate
 	 * through all of the active typehandlers
 	 */	
	@Override
	public void updateJobStatusInfoWithEndpointStatus(List<OutputJob> outputJobs) {
		_endpointManager.updateJobStatusWithEndpointStatus(outputJobs);
	}
}
