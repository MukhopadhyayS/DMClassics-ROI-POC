/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.mckesson.eig.output.device.disc.DiscContentPreparationOrder;
import com.mckesson.eig.output.device.disc.rimage.imageorder.Format;
import com.mckesson.eig.output.device.disc.rimage.imageorder.ImageOrder;
import com.mckesson.eig.output.device.disc.rimage.imageorder.ImageOrderEditList;
import com.mckesson.eig.output.device.disc.rimage.imageorder.Output;
import com.mckesson.eig.output.device.disc.rimage.imageorder.PCMACFormat;
import com.mckesson.eig.output.device.disc.rimage.imageorder.Source;
import com.mckesson.eig.output.device.disc.rimage.imageorder.Target;
import com.mckesson.eig.output.device.disc.rimage.imageorder.XMLEditListFile;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputJobFiles;
import com.mckesson.eig.output.model.OutputJobResults;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class RimageDiscContentPreparationOrder implements DiscContentPreparationOrder {

    public static final Log LOG = LogFactory.getLogger(RimageDiscContentPreparationOrder.class);

    private OutputJob job;
    private String clientId;
    private String imagefileName;
    private OutputJobFiles jobFiles;
    private String destination;
    private String userName;
    private String orderId;
    private String xmlEditListfileName;
    private String pdfFilesDestination;

    public RimageDiscContentPreparationOrder(OutputJob job) throws Exception {
        super();
        this.job = job;
        processJobParameters();
    }

    private void processJobParameters() throws Exception {
        // define client ID
        this.clientId = OutputUtil.getServerName();
        OutputJobResults results = this.job.getOutputJobResults();
        
        if(results != null){
        	this.jobFiles = results.getOutputJobFiles();
        }else{
        	LOG.error("Failed to identify pdf files while creating Image Order.");
        	//TODO: throw exception
        }
        
        //location where pdf files are created by OutputService 
        if(jobFiles != null){
        	this.pdfFilesDestination = this.jobFiles.getJobDirectory();
        }else{
        	LOG.error("Failed to identify job directory while creating Image Order.");
        	//TODO: throw exception
        }
        
        //create random name; use that name for the order ID and destination;
        String random = UUID.randomUUID().toString();
        this.destination = new StringBuffer(this.jobFiles.getJobDirectory()).append(File.separator).append(random).toString();
        this.imagefileName = new StringBuffer(this.destination).append(File.separator).append(this.job.getJobSeq()).append(".img").toString();
        this.userName = this.job.getUserName();
        // order ID
        this.orderId = new StringBuffer().append(this.job.getJobSeq()).append("_").append(random).append("_").append(RimageConstants.IMAGE_ORDER_JOB_SUFIX)
                .toString();
        this.xmlEditListfileName = new StringBuffer(this.destination).append(File.separator).append(job.getJobSeq()).append(".xml").toString();
    }

    public String getXML() throws Exception {
        createEditListXML();
        return createImageOrderXML();
    }

    private void createEditListXML() throws Exception {
        // create a list of unique names
        List<String> uniqueNames = new ArrayList<String>();
        for (String aFileName : this.jobFiles.getFileNames()) {
            int fileNameIndex = aFileName.indexOf(".");
            String fileNameNoExtension = aFileName.substring(0, fileNameIndex);
            if (!uniqueNames.contains(fileNameNoExtension)) {
                uniqueNames.add(fileNameNoExtension);
            }
        }

        // create data for XMLEditList file
        XMLEditListFile editList = new XMLEditListFile(uniqueNames, this.pdfFilesDestination);
        String editListContext = editList.getXML();
        // write it to disk; file name = jobID;
        writeXMLEditListFileToDisc(editListContext);

    }

    private void writeXMLEditListFileToDisc(String context) throws Exception {
        try {
            //create directory
            File file = new File(this.destination);
            if(!file.exists()){
                file.mkdir();
            }
            FileWriter writer = new FileWriter(this.xmlEditListfileName);
            writer.write(context);
            writer.close();
        } catch (Exception ex) {
            String message = new StringBuffer(RimageConstants.CAN_NOT_CREATE_XML_EDIT_LIST_FILE).append("Output job id: ").append(job.getJobSeq()).
                    append(". Reason: ").append(ex.getMessage()).toString();
            LOG.error(message);
            throw new OutputException(message, OutputConstants.OutputErrorCode.DEVICE_ERROR);
        }

    }

    private String createImageOrderXML() throws Exception {
        ImageOrder order = createImageOrderObject();
        return ObjectMarshaller.marshalObject(order, RimageConstants.IMAGE_ORDER_DTD);
    }

    private ImageOrder createImageOrderObject() throws Exception {
        ImageOrder order = new ImageOrder();
        // output disc image file
        Output output = new Output(this.imagefileName);
        // source for the order
        Source source = new Source();
        ImageOrderEditList editList = new ImageOrderEditList();
        editList.setEditListPath(this.xmlEditListfileName);
        source.setEditlist(editList);
        // format
        Format format = new Format();
        PCMACFormat pcmacFormat = new PCMACFormat();
        format.setPcmac_format(pcmacFormat);
        order.setClientId(this.clientId);
        order.setOrderId(this.orderId);
        order.setPriority(RimageConstants.NORMAL_PRIORITY);
        order.setOriginator(this.userName);
        order.setFormat(format);
        order.setTarget(new Target());
        order.setOutput(output);
        order.setSource(source);
        return order;
    }
    
    public String getOrderId() {
    	return orderId;
    }

}
