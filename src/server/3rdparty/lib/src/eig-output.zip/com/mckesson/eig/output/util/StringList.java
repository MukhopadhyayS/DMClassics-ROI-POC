/**
 *
 */
package com.mckesson.eig.output.util;

import java.io.Serializable;
import java.util.List;

/**
 * @author tlsplh4
 *
 */
public class StringList extends GetSetList<String> implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	public StringList() {
		super();
	}

	/**
	 * @param delegate
	 */
	public StringList(List<String> delegate) {
		super(delegate);
	}

}
