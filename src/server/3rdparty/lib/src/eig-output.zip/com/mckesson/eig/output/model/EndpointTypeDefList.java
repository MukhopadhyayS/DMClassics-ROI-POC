/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;

import com.mckesson.eig.output.util.GetSetList;

/**
 * GetSetList implementation that contains EndpointTypeDefs
 *
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "endpointTypes")
@XmlType(name = "endpointTypes")
public class EndpointTypeDefList extends GetSetList<EndpointTypeDef> {

	/**
	 * Creates a list with the default delegate
	 */
	public EndpointTypeDefList() {
		super();
	}

	/**
	 * Creates a list with the specified delegate
	 *
	 * @param delegate not <code>null</code>
	 */
	public EndpointTypeDefList(List<EndpointTypeDef> delegate) {
		super(delegate);
	}

	/**
	 * Lookup the type by typeName
	 *
	 * @param typeName name of type to lookup
	 * @return <code>null</code> if not found
	 */
	public EndpointTypeDef findTypeDef(String typeName) {

	    for (EndpointTypeDef endpointTypeDef : this) {

	        if (ObjectUtils.equals(endpointTypeDef.getType(), typeName)) {
	            return endpointTypeDef;
	        }
	    }

	    return null;
	}

    /**
     * Returns the index of the type identified by <code>typeName</code>
     *
     * @param typeName name of type to lookup
     * @return -1 if not found
     */
    public int indexOfEndpointTypeDef(String typeName) {

    	for (int i = 0; i < size(); ++i) {

    		EndpointTypeDef typeDef = get(i);
            if (ObjectUtils.equals(typeDef.getType(), typeName)) {
                return i;
            }

    	}
    	return -1;
    }
}
