/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries. 
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material 
 * contains confidential, proprietary and trade secret information of 
 * McKesson Corporation and is protected under United States and 
 * international copyright and other intellectual property laws. Use, 
 * disclosure, reproduction, modification, distribution, or storage 
 * in a retrieval system in any form or by any means is prohibited without 
 * the prior express written permission of McKesson Corporation.
 */
package com.mckesson.eig.output.local.fax;

import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputProperty;

/**
 * Dummy implementation class to show fax implementaion plug-in feature 
 * 
 * @author OFS
 * @since Dec 4, 2009
 */
public class InterFaxImpl extends FaxDestination {
    
    private String _interfaxUserName;
    private String _interfaxPassword;
    private String _interfaxFileType;
    
    public InterFaxImpl() {
        super();
    }
    
    @OutputProperty(
            defaultValue = "", 
            description = "Username for the Fax Queue",
            label = "Username")
    public String getInterfaxUserName() {
        return _interfaxUserName;
    }

    public void setInterfaxUserName(String interfaxUserName) {
        this._interfaxUserName = interfaxUserName;
    }

    @OutputProperty(
            defaultValue = "", 
            description = "Password for the Fax Queue",
            label = "Password")
    public String getInterfaxPassword() {
        return _interfaxPassword;
    }
    
    public void setInterfaxPassword(String interfaxPassword) {
        this._interfaxPassword = interfaxPassword;
    }

    @OutputProperty(
            defaultValue = "",
            description = "File type for the Fax Queue",
            label = "File type")
    public String getInterfaxFileType() {
        return _interfaxFileType;
    }

    public void setInterfaxFileType(String interfaxFileType) {
        this._interfaxFileType = interfaxFileType;
    }

    /**
     * @see com.mckesson.eig.output.local.fax#processJob(com.mckesson.eig.output.model.OutputJob)
     */
    public void processJob(OutputJob job) {
        // Send Fax using InterFax
    }    
}
