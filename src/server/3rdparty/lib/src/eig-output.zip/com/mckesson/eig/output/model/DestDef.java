/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;



/**
 * <code>DestDef</code> is a request object used to ask the OutputService to create a
 * destination to which <code>OutputJob</code>s may be routed. Each destinations will have a unique
 * name among destinations defined for a given Output Service. The type member is used to identify
 * what handler will be used for the specific destination. Expected values would be something like
 * FAX or PRING. The properties map associated to the destination provides the setting of type
 * specific options.
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "destDef")
@XmlType(name = "destDef")
public class DestDef extends EndpointDef {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 69;
	private static final int HASH_INIT = 63;

	private int _rank;
	private String _deviceID;

	/**
	 * Constructor
	 */
	public DestDef() {
		super(EndpointCategory.DESTINATION);
	}

	@Override
	public boolean equals(Object o) {

	    if (!super.equals(o)) {
	    	return false;
	    }

	    DestDef destDef = (DestDef) o;
	    if (!ObjectUtils.equals(destDef._deviceID, _deviceID)) {
	        return false;
	    }
	    return true;
	}

	@Override
	public int hashCode() {

	    HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
	    builder.appendSuper(super.hashCode());
	    builder.append(_deviceID);

	    return builder.toHashCode();
	}

	/**
	 * Returns the ID of the device married to this destination
	 *
	 * @return the _deviceID
	 */
	public String getDeviceID() {
	    return _deviceID;
	}

	/**
	 * @param deviceID the _deviceID to set
	 */
	@XmlElement (name = "deviceID")
	public void setDeviceID(String deviceID) {
	    _deviceID = deviceID;
	}

	public int getRank() {
        return _rank;
    }
    
	@XmlElement (name = "rank")
    public void setRank(int rank) {
        _rank = rank;
    }
}
