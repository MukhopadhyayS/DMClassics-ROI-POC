/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

/*
 * TODO :  this should be rewritten as an object to the PdfHeaderFooter class
 * PdfHeaderFooter class should call get properties from this object for processing
 *
 * OR:  this class should be added to route before processing to set properties
 */
package com.mckesson.eig.output.local.transformers;


import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;


public class ROIHeaderFooter extends DefaultHeaderFooter {

    private static final int MAX_CONTENT_SIZE = 100;

	public ROIHeaderFooter() {
	    super();
	}

    public Map <String, String> getHeaderFooterProperties(OutputManager outputManager,
                                                          OutputTransform transform) {
       HashMap <String, String> properties = new HashMap <String, String>();
       Map<String, String> props = transform.getProperties();

	   // CR # 354134 - performed based upon header footer overwritten value 
       // -- TODO: Verify : - if transform property is not set, default to configured settings
       // set default headerEnabled from configuration settings
       boolean headerEnabled = ((String) outputManager.getProperty(OutputConstants.KEY_DISPLAY_HEADER))
       .equalsIgnoreCase(OutputConstants.YES);
       
       // set default footerEnabled from configuration settings
       boolean footerEnabled = ((String) outputManager.getProperty(OutputConstants.KEY_DISPLAY_FOOTER))
       .equalsIgnoreCase(OutputConstants.YES);
       
       //set transform property override value if it exists
       if (StringUtils.isNotBlank(props.get(OutputConstants.HEADER_ENABLED))) {
    	   headerEnabled = OutputConstants.TRUE.equalsIgnoreCase(props.get(OutputConstants.HEADER_ENABLED)) ||
		   OutputConstants.YES.equalsIgnoreCase(props.get(OutputConstants.HEADER_ENABLED));
       }
       if (StringUtils.isNotBlank(props.get(OutputConstants.FOOTER_ENABLED))) {
    	   footerEnabled = OutputConstants.TRUE.equalsIgnoreCase(props.get(OutputConstants.FOOTER_ENABLED)) ||
   		OutputConstants.YES.equalsIgnoreCase(props.get(OutputConstants.FOOTER_ENABLED));
       }
       
       if (headerEnabled) {
            setHeaderProperties(outputManager, transform, properties);
        }

        if (footerEnabled) {
            setFooterProperties(outputManager, transform, properties);
        }

        return properties;
    }

    public void addHeaderFooter(InputStream in, OutputStream out,
			Map<String, String> properties) {
    	new ROIHeaderFooterProcessor().addHeaderFooter(in, out, properties);
	}

    private void setHeaderProperties(OutputManager outputManager,
                                     OutputTransform transform,
                                     HashMap <String, String> properties) {
        try {

            setProperties(OutputConstants.HEADER,
                          OutputConstants.HEADER_LEFT,
                          OutputConstants.HEADER_CENTER,
                          OutputConstants.HEADER_RIGHT,
                          outputManager,
                          transform,
                          properties);
        } catch (Exception e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

    private void setFooterProperties(OutputManager outputManager,
                                     OutputTransform transform,
                                     HashMap <String, String> properties) {

        try {

            setProperties(OutputConstants.FOOTER,
                          OutputConstants.FOOTER_LEFT,
                          OutputConstants.FOOTER_CENTER,
                          OutputConstants.FOOTER_RIGHT,
                          outputManager,
                          transform,
                          properties);

        } catch (Exception e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

    private void setProperties(String headerFooterProp,
                               String leftProp,
                               String centerProp,
                               String rightProp,
                               OutputManager outputManager,
                               OutputTransform transform,
                               HashMap <String, String> properties) {

            setPageNumProperty(outputManager,
                               OutputConstants.KEY_ABSOLUTE_PAGE_NO_LOC,
                               headerFooterProp,
                               OutputConstants.KEY_DISPLAY_ABSOLUTE_PAGE_NO,
                               leftProp,
                               properties);

            setPageNumProperty(outputManager,
                               OutputConstants.KEY_REL_PAGE_NO_LOC,
                               headerFooterProp,
                               OutputConstants.KEY_DISPLAY_REL_PAGE_NO,
                               rightProp,
                               properties);

            setContentProperty(outputManager,
                               headerFooterProp,
                               centerProp,
                               transform,
                               properties);
    }

    private void setPageNumProperty(OutputManager outputManager,
                                    String managerPropLoc,
                        String headerFooterProp,
                        String managerProp,
                        String headerFooterLoc,
                        HashMap <String, String> properties) {

        if (((String) outputManager.getProperty(managerPropLoc))
                              .equalsIgnoreCase(headerFooterProp)) {

            if (((String) outputManager.getProperty(managerProp))
            .equalsIgnoreCase(OutputConstants.YES)) {
                properties.put(headerFooterLoc, "pageNum");
            }
        }
    }
    
    private void setContentProperty(OutputManager outputManager,
    								String headerFooterProp,
    								String contentLocation,
    								OutputTransform transform,
    								HashMap <String, String> properties) {

    	String content = "";
    	content += getContent(outputManager,
    				(String)outputManager.getProperty( OutputConstants.KEY_DISPLAY_PATIENT_NAME_LOC),
    				headerFooterProp,
    				(String) outputManager.getProperty(OutputConstants.KEY_DISPLAY_PATIENT_NAME),
    				transform.getProperties()
    				.get(OutputConstants.HEADER_FOOTER_PATIENT_NAME));

    	content += "     ";

    	content += getContent(outputManager,
    				(String)outputManager.getProperty(OutputConstants.KEY_ENCOUNTER_LOC),
    				headerFooterProp,
    				(String) outputManager.getProperty(OutputConstants.KEY_DISPLAY_ENCOUNTER),
    				transform.getProperties()
    				.get(OutputConstants.HEADER_FOOTER_ENCOUNTER));

    	content += "     ";    	

    	String mrnContent = getContent(outputManager,
    					(String)outputManager.getProperty( OutputConstants.KEY_MRN_LOC),
    					headerFooterProp,
    					(String) outputManager.getProperty(OutputConstants.KEY_DISPLAY_MRN),
    					transform.getProperties()
    					.get(OutputConstants.HEADER_FOOTER_MRN));
    	
    	if (StringUtils.isNotBlank(mrnContent)) {
    			
    		String mrnMasking = (String) outputManager.getProperty(OutputConstants.KEY_MRN_MASKING);
    		int mrnMask = Integer.parseInt(mrnMasking);
    		content += mask(mrnContent, mrnMask);  				
    	}
    	properties.put(contentLocation, checkContentSize(content));
    }


    //Verify expected header/footer content is not null
    private String verifyContent(String content) {

        if (content == null) {
            throw new OutputException("Output Header/Footer invalid data",
                                      OutputErrorCode.RUNTIME_ERROR);
        }

        return content;
    }

    private String getContent(OutputManager outputManager,
    							String managerPropLoc,
    							String headerFooterProp,
    							String displayManagerProp,
    							String managerProp) {
    	String content = "";

    	if (managerPropLoc.equalsIgnoreCase(headerFooterProp)) {
    		if (displayManagerProp.equalsIgnoreCase(OutputConstants.YES)) {
    			content +=
    				verifyContent(managerProp);
    		}
    	}
    	return content;
    }
    
    private String checkContentSize(String content) {

        //size limit
        String tmpString = content;
        if (tmpString.length() > MAX_CONTENT_SIZE) {
            tmpString = tmpString.substring(0, MAX_CONTENT_SIZE);
        }
        return tmpString;
    }

    private String mask(String content, int numOfCharsToMask) {
        String tmpStr = content;

        if (content.length() >= numOfCharsToMask) {
            tmpStr = content.substring(numOfCharsToMask, content.length());
            tmpStr = StringUtils.leftPad(tmpStr, content.length(), "*");
        } else {
            tmpStr = "";
            tmpStr = StringUtils.leftPad(tmpStr, numOfCharsToMask, "*");
        }
        return tmpStr;
    }
}
