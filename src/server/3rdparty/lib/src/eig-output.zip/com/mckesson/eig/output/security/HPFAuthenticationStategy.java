/*
 * Copyright 2009-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.security;

import java.util.StringTokenizer;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.apache.axis.transport.http.HTTPConstants;


import com.mckesson.eig.Security;
import com.mckesson.eig.SigninPortType;
import com.mckesson.eig.SigninServiceLocator;
import com.mckesson.eig.User;
import com.mckesson.eig.iws.security.Ticket;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.exception.ClientErrorCodes;
import com.mckesson.eig.wsfw.model.authentication.AuthenticatedResult;
import com.mckesson.eig.wsfw.security.AuthenticationStrategy;
import com.mckesson.eig.wsfw.session.WsSession;

public class HPFAuthenticationStategy
implements AuthenticationStrategy {

    private String _url;
    private static final String AUTHENTICATED_USER = "authenticated_roi_user";
    public static final String ENTERPRISE = "E_P_R_S";
    private static final String EIG_USER_SECURITY_RIGHTS = "EIG_USER_SECURITY_RIGHTS";

    public HPFAuthenticationStategy(String url) { _url = url; }
    public String getUrl() { return _url; }

    /**
     * @see com.mckesson.eig.wsfw.security.AuthenticationStrategy
     * #authenticate(java.lang.String, java.lang.String)
     */
    public AuthenticatedResult authenticate(String userName, String password) {

        try {

            SigninServiceLocator loc = new SigninServiceLocator();
            loc.setsigninEndpointAddress(getUrl());

            SigninPortType service = loc.getsignin();
            User user;

            setSessionInfo((Stub) service, WsSession.getSessionId());

            /**
             * Here userName would be like "Domain name\User name" if authentication is
             * ladap authentication.
             */
            StringTokenizer st = new StringTokenizer(userName, "\\");
            if (st.countTokens() == 2) {

                String[] userInfo = userName.split("~");

                user = service.signinWithLdap(userInfo[0], password, userInfo[1]);
            } else {
                user = service.signin(userName, password);
            }

            AuthenticatedResult result = new AuthenticatedResult();
            if (user.getValidateCode() != 0) { //check valid user

                result.setState(AuthenticatedResult.AUTHENTICATION_FAILED);
                return result;
            }

            //load Security rights in session
            for (Security sec : user.getSecurities()) {

                if (ENTERPRISE.equalsIgnoreCase(sec.getFacility())) {

                    WsSession.setSessionData(EIG_USER_SECURITY_RIGHTS, sec);
                    break;
                }
            }

            //load user object in session
            WsSession.setSessionData(AUTHENTICATED_USER, user);
            result.setState(AuthenticatedResult.AUTHENTICATED);
            result.setTicket(Ticket.getTicket(user.getLoginId()));

            return result;

        } catch (Throwable e) {
            throw new ApplicationException(e, ClientErrorCodes.SYSTEM_COULD_NOT_LOG_YOU_ON);
        }
    }

    /**
     * Helper method used to set the session info, which helps to maintain the session.
     *
     * @param stub
     * @param sessionId
     * @throws Exception
     */
     private void setSessionInfo(Stub stub, String sessionId)
     throws Exception {

            //For Axis to maintain session
            stub.setMaintainSession(true);
            stub._setProperty(HTTPConstants.HEADER_COOKIE, "JSESSIONID=" + sessionId);
            // This trackSession property is used to track session for HPF Server with respect any
            // client application.
            SOAPHeaderElement elem = new SOAPHeaderElement("urn:eig.mckesson.com", "trackSession");
            elem.addTextNode("true");

            stub.setHeader(elem);
     }

    public AuthenticatedResult login(String user, String password) {
        return authenticate(user, password);
    }

    public void authenticate(String userName) {
    }
}
