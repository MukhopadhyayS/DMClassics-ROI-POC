/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.transformers;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.SimpleBookmark;
import com.mckesson.eig.output.local.file.FileNameStrategy;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.SourceType;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.PdfSupport;
import com.mckesson.eig.output.util.PdfUtils;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;

public class PdfConcatenate implements Concatenate {
	
	private static final Log LOG = LogFactory.getLogger(PdfConcatenate.class);
	public static final String ATTACHMENTS = "ATTACHMENTS";
	protected static final String TEMP_FILE_DIR = "FILECONCAT";
	protected static final String SUPPLEMENTAL_DOC_NAME = "-Supplementary-";
	protected static final String EMPTY_PAGE_DIR = "EMPTYPAGE";
	private static final String REQUESTOR_INV_DOC_NAME = "-Invoices-";
	private static final String REQUESTOR_LETTER_DOC_NAME = "-Letters-";
	private static final String REQUESTOR_LETTER_INV_DOC_NAME = "-";
	private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("yyyyMMddhhmmSSS");

	protected static final String PDF_EXT = ".pdf";
	protected static final String PDF_FILE_EXT = "pdf";
	protected static final int MB_SIZE = 1024;
	protected static final int FILE_BUFFER_SIZE = 5;

	protected FileNameStrategy _nameStrategy;
	protected Properties _cryptoProperties;

	public List<String> concatenate(OutputJob job) {
		return concatenate(job, -1);
	}

	public List<String> concatenate(OutputJob job, long size) {
		List<String> result = new ArrayList<String>();
		List<String> supplements = processROISource(job, size);
		if (!CollectionUtilities.isEmpty(supplements)) {
			result.addAll(supplements);
		}
		List<String> hpfDocs = processHPFSource(job, size);
		if (!CollectionUtilities.isEmpty(hpfDocs)) {
			result.addAll(hpfDocs);
		}
		List<String> otherDocs = processOtherSource(job, size);
		if (!CollectionUtilities.isEmpty(otherDocs)) {
			result.addAll(otherDocs);
		}
		return result;
	}

	protected List<JobPart> getROIJobParts(OutputJob job) {
		List<JobPart> result = null;
		Iterator<JobPart> iter = job.getParts().iterator();
		while (iter.hasNext()) {
			JobPart jobPart = iter.next();
			if (jobPart.getContentSourceType().equalsIgnoreCase(SourceType.ROI.toString()) 
					&& !CollectionUtilities.isEmpty(jobPart.getSources())) {
				if (result == null) {
					result = new ArrayList<JobPart>();
				}
				result.add(jobPart);
			}
		}
		return result;
	}

	protected List<String> processROISource(OutputJob job, long maxSize) {
		List<JobPart> jobParts = getROIJobParts(job);
		if (CollectionUtilities.isEmpty(jobParts)) {
			return null;
		}
		
		boolean requestorGroupingEnabled = new Boolean(
        		job.getProperties().get(OutputConstants.REQUESTOR_GROUPING_ENABLED));
		String fileName = null;
		List<String> result = new ArrayList<String>();
        if (requestorGroupingEnabled) {
        	
        	ArrayList<String> files;
        	for (JobPart jobPart : job.getParts()) {
        		
        		files = new ArrayList<String>();
                for (String fName : jobPart.getSources()) {
                    files.add(fName);
                }
                String location = getTempDirectory(job);
                fileName = getRequestorFileName(jobPart);
        		result.addAll(addFilesToPdf(location, fileName, files, maxSize, false, false));
        	}
        	return result;
        } else {
		
		
			List<String> files = new ArrayList<String>();
			for (JobPart part : jobParts) {
				files.addAll(part.getSources());
			}
			String location = getTempDirectory(job);
			String baseFileName = _nameStrategy.createROIFileName(job);
			result = addFilesToPdf(location, baseFileName, files, maxSize, false, false);
			return result;
        }
	}

	/**
	 * code merge for ROI wheaton
	 * for each requestor the requestor filename is constructed 
	 */
	 private String getRequestorFileName(JobPart jobPart) {
	    	
    	boolean hasInvoice =  jobPart.getProperties().get("FILE_IDS")
							.contains(OutputConstants.INVOICE_TYPE);
    	
    	boolean hasRequestorLetter =  jobPart.getProperties().get("FILE_IDS")
    						.contains(OutputConstants.REQUETOR_LETTER_TYPE);

    	StringBuffer baseFileName = new StringBuffer().append(jobPart.getProperties()
    					.get(OutputConstants.OUTPUT_REQUESTOR_GROUPING_KEY));
	    	
	    String date = DATE_FORMATTER.format(Calendar.getInstance().getTime());	
    	
	    StringBuffer fileName =  (hasInvoice && hasRequestorLetter)
	    					? baseFileName.append(REQUESTOR_LETTER_INV_DOC_NAME)
	    					: (hasInvoice && !hasRequestorLetter) 
	    					? baseFileName.append(REQUESTOR_INV_DOC_NAME)
	    					: baseFileName.append(REQUESTOR_LETTER_DOC_NAME);
    	
    					
		return fileName.append(date).toString();
	}
	 
	protected List<JobPart> getHPFJobParts(OutputJob job) {
		List<JobPart> result = null;
		Iterator<JobPart> iter = job.getParts().iterator();
		while (iter.hasNext()) {
			JobPart jobPart = iter.next();
			if (jobPart.getContentSourceType().equalsIgnoreCase(
					SourceType.HPF.toString())) {
				if (result == null) {
					result = new ArrayList<JobPart>();
				}
				result.add(jobPart);
			}
		}
		return result;
	}
	
	protected Map<String, List<JobPart>> getPatientMap(List<JobPart> jobParts) {
		Map<String, List<JobPart>> result = new HashMap<String, List<JobPart>>();
		for (JobPart part : jobParts) {
			Map<String, String> partProp = part.getProperties();
			String key = partProp.get(OutputConstants.FACILITY) + "|"
					+ partProp.get(OutputConstants.MRN);
			List<JobPart> list = result.get(key);
			if (list == null) {
				list = new ArrayList<JobPart>();
				result.put(key, list);
			}
			list.add(part);
		}
		return result;
	}

	protected List<String> processHPFSource(OutputJob job, long maxSize) {
		List<JobPart> jobParts = getHPFJobParts(job);
		if (CollectionUtilities.isEmpty(jobParts)) {
			return null;
		}
		Map<String, List<JobPart>> map = getPatientMap(jobParts);
		Iterator<List<JobPart>> i = map.values().iterator();
		List<String> result = new ArrayList<String>();
		while (i.hasNext()) {
			List<JobPart> parts = i.next();
			List<String> list = processHPFSource(job, parts, maxSize);
			result.addAll(list);
		}
		return result;
	}

	protected List<String> processHPFSource(OutputJob job, List<JobPart> jobParts, long maxSize) {
		if (CollectionUtilities.isEmpty(jobParts)) {
			return null;
		}
		List<String> files = new ArrayList<String>();
		boolean docSeperator = job.haveDocumentSeperator();
		for (JobPart part : jobParts) {
			files.addAll(part.getSources());
			if (docSeperator) {
				addEmptyPage(files, job, EMPTY_PAGE_DIR);
			}
		}
		
		String location = getTempDirectory(job);
		String baseFileName = _nameStrategy.createHPFPartFileName(job, jobParts.get(0));
		List<String> result = addFilesToPdf(location, baseFileName, files, maxSize, true, false);
		return result;
	}


	protected void addEmptyPage(List<String> files, OutputJob job, String fileName) {
		String tempFile = getTempDirectory(job, EMPTY_PAGE_DIR) + fileName + ".pdf";
		File f = new File(tempFile);
		if(! f.exists()) {
	        PdfPageSeparator pgSeparator = new PdfPageSeparator();
	        pgSeparator.addPageSeparator(f.getAbsolutePath(), "");
		}
		files.add(tempFile);
	}
	
	protected List<JobPart> getOtherSourceJobParts(OutputJob job) {
		List<JobPart> result = null;
		Iterator<JobPart> iter = job.getParts().iterator();
		while (iter.hasNext()) {
			JobPart jobPart = iter.next();
			if (!jobPart.getContentSourceType().equalsIgnoreCase(SourceType.ROI.toString()) 
					&& !jobPart.getContentSourceType().equalsIgnoreCase(SourceType.HPF.toString())) {
				if (result == null) {
					result = new ArrayList<JobPart>();
				}
				result.add(jobPart);
			}
		}
		return result;
	}

	protected List<String> processOtherSource(OutputJob job, long maxSize) {
		List<JobPart> jobParts = getOtherSourceJobParts(job);
		if (CollectionUtilities.isEmpty(jobParts)) {
			return null;
		}
		List<String> files = new ArrayList<String>();
		for (JobPart part : jobParts) {
			files.addAll(part.getSources());
		}
		String location = getTempDirectory(job);
		String baseFileName = _nameStrategy.createOtherSourceFileName(job);
		List<String> result = addFilesToPdf(location, baseFileName, files, maxSize, false, false);
		return result;
	}

	protected List<List<String>> divideFileBySize(List<String> src, long fileMaxSize) {
		
		if (CollectionUtilities.isEmpty(src)) {
			return null;
		}
		List<List<String>> result = new ArrayList<List<String>>();
		List<String> parts = new ArrayList<String>();
		long currDocSize = 0;
		for (String tmpFileName : src) {
			long nextDocSize = PdfSupport.getFileSize(tmpFileName);
			if (nextDocSize > fileMaxSize && fileMaxSize > 0) {
				throw new OutputException(
						"Part size is greater than permissed",
						OutputErrorCode.RUNTIME_ERROR);
			}
			if ((currDocSize + nextDocSize) >= fileMaxSize && fileMaxSize > 0) {
				result.add(parts);
				parts = new ArrayList<String>();
				currDocSize = 0;
			}
			currDocSize += nextDocSize;
			parts.add(tmpFileName);
		}
		result.add(parts);
		return result;
	}

	protected List<String> addFilesToPdf(String location, String targetFileName, 
		List<String> src, long maxSize, boolean manipulateBookmark, boolean displayTotalNumber) {
		List<List<String>> list = divideFileBySize(src, maxSize);
		if (CollectionUtilities.isEmpty(list)) {
			return null;
		}
		List<String> result = new ArrayList<String>();
		int totalNumber = list.size();
		int part = 1;
		for (List<String> files : list) {
			String fileName = displayFileName(targetFileName, part, totalNumber, displayTotalNumber);
			String destFile = location + fileName + PDF_EXT;
			manipulatePdf(files, destFile, manipulateBookmark);
			result.add(destFile);
			part ++;
		}
		return result;
	}
	

	protected List<String> addFilesToPdfAsContainer(String location, String targetFileName, 
			List<String> src, long maxSize, boolean generateHash, boolean displayTotalNumber) {
		List<List<String>> list = divideFileBySize(src, maxSize);
		if (CollectionUtilities.isEmpty(list)) {
			return null;
		}
		List<String> result = new ArrayList<String>();
		int totalNumber = list.size();
		int part = 1;
		for (List<String> files : list) {
			String fileName = displayFileName(targetFileName, part, totalNumber, displayTotalNumber);
			String destFile = location + fileName + PDF_EXT;
			createPdfCollection(files, destFile, generateHash);
			result.add(destFile);
			part ++;
		}
		return result;
	}
	
	protected String displayFileName(String fileName, int partNumber, int totalNumber, boolean displayTotalNumber) {
		if(displayTotalNumber) {
			return _nameStrategy.generateFileNameWithPartNumberTotalNumber(fileName, partNumber, totalNumber);
		}
		return _nameStrategy.generateFileNameWithPartNumber(fileName, partNumber, totalNumber);
	}

	protected void createPdfCollection(List<String> srcs, String dest, boolean generateHash) {
		try {
			PdfUtils.createPdf(srcs, dest, generateHash, _cryptoProperties);
		} catch (Exception e) {
			throw new OutputException(e.getMessage(),
					OutputErrorCode.RUNTIME_ERROR);
		}
	}

	protected void manipulatePdf(List<String> srcs, String dest, boolean manipulateBookmark) {
		try {
			// step 1
			Document document = new Document();
			// step 2
			PdfCopy copy = new PdfCopy(document, new FileOutputStream(dest));
			// step 3
			if (manipulateBookmark) {
				copy.setViewerPreferences(PdfWriter.PageModeUseOutlines);
			}
			document.open();
			// step 4
			PdfReader reader;
			int page_offset = 0;
			int n;
			// Create a list for the bookmarks
			ArrayList<HashMap<String, Object>> bookmarks = new ArrayList<HashMap<String, Object>>();
			List<HashMap<String, Object>> tmp;
			for (String s : srcs) {
				reader = new PdfReader(s);
				if (manipulateBookmark) {
					// merge the bookmarks
					tmp = SimpleBookmark.getBookmark(reader);
					if(tmp != null) {
						SimpleBookmark.shiftPageNumbers(tmp, page_offset, null);
						bookmarks.addAll(tmp);
					}
				}
				// add the pages
				n = reader.getNumberOfPages();
				page_offset += n;
				for (int page = 0; page < n;) {
					copy.addPage(copy.getImportedPage(reader, ++page));
				}
				copy.freeReader(reader);
			}
			if (manipulateBookmark) {
				// Add the merged bookmarks
				copy.setOutlines(groupBookmarks(bookmarks));
			}
			// step 5
			document.close();
		} catch (Exception e) {
			LOG.error("Error processing Job: " + e);
			throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
		}
	}

	@SuppressWarnings("unchecked")
	protected ArrayList groupBookmarks(ArrayList bookmarkList) {
		if (bookmarkList.size() == 1) {
			return bookmarkList;
		}
		ArrayList rtnBookmarks = new ArrayList();
		ArrayList encounterList = null;
		for (int i = 0; i < bookmarkList.size(); i++) {
			HashMap tmpMap = (HashMap) bookmarkList.get(i);
			if (i == 0) {
				
				rtnBookmarks.add(tmpMap);
				encounterList = (ArrayList) tmpMap.get("Kids");
				// CR# 365589
				// remove the document Id which is added for uniqueness
				stripeDocumentId(encounterList);
				
			} else {
				String encounter = getEncounterFromBookmark(tmpMap);
				ArrayList documentList = getDocumentListByEncounter(
						encounterList, encounter);
				if (documentList != null) {
					mergeDocumentBookmark(documentList, tmpMap);
				} else {
					ArrayList list = (ArrayList) tmpMap.get("Kids");
					encounterList.addAll(list);
				}
			}
		}
		return rtnBookmarks;
	}

	@SuppressWarnings("unchecked")
	protected String getEncounterFromBookmark(HashMap bookmark) {
		if (bookmark != null) {
			ArrayList list = (ArrayList) bookmark.get("Kids");
			HashMap map = (HashMap) list.get(0);
			return (String) map.get("Title");
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	protected ArrayList getDocumentListByEncounter(ArrayList encounterList,
			String encounter) {
		if (encounterList != null) {
			Iterator i = encounterList.iterator();
			while (i.hasNext()) {
				HashMap map = (HashMap) i.next();
				String s = (String) map.get("Title");
				// CR# 365589
				// remove the document Id which is added for uniqueness
				stripeDocumentId(encounterList);
				if (encounter.equalsIgnoreCase(s)) {
					return (ArrayList) map.get("Kids");
				}
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	protected void mergeDocumentBookmark(ArrayList docList, HashMap bookmark) {
		ArrayList list = (ArrayList) bookmark.get("Kids");
		HashMap map = (HashMap) list.get(0);
		list = (ArrayList) map.get("Kids");
		docList.addAll(list);
	}

	public FileNameStrategy getNameStrategy() {
		return _nameStrategy;
	}

	public void setNameStrategy(FileNameStrategy nameStrategy) {
		_nameStrategy = nameStrategy;
	}

	public Properties getCryptoProperties() {
		return _cryptoProperties;
	}

	public void setCyptoProperties(Properties cryptoProperties) {
		_cryptoProperties = cryptoProperties;
	}

	public void setPropertiesFile(String properties) {
		_cryptoProperties = PdfUtils.loadProperties(properties);
	}

	protected String getTempDirectory(OutputJob job) {
		return getTempDirectory(job, TEMP_FILE_DIR);
	}

	protected String getTempDirectory(OutputJob job, String path) {
		String location = job.getBaseLocation() + File.separator
				+ path + File.separator;
		File dir = new File(location);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		return location;
	}
	

	// CR# 365589
    // 	added to stripe the document Id added previously in ROIBookmark
	/**
     * This method stripes the document id from the title 
     * which is assigned while creating bookmark
     * 
     * @param tmpKidsMap
     * @return hashmap with the docId stripped title
     */
	protected ArrayList stripeDocumentId(ArrayList encounterList) {
		
		Iterator iterator = encounterList.iterator();
		if (iterator.hasNext()) {
			
			HashMap kidsMap = (HashMap) iterator.next();
			
			ArrayList docList = (ArrayList) kidsMap.get("Kids");
			Iterator docIterator = docList.iterator();
			while (docIterator.hasNext()) {
				
				HashMap map = (HashMap) docIterator.next();

				String title = (String) map.get("Title");
				int index = title.lastIndexOf(OutputConstants.DELIMITER);
				
				String strippedTitle = "";
				if (index > 0) {
					
					strippedTitle = title.substring(0, index);
					map.put("Title", strippedTitle);
				} 
			}
		}
		return encounterList;
	}

}
