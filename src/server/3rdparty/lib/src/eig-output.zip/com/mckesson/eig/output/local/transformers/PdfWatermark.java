/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;


import java.awt.Color;
import java.io.FileOutputStream;

import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfGState;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


public class PdfWatermark {

    private static final int    FONT_SIZE = 72;
    private static final double OPACITY   = 0.5;
    private BaseFont _bf;

    private static final Log    LOG       = LogFactory.getLogger(PdfWatermark.class);

    public PdfWatermark() {
        super();
        try {
            _bf = BaseFont.createFont("Helvetica", BaseFont.WINANSI, false);
        } catch (Exception e) {
            LOG.error(e.toString());
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

    public void addWatermark(String watermark,
                             String soureFileName,
                             String ouputFileName) {

        try {
            PdfReader reader = new PdfReader(soureFileName);
            PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(ouputFileName));
            int fontsize = new Integer(FONT_SIZE);
            float opacity = new Float(OPACITY);
            int pagecount = reader.getNumberOfPages();
            PdfGState gs1 = new PdfGState();
            gs1.setFillOpacity(opacity);

            String text = watermark;
            float txtwidth = _bf.getWidthPoint(text, fontsize);
            for (int i = 1; i <= pagecount; i++) {
                PdfContentByte seitex = stamper.getOverContent(i);
                seitex.setColorFill(Color.GRAY);
                Rectangle recc = reader.getCropBox(i);
                float winkel = (float) Math.atan(recc.getHeight() / recc.getWidth());
                float m1 = (float) Math.cos(winkel);
                float m2 = (float) -Math.sin(winkel);
                float m3 = (float) Math.sin(winkel);
                float m4 = (float) Math.cos(winkel);
                float xoff =
                (float) (-Math.cos(winkel) * txtwidth / 2 - Math.sin(winkel) * fontsize / 2);
                float yoff =
                (float) (Math.sin(winkel) * txtwidth / 2 - Math.cos(winkel) * fontsize / 2);
                seitex.saveState();
                seitex.setGState(gs1);
                seitex.beginText();
                seitex.setFontAndSize(_bf, fontsize);
                seitex.setTextMatrix(m1, m2, m3, m4, xoff + recc.getWidth() / 2, yoff + recc
                                                                                 .getHeight()
                                                                                 / 2);
                seitex.showText(text);
                seitex.endText();
                seitex.restoreState();
            }
            if (reader != null) {
                reader.close();
            }

            if (stamper != null) {
                stamper.close();
            }

        } catch (Exception e) {
            LOG.error(e.toString());
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }
}
