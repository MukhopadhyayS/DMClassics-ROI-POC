/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;


import java.io.ByteArrayOutputStream;
import java.io.File;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


/*
 * Creates PDF page
 */

public class PdfPageSeparator {

    private static final Log LOG = LogFactory.getLogger(PdfPageSeparator.class);

    public PdfPageSeparator() {

        super();
    }

    /**
     * TODO
     *
     * @param transformDef
     */

    public void addPageSeparator(String destinationFile, String pageSeparator) {
    	byte[] content = createPageSeperator(pageSeparator);
    	File file = new File(destinationFile);
    	IOUtilities.write(file, content);
    }

    public byte[] createPageSeperator(String pageSeparator) {
        Document document = new Document(PageSize.LETTER);
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		PdfWriter writer = null;
		try {
            writer = PdfWriter.getInstance(document, output);
            writer.setViewerPreferences(PdfWriter.PageModeUseOutlines);
	        document.open();
	        PdfPTable table = new PdfPTable(1);
	        table.setTotalWidth(writer.getPageSize().getWidth());
	        table.setLockedWidth(true);
	        table.getDefaultCell().setPadding(0);
	        table.getDefaultCell().setBorderWidth(0);
	        table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	        table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
	        table.addCell(pageSeparator);
	        table.writeSelectedRows(0, -1, 0, writer.getPageSize().getHeight() / 2, writer
	        .getDirectContent());

	        document.close();

	    } catch (Exception e) {
	        LOG.error("error processing page separator : " + pageSeparator, e);
	        throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
	    }
        return output.toByteArray();
	 }
}
