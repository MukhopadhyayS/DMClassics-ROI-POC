/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.lang.ObjectUtils;
import org.springframework.util.ClassUtils;

import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.util.OutputConstants.PropertyType;
import com.mckesson.eig.output.util.OutputProperty.PropertyFlag;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.util.BeanUtilities;

/**
 * General support and utility methods for dealing with the properties objects
 * used extensively in the output service
 *
 * @author Jon Anderson
 */
public final class PropertySupport {

	private static final ConvertUtilsBean CONVERTER = new ConvertUtilsBean();
	/** TODO */
	public static final PropertyDef[] EMPTY_PROPERTY_DEFS = new PropertyDef[0];

	private PropertySupport() {
		super();
	}

	/**
	 * Tests if to propertyFlags array contain the same contents though
	 * possibly not in the same order
	 *
	 * @param propertyFlags1 maybe <code>null</code>
	 * @param propertyFlags2 maybe <code>null</code>
	 * @return true if same contents
	 */
    public static boolean propertyFlagsEqual(
	        PropertyFlag[] propertyFlags1,
	        PropertyFlag[] propertyFlags2) {

        if (propertyFlags1 == null) {
            if (propertyFlags2 != null) {
                return false;
            }
            return true;
        } else if (propertyFlags2 == null) {
            return false;
        } else if (propertyFlags1.length != propertyFlags2.length) {
            return false;
        }

        for (int i = 0; i < propertyFlags1.length; ++i) {

            boolean found = false;
            for (int ii = 0; ii < propertyFlags2.length; ++ii) {
                if (propertyFlags2[ii] == propertyFlags1[i]) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }

        return true;
	}

	/**
	 * Look up a propertyDef object in an array of propertyDefs  by
	 * propertyName
	 *
	 * @param propertyDefs may be <code>null</code>
	 * @param propertyName may be <code>null</code>
	 * @return <code>null</code> if not found
	 */
	public static PropertyDef findPropertyDef(
			PropertyDef[] propertyDefs,
			final String propertyName) {

		if (propertyDefs != null) {

			for (PropertyDef def : propertyDefs) {
				if (def != null) {
					if (ObjectUtils.equals(
							def.getPropertyName(),
							propertyName)) {
						return def;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Converts the value  to a string
	 *
	 * @param value value to convert. may be <code>null</code>
	 * @return won't be <code>null</code>
	 */
	public static String valueToString(Object value) {
		return CONVERTER.convert(value);
	}

	/**
	 * Compares two values for equality using the propertyDef argument for
	 * conversion purposes. For example if value1 = 1 and value2 = "1" the
	 * method would return true.
	 *
	 * @param propertyDef not <code>null</code>
	 * @param value1 may be <code>null</code>
	 * @param value2 may be <code>null</code>
	 * @return comparison
	 */
	public static boolean propertyValueEquals(
			PropertyDef propertyDef,
			Object value1,
			Object value2) {

		if (propertyDef == null) {
			throw new IllegalArgumentException("propertyDef argument is null");
		}

		return ObjectUtils.equals(
				propertyToValue(propertyDef, value1),
				propertyToValue(propertyDef, value2));
	}

	/**
	 * Converts a propertyValue using the bean and propertyName to figure out
	 * the correct type
	 *
	 * @param bean not <code>null</code>
	 * @param propertyName not <code>null</code>
	 * @param value value to convert
	 * @return not <code>null</code>
	 */
	public static Object propertyToValue(
	        Object bean,
	        String propertyName,
	        Object value) {

	    if (bean == null) {
	        throw new IllegalArgumentException("bean argument is null");
	    }
	    if (propertyName == null) {
	        throw new IllegalArgumentException("propertyName is null");
	    }

	    PropertyDescriptor descriptor =
	        BeanUtilities.getPropertyDescriptor(bean, propertyName);
	    return CONVERTER.convert(value, descriptor.getPropertyType());
	}
	/**
	 * converts <code>value</code> to  the type defined in
	 * <code>propertyDef.getDataType()</code> if it is not already that type
	 *
	 * @param propertyDef
	 * @param value
	 * @return converted <code>value</code> or <code>null</code> if
	 * <code>value</code> is <code>null</code>
	 */
	public static Object propertyToValue(
			PropertyDef propertyDef,
			Object value) {

		if (propertyDef == null) {
			throw new IllegalArgumentException("propertyDef argument is null");
		}

		if (value == null) {
			return null;
		}

		String dataType = propertyDef.getDataType();
		if (dataType == null) {
			throw new IllegalArgumentException(
					"dataType member of propertyDef is null");
		}

		Class< ? extends Object > valueClass =
			PropertyType.valueOf(dataType).typeClass();

		if (valueClass.isInstance(value)) {
			return value;
		}

		if (!(value instanceof String)) {
			throw new IllegalArgumentException(
					"do not know how to convert from " + value.getClass()
					+ " to " + valueClass);
		}

		return parsePropertyValue(propertyDef, (String) value);
	}

	/**
	 * @param propertyDef
	 * @param value
	 * @return not <code>null</code>
	 */
	public static Object parsePropertyValue(
			PropertyDef propertyDef,
			String value) {

		if (propertyDef == null) {
			throw new IllegalArgumentException("propertyDef argument is null");
		}

		String dataType = propertyDef.getDataType();
		if (dataType == null) {
			throw new IllegalArgumentException(
					"dataType member of propertyDef is null");
		}

		PropertyType propertyType = PropertyType.valueOf(dataType);
		Class< ? > targetType;

		if (propertyType == PropertyType.NUMBER) {

			targetType = guessNumericType(value);

		} else {
		    targetType = propertyType.typeClass();
		}

		return CONVERTER.convert(value, targetType);
	}

	private static  Class< ? > guessNumericType(String value) {

	    if (value == null || value.length() == 0) {
	        return Integer.class;
	    } else if (value.startsWith("0x")) {
	    	return Long.class;
	    } else if (value.endsWith("D") || value.endsWith("d")) {
	        return Double.class;
	    } else if (
	            value.endsWith("F")
	            || value.endsWith("f")
	            || value.indexOf('.') >= 0) {
	        return  Float.class;
	    }
        return Integer.class;
	}

	/**
	 * Converts a <code>Map<String, Object></code>
	 * 	to a <code>Map<String, String></code>
	 *
	 * @param properties
	 * @return not <code>null</code>
	 */
	public static Map<String, String> propertiesToStrings(
			Map<String, ? extends Object> properties) {

		if (properties == null) {
			throw new IllegalArgumentException("properties argument is null");
		}

		Map<String, String> transformed = new GetSetMap<String, String>();

		for (Entry<String, ? extends Object> entry : properties.entrySet()) {

			transformed.put(
					entry.getKey(),
					valueToString(entry.getValue()));

		}

		return transformed;
	}

	/**
	 * Creates a map where key is the propertyName member of a propertyDef and
	 * value is the defaultValue member converted to whatever type the
	 * propertyDef specifies
	 *
	 * @param propertyDefs not <code>null</code>
	 * @return not <code>null</code>
	 */
	public static Map<String, Object>  createDefaultValuesMap(
			PropertyDef[] propertyDefs) {

		Map<String, Object>  map = new HashMap<String, Object>();

		for (PropertyDef def : propertyDefs) {

			String propName = def.getPropertyName();
			map.put(propName, parsePropertyValue(def, def.getDefaultValue()));
		}

		return map;
	}

	/**
	 * Determines what PropertyType a given class translates to. Only primitives
	 * are supported right now.
	 *
	 * @param propertyClass not <code>null</code>
	 * @return not <code>null</code>
	 */
	public static PropertyType propertyTypeForClass(Class< ? >  propertyClass) {

		if (propertyClass == null) {
			throw new IllegalArgumentException(
					"propertyClass argument is null");
		}

		Class< ? > assignableClass = toAssignableClass(propertyClass);

		for (PropertyType propertyType : PropertyType.values()) {

			if (ClassUtils.isAssignable(
					propertyType.typeClass(),
					assignableClass)) {
				return propertyType;
			}
		}
		throw new ApplicationException("unknown property type: "
				+ propertyClass);
	}

	/**
	 * if <code>c</code> is a Type return the corresponding class
	 *
	 * @param c ignored if <code>null</code>
	 * @return <code>null</code> only  if c is <code>null</code>
	 */
	public static Class< ? > toAssignableClass(Class< ? > c) {

		// I can't believe I am writing this. There has got to be a method
		// somewhere that does this. I am just tired of looking for it.

		if (c == Boolean.TYPE) {
			return Boolean.class;
		} else if (c == Character.TYPE) {
			return Character.class;
		} else if (c == Integer.TYPE) {
			return Integer.class;
		} else if (c == Short.TYPE) {
			return Short.class;
		} else if (c == Long.TYPE) {
			return Long.class;
		} else if (c == Float.TYPE) {
			return Float.class;
		} else if (c == Double.TYPE) {
			return Double.class;
		}
		return c;
	}

	/**
	 * Reflectively looks for OutputProperty annotations on a given class and
	 * converts them into PropertyDef objects.
	 *
	 * @param annotatedClass not <code>null</code>
	 * @return not <code>null</code>
	 */
	public static PropertyDef[] extractAnnotatedProperties(
			Class< ? > annotatedClass) {

		if (annotatedClass == null) {
			throw new IllegalArgumentException(
					"annotatedClass argument is null");
		}

		List<PropertyDef> propertyDefs = new ArrayList<PropertyDef>();
		BeanInfo info;
		try {
			info = Introspector.getBeanInfo(annotatedClass);
		} catch (IntrospectionException e) {
			throw new ApplicationException(e);
		}

		PropertyDescriptor[] propDescriptors = info.getPropertyDescriptors();

		if (propDescriptors != null) {

			for (PropertyDescriptor descriptor : propDescriptors) {

				Method method = descriptor.getReadMethod();
				OutputProperty outputProperty = null;

				if (method != null) {
					outputProperty = method.getAnnotation(OutputProperty.class);
				}
				if (outputProperty == null) {

					method = descriptor.getWriteMethod();
					if (method != null) {
						outputProperty =
							method.getAnnotation(OutputProperty.class);
					}
				}

				if (outputProperty != null) {
					PropertyDef propertyDef = new PropertyDef();
					propertyDef.setPropertyName(descriptor.getDisplayName());
					propertyDef.setLabel(outputProperty.label());
					propertyDef.setDescription(outputProperty.description());
					propertyDef.setDefaultValue(outputProperty.defaultValue());
                    propertyDef.setPossibleValues(outputProperty.possibleValues());
                    propertyDef.setRequired(outputProperty.required());
                    propertyDef.setIndex(outputProperty.index());
                    propertyDef.setRowCount(outputProperty.rowCount());
                    propertyDef.setPairPropertyName(outputProperty.pairPropertyName());
                    propertyDef.setBindingProperty(outputProperty.bindingProperty());
					propertyDef.setPropertyFlags(outputProperty.flags());
					propertyDef.setContextMenu(outputProperty.contextMenu());
					propertyDef.setDataType(propertyTypeForClass(
							descriptor.getPropertyType()).name());
					propertyDef.setJsAction(outputProperty.jsAction());
					propertyDef.setSize(outputProperty.size());
					propertyDef.setMaxLength(outputProperty.maxLength());
					propertyDefs.add(propertyDef);
				}
			}
		}

		PropertyDef[] defsArray = new PropertyDef[propertyDefs.size()];
		return propertyDefs.toArray(defsArray);
	}

	/**
	 * Tests if a specific flag is set in the array <code>flags</code>
	 *
	 * @param flags could be <code>null</code>
	 * @param flag flag to look for
	 * @return true if found
	 */
	public static boolean isPropertyFlagSet(
	        PropertyFlag [] flags,
	        PropertyFlag flag) {

	    if (flags == null) {
	        return false;
	    }

	    for (PropertyFlag f : flags) {
	        if (f == flag) {
	            return true;
	        }
	    }

	    return false;
	}

	/**
	 * Collects all the PropertyDefs that have the JOB_DEFAULT flag set
	 *
	 * @param propertyDefs not <code>null</code>
	 * @return not <code>null</code>
	 */
	public static PropertyDef[] collectJobDefaultPropertyDefs(
	        PropertyDef[] propertyDefs) {

	    if (propertyDefs == null) {
	        throw new IllegalArgumentException("propertyDefs argument is null");
	    }

	    List<PropertyDef> foundDefs = new ArrayList<PropertyDef>();

	    for (PropertyDef propertyDef : propertyDefs) {

	        if (isPropertyFlagSet(
	                propertyDef.getPropertyFlags(),
	                PropertyFlag.JOB_DEFAULT)) {
	            foundDefs.add(propertyDef);
	        }
	    }

	    return foundDefs.toArray(new PropertyDef[foundDefs.size()]);
	}
}
