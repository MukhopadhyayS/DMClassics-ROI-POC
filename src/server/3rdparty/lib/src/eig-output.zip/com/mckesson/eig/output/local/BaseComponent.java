/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import org.apache.commons.beanutils.BeanUtils;

import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputPropertyMap;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.util.BooleanUtilities;

/**
 * BaseComponent is a convenience class which is useful creating objects
 * which must implement the OutputComponent interface.
 * The classes no-arg constructor will reflectively look for OutputProperty
 * annotations which are used to infer the class's PropertyDef array.
 * If the annotations are found, it will construct an OutputPropertyMap using
 * that array and wire a change listener to it that will propagate property
 * changes to the annotated setter methods, thus allowing properties to
 * be maintained in the map and in the object as a bean.
 *
 * @author Jon Anderson
 * @see OutputPropertyMap
 * @see com.mckesson.eig.output.util.OutputProperty
 */
public class BaseComponent implements PropertyChangeListener, OutputComponent {

	private OutputPropertyMap _properties;
	private boolean _enabled = true;

	/**
	 * Constructor which looks at the class reflectively to find OutputProperty
	 * annotations, construct PropertyDefs and set default values. If no
	 * annotations are present on the class, this constructor doesn't do
	 * much
	 */
	public BaseComponent() {

		_properties = new OutputPropertyMap();

		PropertyDef[] propertyDefs =
			PropertySupport.extractAnnotatedProperties(getClass());

		if (propertyDefs.length > 0) {
	        _properties.addPropertyChangeListener(this);
    		_properties.setPropertyDefs(propertyDefs);
		}
	}

	public BaseComponent(boolean enabled) {
		super();
		_enabled = enabled;
	}

	public boolean isEnabled() {
		return _enabled;
	}

	protected void setEnabled(boolean enable) {
		_enabled = enable;
	}

	protected void setEnabled(String enable) {
		boolean b = BooleanUtilities.valueOf(enable, true);
		_enabled = b;
	}

	/**
	 * @see com.mckesson.eig.output.local.OutputComponent#getPropertyDefs()
	 */
	public PropertyDef[] getPropertyDefs() {
		return _properties.getPropertyDefs();
	}

	/**
	 * Change listener method which forwards events to
	 * @see java.beans.PropertyChangeListener#propertyChange(java.beans.PropertyChangeEvent)
	 */
	public void propertyChange(PropertyChangeEvent evt) {

		if (evt == null) {
			throw new IllegalArgumentException("evt argument is null");
		}

		String propertyName = evt.getPropertyName();

		PropertyDef propertyDef = PropertySupport.findPropertyDef(
		        _properties.getPropertyDefs(),
		        propertyName);

		if (propertyDef == null) {
		    return;
		}

		Object newValue = PropertySupport.propertyToValue(
		        this,
		        propertyName,
		        evt.getNewValue());
		try {
			BeanUtils.setProperty(this, propertyName, newValue);
		} catch (Exception e) {
			throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
		}
	}

	/**
	 * @see OutputComponent#getProperties()
	 */
	public OutputPropertyMap getProperties() {
		return _properties;
	}


	/**
	 * @see OutputComponent#getProperty(String)
	 */
	public Object getProperty(String propertyName) {
		return _properties.get(propertyName);
	}

	/**
	 * @see OutputComponent#setProperty(String, Object)
	 */
	public void setProperty(String propertyName, Object value) {
		_properties.put(propertyName, value);
	}
}
