/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.LocationSupport;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.OutputTransforms;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


/* This OutputTransformer is called when there is a PdfPageSeparator TransformDef
 *
 */

public class PdfPageSeparatorJob
extends PdfJobTransforms {

    private static final Log LOG = LogFactory.getLogger(PdfPageSeparatorJob.class);

    public PdfPageSeparatorJob() {

        super();
    }

    //processes Job page separator Transformation -- applied to all Parts
    @Override
    public void processJob(OutputJob job) {

        if (job == null) {
            throw new IllegalArgumentException("job argument is null");
        }

        try {
            processPageSeparatorTransform(job);
            //TODO : is an update job status required?
            //updateJobStatus(job, StatusUtils.createRequestStatus(RequestStatus.PROCESSING, null));
        } catch (Exception e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }

        LOG.info("Page separator transform completed for Job: " + job.getJobSeq());
    }

    private void processPageSeparatorTransform(OutputJob job) throws Exception {

        try {
            PdfPageSeparator pdfPageSeparator = new PdfPageSeparator();

            StringBuilder pageSeparator = new StringBuilder();
            if (job.getSubmitInfo() == null) {
                throw new IllegalArgumentException("job submitter info argument is null");
            }
            if (StringUtils.isNotEmpty(job.getSubmitInfo().getSubmitterData())) {
                pageSeparator.append(job.getSubmitInfo().getSubmitterData());
            }

            //TODO - Modify to Support Local format
            SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy  HH:mm:ss");

            pageSeparator.append("      " + job.getDestName());
            pageSeparator.append("      " + dateFormatter.format(Calendar.getInstance().getTime()));

            //Insert a Part at the first Index for the Page Separator Transform.
            //Not storing this part in DB -- this is a transform.
            //Parts stored in DB are endpoint category.SOURCE
            JobPart jobPart = new JobPart();
            jobPart.setProperties(new HashMap <String, String>());
            jobPart.addSource(OutputTransforms.PAGE_SEPARATOR.toString() + ".pdf");
            jobPart.setNoOfPages(1);
            jobPart.setContentSourceName(OutputTransforms.PAGE_SEPARATOR.toString());
            jobPart.setContentID(OutputTransforms.PAGE_SEPARATOR.toString());
            jobPart.setCurrentLocation(job.getBaseLocation());
            //Set destination directory and clear if existing
            LocationSupport.setNextLocation(jobPart, OutputTransforms.PAGE_SEPARATOR.toString());
            LocationSupport.cleanNextLocation(jobPart);
            String destFile =
            jobPart.getNextLocation() + "//" + OutputTransforms.PAGE_SEPARATOR.toString() + ".pdf";
            pdfPageSeparator.addPageSeparator(destFile, pageSeparator.toString());
            LocationSupport.setNextLocationAsCurrentLocation(jobPart);
            //Add a new document: Add document to file list
            List <JobPart> jobPartList = job.getParts();
            jobPartList.add(0, jobPart);

        } catch (Exception e) {

            String message = "error processing page separator for job: " + job.getJobSeq();
			LOG.error(message, e);
            throw new ApplicationException(message, e.getMessage());
        }
    }
}
