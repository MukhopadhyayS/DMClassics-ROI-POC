/**
 * Copyright � 2010 McKesson Corporation and/or one of its subsidiaries.
 * All rights reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.printer;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;

import javax.print.PrintService;
import javax.print.PrintServiceLookup;

/**
 * This class is meant to abstract away the access to the <code>sun.awt.AppContext</code> since
 * that class is a sun print class.  The reflection usage is there to remove all of the warnings
 * during compilation.
 *
 * @author Michael Macaluso
 */
public class PrintUtilities {

	private static final Method AppContextGetAppContextMethod;

	private static final Method AppContextRemoveMethod;

	static {
		Class<?> clazz = null;
		Method methodGetAppContext = null;
		Method methodRemove = null;
		try {
			clazz = Class.forName("sun.awt.AppContext");
			methodGetAppContext = clazz.getDeclaredMethod("getAppContext");
			methodRemove = clazz.getDeclaredMethod("remove", Object.class);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		AppContextGetAppContextMethod = methodGetAppContext;
		AppContextRemoveMethod = methodRemove;
	}

    public static String[] getAvailablePrinters() {
		clearSystemPrinterList();

		Collection<String> availablePrinters = new ArrayList <String>();
		PrintService[] printServices = PrintServiceLookup.lookupPrintServices(null, null);
		if (printServices.length > 0) {
			for (PrintService printService : printServices) {
				availablePrinters.add(printService.getName());
			}
		}
		String[] printers = availablePrinters.toArray(new String[availablePrinters.size()]);
		return printers;
	}

    public static void clearSystemPrinterList() {
		try {
			Object appContext = AppContextGetAppContextMethod.invoke(null);
			Class<?>[] classes = PrintServiceLookup.class.getDeclaredClasses();
			for (Class<?> clazz : classes) {
				if ("javax.print.PrintServiceLookup$Services".equals(clazz.getName())) {
					AppContextRemoveMethod.invoke(appContext, clazz);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
