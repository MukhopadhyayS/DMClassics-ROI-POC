/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;

import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.util.LocationSupport;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.PdfSupport;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.OutputTransforms;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;



public class PdfHeaderFooterPart extends PdfPartTransforms  {
    private static final Log LOG  = LogFactory.getLogger(PdfHeaderFooterPart.class);
	private static final int FIVE_HUNDRED = 500;
	private static final int TEWNTY = 20;

	public PdfHeaderFooterPart() {

        super();
    }


    public void transform(Map<String, String> properties,
                          String sourceFile,
                          String destinationFile) {

        PdfHeaderFooter pdfHeaderFooter =  new PdfHeaderFooter();
        pdfHeaderFooter.addHeaderFooter(properties, sourceFile, destinationFile);
    }

    //processes Part header footer Transformation
    @Override
    public void processJobParts(OutputJob job, Collection <JobPart> jobParts) {

        int counter = 0;

        if (jobParts.size() > FIVE_HUNDRED) {
            counter = jobParts.size() / TEWNTY;
        }

        OutputJobDAO outputJobDAO = getOutputJobDAO();
        int index   = 0;

        try {
            for (JobPart part : jobParts) {
                index++;

                if ((counter != 0) && (index == counter)) {

                    if (checkJobStatus(outputJobDAO, job.getJobSeq())) {
                        break;
                    }
                    index = 0;
                }
                processPart(job, part);
            }
        } catch (Exception e) {
            throw new OutputException("Error: " + e.toString()
                                      + "  processing "
                                      + job.getJobSeq(),
                                      OutputErrorCode.RUNTIME_ERROR);
        }
    }

    public void processPart(OutputJob job, JobPart part) {
        if (part == null) {
            throw new IllegalArgumentException("part argument is null");
        }

        OutputTransform transform =
        OutputUtil.lookupPartTransform(part, OutputTransforms.HEADER_FOOTER.toString());
        Map<String, String> properties = getHeaderFooterProperties(job, part);
        setJobPageNumProperties(properties,
                                job,
                                part);

        properties.put(OutputConstants.PART_TOTAL_PAGES,
                       Integer.toString(part.getPages()));

        int absolutePageCnt = 0;
        Iterator <String> filesIterator = part.getSourcesIterator();
        //Set destination directory and clear existing only if work to be done
        if (part.getSources().size()  > 0) {
            LocationSupport.setNextLocation(part, OutputTransforms.HEADER_FOOTER.toString());
            LocationSupport.cleanNextLocation(part);               	 
        }
        while (filesIterator.hasNext()) {
            String fileName = filesIterator.next();
            String srcFileName = part.getCurrentLocation() + File.separatorChar + fileName;
            String destFileName = part.getNextLocation() + File.separatorChar + fileName;

            int currFilePageCnt = PdfSupport.getPageCount(srcFileName);
            properties.put(OutputConstants.PART_CURRENT_PAGE_NUM,
                           Integer.toString(absolutePageCnt));

            transform(properties,
                      srcFileName,
                      destFileName);

            absolutePageCnt += currFilePageCnt;
        }
        //Set current directory only if work to be done
        if (part.getSources().size()  > 0) {
       	 LocationSupport.setNextLocationAsCurrentLocation(part);       	 
        }

        LOG.info("Header/Footer transform completed for part: " + part.getPartID());
    }

    public Map< String, String > getHeaderFooterProperties(OutputJob job, JobPart part) {
        //NOOP -- header/footer will not be added to document
        return new HashMap< String, String >();
    }

    protected void setJobPageNumProperties(Map<String, String> properties,
                                         OutputJob job,
                                         JobPart part) {

           properties.put(OutputConstants.JOB_TOTAL_PAGES,
                          Integer.toString(job.getPages()));
           //supports relative page count
           properties.put(OutputConstants.JOB_CURRENT_PAGE_NUM,
                          Integer.toString(PdfSupport.getPartStartPage(job, part)));


       }

    public PdfHeaderFooter getHeaderFooterClass() {
    	return new PdfHeaderFooter();
    }

}
