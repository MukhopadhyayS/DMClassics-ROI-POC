/**
 * 
 */
package com.mckesson.eig.output.local.dao;

import java.util.List;
import java.util.Set;

import com.mckesson.eig.output.model.OutputSearchLoV;

/**
 *  
 * @author OFS
 * @since  Output 3.0; Nov 19, 2009
 *
 */
public interface OutputSearchLoVDAO {

	/**
	 * Persists the set of OutputSearchLoVs in database.
	 * @param lovs
	 * 		  The set of lovs to be persisted
	 */
	void createOutputSearchLoVs(Set <OutputSearchLoV>  lovs);

	/**
	 * Delete the given OutputSearchLoV from database.
	 * @param jobId
	 *        The unique job id whose LoVs need to be deleted
	 */
	void deleteOutputSearchLoVs(int jobId); 
	
	/**
     * This method is used to fetch the output search LoVs based on the jobId.
     * @param jobId
     * @return List<OutputSearchLoV>
     */
    List<OutputSearchLoV> readOutputSearchLoVs(int jobId); 

}
