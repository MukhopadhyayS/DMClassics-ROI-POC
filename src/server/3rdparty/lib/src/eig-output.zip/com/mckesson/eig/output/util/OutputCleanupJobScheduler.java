package com.mckesson.eig.output.util;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Date;

import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.Scheduler;
import org.quartz.StatefulJob;
import org.quartz.Trigger;
import org.quartz.TriggerUtils;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


public class OutputCleanupJobScheduler extends QuartzJobBean implements StatefulJob {


     /**
     * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
     */
     private static final Log LOG = LogFactory.getLogger(OutputCleanupJobScheduler.class);

     public static final String QUARTZ_SCHEDULE_NAME = "TempFileCleanup";
     public static final String QUARTZ_INTVERAL_MINS = "purgeIntervalMins";

     public static final String EXPIRES_PROP_NAME_PROP = "ExpireTimeServiceProp";

     public static final long DEFAULT_EXPIRE_MINS = 420;
     public static final long DEFAULT_EXPIRE_HRS = 8;

     public static final long MILLIS_IN_MIN = 60000;

     public static final long MIN_IN_HRS = 60;

     private JobExecutionContext _jeContext = null;

    @Override
    public void executeInternal(JobExecutionContext context) {

        if (context == null) {
            throw new IllegalArgumentException("context argument is null");
        }

        _jeContext = context;
        JobDataMap map = context.getMergedJobDataMap();

        OutputManager outputManager =
            (OutputManager) map.get(OutputConstants.OUTPUT_MANAGER_BEAN_NAME_PROP);


        // Define PropertyChangeListener
        PropertyChangeListener propertyChangeListener = new PropertyChangeListener() {
          public void propertyChange(PropertyChangeEvent propertyChangeEvent) {
            String property = propertyChangeEvent.getPropertyName();
            if (OutputConstants.KEY_SAVE_COMPLETED_JOBS_IN_HRS.toString().equals(property)) {
                String newExpireTime = (String) propertyChangeEvent.getNewValue();
                if (newExpireTime == null) {
                    newExpireTime = Long.toString(DEFAULT_EXPIRE_HRS);
                }
                //cleanup immediately - reschedule next cycle time

                OutputCleanupJob outputCleanup = new OutputCleanupJob();
                outputCleanup.executeInternal(_jeContext);
                rescheduleOutputJobCleanup(_jeContext);
            }
          }
        };


        outputManager.addPropertyChangeListener(OutputConstants.KEY_SAVE_COMPLETED_JOBS_IN_HRS,
                                                propertyChangeListener);


        scheduleOutputJobCleanup(context);
    }

    public void scheduleOutputJobCleanup(JobExecutionContext context) {
        try {

        JobDataMap map = context.getMergedJobDataMap();

        String triggerMinInterval = (String) map.get(QUARTZ_INTVERAL_MINS);
        Integer triggerInterval = Integer.valueOf(triggerMinInterval);
        Scheduler scheduler = context.getScheduler();

        JobDetail jobDetail = new JobDetail(QUARTZ_SCHEDULE_NAME,
                                            Scheduler.DEFAULT_GROUP,
                                            com.mckesson.eig.output.util.OutputCleanupJob.class);
        jobDetail.setJobDataMap(map);
        Trigger trigger = TriggerUtils.makeMinutelyTrigger(triggerInterval);
        trigger.setStartTime(new Date());
        //Unique name
        trigger.setName(QUARTZ_SCHEDULE_NAME);
        trigger.setJobGroup(Scheduler.DEFAULT_GROUP);
        trigger.setJobName(QUARTZ_SCHEDULE_NAME);
        scheduler.scheduleJob(jobDetail, trigger);
        } catch (Exception e) {
            LOG.error("error scheduling next temporary file cleanup", e);
        }
    }

    public void rescheduleOutputJobCleanup(JobExecutionContext context) {

        try {
        JobDataMap map = context.getMergedJobDataMap();
        String triggerMinInterval = (String) map.get(QUARTZ_INTVERAL_MINS);
        Integer triggerInterval = Integer.valueOf(triggerMinInterval);
        Scheduler scheduler = context.getScheduler();

        Trigger trigger = TriggerUtils.makeMinutelyTrigger(triggerInterval);
        trigger.setStartTime(new Date());
        //Trigger name
        trigger.setName(QUARTZ_SCHEDULE_NAME);
        trigger.setJobGroup(Scheduler.DEFAULT_GROUP);
        trigger.setJobName(QUARTZ_SCHEDULE_NAME);
        scheduler.rescheduleJob(QUARTZ_SCHEDULE_NAME, Scheduler.DEFAULT_GROUP, trigger);
        } catch (Exception e) {
            LOG.error("error scheduling next temporary file cleanup", e);
        }
   }
}
