/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.roi;

import java.util.Map;

import com.mckesson.eig.output.model.RequestPart;


/**
 * @author OFS
 * @date   Feb 3, 2009
 * @since  HPF 13.1; Feb 3, 2009
 */
public class ROIRequest {

	public static final String USER_NAME = "USERNAME";
	public static final String PASSWORD = "PASSWORD";
	public static final String FILE_IDS = "FILE_IDS";
	public static final String FILE_NAME = "FILE_NAME";
	public static final String CONTENT_TYPE = "CONTENT_TYPE";
	public static final String FILE_EXTS = "FILE_EXTS";

	public ROIRequest() {
	}

	public ROIContent getContent(RequestPart part) {
		return getROIContent(part);
	}

	private ROIContent getROIContent(RequestPart part) {
		Map<String, String> map = part.getProperties();
		ROIContent content = new ROIContent();
		if (map != null) {
			String fileIds = map.get(FILE_IDS);
			String userName = map.get(USER_NAME);
			String pwd = map.get(PASSWORD);
			String contentType = map.get(CONTENT_TYPE);
			content = createContent(fileIds, userName, pwd, contentType);
		}
		return content;
	}

	private ROIContent createContent(String fileIds, String userName, 
			                            String password, String contentType) {
		ROIContent result = new ROIContent();
		result.setFileIds(fileIds);
		result.setUserName(userName);
		result.setPassword(password);
		result.setContentType(contentType);
		return result;
	}
}
