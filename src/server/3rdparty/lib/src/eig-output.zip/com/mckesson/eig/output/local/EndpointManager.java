/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.local.model.ActiveEndpointType;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.EndpointDefList;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.model.EndpointTypeDefList;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputRequest;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.status.StatusChangeListener;

/**
 * The EndpointManager is responsible for doing the work of creating,
 * maintaining and destroying OutputEndpoints. As such, the OutputManager
 * instance delegates all of it's endpoint related processing to a single
 * EndpointManager instance which it will maintain along with it's own life
 * cycle.
 *
 * EndpointManagers deal with two basic concepts: Endpoints and EndpointTypes
 * Endpoints are the actual processors within the OutputService that do the
 * work of retrieving content, transforming content and delivering content
 * to some real destination. EndpointTypes represent a class of Endpoint, for
 * example, an Endpoint may defined for the system which delivers it's output
 * to a specific Cannon Printer. The EndpointType for that Endpoint would be
 * Printer and would be responsible for creating Endpoints which can speak to
 * specific Printer devices. Additionally, Endpoints and EndpointTypes have a
 * EndpointCategory which defines which mode of processing the endpoints
 * perform. Currently there are four EndpointCategories defined:
 * <p>
 * <li>SOURCE - responsible for retrieving content
 * <li>PART_TRANSFORM - responsible for transforming content at the part level
 * <li>JOB_TRANSFORM - responsible for transforming content at the job level
 * <li>DESTINATION - responsible for delivering content to a real destination
 *
 * @author Jon Anderson
 */
public interface EndpointManager {

	/**
	 * Return a EndpointDefList for all the active endpoints
	 *
	 * @return not <code>null</code>
	 */
	EndpointDefList readEndpointDefs(EndpointTypeDef typeDef);

	/**
	 * Update the meta data describing an endpoint
	 *
	 * @param endpointDef not <code>null</code> and
	 * <code>endpointDef.getName()</code> must return a previously defined
	 * endpointName
	 * @return not <code>null</code> updated metadata
	 */
	ActiveEndpoint updateEndpointDef(EndpointDef endpointDef);

	/**
	 * Adds an EndpointDef to the system and prepares it to start processing
	 * jobs.
	 *
	 * @param endpointDef definition of the endpoint. not <code>null</code>
	 * and not other endpoint can be defined with the same name.
	 *
	 * @return not <code>null</code>
	 */
	ActiveEndpoint createActiveEndpoint(EndpointDef endpointDef)
	throws Exception;


	/**
	 * Removes an EndpointDef from the system and performs any necessary cleanup
	 *
	 * @param endpointName not <code>null</code> and must exist in the system
	 * @param force
	 */
	void deleteActiveEndpoint(int endpointId);

	/**
	 * Returns the collection of all ActiveEndpoint's currently defined in the
	 * system
	 *
	 * @return not <code>null</code>
	 */
	Collection<ActiveEndpoint> getActiveEndpoints();

	/**
     * Returns the collection of all ActiveEndpoint's for typeName currently defined in the
     * system
     *
     * @return not <code>null</code>
     */

	Collection<ActiveEndpoint> getActiveEndpoints(String typeName);

	/**
	 * Returns the ActiveEndpoint identified by <code>endpointName</code>
	 *
	 * @param endpointName not <code>null</code>, if not a valid endpoint name
	 * an exception will be thrown
	 * @return not <code>null</code>
	 */
	ActiveEndpoint getActiveEndpoint(int endpointId);

    ActiveEndpoint getActiveEndpoint(String typeName, String endpointName);

    /**
     * Explicitly pause an Endpoint. This call is different from simply
     * updating an endpoint's status to a paused state via the
     * updateEndpointStatus call in that the endpoint's status will only be
     * restored once a call to restartActiveEndpoint has been called.
     *
     * @param endpoint valid endpoint name
     * @return not <code>null</code>
     */
    ActiveEndpoint pauseActiveEndpoint(int endpointId);

    /**
     * Explicitly restart an endpoint. see pauseActiveEndpoint for details
     *
     * @param endpoint valid endpoint name
     * @return not <code>null</code>
     */
    ActiveEndpoint restartActiveEndpoint(int endpointId);

	/**
	 * Update the status of an endpoint, this method may be called by endpoints
	 * themselves to notify the system of status changes or by the OutputManager,
	 * to pause or restart an endpoint, if the OutputManager is pausing or
	 * restarting.
	 *
	 * @param endpointName valid endpoint name
	 * @param info if <code>null</code> the endpoint will be queried for it's
	 * current status.
	 * @return not <code>null</code>
	 */
	ActiveEndpoint updateEndpointStatus(int endpointId, StatusInfo info);

	/**
	 * Returns a collection ActiveEndpoint's that match <code>queryParams</code>
	 *
	 * @param queryParams if null all active endpoints should be returned,
	 * otherwise the contents of this map are implementation specific
	 * @return not <code>null</code>
	 */
	Collection<ActiveEndpoint> queryActiveEndpoints(
			Map<String, String> queryParams);

	/**
	 * Returns a list of all EndpointTypeDefs available in the system
	 * @return not <code>null</code>
	 */
	EndpointTypeDefList readEndpointTypeDefs();

	/**
	 * Updates the metadata describing an EndpointType
	 *
	 * @param typeDef must be a typeDef for a valid ActiveEndointType
     * @return not <code>null</code> updated metadata
	 */
	EndpointTypeDef updateEndpointTypeDef(EndpointTypeDef typeDef);

	/**
	 * Return the ActiveEndpointType defined by <code>endpointType</code>
	 *
	 * @param endpointType valid type
	 * @return not <code>null</code>
	 */
	ActiveEndpointType getActiveEndpointType(String endpointType);

	/**
	 * Returns all EndpointTypes defined in the system
	 *
	 * @return not <code>null</code>
	 */
	Collection<ActiveEndpointType> getActiveEndpointTypes();

	/**
	 * Returns the collection of all Endpoint Types/ all ActiveEndpoint types
	 * currently defined in the system based on the value of the getAll
	 * parameter passed.
	 *
	 * @param getAll
	 * @return
	 */
	Collection<ActiveEndpointType> getActiveEndpointTypes(boolean getAll);
	
	/**
	 * Returns the collection of all Device Vendor Endpoint Types/ all ActiveEndpoint types
	 * currently defined in the system based on the value of the getAll
	 * parameter passed.
	 *
	 * @param getAll
	 * @return
	 */	
	Collection<ActiveEndpointType> getActiveDeviceVendorEndpointTypes(String deviceType, boolean getAll);

    /**
     * Adds a listener which will receive StatusEvents that occur on any
     * endpoint
     *
     * @param statusChangeListener not <code>null</code>
     */
    void addStatusChangeListener(StatusChangeListener statusChangeListener);

    /**
     * Adds a listener which will receive StatusEvents that occur on the
     * endpoint identified by <code>endpointName</code>
     *
     * @param endpointName valid endpoint name
     * @param statusChangeListener not <code>null</code>
     */
    void addStatusChangeListener(int endpointId,
            StatusChangeListener statusChangeListener);

    /**
     * Removes a listener such that it will no longer receive StatusChangeEvents
     *
     * @param statusChangeListener previously added listener
     */
    void removeStatusChangeListener(StatusChangeListener statusChangeListener);

    /**
     * Returns a collection of all registered listeners
     *
     * @return not <code>null</code> collection
     */
    Collection<StatusChangeListener> getStatusChangeListeners();

    /**
     * Called to remove an active endpoint from the system without removing
     * it's definition from the store
     *
     * @param name not <code>null</code> endpoint name
     */
    void cleanUpActiveEndpoint(int endpointId);

    /**
     * Return the ActiveEndpoint defined by outputRequest
     *
     * @param outputRequest
     * @return not <code>null</code>
     */
    ActiveEndpoint getActiveEndpoint(OutputRequest outputRequest);
    
    /**
     * Adds a deviceInfo endpoint definition to output service
     */
    DeviceInfo createDevice(DeviceInfo deviceInfo);
    
	/**
	 * Returns the collection of all Device Endpoint Types
	 * currently defined in the system based on the value of the typeNames
	 * parameter passed.
	 *
	 * @param typeNames
	 * @return
	 */	
    public List<EndpointDef> getDevicesByType(List<String> typeNames);
    
	/**
	 * Returns the Device identified by <code>deviceId</code>
	 *
	 * @param deviceId not <code>null</code>, if not a valid deviceId
	 * an exception will be thrown
	 * @return not <code>null</code>
	 */
    EndpointDef getDevice(int deviceId);
    
	/**
	 * Update the meta data for the specified device definition
	 */
	DeviceInfo updateDevice(DeviceInfo deviceInfo);    
    
	/**
	 * Tests(validate) the device endpoint using the values of the deviceInfo object
	 */
    DeviceInfo testDevice(DeviceInfo deviceInfo);
    
	/**
	 * Gets the EndpointDef for a device based on the name and definition type passed in
	 */
    EndpointDef getDevice(String name, String defType);
    
    /**
     * Deletes the device with the passed in deviceId if it is not in use by a DISC queue
     * if the force value is true, delete the device even if it is in use by a DISC queue
     */
    void deleteDevice(int deviceId, boolean force);    
    
    /**
     * Iterates through all typeHandlers to allow
     * Defined definition type handlers to update the outputJob in the outputJobs collection
     * with additional details 
     */
    void updateJobStatusWithEndpointStatus(List<OutputJob> outputJobs);
}
