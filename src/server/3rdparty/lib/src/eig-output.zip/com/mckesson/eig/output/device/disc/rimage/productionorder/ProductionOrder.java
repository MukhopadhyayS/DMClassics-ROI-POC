/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage.productionorder;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "ProductionOrder")
@XmlType( propOrder={"media","target","writetrack","fixate","label" })
public class ProductionOrder {
    
    private int numberOfCopies;
    private String order_Id;
    private String client_Id;
    private String priority;
    private String originator;
    private String referencedSet;
    private String referenced_job_Id;
    private Media media;
    private ProductionOrderTarget target;
    private ActionWriteTrack writetrack;
    private ActionFixate fixate;
    private ActionLabel label;
    
    
    public int getNumberOfCopies() {
        return numberOfCopies;
    }
    
    @XmlAttribute(name = "Copies")
    public void setNumberOfCopies(int numberOfCopies) {
        this.numberOfCopies = numberOfCopies;
    }
    
    public String getOrder_Id() {
        return order_Id;
    }
    
    @XmlAttribute(name = "OrderId")
    public void setOrder_Id(String order_Id) {
        this.order_Id = order_Id;
    }
    
    public String getClient_Id() {
        return client_Id;
    }
    
    @XmlAttribute(name = "ClientId")
    public void setClient_Id(String client_Id) {
        this.client_Id = client_Id;
    }
    
    public String getPriority() {
        return priority;
    }
    
    @XmlAttribute(name = "Priority")
    public void setPriority(String priority) {
        this.priority = priority;
    }
    
    public String getOriginator() {
        return originator;
    }
    
    @XmlAttribute(name = "Originator")
    public void setOriginator(String originator) {
        this.originator = originator;
    }
    
    public String getReferencedSet() {
        return referencedSet;
    }
    
    @XmlAttribute(name = "ReferencedSet")
    public void setReferencedSet(String referencedSet) {
        this.referencedSet = referencedSet;
    }
    
    public String getReferenced_job_Id() {
        return referenced_job_Id;
    }
    
    @XmlAttribute(name = "ReferencedJobId")
    public void setReferenced_job_Id(String referenced_job_Id) {
        this.referenced_job_Id = referenced_job_Id;
    }
    
    public Media getMedia() {
        return media;
    }
    
    @XmlElement(name = "Media")
    public void setMedia(Media media) {
        this.media = media;
    }
    
    public ProductionOrderTarget getTarget() {
        return target;
    }
    
    @XmlElement(name = "Target")
    public void setTarget(ProductionOrderTarget target) {
        this.target = target;
    }
    
    public ActionWriteTrack getWritetrack() {
        return writetrack;
    }
    
    @XmlElement(name = "Action")
    public void setWritetrack(ActionWriteTrack writetrack) {
        this.writetrack = writetrack;
    }
    
    public ActionFixate getFixate() {
        return fixate;
    }
    
    @XmlElement(name = "Action")
    public void setFixate(ActionFixate fixate) {
        this.fixate = fixate;
    }
    
    public ActionLabel getLabel() {
        return label;
    }
    
    @XmlElement(name = "Action")
    public void setLabel(ActionLabel label) {
        this.label = label;
    }
    
}
