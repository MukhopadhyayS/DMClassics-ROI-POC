package com.mckesson.eig.output.model;

import java.util.List;

public class ShutdownBean {

	public ShutdownBean(List<ShutdownHook> hooks) {
	      Runtime.getRuntime().addShutdownHook(
	    		  new ShutdownThread(hooks));
	}
}
