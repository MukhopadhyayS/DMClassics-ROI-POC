/*
 * Copyright 2009-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;

/**
 * Definition of a Part Transform Endpoint
 *
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "partTransformDef")
@XmlType(name = "partTransformDef")
public class PartTransformDef extends EndpointDef {

    private static final long serialVersionUID = 1L;

    /**
     * Simple Constructor
     */
    public PartTransformDef() {
        super(EndpointCategory.PART_TRANSFORM);
    }

}
