/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.service;

import java.util.List;
import java.util.Map;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.Use;

import com.mckesson.eig.output.model.DestDef;
import com.mckesson.eig.output.model.DestInfoList;
import com.mckesson.eig.output.model.DestTypeInfoList;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.DestInfo;
import com.mckesson.eig.output.model.DestTypeInfo;
import com.mckesson.eig.output.model.DeviceInfoList;
import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.output.util.MapModelList;
import com.mckesson.eig.output.util.StringList;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;

/**
 * The <code>DestinationService</code> provides the interface to query and manage the
 * OutputService's destinations and destination types. Destination types represent a class of
 * destinations which may be installed. For example, Printer, Fax and File may all represent
 * unique destination types. Each destination type has a set of devices associated with it. For
 * example, the Printer destination type would have a device for each physical printer to
 * which the OutputService could send content. These devices are mapped to Output Destinations
 * which represent the OutputService's queue and route for processing content to be delivered
 * to the actual device.
 *
 * @author OFS
 * @author Jon Anderson
 *
 */
@WebService(name            = "DestinationPortType_v1_0",
            targetNamespace = "http://eig.mckesson.com/wsdl/destination-v1")
@SOAPBinding(style          = Style.DOCUMENT,
             use            = Use.LITERAL,
             parameterStyle = SOAPBinding.ParameterStyle.WRAPPED)
public interface DestinationService {

	/**
	 * Returns the list of destination type names that are supported by the OutputService. For
	 * the destination type to be supported a handler (meaning some class which handles
	 * configuration and management of destinations of that type) must be installed.
	 *
	 * @return should not be <code>null</code>
	 */
    @WebMethod (operationName = "getSupportedDestTypes",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getSupportedDestTypes",
                exclude       = true)
    @WebResult (name          = "stringList")
    StringList getSupportedDestTypes();

	/**
	 * Returns the type info for all destination types which are enabled meaning that
	 * destinations of that type may be defined or undefined.
	 *
	 * @return not <code>null</code>
	 */
	@WebMethod (operationName = "getEnabledDestTypes",
	            action = "http://eig.mckesson.com/wsdl/destination-v1/getEnabledDestTypes",
	            exclude = true)
    @WebResult (name = "destTypeInfos")
    DestTypeInfoList getEnabledDestTypes();

	/**
	 * Returns the type info for all destination types.
	 *
	 * @return not <code>null</code>
	 */
	@WebMethod (operationName = "getAllDestTypes",
	            action        = "http://eig.mckesson.com/wsdl/destination-v1/getAllDestTypes",
	            exclude       = true)
    @WebResult (name = "destTypeInfos")
	DestTypeInfoList getAllDestTypes();

	/**
	 * Returns the type info for all source types which are enabled meaning that
	 * destinations of that type may be defined or undefined.
	 *
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "getEnabledSourceTypes",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getEnabledSourceTypes",
                exclude       = true)
	@WebResult (name = "destTypeInfos")
	DestTypeInfoList getEnabledSourceTypes();

	/**
	 * Returns the type info for all source types.
	 *
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "getAllSourceTypes",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getAllSourceTypes",
                exclude       = true)
    @WebResult (name = "destTypeInfos")
    DestTypeInfoList getAllSourceTypes();
    
	/**
	 * Returns the list of supported device type names that are supported by the OutputService. For
	 * the device type to be supported a handler (meaning some class which handles
	 * configuration and management of device of that type) must be installed.
	 *
	 * @return should not be <code>null</code>
	 */
    @WebMethod (operationName = "getSupportedDeviceTypes",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getSupportedDeviceTypes",
                exclude       = true)
    @WebResult (name          = "destTypeInfos")
    DestTypeInfoList getSupportedDeviceTypes();    
    
	/**
	 * Returns the list of supported device vendor type  that are supported by the OutputService. For
	 * the device vendor type to be supported a handler (meaning some class which handles
	 * configuration and management of device of that type) must be installed.
	 *
	 * @return should not be <code>null</code>
	 */
    @WebMethod (operationName = "getSupportedDeviceVendorTypes",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getSupportedDeviceVendorTypes",
                exclude       = true)
    @WebResult (name          = "destTypeInfos")
    DestTypeInfoList getSupportedDeviceVendorTypes(String deviceType, boolean includeDisbaled);       
    

	/**
	 * Certain destination types will support properties which may be set for the type itself.
	 * This call allows these properties to be set at runtime.
	 *
	 * @param typeName type for which the property is to be set. Must be an enabled type
	 *  and not <code>null</code>
	 * @param propertyName property to set. not <code>null</code>
	 * @param propertyValue value for the property.
	 */
    @WebMethod (operationName = "setDestTypeProperty",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/setDestTypeProperty",
                exclude       = true)
    void setDestTypeProperty(String typeName, String propertyName, String propertyValue);

	/**
	 * Return the property value for the given type
	 *
	 * @param typeName type for which the property is to be set. Must be an enabled type
	 *  and not <code>null</code>
	 * @param propertyName name of the property. not <code>null</code>
	 * @return may be <code>null</code>
	 */
    @WebMethod (operationName = "getDestTypeProperty",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getDestTypeProperty",
                exclude       = true)
    String getDestTypeProperty(String typeName, String propertyName);

	/**
	 * Return the current info for the type. The type must be enabled for the info to be
	 * returned.
	 *
	 * @param typeName type for which the property is to be set. Must be an enabled type
	 *  and not <code>null</code>
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "getDestTypeInfo",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getDestTypeInfo",
                exclude       = true)
    DestTypeInfo getDestTypeInfo(String typeName);

	/**
	 * Enables a destination type such that destinations may be defined and undefined for it.
	 *
	 * @param typeName name of the type. not <code>null</code>
	 * @return the info for the newly enable type
	 */
    @WebMethod (operationName = "enableDestType",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/enableDestType",
                exclude       = true)
    DestTypeInfo enableDestType(String typeName);

	/**
	 * Disables a destination type such that destinations may no longer be defined and
	 * undefined for it. The type must not have any destinations currently defined.
	 *
	 * @param typeName name of the type. not <code>null</code>
	 */
    @WebMethod (operationName = "disableDestType",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/disableDestType",
                exclude       = true)
    void disableDestType(String typeName);

	/**
	 * Queries a destination for it's current status info.
	 *
	 * @param destName name of the destination to query. must be a defined destination.
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "queryDestination",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/queryDestination",
                exclude       = true)
    DestInfo queryDestination(int destId);
   
    
	/**
	 * Queries a destination for it's current status info.
	 *
	 * @param destType type of destination.
	 * @param destName name of the destination to query. must be a defined destination.
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "queryDestinationByNameAndType",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/queryDestinationByNameAndType",
                exclude       = true)
    DestInfo queryDestination(String destType, String destName);
    
	/**
	 * Query a destination property.
	 *
	 * @param destName name of the destination whose property is to be queried. must be a
	 * defined destination
	 * @param propertyName name of the property to query
	 * @return may be <code>null</code>
	 */
    @WebMethod (operationName = "getDestProperty",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getDestProperty",
                exclude       = true)
    String getDestProperty(int destId, String propertyName);

	/**
	 * Set a destination property.
	 *
	 * @param destName name of the destination whose property is to be set. must be a
	 * defined destination
	 * @param propertyName name of the property to set. not <code>null</code>
	 * @param value new value. may be <code>null</code>
	 */
    @WebMethod (operationName = "setDestProperty",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/setDestProperty",
                exclude       = true)
    void setDestProperty(int destId, String propertyName, String value);

	/**
	 * Pause a destination such that OutputJobs sent will be queued and not delivered until
	 * the destination is re-started.
	 *
	 * @param destName name of the destination to be paused. must be a
	 * defined destination
	 */
    @WebMethod (operationName = "pauseDestination",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/pauseDestination",
                exclude       = true)
    void pauseDestination(int destId);

	/**
	 * Re-start a previously paused destination such that OutputJobs sent will be
	 *
	 * @param destName name of the destination to be re-started. must be a
	 * defined destination
	 */
    @WebMethod (operationName = "restartDestination",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/restartDestination",
                exclude       = true)
    void restartDestination(int destId);

	/**
	 * Query status information about a physical device.
	 *
	 * @param typeName type of device to be queried. Must be an enabled type
	 *  and not <code>null</code>
	 * @param deviceID id of the device. not <code>null</code>
	 * @return  not <code>null</code>
	 */
    @WebMethod (operationName = "queryDevice",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/queryDevice",
                exclude       = true)
    DeviceInfo queryDevice(String typeName, String deviceID);

	/**
	 * Queries the current status of all destinations which satisfy <code>queryOptions</code>
	 *
	 * @param queryOptions set of name / value pairs specifying destination properties to be
	 * matched.
	 * @return not <code>null</code>
	 */
	@WebMethod (operationName = "queryDestinations",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/queryDestinations",
                exclude       = true)

	List<DestInfo> queryDestinations(@WebParam(name = "queryOptions")
	                                Map<String, String> queryOptions);


	/**
	 * Queries the current status of all system destinations which satisfy <code>queryOptions</code>
	 *
	 * @param queryOptions set of name / value pairs specifying destination properties to be
	 * matched.
	 * @return not <code>null</code>
	 */
	@WebMethod (operationName = "querySystemDestinations",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/querySystemDestinations",
                exclude       = true)

	DestInfoList querySystemDestinations(@WebParam(name = "queryOptions")
	                                     List<MapModel> queryOptions);
	
	
	
	/**
	 * Queries the active destinations of certain category
	 *
	 * @param EndpointCategory
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "queryDestinationsByCategory",
                action = "http://eig.mckesson.com/wsdl/destination-v1/queryDestinationsByCategory",
                exclude = true)
	DestInfoList queryDestinationsByCategory(EndpointCategory category);

	/**
	 * Queries all destinations of certain category
	 *
	 * @param EndpointCategory
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "queryAllDestinationsByCategory",
              action = "http://eig.mckesson.com/wsdl/destination-v1/queryAllDestinationsByCategory",
              exclude = true)
    @WebResult (name          = "destInfos")
    DestInfoList queryAllDestinationsByCategory(EndpointCategory category);

    /**
     * Returns all destinations current status info of type typeName
     *
     * @param typeName type of destinations
     * @return not <code>null</code>
     */
	@WebMethod (operationName = "getDestinations",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getDestinations")
    @WebResult (name = "destInfos")
    DestInfoList getDestinations(@WebParam(name = "typeName")String typeName);

    /**
     * Returns all system destinations current status info of type typeName
     *
     * @param typeName type of system destinations
     * @return not <code>null</code>
     */
	@WebMethod (operationName = "getSystemDestinations",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getSystemDestinations")
    @WebResult (name = "destInfos")
    DestInfoList getSystemDestinations(@WebParam(name = "typeName")String typeName);	
	
	
	/**
	 * Defines a new destination to which output may be routed
	 *
	 * @param destDef definition of the new destination. not <code>null</code>
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "defineDestination",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/defineDestination",
                exclude       = true)
    @WebResult (name          = "destInfo")
	DestInfo defineDestination(@WebParam(name = "destDef")DestDef destDef) throws Exception;
    
	/**
	 * Defines a new system destination to which output may be routed
	 *
	 * @param destDef definition of the new system destination. not <code>null</code>
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "defineSystemDestination",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/defineSystemDestination",
                exclude       = true)
    @WebResult (name          = "destInfo")
	DestInfo defineSystemDestination(@WebParam(name = "destDef")DestDef destDef) throws Exception;    
    

    /**
     * Edits a destination to which output may be routed
     *
     * @param destDef definition of the edited destination. not <code>null</code>
     * @return not <code>null</code>
     */
    @WebMethod (operationName = "updateDestination",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/updateDestination",
                exclude       = true)
    @WebResult (name          = "destInfo")
    DestInfo updateDestination(@WebParam(name = "destDef")DestDef destDef);
    
    
    /**
     * Edits a system destination to which output may be routed
     *
     * @param destDef definition of the edited system destination. not <code>null</code>
     * @return not <code>null</code>
     */
    @WebMethod (operationName = "updateSystemDestination",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/updateSystemDestination",
                exclude       = true)
    @WebResult (name          = "destInfo")
    DestInfo updateSystemDestination(@WebParam(name = "destDef")DestDef destDef);
    
    

	/**
	 * Un-defines a destination such that output may no longer be routed to it.
	 *
	 * @param destName name of the destination to be removed. not <code>null</code>
	 * @param force if true, any queued jobs for the destination will be re-routed to the
	 * error destination. Otherwise already queued jobs will be completed before the destination
	 * is undefined.
	 */
    @WebMethod (operationName = "undefineDestination",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/undefineDestination",
                exclude       = true)
    void undefineDestination(@WebParam(name = "destinationId")int destId,
                             @WebParam(name = "force")boolean force);
    
    /**
     * Method retrieves all destination ids and name. 
     *
     * @return not <code>null</code>
     */
    @WebMethod (operationName = "getDestinationNameIdMap",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/getDestinationNameIdMap",
                exclude       = true)
    @WebResult (name          = "mapModelList")
    MapModelList getDestinationNameIdMap();
    
    
	/**
	 * Defines a new destination to which output may be routed
	 *
	 * @param deviceInfo  of the new device. not <code>null</code>
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "defineDevice",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/defineDevice",
                exclude       = true)
    @WebResult (name          = "deviceInfo")
	DeviceInfo defineDevice(@WebParam(name = "deviceInfo")DeviceInfo deviceInfo) throws Exception;    
    
	/**
	 * Queries the active devices of certain category
	 *
	 * @param EndpointCategory
	 * @return not <code>null</code>
	 */
    @WebMethod (operationName = "queryDevicesByCategory",
                action = "http://eig.mckesson.com/wsdl/destination-v1/queryDevicesByCategory",
                exclude = true)
	DeviceInfoList queryDevicesByCategory(EndpointCategory category);    
    
	/**
	 * Query status information about a physical device.
	 *
	 * @param typeName type of device to be queried. Must be an enabled type
	 *  and not <code>null</code>
	 * @param deviceID id of the device. not <code>null</code>
	 * @return  not <code>null</code>
	 */
    @WebMethod (operationName = "queryDevice",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/queryDevice",
                exclude       = true)
    DeviceInfo queryDevice(int deviceId);   
    
    /**
     * Edits a destination to which output may be routed
     *
     * @param destDef definition of the edited destination. not <code>null</code>
     * @return not <code>null</code>
     */
    @WebMethod (operationName = "updateDeevice",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/updateDevice",
                exclude       = true)
    @WebResult (name          = "deviceInfo")
    DeviceInfo updateDevice(@WebParam(name = "deviceInfo")DeviceInfo deviceInfo);    
    
	/**
	 * Un-defines a device such that output may no longer be routed to it.
	 *
	 * @param device id of the device to be removed. not <code>null</code>
	 * @param force if true, any queued jobs for the device will be re-routed to the
	 * error destination. Otherwise already queued jobs must be completed before the device
	 * is undefined.
	 */
    @WebMethod (operationName = "undefineDevice",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/undefineDevice",
                exclude       = true)
    void undefineDevice(@WebParam(name = "deviceId")int deviceId,
                             @WebParam(name = "force")boolean force);    
    
	/**
	 * Un-defines a device such that output may no longer be routed to it.
	 *
	 * @param device id of the device to be removed. not <code>null</code>
	 * @param force if true, any queued jobs for the device will be re-routed to the
	 * error destination. Otherwise already queued jobs must be completed before the device
	 * is undefined.
	 */
    @WebMethod (operationName = "testDevice",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/testDevice",
                exclude       = true)
    DeviceInfo testDevice(@WebParam(name = "deviceInfo")DeviceInfo deviceInfo);    
    
	/**
	 * Un-defines a device such that output may no longer be routed to it.
	 *
	 * @param device id of the device to be removed. not <code>null</code>
	 * @param force if true, any queued jobs for the device will be re-routed to the
	 * error destination. Otherwise already queued jobs must be completed before the device
	 * is undefined.
	 */
    @WebMethod (operationName = "refreshDeviceLabels",
                action        = "http://eig.mckesson.com/wsdl/destination-v1/refreshDeviceLabels",
                exclude       = true)
    List<String> refreshDeviceLabels(@WebParam(name = "deviceId")int deviceId);     
}
