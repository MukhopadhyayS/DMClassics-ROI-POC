/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage.imageorder;

import java.io.File;
import java.util.List;

import com.mckesson.eig.output.device.disc.rimage.ObjectMarshaller;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class XMLEditListFile {

    public static final Log LOG = LogFactory.getLogger(XMLEditListFile.class);

    public static final String EDIT_LIST_HEADER = new StringBuffer("<?xml version=\"1.0\"?>")
                                                       .append("<!DOCTYPE EditList SYSTEM \"Editlist_1.5.dtd\"><EditList VolumeGroupPacking = \"false\">")
                                                       .append("<Options ExpandFolders=\"false\"/>").toString();

    public static final String EDIT_LIST_FOOTER = "</EditList>";

    public static final String GROUP_START = "<Options VolumeGroup=\"start\"/>";
    public static final String GROUP_END = "<Options VolumeGroup=\"end\"/>";

    private List<String> fileNames;
    
    private String destination;

    public XMLEditListFile() {
        super();
    }

    public XMLEditListFile(List<String> fileNames) {
        super();
        this.fileNames = fileNames;
    }
    
    public XMLEditListFile(List<String> fileNames, String destination) {
        super();
        this.fileNames = fileNames;
        this.destination = destination;
    }

    
    public String getXML() throws Exception{

        StringBuffer temp = new StringBuffer();
        temp.append(EDIT_LIST_HEADER);

        for (String aFilename : fileNames) {
            temp.append(GROUP_START);
            SourceDestination obj = new SourceDestination();
            String fileWithDestination = new StringBuffer(this.destination).append(File.separator).append(aFilename).append(".*").toString();
            obj.setSource(fileWithDestination);
            try {
                String str = ObjectMarshaller.marshalAsFragment(obj);
                temp.append(str);
            } catch (Exception ex) {
                LOG.error("Can not marshall object, object type: " + obj.getClass() + "; reason: " + ex.getMessage());
                throw new Exception("Can not marshall object, object type: " + obj.getClass() + "; reason: " + ex.getMessage());
            }
            temp.append(GROUP_END);
        }

        temp.append(EDIT_LIST_FOOTER);

        return temp.toString();
    }

}
