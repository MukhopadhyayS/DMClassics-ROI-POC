/**
 * Copyright � 2010 McKesson Corporation and/or one of its subsidiaries.
 * All rights reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.hpf.service;

import java.util.HashMap;
import java.util.Iterator;

import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.w3c.dom.NodeList;

import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.wsfw.session.WsSession;

public class ConfigurationWebServiceCaller extends WebServiceCaller {
	private static final Log LOG = LogFactory.getLogger(ConfigurationWebServiceCaller.class);
	private static final String GET_CONFIGURATION_OPERATION = "getConfiguration";
	private static final String NAMESPACE = "urn:eig.mckesson.com";

	public ConfigurationWebServiceCaller() {
		super(false, null);
	}

	public HashMap<String, String> getConfiguration(String url, String userId,
			String userPassword) throws SOAPException {
		String sendUrl = getWebURL(url);
		SOAPMessage request = createGetConfigurationRequest(userId, userPassword);
		return getConfigurationResult(request, sendUrl);
	}

	private SOAPMessage createGetConfigurationRequest(String userId,
			String userPassword) throws SOAPException {
		SOAPMessage msg = createSOAPMessage();
		SOAPPart sp = msg.getSOAPPart();
		SOAPEnvelope env = sp.getEnvelope();
		SOAPBody bdy = env.getBody();
		SOAPBodyElement gltp = bdy.addBodyElement(env.createName(
				GET_CONFIGURATION_OPERATION, "", NAMESPACE));
		gltp.addChildElement("userid").addTextNode(userId);
		gltp.addChildElement("userpassword").addTextNode(userPassword);
		return msg;
	}

	private HashMap<String, String> getConfigurationResult(SOAPMessage request,
			String url) {
		LOG.debug("Web Servcie Call URL=[" + url + "]");

//		URLEndpoint endpoint = new URLEndpoint(url);
		try {
			SOAPConnection conn = createSOAPConnection();
			MimeHeaders headers = request.getMimeHeaders();
			headers.setHeader("SOAPAction", "");

			// To use the same session for output request with respect to hpf
			headers.setHeader("Set-Cookie", "JSESSIONID=" + WsSession.getSessionId());

//			SOAPMessage response = conn.call(request, endpoint);
			SOAPMessage response = conn.call(request, url);

			return parserConfiguration(response);
		} catch (Exception e) {
			LOG.error("Failed to getSearchResult: " + e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	private HashMap<String, String> parserConfiguration(SOAPMessage response)
			throws SOAPException {
		SOAPBody body = response.getSOAPBody();
		Iterator < SOAPBodyElement > it = body.getChildElements();
		if (it.hasNext()) {
			SOAPBodyElement bodyElement = it.next();
			Iterator < SOAPElement > it2 = bodyElement.getChildElements();
			if (it2.hasNext()) {
				HashMap<String, String> map = new HashMap<String, String>();
				SOAPElement messageElement = it2.next();
				NodeList list = messageElement.getElementsByTagName("name");
				setConfigurationItem(list, map);
				return map;
			}
		}
		return null;
	}

	private void setConfigurationItem(NodeList list, HashMap<String, String> map) {
		if (list != null) {
			int count = list.getLength();
			for (int i = 0; i < count; i++) {
				SOAPElement element = (SOAPElement) list.item(i);
				String name = element.getValue();
				map.put(name, getValueElement(element));
			}
		}
	}

	private String getValueElement(SOAPElement element) {
		SOAPElement parentElement = element.getParentElement();
		NodeList list = parentElement.getElementsByTagName("value");
		if (list != null && list.getLength() == 1) {
			return ((SOAPElement) list.item(0)).getValue();
		}
		return null;
	}
}
