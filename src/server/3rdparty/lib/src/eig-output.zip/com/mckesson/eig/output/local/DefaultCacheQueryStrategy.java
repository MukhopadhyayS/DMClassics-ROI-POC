/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.BeanUtils;

import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;



/**
 * TODO
 * @author Jon Anderson
 *
 */
public class DefaultCacheQueryStrategy implements CacheQueryStrategy {

	/**
	 * TODO
	 */
	public DefaultCacheQueryStrategy() {
		super();
	}

	@SuppressWarnings("unchecked")
	public void queryCache(
			Map<String, String> query,
			Collection cachedObjects,
			Collection results) {

		if (cachedObjects == null) {
			throw new IllegalArgumentException(
					"cachedObjects argument is null");
		}
		if (results == null) {
			throw new IllegalArgumentException("results argument is null");
		}

		if (query == null) {
			results.addAll(cachedObjects);
			return;
		}

		Map<String, Pattern> compiledQuery = compileQuery(query);

		Iterator cachedIterator = cachedObjects.iterator();
		while (cachedIterator.hasNext()) {

			Object cachedObject = cachedIterator.next();
			if (matchesQuery(compiledQuery, cachedObject)) {
				results.add(cachedObject);
			}
		}
	}

	private boolean matchesQuery(Map<String, Pattern> query, Object bean) {

		assert query != null;
		assert bean != null;

		for (Entry<String, Pattern> mapEntry : query.entrySet()) {


			Object rawValue;
            try {
                rawValue = BeanUtils.getProperty(bean, mapEntry.getKey());
            } catch (Exception e) {
                throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
            }

			String convertedValue = PropertySupport.valueToString(rawValue);

			if (!mapEntry.getValue().matcher(convertedValue).matches()) {
				return false;
			}
		}

		return true;
	}

	private static Map<String, Pattern> compileQuery(
			Map<String, String> query) {

		assert query != null;

		Map<String, Pattern> compiled = new HashMap<String, Pattern>();

		for (Entry<String, String> mapEntry : query.entrySet()) {

			Pattern pattern = Pattern.compile(mapEntry.getValue());
			compiled.put(mapEntry.getKey(), pattern);
		}

		return compiled;
	}

}
