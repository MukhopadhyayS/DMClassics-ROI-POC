/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfAction;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfDestination;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfOutline;
import com.lowagie.text.pdf.PdfReader;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.SourceType;
import com.mckesson.eig.output.util.OutputException;

//TODO :  Bookmark should be implemented as another transform type.

public class DefaultBookmark implements PdfBookmark {

    public DefaultBookmark() {
    }

    public void createJobBookmark(OutputJob job, long maxSize) {
        for (JobPart part : job.getParts()) {
            createPartBookmark(part);
        }
    }

    protected void createPartBookmark(JobPart part) {
        try {

            //bookmarks HPF documents
            if (part.getContentSourceType() != null) {
                if (part.getContentSourceType().equalsIgnoreCase(SourceType.HPF.toString())) {
                    Iterator <String> filesIterator = part.getSourcesIterator();
                    int pageNo = 1;
                    while (filesIterator.hasNext()) {

                        String currFileName = part.getCurrentLocation()
                        + File.separatorChar
                        + filesIterator.next();
                        Document document = null;
                        PdfCopy writer = null;
                        PdfReader reader = new PdfReader(currFileName);
                        document = new Document(reader.getPageSizeWithRotation(1));
                        String  bookmarkFileName = currFileName + "_BOOKMARK";
                        writer = new PdfCopy(document, new FileOutputStream(bookmarkFileName));

                        document.open();
                        PdfImportedPage page;
                        for (int i = 1; i <= reader.getNumberOfPages(); i++) {
                            page = writer.getImportedPage(reader, i);
                            writer.addPage(page);
                        }

                        PdfOutline root = writer.getRootOutline();
                        PdfOutline outline1 = new PdfOutline(root,
                                                             PdfAction.gotoLocalPage(1,
                                             new PdfDestination(PdfDestination.XYZ,
                                                                0,
                                                                reader.getPageSize(1).getHeight(),
                                                                0),
                                                                writer),
                                                                part.getProperties().
                                                                get(OutputConstants.PATIENT_NAME));
                        PdfOutline outline2 = new PdfOutline(outline1,
                                                             PdfAction.gotoLocalPage(1,
                                             new PdfDestination(PdfDestination.XYZ,
                                                                0,
                                                                reader.getPageSize(1).getHeight(),
                                                                0),
                                                                writer),
                                                                part.getProperties().
                                                                get(OutputConstants.MRN));
                        PdfOutline outline3 = new PdfOutline(outline2,
                                                             PdfAction.gotoLocalPage(1,
                                             new PdfDestination(PdfDestination.XYZ,
                                                                0,
                                                                reader.getPageSize(1).getHeight(),
                                                                0),
                                                                writer),
                                                                part.getProperties().
                                                                get(OutputConstants.ENCOUNTER));

                        PdfOutline outline4 = new PdfOutline(outline3,
                                                             PdfAction.gotoLocalPage(1,
                                             new PdfDestination(PdfDestination.XYZ,
                                                                0,
                                                                reader.getPageSize(1).getHeight(),
                                                                0),
                                                                writer),
                                                                part.getProperties().
                                                                get(OutputConstants.DOCNAME));

                        for (int i = 1; i <= reader.getNumberOfPages(); i++) {

                        PdfOutline outline5 = new PdfOutline(outline4,
                                                             PdfAction.gotoLocalPage(1,
                                             new PdfDestination(PdfDestination.XYZ,
                                                                0,
                                                                reader.getPageSize(1).getHeight(),
                                                                0),
                                                                writer),
                                                                "Page " + pageNo);
                        pageNo++;
                        }
                        document.close();
                        FileUtils.deleteQuietly(new File(currFileName));
                        FileUtils.moveFile(new File(bookmarkFileName), new File(currFileName));
                    }
                }
            }
        } catch (Exception e) {
            throw new OutputException();
        }
    }
}
