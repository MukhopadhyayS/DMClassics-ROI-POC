package com.mckesson.eig.output.plugin.hpf;


	/*
	 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
	 * All Rights Reserved.
	 *
	 * Use of this material is governed by a license agreement. This material
	 * contains confidential, proprietary and trade secret information of
	 * McKesson Information Solutions and is protected under United States and
	 * international copyright and other intellectual property laws. Use,
	 * disclosure, reproduction, modification, distribution, or storage
	 * in a retrieval system in any form or by any means is prohibited without
	 * the prior express written permission of McKesson Information Solutions.
	 */

	import com.mckesson.eig.CodeList;

	/**
	 * @author Pranav Amarasekaran
	 * @date   Jul 28, 2009
	 * @since  Output 1.0; Jul 28, 2009
	 *
	 * This class is the output plugin implementation of ROI application. The plugin extends
	 * the HPFOutputPlugin as the Dispatcher application uses the HPF users. Therefore there may
	 * be some implementation available in the HPFOutputPlugin.
	 */
	public class OutputDispatchPlugin extends HPFOutputPlugin {

		/**
		 * This constructor is invoked from the spring configuration. The application which
		 * uses the service is responsible to specify these parameters as they are used by
		 * the class to communicate to the web service.
		 *
		 * @param protocol
		 * @param server
		 * @param port
		 */
		public OutputDispatchPlugin(String protocol, String server, String port) {
			super(protocol, server, port);
		}

		/**
		 * This method returns the output specific rights
		 * which the Dispatcher application uses.
		 */
		protected CodeList getOutputRights() {

			CodeList codeList = new CodeList();

			//final int exportToPDFRight = 6113;
			final int printFaxRight = 7112;

			int[] codes = {printFaxRight};
			codeList.setCodes(codes);
			return codeList;
		}
	}

