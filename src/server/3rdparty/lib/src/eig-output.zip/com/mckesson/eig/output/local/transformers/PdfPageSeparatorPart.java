/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;


import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.LocationSupport;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.OutputTransforms;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


/* This OutputTransformer is called when there is a PdfPageSeparator TransformDef
 *
 */

public class PdfPageSeparatorPart
extends PdfPartTransforms {

    private static final Log LOG = LogFactory.getLogger(PdfPageSeparatorPart.class);
	private static final int FIVE_HUNDRED = 500;
	private static final int TEWNTY = 20;

    public PdfPageSeparatorPart() {

        super();
    }

    //processes Part water mark Transformation
    @Override
    public void processJobParts(OutputJob job, Collection <JobPart> jobParts) {

        int counter = 0;
        List<JobPart> parts = job.getParts();

        if (parts.size() > FIVE_HUNDRED) {
            counter = parts.size() / TEWNTY;
        }

        OutputJobDAO outputJobDAO = getOutputJobDAO();
        int index   = 0;

        try {
            for (JobPart part : parts) {
                index++;

                if ((counter != 0) && (index == counter)) {

                    if (checkJobStatus(outputJobDAO, job.getJobSeq())) {
                        break;
                    }
                    index = 0;
                }
                processPageSeparatorTransform(job, part);
                LOG.info("Page separator transform completed for Part " + part.getPartID());
            }
        } catch (Exception e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

    private void processPageSeparatorTransform(OutputJob job, JobPart jobPart) throws Exception {

        try {
            PdfPageSeparator pdfPageSeparator = new PdfPageSeparator();

            StringBuilder pageSeparator = new StringBuilder();
            if (job.getSubmitInfo() == null) {
                throw new IllegalArgumentException("job submitter info argument is null");
            }
            if (StringUtils.isNotEmpty(job.getSubmitInfo().getSubmitterData())) {
                pageSeparator.append(job.getSubmitInfo().getSubmitterData());
            }

            //TODO - Modify to Support Local format
            SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy  HH:mm:ss");

            pageSeparator.append("      " + job.getDestName());
            pageSeparator.append("      " + dateFormatter.format(Calendar.getInstance().getTime()));

            //Insert a page at the first Index in source.
            jobPart.setNoOfPages(jobPart.getNoOfPages() + 1);
            String pageSeparatorFileName = OutputTransforms.PAGE_SEPARATOR.toString() + ".pdf";
            String destFile =
            jobPart.getNextLocation() + File.separatorChar + pageSeparatorFileName;
            LocationSupport.removeFile(destFile);
            pdfPageSeparator.addPageSeparator(destFile, pageSeparator.toString());
            //Add a new document: Add document to source list
            jobPart.getSources().add(0, pageSeparatorFileName);
        } catch (Exception e) {

            String message = "error processing page separator for part: " + jobPart.getPartID();
			LOG.error(message, e);
            throw new ApplicationException(message, e.getMessage());
        }
    }
}
