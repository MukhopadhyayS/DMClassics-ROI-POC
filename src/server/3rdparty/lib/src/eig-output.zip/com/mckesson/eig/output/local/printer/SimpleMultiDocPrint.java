/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * author: Latonia
 */


package com.mckesson.eig.output.local.printer;


import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ListIterator;

import javax.print.Doc;
import javax.print.MultiDoc;

import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.output.util.PdfSupport;
import com.sun.pdfview.PDFFile;
import com.sun.pdfview.PDFPage;
import com.sun.pdfview.PDFRenderer;


public class SimpleMultiDocPrint
implements
Pageable,
Printable,
MultiDoc {

    private static final Log LOG = LogFactory.
							getLogger(SimpleMultiDocPrint.class);
    private PageFormat   _format;
    private int _numPages = 0;

    private PDFFile               _file;
    private ArrayList <String>    _fileList = new ArrayList <String>();
    private ListIterator <String> _fileListIter = null;
    private int                   _numPagesPrintedAtStartOfFile = 0;
    
    private boolean _reverseOrderFlag;

    public SimpleMultiDocPrint(Collection <String> fileList, boolean reverseOrder) {

        try {

        	_fileList.addAll(fileList);
            _numPages = PdfSupport.getPageCount(fileList);

            // set file list iterator for processing
            _fileListIter = _fileList.listIterator(0);

            // setup first file for printing
            getNextFile();

            // sets the order of printing. if true then reverse order else sequential order.
            _reverseOrderFlag = reverseOrder;
        } catch (Exception e) {
            LOG.error("SimpleMultiDocPrint:" + e.getMessage());
        }
    }

    private boolean getNextFile() {

        boolean rtnBool = false;

        try {
            if (_fileListIter.hasNext()) {
                // Create a PDFFile from a File reference
                File f = new File(_fileListIter.next());
                FileInputStream fis = new FileInputStream(f);
                FileChannel fc = fis.getChannel();
                ByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0, fc.size());
                PDFFile pdfFile = new PDFFile(bb);
                _file = pdfFile;

                fis.close();
                fc.close();

                rtnBool = true;
            }
            return rtnBool;
        } catch (Exception e) {
            LOG.error("getNextFile:" + e.getMessage());
            return false;
        }

    }

    public int getNumberOfPages() {

        return _numPages;
    }

    public void setPageFormat(PageFormat pageFormat) {

        _format = pageFormat;
    }

    public PageFormat getPageFormat(int pagenum) {

        return _format;
    }

    public Printable getPrintable(int pagenum) {

        return this;
    }

    public int print(Graphics g, PageFormat format, int index) throws PrinterException {

    	int pagenum;

    	if (_reverseOrderFlag) {
    		pagenum = (getNumberOfPages() - 1) - index + 1;
    	} else {
    		pagenum = index + 1;
    	}
    	
        // don't bother if the page number is out of range.
        if ((pagenum >= 1) && (pagenum <= _file.getNumPages())) {
            processPage(g, pagenum);
            return PAGE_EXISTS;
        } else {
            // getNextFile
            if (getNextFile()) {
                _numPagesPrintedAtStartOfFile = index;
                pagenum = index - _numPagesPrintedAtStartOfFile + 1;
                processPage(g, pagenum);
                return PAGE_EXISTS;
            }
            return NO_SUCH_PAGE;
        }
    }

    private void processPage(Graphics g, int pagenum) throws PrinterException {

        // fit the PDFPage into the printing area
        Graphics2D g2 = (Graphics2D) g;
        PDFPage page = _file.getPage(pagenum);

        double pwidth = _format.getImageableWidth();
        double pheight = _format.getImageableHeight();

        double aspect = page.getAspectRatio();
        double paperaspect = (float) pwidth / (float) pheight;

        Rectangle imgbounds;

        if (aspect == paperaspect) {
            imgbounds =
                new Rectangle(0, 0, (int) pwidth, (int) pheight);
        } else if (aspect > paperaspect) {
            // paper is too tall / pdfpage is too wide
            int height = (int) (pwidth / aspect);
            imgbounds =
            new Rectangle((int) _format.getImageableX(),
                          (int) (_format.getImageableY() + ((pheight - height) / 2)),
                          (int) pwidth,
                          height);
        } else {
            // paper is too wide / pdfpage is too tall
            int width = (int) (pheight * aspect);
            imgbounds =
            new Rectangle((int) (_format.getImageableX() + ((pwidth - width) / 2)), (int) _format
            .getImageableY(), width, (int) pheight);
        }

        // render the page
        PDFRenderer pgs = new PDFRenderer(page, g2, imgbounds, null, null);
        try {
            page.waitForFinish();
            pgs.run();
        } catch (InterruptedException ie) {
            LOG.debug("processPage:" + ie.getMessage());
        }
        g2.dispose();
    }

    public Doc getDoc() {
        //NOOP not used in current implementation.
        //current implementation uses pageable definition
        return null;
    }

    public MultiDoc next() {
        //NOOP not used in current implementation.
        //current implementation uses pageable definition
        return null;
    }
}
