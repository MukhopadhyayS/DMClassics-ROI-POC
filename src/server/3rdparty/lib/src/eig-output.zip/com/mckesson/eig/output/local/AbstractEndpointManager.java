/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.print.PrintService;
import javax.print.PrintServiceLookup;

import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.dao.MemoryDAO;
import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.local.model.ActiveEndpointType;
import com.mckesson.eig.output.local.printer.PrintDestination;
import com.mckesson.eig.output.model.DestDef;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.EndpointDefList;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.model.EndpointTypeDefList;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputRequest;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.UnknownObjectException;
import com.mckesson.eig.output.util.OutputConstants.DestinationType;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.status.StatusChangeListener;
import com.mckesson.eig.output.util.status.StatusChangeSupport;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * Thread-safe base implementation of <code>EndpointManager</code> which handles
 * the in memory cache and status change functions of the interface, and
 * performing persistence to a DAO.
 *
 * @author Jon Anderson
 */
public abstract class AbstractEndpointManager extends BaseComponent implements
		EndpointManager, OutputManagerAware {

	private static final Log LOG = LogFactory
			.getLogger(AbstractEndpointManager.class);

	private EndpointDAO _endpointDAO;
	private CacheQueryStrategy _cacheQueryStrategy;
	private Map<String, ActiveEndpointType> _activeEndpointTypes;
	private StatusChangeSupport _statusChangeSupport;
	private OutputManager _outputManager;
	private Object _semaphore;

	/**
	 * Simple constructor which just instantiates the internal objects
	 */
	protected AbstractEndpointManager() {
		_semaphore = new Object();
		_statusChangeSupport = new StatusChangeSupport();
		_activeEndpointTypes = new HashMap<String, ActiveEndpointType>();
		setCacheQueryStrategy(createDefaultCacheQueryStrategy());
		setEndpointDAO(createDefaultEndpointDAO());
	}

	/**
	 * Constructor with DAO specified
	 *
	 * * @param endpointDAO not <code>null</code>
	 */
	protected AbstractEndpointManager(EndpointDAO endpointDAO) {
		_semaphore = new Object();
		_statusChangeSupport = new StatusChangeSupport();
		_activeEndpointTypes = new HashMap<String, ActiveEndpointType>();
		setCacheQueryStrategy(createDefaultCacheQueryStrategy());
		setEndpointDAO(endpointDAO);
	}

	/**
	 * Called inside <code>createActiveEndpoint</code> after the EndpointDef has
	 * been validated and the EndpointTypeHandler has created the actual
	 * endpoint object. If an error occurs an exception should be thrown.
	 *
	 * @param activeEndpoint
	 *            not <code>null</code>
	 */
	protected abstract void activateEndpoint(ActiveEndpoint activeEndpoint);

	/**
	 * Called inside <code>destroyActiveEndpoint</code> before the
	 * EndpointTypeHandler is called to destroy the endpoint object. If an error
	 * occurs an exception should be thrown.
	 *
	 * @param activeEndpoint
	 *            not <code>null</code>
	 */
	protected abstract void deactivateEndpoint(ActiveEndpoint activeEndpoint);

	/**
	 * Called whenever an Endpoint's status is first set to PAUSE.
	 *
	 * @param activeEndpoint
	 *            not <code>null</code>
	 */
	protected abstract void pauseActiveEndpoint(ActiveEndpoint activeEndpoint);

	/**
	 * Called whenever an Endpoint's status is first set from PAUSE.
	 *
	 * @param activeEndpoint
	 *            not <code>null</code>
	 */
	protected abstract void restartActiveEndpoint(ActiveEndpoint activeEndpoint);

	/**
	 * Called by the manager to create an EndpointTypeHandler
	 *
	 * @param endpointTypeDef
	 *            not <code>null</code> definition of the type
	 * @return not <code>null</code>
	 */
	protected abstract EndpointTypeHandler createEndpointTypeHandler(
			EndpointTypeDef endpointTypeDef);

	/**
	 * Method to allow implementors to provide there own CacheQueryStrategy as
	 * opposed to DefaultCacheQueryStrategy
	 *
	 * @return not <code>null</code>
	 */
	protected CacheQueryStrategy createDefaultCacheQueryStrategy() {
		return new DefaultCacheQueryStrategy();
	}

	/**
	 * Method to allow implementors to provide there own EndpointDAO as opposed
	 * to MemoryDAO
	 *
	 * @return not <code>null</code>
	 */
	protected EndpointDAO createDefaultEndpointDAO() {
		return new MemoryDAO();
	}


	/**
	 * @throws Exception
	 * @see EndpointManager#createActiveEndpoint(EndpointDef)
	 */
	public ActiveEndpoint createActiveEndpoint(EndpointDef endpointDef) throws Exception {

		validateEndpointDef(endpointDef);

		ActiveEndpoint activeEndpoint = null;
		String endpointType = endpointDef.getType();

        ActiveEndpointType activeType = _activeEndpointTypes.get(endpointType);
        if (activeType == null) {
            throw new InvalidDefinitionException("type: " + endpointType,
                    OutputErrorCode.REFERENCE_INVALID);
        }

        //verify endpoint does not exist
        String name = endpointDef.getName();
        ActiveEndpoint lookupActiveEndpoint =  lookupActiveEndpoint(endpointType, name);

        if (lookupActiveEndpoint != null) {
            throw new InvalidDefinitionException("name: " + name,
                                                 OutputErrorCode.NAME_ALREADY_DEFINED);
        }

        if (activeType.getEndpointTypeDef().isEnabled()) {
            //set default endpoint status to OK
            endpointDef.setStatusInfo(
                                      StatusUtils.createEndpointStatus(EndpointStatus.OK, null));
            EndpointTypeHandler typeHandler = activeType.getEndpointTypeHandler();
            EndpointTypeDef type = activeType.getEndpointTypeDef();
            endpointDef.setTypeId(type.getId());
            try {
                OutputEndpoint endpoint = typeHandler.createEndpoint(endpointDef);
                if (!StatusUtils.isStatusOK(endpoint.queryEndpointStatus()))
                {
                    throw new InvalidDefinitionException(endpoint.queryEndpointStatus().getDetail(),
                                                         OutputErrorCode.REFERENCE_INVALID);
                }
                OutputUtil.setOutputManager(endpoint, _outputManager);
                //persist endpointDef
                endpointDef = _endpointDAO.createEndpointDef(endpointDef);
                activeEndpoint = new ActiveEndpoint(endpointDef, endpoint);
                LOG.info("Enpoint CREATED: " + name + ", " + endpointType);
            } catch (Exception ex) {
                if ((ex instanceof InvalidDefinitionException)) {
                    throw ex;
                }
                LOG.error("Error loading end point def :" + ex.toString());
            }
        }
        return activeEndpoint;
	}

    private ActiveEndpoint loadActiveEndpoint(EndpointDef endpointDef) {
        ActiveEndpoint activeEndpoint = null;

        if (endpointDef == null) {
            return null;
        }

        String endpointType = endpointDef.getType();
        String name = endpointDef.getName();
        ActiveEndpointType activeType = _activeEndpointTypes.get(endpointType);
        if (activeType == null) {
            throw new InvalidDefinitionException("type: " + endpointType,
                    OutputErrorCode.REFERENCE_INVALID);
        }

        // Added for CR 346,831
        // To retrieve all sources (both enabled and disabled) in ConfigureOutputSettings
        // Removed the if condition activeType.getEndpointTypeDef().isEnabled()
        
        EndpointTypeHandler typeHandler = activeType.getEndpointTypeHandler();
        endpointDef.setTypeId(activeType.getEndpointTypeDef().getId());

        try {
            OutputEndpoint endpoint = typeHandler.createEndpoint(endpointDef);
            OutputUtil.setOutputManager(endpoint, _outputManager);
            activeEndpoint = new ActiveEndpoint(endpointDef, endpoint);
            //LH - backward compatibility:  set default status info to OK
            if (activeEndpoint.getStatusInfo() == null) {
                activeEndpoint.setStatusInfo(
                                 StatusUtils.createEndpointStatus(EndpointStatus.OK, null));

            }
            return activeEndpoint;
        } catch (Exception ex) {

            LOG.error("Error loading end point def :" + ex.toString());
        }

        return null;
   }

	private void validateEndpointDef(EndpointDef endpointDef) {

		if (endpointDef == null) {
			throw new IllegalArgumentException("endpointDef argument is null");
		}

		String name = endpointDef.getName();
		if (name == null) {
			throw new InvalidDefinitionException("name: " + name,
					OutputErrorCode.MISSING_DATA);
		}

		String endpointType = endpointDef.getType();
		if (endpointType == null) {
			throw new InvalidDefinitionException("type: " + endpointType,
					OutputErrorCode.MISSING_DATA);
		}
	}

	/**
	 * Returns a count of ActiveEndpointTypes
	 *
	 * @return count
	 */
	public int getActiveEndpointTypeCount() {
		synchronized (_semaphore) {
			return _activeEndpointTypes.size();
		}
	}

	/**
	 * @see EndpointManager#readEndpointDefs()
	 */
	public EndpointDefList readEndpointDefs(EndpointTypeDef typeDef) {
		return _endpointDAO.getEndpointDefByType(typeDef);
	}

	/**
	 * @see EndpointManager#readEndpointTypeDefs()
	 */
	public EndpointTypeDefList readEndpointTypeDefs() {
		return _endpointDAO.readAllEndpointTypeDefs();
	}

	/**
	 * @see EndpointManager#getActiveEndpointTypes()
	 */
	public Collection<ActiveEndpointType> getActiveEndpointTypes() {
			return getActiveEndpointTypes(false);
	}

	public Collection<ActiveEndpointType> getActiveEndpointTypes(boolean getAll) {
		synchronized (_semaphore) {
			ArrayList<ActiveEndpointType> result = new ArrayList<ActiveEndpointType>();
			Iterator<ActiveEndpointType> i = _activeEndpointTypes.values().iterator();
			while (i.hasNext()) {
				ActiveEndpointType def = i.next();
				if (getAll || def.getEndpointTypeDef().isEnabled()) {
					result.add(def);
				}
			}
			return result;
		}
	}

	/*
	 * TODO:  modify to build list once and save in memory
	 */
	public Collection<ActiveEndpointType> getActiveDeviceVendorEndpointTypes(String deviceType, boolean getAll) {
		synchronized (_semaphore) {
			//Loop through each of the 
			ArrayList<ActiveEndpointType> result = new ArrayList<ActiveEndpointType>();
			ActiveEndpointType deviceTypeEndpoint = _activeEndpointTypes.get(deviceType);
			
			Map<String,EndpointTypeHandler> deviceSubHandlers  = 
					deviceTypeEndpoint.getEndpointTypeHandler().getSubHandlers();

			for (String deviceSubHandler : deviceSubHandlers.keySet()) {
				ActiveEndpointType activeType = null;
				EndpointTypeHandler handler = deviceSubHandlers.get(deviceSubHandler);
				if (handler != null && handler.isEnabled()) {
					
			        EndpointTypeDef endpointTypeDef = OutputUtil.createEndpointTypeDef(
			        		handler.getEndpointCategory());
			        endpointTypeDef.setType(deviceSubHandler);
			        endpointTypeDef.setEnabled(true);
			        endpointTypeDef.setProperties(handler.getProperties());					
				
					
					OutputUtil.setOutputManager(handler, _outputManager);
					activeType = new ActiveEndpointType(endpointTypeDef, handler);
					result.add(activeType);
				}		
			}
		
			return result;
		}
	}	
	
	
	
	/**
	 * @see EndpointManager#cleanUpActiveEndpoint(String)
	 */
	public void cleanUpActiveEndpoint(int endpointId) {
		synchronized (_semaphore) {

			ActiveEndpoint activeEndpoint = lookupActiveEndpoint(endpointId);
			activeEndpoint = cleanUpActiveEndpoint(activeEndpoint);

		}

	}

	private ActiveEndpoint cleanUpActiveEndpoint(ActiveEndpoint activeEndpoint) {
		try {

			deactivateEndpoint(activeEndpoint);

		} finally {
		    //noop
		}

        return updateEndpointStatus(activeEndpoint, StatusUtils
                                    .createEndpointStatus(EndpointStatus.STOPPED, "stopped"));
	}

	/**
	 * @see EndpointManager#deleteActiveEndpoint(String)
	 */
	public void deleteActiveEndpoint(int endpointId) {

		synchronized (_semaphore) {

			ActiveEndpoint activeEndpoint = lookupActiveEndpoint(endpointId);

			try {
				activeEndpoint = cleanUpActiveEndpoint(activeEndpoint);
			} catch (Exception e) {
				LOG.warn("Failed to CleanUP Active Endpoint", e);
			} finally {
				_endpointDAO.deleteEndpointDef(activeEndpoint.getEndpointDef());
			}
		}

	}

	/**
	 * @see EndpointManager#getActiveEndpoint(String)
	 */
	public ActiveEndpoint getActiveEndpoint(OutputRequest outputRequest) {
		synchronized (_semaphore) {
			return lookupActiveEndpoint(outputRequest);
		}
	}

	private ActiveEndpoint lookupActiveEndpoint(OutputRequest outputRequest) {

	    ActiveEndpoint activeEndpoint = lookupActiveEndpoint(
	                                            Integer.valueOf(outputRequest.getDestID()));

	    if (!OutputConstants.PRINT.equalsIgnoreCase(outputRequest.getDestType())) {
	        if (activeEndpoint == null) {
	            throw new UnknownObjectException(Integer.toString(outputRequest.getDestID()));
	        }

	        outputRequest.setDestName(activeEndpoint.getEndpointDef().getName());
	        outputRequest.setDestType(activeEndpoint.getEndpointDef().getType());
            return activeEndpoint;
        }

	    if (activeEndpoint != null) {

	       PrintDestination printDestination = (PrintDestination) activeEndpoint.getEndpoint();
	       if (!isPrinterActive(printDestination.getPrinterName())) {
	            activeEndpoint = null;
	       }
	    }

        if (activeEndpoint == null) {
            if (outputRequest.isDelegateOnFailure()) {
                return useAuxPrinter(outputRequest);
            }
            throw new UnknownObjectException(Integer.toString(outputRequest.getDestID()));
        }

        outputRequest.setDestName(activeEndpoint.getEndpointDef().getName());
        outputRequest.setDestType(activeEndpoint.getEndpointDef().getType());
        return activeEndpoint;
    }

    @SuppressWarnings("unchecked")
    private ActiveEndpoint useAuxPrinter(OutputRequest outputRequest) {

        ActiveEndpoint activeEndpoint = null;
        for (DestDef destDef : outputRequest.getDelegationList()) {

            activeEndpoint = lookupActiveEndpoint(destDef.getId());
            if (activeEndpoint != null) {

                PrintDestination printDestination = (PrintDestination) activeEndpoint.getEndpoint();
                if (!isPrinterActive(printDestination.getPrinterName())) {
                    continue;
                }

                outputRequest.setDestID(destDef.getId());
                outputRequest.setDestName(activeEndpoint.getEndpointDef().getName());
                outputRequest.setDestType(activeEndpoint.getEndpointDef().getType());
                outputRequest.setProperties((Map<String, String>) destDef.getProperties());
                break;
            }
        }

        if (activeEndpoint == null) {
            throw new UnknownObjectException(Integer.toString(outputRequest.getDestID()));
        }
        return activeEndpoint;
    }

    public boolean isPrinterActive(String prnName) {

        PrintService[] prnSvcs;
        PrintService prnSvc = null; // get all print services for this machine
        prnSvcs = PrintServiceLookup.lookupPrintServices(null, null);
        if (prnSvcs.length > 0) {
            int ii = 0;
            while (ii < prnSvcs.length) {
                if (prnSvcs[ii].getName().equalsIgnoreCase(prnName)) {
                    prnSvc = prnSvcs[ii];
                    break;
                }
                ii++;
            }
        }
        if (prnSvc == null) {
            return false;
        }
        return true;
    }

    /**
     * @see EndpointManager#getActiveEndpoint(String)
     */
    public ActiveEndpoint getActiveEndpoint(int endpointId) {
        synchronized (_semaphore) {
            return lookupActiveEndpoint(endpointId);
        }
    }

	public ActiveEndpoint getActiveEndpoint(String typeName, String endpointName) {
        synchronized (_semaphore) {
            return lookupActiveEndpoint(typeName, endpointName);
        }
	}

	public Collection<ActiveEndpoint> getActiveEndpoints(String endpointType) {
		synchronized (_semaphore) {
            ArrayList<ActiveEndpoint> endpointArr = new ArrayList<ActiveEndpoint>();
        	ActiveEndpointType activeType = _activeEndpointTypes.get(endpointType);
        	
        	// Added for CR 346,831
        	// To show the disabled source - removed the isEnabled() validation
        	if ((activeType != null)) {
        	//------------
        		
                EndpointDefList endpointDefList = _endpointDAO.getEndpointDefByType(
                                                           activeType.getEndpointTypeDef());
                for (EndpointDef endpointDef : endpointDefList) {
                    try {
                        ActiveEndpoint activeEndpoint =
                            lookupActiveEndpoint(endpointDef.getId());
                        if (activeEndpoint != null) {
                            endpointArr.add(activeEndpoint);
                        }
                    } catch (Exception e) {
                        LOG.warn("Error loading endpoint name-"
                                  + endpointDef.getName()
                                  + "  type-"
                                  + endpointDef.getType()
                                  + ":  "
                                  + e.toString(), e);
                    }
                }
               EndpointTypeHandler typeHandler = activeType.getEndpointTypeHandler();
               typeHandler.updateEndpoints(endpointArr) ; 
        	}

        	return endpointArr;
		}
	}

	public Collection<ActiveEndpoint> getActiveEndpoints() {
		synchronized (_semaphore) {
            ArrayList<ActiveEndpoint> endpointArr = new ArrayList<ActiveEndpoint>();
            for (ActiveEndpointType activeType : _activeEndpointTypes.values()) {
                if (activeType.getEndpointTypeDef().isEnabled()) {
                    endpointArr.addAll(getActiveEndpoints(
                                            activeType.getEndpointTypeDef().getType()));
                }
            }
            return endpointArr;
		}
	}

	/**
	 * @see EndpointManager#getActiveEndpointType(String)
	 */
	public ActiveEndpointType getActiveEndpointType(String endpointType) {

		if (endpointType == null) {
			throw new IllegalArgumentException("endpointType argument is null");
		}

		ActiveEndpointType activeEndpointType;
		synchronized (_semaphore) {
			activeEndpointType = _activeEndpointTypes.get(endpointType);
		}

		if (activeEndpointType == null) {
			throw new UnknownObjectException(endpointType);
		}

		return activeEndpointType;
	}

	/**
	 * Method which loads the ActiveEndpointTypes from the DAO. Is never called
	 * by the abstract class directly but is available as a convenience for
	 * implementors so they can load the type metadata once they know how to
	 * construct type handlers.
	 */
	protected void loadActiveEndpointTypes() {

		synchronized (_semaphore) {

			EndpointTypeDefList typeDefList = _endpointDAO
					.readAllEndpointTypeDefs();

			Iterator<EndpointTypeDef> i = typeDefList.iterator();
			while (i.hasNext()) {
				EndpointTypeDef def = i.next();
				createActiveEndpointType(def);
			}
		}
	}

	/**
	 * Thread safe call to look up an ActiveEndpointType without throwing an
	 * exception if the type is not valid
	 *
	 * @param endpointType
	 *            type to lookup
	 * @return <code>null</code> if not found
	 */
	protected ActiveEndpointType lookupActiveEndpointType(String endpointType) {
		synchronized (_semaphore) {
			return _activeEndpointTypes.get(endpointType);
		}
	}

	/**
	 * @see EndpointManager#queryActiveEndpoints(Map)
	 */
	public Collection<ActiveEndpoint> queryActiveEndpoints(
			Map<String, String> queryParams) {

		Collection<ActiveEndpoint> results = new ArrayList<ActiveEndpoint>();
		synchronized (_semaphore) {
            _cacheQueryStrategy.queryCache(
                                           queryParams,
                                           getActiveEndpoints(),
                                           results);
		}
		return results;
	}

	/**
	 * Thread safe call to install a new EndpointTypeHandler in the class's list
	 * of handlers
	 *
	 * @param endpointTypeDef
	 *            not <code>null</code> metadata
	 * @param typeHandler
	 *            not <code>null</code> handler
	 * @return ActiveEndpointType
	 */
	protected ActiveEndpointType createActiveEndpointType(
			EndpointTypeDef endpointTypeDef) {

		if (endpointTypeDef == null) {
			throw new IllegalArgumentException(
					"endpointTypeDef argument is null");
		}

		String type = endpointTypeDef.getType();
		if (type == null) {
			throw new InvalidDefinitionException("type: " + type,
					OutputErrorCode.MISSING_DATA);
		}
		ActiveEndpointType activeType = null;

		synchronized (_semaphore) {
			if (_activeEndpointTypes.containsKey(type)) {
				throw new InvalidDefinitionException("type: " + type,
						OutputErrorCode.NAME_ALREADY_DEFINED);
			}

			EndpointTypeHandler handler = createEndpointTypeHandler(endpointTypeDef);
			if (handler != null && handler.isEnabled()) {
				OutputUtil.setOutputManager(handler, _outputManager);
				activeType = new ActiveEndpointType(endpointTypeDef, handler);
				_activeEndpointTypes.put(type, activeType);
			}
		}
		return activeType;
	}

	/**
	 * Thread safe method to remove and ActiveEndpointType from the list of
	 * current types and update its metadata to enabled = false in the DAO
	 *
	 * @param activeType
	 *            not <code>null</code>
	 * @return the updated metadata.
	 */
	protected EndpointTypeDef disableActiveEndpointType(
			ActiveEndpointType activeType) {

		if (activeType == null) {
			throw new IllegalArgumentException("activeType argument is null");
		}

		EndpointTypeDef typeDef = activeType.getEndpointTypeDef();
		String typeName = typeDef.getType();
		synchronized (_semaphore) {
			typeDef.setEnabled(false);
			OutputUtil.setOutputManager(activeType.getEndpointTypeHandler(),
					null);
			typeDef = _endpointDAO.updateEndpointTypeDef(new Integer(1),
						typeDef);
			activeType.setEndpointTypeDef(typeDef);
		}
		return typeDef;
	}

	/**
	 * The CacheQueryStrategy is strategy pattern implementation for perform
	 * endpoint query operations
	 *
	 * @return not <code>null</code>
	 */
	public CacheQueryStrategy getCacheQueryStrategy() {
		return _cacheQueryStrategy;
	}

	/**
	 * The CacheQueryStrategy is strategy pattern implementation for perform
	 * endpoint query operations
	 *
	 * @param cacheQueryStrategy
	 *            not <code>null</code>
	 */
	public void setCacheQueryStrategy(CacheQueryStrategy cacheQueryStrategy) {

		if (cacheQueryStrategy == null) {
			throw new IllegalArgumentException(
					"cacheQueryStrategy argument is null");
		}

		OutputUtil.setOutputManager(_cacheQueryStrategy, null);
		_cacheQueryStrategy = cacheQueryStrategy;
		OutputUtil.setOutputManager(_cacheQueryStrategy, _outputManager);
	}

	/**
	 * @see EndpointManager#updateEndpointDef(EndpointDef)
	 */
	public ActiveEndpoint updateEndpointDef(EndpointDef endpointDef) {

		EndpointDef myEndpointDef;
		ActiveEndpoint activeEndpoint;

		synchronized (_semaphore) {

			activeEndpoint = lookupActiveEndpoint(endpointDef.getId());

			if (activeEndpoint == null) {
	            throw new InvalidDefinitionException("id: " + endpointDef.getId(),
	                                                 OutputErrorCode.REFERENCE_INVALID);
			}
			myEndpointDef = activeEndpoint.getEndpointDef();
			myEndpointDef.setName(endpointDef.getName());
			myEndpointDef.setDescription(endpointDef.getDescription());
			myEndpointDef.setProperties(endpointDef.getProperties());
			myEndpointDef.setStatusInfo(endpointDef.getStatusInfo());
			try {
				ActiveEndpointType activeType = _activeEndpointTypes
						.get(activeEndpoint.getEndpointDef().getType());
				EndpointTypeHandler typeHandler = activeType
						.getEndpointTypeHandler();
				OutputEndpoint endpoint = typeHandler
						.createEndpoint(myEndpointDef);

				//only update the endpoint if status is OK.
                if (endpoint.queryEndpointStatus().getStatusCode()
                == OutputConstants.EndpointStatus.OK.statusCode()) {
                     myEndpointDef = _endpointDAO.updateEndpointDef(
                                                                   new Integer(myEndpointDef.getId()), myEndpointDef);
                                                           activeEndpoint.setEndpointDef(myEndpointDef);
                } else {
                    throw new InvalidDefinitionException(endpoint.queryEndpointStatus().getDetail(),
                                                         OutputErrorCode.DESTINATION_INVALID);
                }


			} catch (Exception e) {
				myEndpointDef = _endpointDAO.getEndpointDef(myEndpointDef
						.getId());
				activeEndpoint.setEndpointDef(myEndpointDef);
				if ((e instanceof InvalidDefinitionException)
				&& DestinationType.FILE.toString().equals(endpointDef.getType())) {
					throw new OutputException(e.getMessage(),
							OutputErrorCode.DESTINATION_INVALID);
				}
				throw new OutputException(
						OutputErrorCode.PERSISTENCE_MERGE_ERROR, e);
			}
		}

		return activeEndpoint;
	}

    //lookup an existing active endpoint -- throws error if endpoint is not found
	private ActiveEndpoint lookupActiveEndpoint(int endpointId) {
        EndpointDef endpointDef =  _endpointDAO.getEndpointDef(endpointId);
        if (endpointDef == null) {
            throw new UnknownObjectException(Integer.toString(endpointId));
        }
        ActiveEndpoint activeEndpoint = loadActiveEndpoint(endpointDef);
        return activeEndpoint;
	}

    //search for endpoint - used to verify endpoint existence - can return null if
	//endpoint is not found
    private ActiveEndpoint lookupActiveEndpoint(String endpointType, String endpointName) {
        EndpointDef endpointDef = _endpointDAO.getEndpointDef(endpointName, endpointType);

        return loadActiveEndpoint(endpointDef);
    }


	/**
	 * @see EndpointManager#updateEndpointTypeDef(EndpointTypeDef)
	 */
	public EndpointTypeDef updateEndpointTypeDef(EndpointTypeDef typeDef) {

		if (typeDef == null) {
			throw new IllegalArgumentException("typeDef argument is null");
		}
		String typeName = typeDef.getType();
		EndpointTypeDef myEndpointTypeDef;
		synchronized (_semaphore) {

			myEndpointTypeDef = _endpointDAO.updateEndpointTypeDef(new Integer(
					1), typeDef);
			ActiveEndpointType activeType = _activeEndpointTypes.get(typeName);
			if (activeType != null) {
				activeType.setEndpointTypeDef(myEndpointTypeDef);
			}
		}
		return myEndpointTypeDef;
	}

	/**
	 * @see EndpointManager#updateEndpointStatus(String, StatusInfo)
	 */
	public ActiveEndpoint updateEndpointStatus(int endpointId,
	                                           StatusInfo info) {

        ActiveEndpoint activeEndpoint;
        activeEndpoint = lookupActiveEndpoint(endpointId);
        activeEndpoint.setStatusInfo(info);
        return updateEndpointStatus(activeEndpoint, info);

	}

	/**
	 * @see EndpointManager#addStatusChangeListener(StatusChangeListener)
	 */
	public void addStatusChangeListener(
			StatusChangeListener statusChangeListener) {
		_statusChangeSupport.addStatusChangeListener(statusChangeListener);
	}

	/**
	 * @see EndpointManager#addStatusChangeListener(String,
	 *      StatusChangeListener)
	 */
	public void addStatusChangeListener(int endpointId,
	                                    StatusChangeListener statusChangeListener) {

		ActiveEndpoint activeEndpoint;
		synchronized (_semaphore) {
			activeEndpoint = lookupActiveEndpoint(endpointId);
		}

		_statusChangeSupport.addStatusChangeListener(activeEndpoint,
				statusChangeListener);
	}

	/**
	 * @see EndpointManager#getStatusChangeListeners()
	 */
	public Collection<StatusChangeListener> getStatusChangeListeners() {
		return _statusChangeSupport.getStatusChangeListeners();
	}

	/**
	 * @see EndpointManager#pauseActiveEndpoint(String)
	 */
	public ActiveEndpoint pauseActiveEndpoint(int endpointId) {
	    ActiveEndpoint activeEndpoint = updateEndpointStatus(endpointId,
	                         StatusUtils
	                         .createEndpointStatus(EndpointStatus.PAUSED,
	                                 "Endpoint Paused"));


	    activeEndpointStopConsumeMsgs(activeEndpoint);
		return activeEndpoint;
	}

	/**
	 * @see EndpointManager#removeStatusChangeListener(StatusChangeListener)
	 */
	public void removeStatusChangeListener(
			StatusChangeListener statusChangeListener) {
		_statusChangeSupport.removeStatusChangeListener(statusChangeListener);
	}

	/**
	 * @see EndpointManager#restartActiveEndpoint(String)
	 */
	public ActiveEndpoint restartActiveEndpoint(int endpointId) {

		ActiveEndpoint activeEndpoint;
		activeEndpoint = updateEndpointStatus(endpointId, StatusUtils
                             .createEndpointStatus(EndpointStatus.OK,
                             "Endpoint Ready"));
		activeEndpointConsumeMsgs(activeEndpoint);

		return activeEndpoint;
	}

	private ActiveEndpoint updateEndpointStatus(ActiveEndpoint activeEndpoint,
			StatusInfo statusInfo) {

		assert activeEndpoint != null : "null argument";

		activeEndpoint.setStatusInfo(statusInfo);
		ActiveEndpoint updatedEndpoint = updateEndpointDef(activeEndpoint.getEndpointDef());
		return updatedEndpoint;
	}

	/**
	 * Sets the OutputManager with which we are running. This call will cascade
	 * to child OutputEndpoints and EndpointTypeHandlers
	 *
	 * @param outputManager
	 *            the outputManager to set
	 */
	public void setOutputManager(OutputManager outputManager) {

		synchronized (_semaphore) {
			_outputManager = outputManager;

			OutputUtil.setOutputManager(_endpointDAO, _outputManager);
			OutputUtil.setOutputManager(_cacheQueryStrategy, _outputManager);

			for (ActiveEndpointType activeType : _activeEndpointTypes.values()) {

				EndpointTypeHandler typeHandler = activeType
						.getEndpointTypeHandler();
				OutputUtil.setOutputManager(typeHandler, _outputManager);

			}
		}
	}

	/**
	 * Returns the OutputManager we received from OutputManagerAware.
	 *
	 * @return the _outputManager
	 */
	public OutputManager getOutputManager() {
		return _outputManager;
	}

	/**
	 * Return the DAO we are using
	 *
	 * @return not <code>null</code>
	 */
	public EndpointDAO getEndpointDAO() {
		return _endpointDAO;
	}

	/**
	 * Sets the DAO and will cause a sync operation to occur
	 *
	 * @param endpointDAO
	 *            not <code>null</code>
	 */
	public void setEndpointDAO(EndpointDAO endpointDAO) {
		if (endpointDAO == null) {
			throw new IllegalArgumentException("endpointDAO argument is null");
		}

		synchronized (_semaphore) {

			OutputUtil.setOutputManager(_endpointDAO, null);
			_endpointDAO = endpointDAO;
			OutputUtil.setOutputManager(_endpointDAO, _outputManager);
		}
	}

	protected void activeEndpointConsumeMsgs(ActiveEndpoint activeEndpoint) {
	    //NO OP
	}

	protected void activeEndpointStopConsumeMsgs(ActiveEndpoint activeEndpoint) {
	    //NO OP
	}

	protected void resubmitPausedJobs(ActiveEndpoint activeEndpoint) {
	    HashMap<String,String> queryOptions = new HashMap<String,String>();
	    queryOptions.put(OutputConstants.KEY_DEST_ID, String.valueOf(
	                                                activeEndpoint.getEndpointDef().getId()));
	    queryOptions.put(OutputConstants.KEY_JOB_STATUS,
	                     String.valueOf(OutputConstants.RequestStatus.DEST_PAUSED.statusCode()));

	    _outputManager.resubmitOutputJob(queryOptions);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.mckesson.eig.output.local.EndpointManager#createDevice(com.mckesson.eig.output.model.DeviceInfo)
	 * Creates a deviceInfo object and persists in the output_listofvalue table
	 */
	public DeviceInfo createDevice(DeviceInfo deviceInfo) {
		//Set device type id  (parent id)
		ActiveEndpointType deviceType = _activeEndpointTypes.get(deviceInfo.getType());
        EndpointTypeDef type = deviceType.getEndpointTypeDef();
        deviceInfo.setTypeId(type.getId());
        deviceInfo.setId(0);
        deviceInfo.setLov(null);
        deviceInfo.setName(deviceInfo.getName().trim());
        
        OutputEndpoint outputEndpoint = 
        		deviceType.getEndpointTypeHandler().createEndpoint(deviceInfo);
        StatusInfo outputEndpointStatus = outputEndpoint.queryEndpointStatus(true);
       
        if (outputEndpointStatus.getStatusCode()
                != OutputConstants.EndpointStatus.OK.statusCode()) {
                    throw new InvalidDefinitionException(outputEndpointStatus.getDetail(),
                                                         OutputErrorCode.REFERENCE_INVALID);
                }
        
        EndpointDef addedDevice = _endpointDAO.createEndpointDef(deviceInfo);
        deviceInfo.setLov(addedDevice.getLov());
        deviceInfo.setId(addedDevice.getId());
		deviceInfo.setStatusInfo(outputEndpointStatus);
		return deviceInfo;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.mckesson.eig.output.local.EndpointManager#getDevicesByType(java.util.List)
	 * retrieves a list of all devices by type(s)
	 */
    public List<EndpointDef> getDevicesByType(List<String> typeNames) {

    	return _endpointDAO.getEndpoints(typeNames);

    }
    
    /*
     * (non-Javadoc)
     * @see com.mckesson.eig.output.local.EndpointManager#getDevice(int)
     * retrieves the deviceInfo object by id
     */
    
    public EndpointDef getDevice(int deviceId) {
    	EndpointDef deviceInfo = _endpointDAO.getEndpointDef(deviceId);
    	if (deviceInfo != null) {
        	ActiveEndpointType activeType = _activeEndpointTypes.get(deviceInfo.getType());
            if (activeType == null) {
                return new DeviceInfo();
            }   
            
            OutputEndpoint outputEndpoint = activeType.getEndpointTypeHandler().createEndpoint(deviceInfo);
            deviceInfo.setStatusInfo(outputEndpoint.queryEndpointStatus());    	
        	return deviceInfo;		
    	}
    	return new DeviceInfo();
    }
    
    /*
     * (non-Javadoc)
     * @see com.mckesson.eig.output.local.EndpointManager#getDevice(java.lang.String, java.lang.String)
     * retrieves the deviceInfo object by name and type
     */
    public EndpointDef getDevice(String name, String defType) {
    	ActiveEndpointType activeType = _activeEndpointTypes.get(defType);
        if (activeType == null) {
            throw new InvalidDefinitionException("type: " + defType,
                    OutputErrorCode.REFERENCE_INVALID);
        }    	
    	
        EndpointDef deviceInfo = _endpointDAO.getEndpointDef(name, defType);
        if (deviceInfo != null) {
	        OutputEndpoint outputEndpoint = activeType.getEndpointTypeHandler().createEndpoint(deviceInfo);
	        deviceInfo.setStatusInfo(outputEndpoint.queryEndpointStatus());    	
        }
	    return deviceInfo;
    }   
	
    /*
     * (non-Javadoc)
     * @see com.mckesson.eig.output.local.EndpointManager#updateDevice(com.mckesson.eig.output.model.DeviceInfo)
     * Updates the deviceInfo object
     */
	public DeviceInfo updateDevice(DeviceInfo deviceInfo) {
		//Set device type id  (parent id) and lov  - represents an update otherwise dao will create new device
		EndpointDef tmpInfo = _endpointDAO.getEndpointDef(deviceInfo.getId());
        deviceInfo.setTypeId(tmpInfo.getTypeId());
        deviceInfo.setLov(tmpInfo.getLov());
        deviceInfo.setName(deviceInfo.getName().trim());

    	ActiveEndpointType activeType = _activeEndpointTypes.get(deviceInfo.getType());
        if (activeType == null) {
            throw new InvalidDefinitionException("type: " + deviceInfo.getType(),
                    OutputErrorCode.REFERENCE_INVALID);
        }    	
        OutputEndpoint outputEndpoint = activeType.getEndpointTypeHandler().createEndpoint(deviceInfo);
        StatusInfo status = outputEndpoint.queryEndpointStatus(true);
        deviceInfo.setStatusInfo(status);
        
        if (status.getStatusCode()!= OutputConstants.EndpointStatus.OK.statusCode()) {
            throw new InvalidDefinitionException(status.getDetail(), OutputErrorCode.REFERENCE_INVALID);
        }       
        //endpoint validated successfully
        _endpointDAO.updateEndpointDef(deviceInfo.getId(), deviceInfo);

		return deviceInfo;
	}    
    
	/*
	 * (non-Javadoc)
	 * @see com.mckesson.eig.output.local.EndpointManager#testDevice(com.mckesson.eig.output.model.DeviceInfo)
	 * Method used to implement the "test" device feature for DISC devices
	 * this method creates and outputendpoint object and
	 * calls the queryEndpointStatus which validates the device
	 */
    public DeviceInfo testDevice(DeviceInfo deviceInfo) {
    	ActiveEndpointType activeType = _activeEndpointTypes.get(deviceInfo.getType());
        if (activeType == null) {
            throw new InvalidDefinitionException("type: " + deviceInfo.getType(),
                    OutputErrorCode.REFERENCE_INVALID);
        }    	
    	
        OutputEndpoint outputEndpoint = activeType.getEndpointTypeHandler().createEndpoint(deviceInfo);        
        deviceInfo.setStatusInfo(outputEndpoint.queryEndpointStatus(true));        
    	return deviceInfo;
    }

    /*
     * (non-Javadoc)
     * @see com.mckesson.eig.output.local.EndpointManager#deleteDevice(int, boolean)
     * Delete specified deviceInfo object if the device is not used in a defined DISC queue
      * Deletes the device with the passed in deviceId if it is not in use by a DISC queue
     * if the force value is true, delete the device even if it is in use by a DISC queue
    */
    public void deleteDevice(int deviceId, boolean force) {
    	if (!force) {
    		checkIfDeviceIsInUse(deviceId);  
    	}
    	deleteNotInUseDevice(deviceId);
    }
    
    /*
     * Checks to determine if specified device is being used in a defined DISC queue
     *
     */
    private void checkIfDeviceIsInUse(int deviceId) {
		synchronized (_semaphore) {
			//Verify device is not attached to a queue if force is not true
			for (ActiveEndpoint destDef : getActiveEndpoints(DestinationType.DISC.toString())) {
				String destinationDeviceId = destDef.getProperties().getAsString(OutputConstants.KEY_DEST_DEVICE_ID);
				if (Integer.valueOf(destinationDeviceId)== deviceId) {
		            throw new ApplicationException(
		            		"Device cannot be deleted.  There is a queue that is using this device.");
				}
			}
		}    	
    }
    
    /*
     * deletes specified deviceInfo object from database
     */
    private void deleteNotInUseDevice(int deviceId)
    {
		EndpointDef deviceEndpoint = null;
		try {
			synchronized (_semaphore) {
				deviceEndpoint = _endpointDAO.getEndpointDef(deviceId);
				cleanUpActiveEndpoint(deviceId);
				_endpointDAO.deleteEndpointDef(deviceEndpoint);
			}
		} catch (Exception e) {
			if (deviceEndpoint != null) {
				LOG.error("Failed to delete device - " + deviceEndpoint.getId()  + " " + deviceEndpoint.getName()
						+ " .  Contact your system administrator.", e);
			}
		} 

    }
    
    /*
     * (non-Javadoc)
     * @see com.mckesson.eig.output.local.EndpointManager#updateJobStatusWithEndpointStatus(java.util.List)
     * method used to iterate over the destination(queue) type handlers and allow each handler to update the
     * outputJob with additional details (handler(type) dependent)
     */
    public void updateJobStatusWithEndpointStatus(List<OutputJob> outputJobs) {
    	/*
    	 * iterate over the destination(queue) type handlers
    	 * and allow each handler to update the jobs status info
    	 */
    	if (outputJobs.size() < 1) {
    		return;
    	}
    	
    	//loop through jobs and find destination types
    	synchronized(_semaphore) {
    		HashMap<String, List<OutputJob>> outputJobsToTypeMap = new HashMap<String, List<OutputJob>>();
    		for (OutputJob outputJob : outputJobs) {
    			if (outputJobsToTypeMap.containsKey(outputJob.getDestType())) {
    				outputJobsToTypeMap.get(outputJob.getDestType()).add(outputJob);
    			} else {
    				List<OutputJob> outputJobList = new ArrayList<OutputJob>();
    				outputJobList.add(outputJob);
    				outputJobsToTypeMap.put(outputJob.getDestType(), outputJobList);
    			}
    		}
	    	for (ActiveEndpointType endpointType : _activeEndpointTypes.values()) {
	    		if (endpointType.getEndpointTypeHandler() instanceof DestTypeHandler) {
	    			if (outputJobsToTypeMap.containsKey(endpointType.getEndpointTypeDef().getType())) {
		    			DestTypeHandler destHandler = (DestTypeHandler) endpointType.getEndpointTypeHandler();
		    			Collection<ActiveEndpoint> endpoints = getActiveEndpoints(endpointType.getEndpointTypeDef().getType());
		    			destHandler.updateJobStatusInfoWithEndpointStatus(endpoints, 
		    					outputJobsToTypeMap.get(endpointType.getEndpointTypeDef().getType()));
	    			}
	    		}
	    		
	    	}
    	}
   	
    }
}
