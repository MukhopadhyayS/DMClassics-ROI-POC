/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.util.CollectionUtilities;

/**
 * @author OFS
 * @author Jon Anderson
 *
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement (name = "endpointDef")
@XmlType(name = "endpointDef")
public abstract class EndpointDef implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 99;
	private static final int HASH_INIT = 13;

	private transient EndpointCategory _endpointCategory;
    private int _id;
	private String _name;
	private String _type;	
	//15.2 introduce concept of system defined queues - default value provided for backwards compatibility
	private String _creatorType ="user";
	private int _typeId;
	private Map<String, ? extends Object> _properties;
	private String _description;
	private transient OutputLoV _lov;
    //added for cxf migration
    private List<MapModel> _propertyList;
    private StatusInfo _statusInfo;

	public EndpointDef() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @param endpointCategory
	 */
	public EndpointDef(EndpointCategory endpointCategory) {
		_endpointCategory = endpointCategory;
	}

	@Override
	public boolean equals(Object o) {

	    EndpointDef endpointDef = (EndpointDef) o;
	    if (endpointDef._endpointCategory != _endpointCategory) {
	    	return false;
	    }
	    if (!ObjectUtils.equals(endpointDef._name, _name)) {
	        return false;
	    }
        if (!ObjectUtils.equals(endpointDef._description, _description)) {
            return false;
        }
	    if (!ObjectUtils.equals(endpointDef._properties, _properties)) {
	        return false;
	    }
	    if (!ObjectUtils.equals(endpointDef._type, _type)) {
	        return false;
	    }
	    return true;
	}

	@Override
	public int hashCode() {

	    HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
	    builder.append(_endpointCategory);
	    builder.append(_name);
	    builder.append(_properties);
	    builder.append(_type);
	    return builder.toHashCode();
	}

	@Override
	public EndpointDef clone() {
		try {
            EndpointDef endpointDef = (EndpointDef) super.clone();
            if (endpointDef._properties != null) {
                endpointDef._properties =
                    new HashMap<String, Object>(endpointDef._properties);
            }

            return endpointDef;
		} catch (CloneNotSupportedException e) {
			throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
		}
	}

    /**
     * The requested id for the destination
     *
     * @return the _id
     */
     public int getId() {
          return _id;
      }

	  /**
	   * The id for the destination
	   *
	   * @param id set the _id
	  */
     @XmlElement (name = "id")
	  public void setId(int id) {
	      _id = id;
	  }

	/**
	 * The requested name for the destination
	 *
	 * @return the _name
	 */
	public String getName() {
		return _name;
	}

	/**
	 * @param name the _name to set
	 */
	@XmlElement (name = "name")
	public void setName(String name) {
		_name = name;
	}

	/**
	 * The type of the destination
	 *
	 * @return the type
	 * @see com.mckesson.eig.output.model.DestTypeInfo
	 */
	public String getType() {
		return _type;
	}

	/**
	 * @param type the _type to set
	 */
	@XmlElement (name = "type")
	public void setType(String type) {
		_type = type;
	}
	
	/**
	 * The type of the destination
	 *
	 * @return the type
	 * @see com.mckesson.eig.output.model.DestTypeInfo
	 */
	public String getCreatorType() {
		return _creatorType;
	}

	/**
	 * @param type the _creatorType to set
	 */
	@XmlElement (name = "creatorType")
	public void setCreatorType(String creatorType) {
		_creatorType = creatorType;
	}	

	/**
	 * The properties which are used to define the specifics of the destination
	 *
	 * @return the _properties
	 * @see com.mckesson.eig.output.model.DestInfo#getPropertyDefs()
	 */
	public Map<String, ? extends Object> getProperties() {

	    if (CollectionUtilities.hasContent(_properties)) {
	        return _properties;
	    }

	    if (CollectionUtilities.hasContent(_propertyList)) {

	        Map<String, Object> prop = new HashMap<String, Object>();
            for (MapModel mapModel : _propertyList) {
                prop.put(mapModel.getKey().toString(), mapModel.getValue());
	        }
            setProperties(prop);
	    }
		return _properties;
	}

	/**
	 * @param properties the _properties to set
	 */
	@XmlTransient
	public void setProperties(Map<String, ? extends Object> properties) {

        if (properties != null) {

            if (CollectionUtilities.hasContent(_propertyList)) {
                _propertyList.clear();
            } else {
                _propertyList = new ArrayList<MapModel>();
            }

            for (Map.Entry<String, ? extends Object> e : properties.entrySet()) {
                _propertyList.add(new MapModel(e.getKey(), e.getValue()));
            }
            _properties = properties;
        }
	}

	/**
	 * @param description the _description to set
	 */
	@XmlElement (name = "description")
	public void setDescription(String description) {
		_description = description;
	}

	/**
	 * @return the _description
	 */
	public String getDescription() {
		return _description;
	}

	/**
	 * TODO
	 * @return the _endpointCategory
	 */
	public EndpointCategory getEndpointCategory() {
		return _endpointCategory;
	}

	public OutputLoV getLov() {
		return _lov;
	}

	@XmlTransient
	public void setLov(OutputLoV lov) {
		_lov = lov;
	}

	public int getTypeId() {
		return _typeId;
	}
    
	@XmlElement (name = "typeId")
	public void setTypeId(int typeId) {
		_typeId = typeId;
	}


	@XmlElementWrapper(name = "properties")
	@XmlElement(name = "property", type = MapModel.class)
	public void setPropertiesList(List<MapModel> properties) {
	    _propertyList = properties;
	}

	public List<MapModel> getPropertiesList() {
	    
	    if (_properties != null) {
            _propertyList = new ArrayList<MapModel>();
            for (Map.Entry<String, ? extends Object> e : _properties.entrySet()) {
                _propertyList.add(new MapModel(e.getKey(), e.getValue()));
            }
        }
        return _propertyList;
	}

    /**
     * The <code>statusInfo</code> member represents the current status of the destination
     *
     * @return the _statusInfo
     */
    public StatusInfo getStatusInfo() {
        return _statusInfo;
    }

    /**
     * @param statusInfo the _statusInfo to set
     */
    @XmlElement (name = "statusInfo", type = StatusInfo.class)
    public void setStatusInfo(StatusInfo statusInfo) {
        _statusInfo = statusInfo;
    }

}
