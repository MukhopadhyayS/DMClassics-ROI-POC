package com.mckesson.eig.output.device.disc.rimage;

import org.w3c.dom.Document;

import com.mckesson.eig.output.local.device.disc.DiscStatusListener;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.utility.util.StringUtilities;

public class ProductionOrderListener extends AbstractOrderListener {

	private static final  String ORDERSET_STATUS = "OrderSetStatus";
	
	public ProductionOrderListener(DiscStatusListener listener) {
		super(listener);
	}

	@Override
	public void onStatus(String receivedXmlOrderStatus) {
		String errMsg;
		String errCode;
		String state;

		// Replace the base URI in the XML string
		String xmlOrderStatus = receivedXmlOrderStatus;
		Document document = parseXML(xmlOrderStatus);
		
		// if the received xml is not belonging to the production order
		// simply logs and ignore the received message
		if (!ORDERSET_STATUS.equalsIgnoreCase(document.getDocumentElement().getNodeName())) {
			
//			LOG.debug("Received Status: " + receivedXmlOrderStatus);
			return;
		}
		
		String orderId = getElementAtt(document, ORDERSET_STATUS, "OrderSetId");
		int jobId = new Integer(orderId.substring(0, orderId.indexOf(OutputConstants.UNDERSCORE)));
		
		// Check for the state of your order here, using an XML parser.
		// This code will run in a different thread from the one
		// that submitted the order
		if (document != null) {
			state = getElementAtt(document, "Status", "State");
			if (state.equals("COMPLETED")) {
				getDiscStatusListener().discBurningCompleted(jobId);
				return;
			}
			errMsg = getElementAtt(document, "Status", "ErrorMessage");
			errCode = getElementAtt(document, "Status", "ErrorCode");

			if (state.equals("FAILED")) {
				if(StringUtilities.isEmpty(errMsg) && (StringUtilities.isEmpty(errCode))) {
					errCode = "Failed writing to disc";
				}
				getDiscStatusListener().discBurningFailed(jobId, errCode + ":" + errMsg);
				return;
			}
			if (state.equals("CANCELLED")) {
				getDiscStatusListener().discBurningFailed(jobId, "Job is cancelled from Remage system");
				return;
			}
			String message = "Burning " + state.toLowerCase() + ": " + getElementAtt(document, "Status", "PercentCompleted") + "% completed.";
			getDiscStatusListener().discBurningInProgress(jobId, message);
		}
	}
}
