/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.plugin.hpf;

import com.mckesson.eig.CodeList;

/**
 * @author Latonia Howaqrd
 * @date  Jan 2012
 * @since  HPF 15.2
 *
 *
 * This class is the output plugin implementation of Records Management application. The plugin extends
 * the HPFOutputPlugin as the Records Management application uses the HPF users. Therefore there may
 * be some implementation available in the HPFOutputPlugin. 
 */
public class RecordsManagementPlugin extends HPFOutputPlugin {
	
	/**
	 * This constructor is invoked from the spring configuration. The application which
	 * uses the service is responsible to specify these parameters as they are used by 
	 * the class to communicate to the web service.
	 * 
	 * @param protocol
	 * @param server
	 * @param port
	 */
	public RecordsManagementPlugin(String protocol, String server, String port) {
		super(protocol, server, port);		
	}	
	
	/**
	 * This method returns the output specific rights which the ROI application uses.
	 */
	protected CodeList getOutputRights() {
		
		CodeList codeList = new CodeList();
		
		final int exportToPDFRight = 6113;

		int[] codes = {exportToPDFRight};
		codeList.setCodes(codes);
		return codeList;
	}
}
