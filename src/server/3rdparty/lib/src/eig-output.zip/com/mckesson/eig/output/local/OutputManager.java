/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local;

import java.beans.PropertyChangeListener;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputRequest;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants.RunState;
import com.mckesson.eig.output.util.status.StatusChangeListener;
import com.mckesson.eig.output.util.status.StatusUtils;

/**
 * TODO
 * @author Jon Anderson
 */
public interface OutputManager extends OutputComponent {


	/**
	 * TODO
	 */
	void start();

	/**
	 * TODO
	 * @param force
	 */
	void shutdown(boolean force);

	/**
	 * TODO
	 */
	void pause();

	/**
	 * TODO
	 */
	void restart();

	/**
	 * TODO
	 * @param queryOptions
	 * @return not <code>null</code>
	 */
//	OutputJobList queryOutputJobs(Map<String, Long> queryOptions);

	/**
	 * Submits an OutputRequest for processing and returns the new OutputJob
	 *
	 * @param request
	 * @return not <code>null</code>, exceptions will be thrown if there are errors
	 */
	OutputJob submitOutputRequest(OutputRequest request);
	
	/**
     * Create an OutputRequest and returns the new OutputJob
     *
     * @param request
     * @return not <code>null</code>, exceptions will be thrown if there are errors
     */
    List<OutputJob> postAndPause(List<OutputRequest> request);

    /**
     * Re-Submits an OutputJob for processing and returns the OutputJob
     *
     * @param job
     * @return not <code>null</code>, exceptions will be thrown if there are errors
     */
    OutputJob resubmitOutputJob(int jobID);

    /**
     * Re-Submits OutputJob(s) for processing using queryOptions and returns the OutputJob(s)
     *
     * @param Map queryOptions
     * @return List of OutputJob(s), exceptions will be thrown if there are errors
     */
    List<OutputJob> resubmitOutputJob(Map<String, String> queryOptions);

	/**
	 * TODO
	 * @param listener
	 */
	void addPropertyChangeListener(PropertyChangeListener listener);

	/**
	 * TODO
	 * @param property
	 * @param listener
	 */
	void addPropertyChangeListener(
			String property,
			PropertyChangeListener listener);

	/**
	 * TODO
	 * @param listener
	 */
	void removePropertyChangeListener(PropertyChangeListener listener);

	/**
	 * TODO
	 * @return
	 */
	Collection<PropertyChangeListener> getPropertyChangeListeners();

	/**
	 * TODO
	 * @param statusChangeListener
	 */
	void addStatusChangeListener(StatusChangeListener statusChangeListener);

	/**
	 * TODO
	 * @param objectType
	 * @param statusChangeListener
	 */
	void addStatusChangeListener(
			StatusUtils.StatusObjectType objectType,
			StatusChangeListener statusChangeListener);

	/**
	 * TODO
	 * @param object
	 * @param statusChangeListener
	 */
	void addStatusChangeListener(
			Object object,
			StatusChangeListener statusChangeListener);

	/**
	 * TODO
	 * @param statusChangeListener
	 */
	void removeStatusChangeListener(StatusChangeListener statusChangeListener);

	/**
	 * TODO
	 * @return
	 */
	Collection<StatusChangeListener> getStatusChangeListeners();

	/**
	 * TODO
	 * @param jobID
	 * @param statusInfo
	 * @return
	 */
	OutputJob updateJobStatus(int jobID, StatusInfo statusInfo);

	/**
	 * TODO
	 * @param jobSeq
	 * @param partID
	 * @param statusInfo
	 * @return
	 */
	JobPart updateJobPartStatus(
			int jobSeq,
			int partID,
			StatusInfo statusInfo);

	/**
	 * TODO
	 * @param jobID
	 * @return
	 */
	OutputJob getOutputJob(int jobID);

	/**
	 * TODO
	 * @return
	 */
	RunState getRunState();

	/**
	 * TODO
	 * @return
	 */
	StatusInfo getStatusInfo();

    /**
     * @param jobSeq
     */
    void restartOutputJob(Integer jobSeq);

    /**
     * @param jobSeq
     */
    void cancelOutputJob(Integer jobSeq);

    int getJobStatus(int jobID);

    /**
     * This method is used to update the job page count
     *
     * @param jobID
     * @param pageCount
     */
    void updateJobPageCount(int jobID, int pageCount);

    /**
     * This method is used to update the job part page count
     * and job part status
     *
     * @param partID
     * @param pageCount
     */
    void updateJobPart(JobPart part);

    LocationStrategy getLocationStrategy();

    void syncJobs();

    /**
     * Re-Directs an OutputJob for processing.
     *
     * @param jobID
     * 		  The unique job id to be redirected
     * @param request
     * 		  The new output properties and preferences that needs to be applied
     * 		  prior to redirecting
     * @return outputJob
     */
     OutputJob redirectOutputJob(int jobID, OutputRequest request);

    /**
     * Re-Submits an OutputJob for processing.
     *
     * @param jobID
     * 		  The unique job id that should be resubmitted
     * @param request
     * 		  The request holds the new output properties and preferences that
     * 		  needs to be applied prior to resubmitting
     * @return outputJob
     */
     OutputJob resubmitOutputJob(int jobID, OutputRequest request);

     /**
      * Re-submitting the output Job As a new Job.
      *
      * When an archived job is to be reprinted, the original job details
      * should not be modified in order to maintain audit trail.
      * So a new job is created during a resubmit of output job.
      * @param jobID The unique id of the job that should be redirected
	  * @param request This request holds the overridden destination and output
	  * preferences that should be applied when the job is redirected
	  * @return OutputJob - Newly constructed output job object will be returned
      */
     OutputJob resubmitAsNewOutputJob(int jobID, OutputRequest request);

     /**
  	 * Method to retrieve the output request information for a given jobID and
     * store the document info in the filepath argument.
  	 *
  	 * @param jobID The unique id of the job that should be redirected
  	 * @param filePath This filePath holds the location where the PDF is available
  	 */
     void retrieveOutputRequestInfo(int jobID, String filePath);
     
 	/**
 	 * TODO
 	 * @param jobID
 	 * @param statusInfo
 	 * @return
 	 */
 	OutputJob updateJobResults(int jobID, String results);

 	OutputJob updateJobResults(int jobID, StatusInfo newStatus, String results);
 	
 	/**
 	 * Method to update the outputjob in the outputJobs collection with
 	 * typehandler specific additional details
 	 */
 	void updateJobStatusInfoWithEndpointStatus(List<OutputJob> outputJobs);
}
