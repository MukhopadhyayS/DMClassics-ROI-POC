package com.mckesson.eig.output.local;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;

public abstract class AbstractTypeHandler extends BaseComponent implements
		DestTypeHandler, OutputManagerAware {
	
	protected OutputManager _outputManager;

	public OutputEndpoint createEndpoint(EndpointDef endpointDef) {
		// TODO Auto-generated method stub
		return null;
	}

	public void destroyEndpoint(OutputEndpoint endpoint) {
		// TODO Auto-generated method stub

	}

	public void cleanUp() {
		// TODO Auto-generated method stub

	}

	public String[] getEndpointContentTypes() {
		// TODO Auto-generated method stub
		return null;
	}

	public EndpointCategory getEndpointCategory() {
		return EndpointCategory.DESTINATION;
	}

	public Collection<String> queryDeviceIDs() {
		// TODO Auto-generated method stub
		return null;
	}

	public StatusInfo queryDeviceStatus(String deviceID) {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<String, Object> queryDeviceProperties(String deviceID) {
		// TODO Auto-generated method stub
		return null;
	}

	public PropertyDef[] getDevicePropertyDefs(String deviceID) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setOutputManager(OutputManager outputManager) {
		_outputManager = outputManager;
	}

    public OutputManager getOutputManager() {
        return _outputManager;
    }

	
	public Map<String, EndpointTypeHandler> getSubHandlers() {
		return null;
	}
	
	@Override
	public void updateEndpoints(List<ActiveEndpoint> endpointArr) {
		//do nothing
	}	
	
    @Override
    public void updateJobStatusInfoWithEndpointStatus(Collection<ActiveEndpoint> endpoints, List<OutputJob> outputJobs) {
    	//updates the destination - just in case queue(endpoint) name was changed since request was sent

		for (OutputJob outputJob : outputJobs) {
			for (ActiveEndpoint endpoint : endpoints) {
				if ( outputJob.getDestID() == endpoint.getEndpointDef().getId()) {
					outputJob.setDestName(endpoint.getEndpointDef().getName());
				}
			}
		}

    }	
}
