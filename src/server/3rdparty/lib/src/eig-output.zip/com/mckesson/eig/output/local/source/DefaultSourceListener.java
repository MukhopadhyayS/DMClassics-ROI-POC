package com.mckesson.eig.output.local.source;

import com.mckesson.eig.output.model.OutputJob;

public class DefaultSourceListener implements SourceListener {

	public void addFile(OutputJob job, String path) {
		// TODO Auto-generated method stub
	}

	public void error(OutputJob job, String errorMessage) {
		// TODO Auto-generated method stub
	}

	public void finish(OutputJob job) {
		// TODO Auto-generated method stub
	}

	public void start(OutputJob job) {
		// TODO Auto-generated method stub
	}

}
