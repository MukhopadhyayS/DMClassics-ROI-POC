/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

public final class OutputSettingConstants {
	public static final String CONCURRENT_PRINT_JOB = "config.concurrent.print.job";
	public static final String CONCURRENT_DEFAULT_JOB = "config.concurrent.default.job";
	public static final String CONCURRENT_DICS_JOB = "config.concurrent.disc.job";
	public static final String DISC_DVD_SIZE = "disc.dvd.size";
	public static final String DISC_CD_SIZE = "disc.cd.size";

	public static final String PRINT_CONVERTER_PATH = "config.print.converter.path";
	public static final String PRINT_CONVERTER_IN_PREFIX = "config.print.converter.inPrefix";
	public static final String PRINT_CONVERTER_OUT_PREFIX = "config.print.converter.outPrefix";

	public static final String REAL_TIME_PRINT_THRESHOLD = "config.realtime.print.thresold";
	public static final String REAL_TIME_PRINT_BATCH_SIZE = "config.realtime.print.batch.size";

	public static final String IDLE_IN_MINUTES ="idle.job.in.minutes";
	
	public static final String IDLE_IN_DAYS ="idle.job.in.days";
	public static final String IDLE_ERROR_MESSAGE ="idle.job.failed.message";
	
	public static final String HPF_CONTENT_WEB_POOL_SIZE
		= "config.hpf.content.web.setting.pool.size";
	public static final String HPF_CONTENT_WEB_THREAD_PER_POOL
		= "config.hpf.content.web.setting.thread.per.pool";

	public static final String SYSTEM_PROPERTY_UNIQUE_KEY = "config.system.property.unique.key";

	public static final String DEFAULT_SYSTEM_PROPERTY_UNIQUE_KEY = "java.endorsed.dirs";

    public static final String OUTPUT_SETTING_PROPERTIES_BEAN = "outputSettingPropertiesBean";

    public static final String PRINT_PDF = "config.print.printpdf";
    
    public static final String PRINT_CONVERTER_BEAN = "printConverterBean";

    public static final String UUID_SETTING_PROPERTIES_BEAN = "uuidSettingPropertiesBean";

}
