/**
 * Copyright � 2010 McKesson Corporation and/or one of its subsidiaries.
 * All rights reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.hpf.service;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.mckesson.eig.utility.encoders.Encoder;
import com.mckesson.eig.utility.encoders.HexEncoder;
import com.mckesson.eig.utility.encryption.Encryptor;
import com.mckesson.eig.utility.encryption.MD5Encryptor;
import com.mckesson.eig.utility.net.HttpTimeRetriever;
import com.mckesson.eig.utility.net.TimeRetriever;

public final class SecureToken {

	private static final int SSL = 883;
	private static final int HTTP = 80;

	private SecureToken() {
	}

	public static String createTime(String server, int port, boolean useSSL) {
		String protocol;
		if (useSSL) {
			protocol = "https";
		} else {
			protocol = "http";
		}
		return createTime(protocol + "://" + server + ":" + String.valueOf(port));
	}

	public static String createTime(String server, boolean useSSL) {
		int port;
		if (useSSL) {
			port = SSL;
		} else {
			port = HTTP;
		}
		return createTime(server, port, useSSL);
	}

	public static String createTime(URL timeURL) {
		TimeRetriever tr = new HttpTimeRetriever(timeURL);
		try {
			return tr.getGMTString();
		} catch (Exception e) {
			System.err.println("Server time is not available.");
			e.printStackTrace();
			return null;
		}
	}

	public static String createTime(String timeURL) {
		try {
			URL url = new URL(timeURL);
			return createTime(url);
		} catch (Exception e) {
			System.err.println("Server time is not available.");
			e.printStackTrace();
			return null;
		}
	}

	public static String createToken(String[] data, String time, String privatekey) {
		StringBuilder input = new StringBuilder();
		for (String element : data)
		{
			if (element != null) {
				input.append(element);
			}
		}
		input.append(time);
		try {
			return encode(input.toString(), privatekey);
		} catch (Exception e) {
			System.err.println("Token can't be created.");
			e.printStackTrace();
			return null;
		}
	}

	public static String createToken(String[] data, Date time, String privatekey) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		return createToken(data, sdf.format(time), privatekey);
	}

	protected static String encode(String data, String key) {
		if (data == null) {
			throw new NullPointerException("data can't be null");
		}
		if (key == null) {
			throw new NullPointerException("key can't be null");
		}
		Encryptor encryptor = new MD5Encryptor();
		Encoder encoder = new HexEncoder();
		return encoder.encode(encryptor.encrypt(data, key));
	}
}
