/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.security.authorization;

import java.util.List;

import com.mckesson.eig.wsfw.security.authorization.AuthorizationStrategy;

/**
 * @author Pranav Amarasekaran
 * @date   Jun 24, 2009
 * @since  Output 1.0; Jun 24, 2009
 */
public abstract class OutputAuthorizationStrategy
implements AuthorizationStrategy {

    public abstract OutputACL initializeOutputACL();
    public final boolean authorize(String serviceName, String operationName, List < ? > params) {
        return initializeOutputACL().checkAccessRights(operationName, params);
    }
}
