/*
 * Copyright 2009-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.model;

import java.io.StringWriter;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.mckesson.eig.output.util.OutputUtil;

/**
 * @author Pranav Amarasekaran
 * @date   May 3, 2009
 * @since  Output 1.0; May 3, 2009
 *
 * This model class holds the list of file names associated to the OutputJob
 * and the updated date of the list.
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "jobFileList")
@XmlType(name = "jobFileList")
public class JobFileList extends EndpointDef {

	private int _listID;
	private Date _lastPurgeDate;
	private List<OutputJobFiles> _jobFileDetails;

	public JobFileList() {
		super();
	}

	/**
	 * Holds the primary key of the LOV.
	 *
	 * @return listID
	 */
	public int getListID() {
		return _listID;
	}

	public void setListID(int listID) {
		_listID = listID;
	}

	public Date getLastPurgeDate() {
		return _lastPurgeDate;
	}

	@XmlElement (name = "lastPurgeDate")
	public void setLastPurgeDate(Date lastPurgeDate) {
	    _lastPurgeDate = lastPurgeDate;
	}

	public List<OutputJobFiles> getJobFileDetails() {
		return _jobFileDetails;
	}

	@XmlElementWrapper(name = "jobFileDetails")
	@XmlElement (name = "outputJobFiles", type = OutputJobFiles.class)
	public void setJobFileDetails(List<OutputJobFiles> jobFileDetails) {
		_jobFileDetails = jobFileDetails;
	}

    /**
     * This method is used to return the XML representation of the
     * object.
     *
     * @return the xml representation of the object.
     */
	public String getXML() {

	    StringWriter writer = new StringWriter();
		OutputUtil.getXML(this, writer);
		return writer.toString();
	}
}
