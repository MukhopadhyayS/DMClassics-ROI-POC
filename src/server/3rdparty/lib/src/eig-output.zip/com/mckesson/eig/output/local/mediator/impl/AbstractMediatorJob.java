/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

 * Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
 * Use of this software and related documentation is governed by a license agreement.
 * This material contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States
 * and international copyright and other intellectual property laws.
 * Use, disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without the
 * prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
 */

package com.mckesson.eig.output.local.mediator.impl;

import java.io.IOException;

import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.mediator.MediatorJob;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.encryption.AESEncryptor;

public abstract class AbstractMediatorJob implements MediatorJob {

	protected OutputJob _job = null;
	protected Destination _destination = null;
	protected DestTypeHandler _handler = null;
	protected AESEncryptor _encryptor = null;

	public AbstractMediatorJob(OutputJob job, Destination d,
			DestTypeHandler handler) {
		_job = job;
		_destination = d;
		_handler = handler;
	}

	public void doneWithJob() throws IOException, InterruptedException {
		// TODO Auto-generated method stub

	}

	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void addFile(String fileName) throws IOException,
			InterruptedException {
		// TODO Auto-generated method stub

	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void initializeJob(Object listener) {
		// TODO Auto-generated method stub

	}

	protected Destination getDestination() {
		return _destination;
	}

	protected DestTypeHandler getHandler() {
		return _handler;
	}

	protected OutputJob getJob() {
		return _job;
	}

	protected void updateStatus(int jobId, RequestStatus status, String detail) {
		StatusInfo statusInfo = StatusUtils.createRequestStatus(status, detail);
		_handler.getOutputManager().updateJobStatus(jobId, statusInfo);
	}

	protected void updateJobResults(int jobId, String results) {
		_handler.getOutputManager().updateJobResults(jobId, results);
	}

	/**
	 * For the precious versions of Output does not uses encryption. 
	 * for the purpose of backward compatibility, we have returned the original password,
	 * if the AES algorithm is unable to decrypt the given text.
	 *  
	 * @param encryptedPassword
	 * @return
	 */
	protected String decryptPassword(String encryptedPassword) {

		try {

			return getEncryptor().decrypt(encryptedPassword,
									  OutputConstants.AES_SECRET_KEY,
									  OutputConstants.AES_SECRET_IV);
		} catch (Exception e) {
			return encryptedPassword;
		}
	}
	
	private AESEncryptor getEncryptor() throws Exception {
		
		if (_encryptor == null) {
			_encryptor = new AESEncryptor();
		}
		
		return _encryptor;
	}
	
}
