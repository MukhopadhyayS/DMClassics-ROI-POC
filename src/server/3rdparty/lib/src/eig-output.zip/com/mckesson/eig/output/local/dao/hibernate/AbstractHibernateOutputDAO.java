/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.dao.hibernate;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.orm.hibernate3.HibernateOptimisticLockingFailureException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.utility.exception.ApplicationException;

/**
 * @author Pranav Amarasekaran
 * @date   Apr 3, 2009
 * @since  Output 1.0; Apr 3, 2009
 *
 * This class holds all the common methods which have to be used in the
 * DAO of the output component, which uses hibernate for persistence. All
 * the DAO implementation classes of the output component will extend this
 * abstract class.
 */
public abstract class AbstractHibernateOutputDAO extends HibernateDaoSupport {

	private static long _diff;
	private static boolean _diffSet;

	/**
	 * This method sets the time difference in milliseconds b/w Database server
	 * and JVM
	 */
    private void setDateDiff() {

        List< ? > list = getHibernateTemplate().findByNamedQuery(
                "getDBDate");

        SimpleDateFormat df = new SimpleDateFormat("MMM dd yyyy h:mma");

        try {
            _diff = df.parse(list.get(0).toString()).getTime() - System.currentTimeMillis();
        } catch (ParseException e) {
            throw new OutputException(
                    e.getMessage(), OutputErrorCode.INVALID_DATA);
        }
    }


	/**
	 * This method gets the current time.
	 */
	public Timestamp getDate() {

		if (!_diffSet) {
			setDateDiff();
			_diffSet = true;
		}

		return new Timestamp(System.currentTimeMillis() + _diff);
	}

    /**
     * This method is used for storing individual objects and handling data
     * integrity violation exceptions.
     *
     * @param object
     *          Object to create in the database.
     *
     * @return Serializable The primary key value of the object
     *         inserted.
     */
    public Serializable create(Object object) {

        try {
            return getHibernateTemplate().save(object);
        } catch (DataIntegrityViolationException e) {
			throw new OutputException(
					"Object Creation failed :" + object.toString(),
					OutputErrorCode.PERSISTENCE_CREATE_ERROR);
        }
    }

    /**
     * This method is used for delete of individual objects.
     *
     * @param object
     *            Object to delete in the database.
     *
     * @return void
     */
    public void delete(Object object) {

        try {
            getHibernateTemplate().delete(object);
        } catch (DataIntegrityViolationException e) {
			throw new ApplicationException(
					"Object Deletion failed :" + e.getMessage(),
						OutputErrorCode.PERSISTENCE_DETETE_ERROR.toString(),
						object.toString());
        } catch (HibernateOptimisticLockingFailureException e) {
			throw new ApplicationException(
					"Object Deletion failed :" + e.getMessage(),
						OutputErrorCode.OPTIMISTIC_LOCKING_COLLISION.toString(),
						object.toString());
        }
    }

    /**
    * Copy the state of the given object onto the persistent object with the same
    * identifier. If there is no persistent instance currently associated with
    * the session, it will be loaded. Return the persistent instance. If the
    * given instance is unsaved, save a copy of and return it as a newly persistent
    * instance. The given instance does not become associated with the session.
    * This operation cascades to associated instances if the association is mapped
    * with cascade="merge".
    *
    * @param object
    *           a detached instance with state to be copied
    * @return
    *           an updated persistent instance
    */
    public Object merge(Object object) {

        try {
            return getHibernateTemplate().merge(object);
        } catch (DataIntegrityViolationException e) {
			throw new ApplicationException(
					"Object Merge failed :" + e.getMessage(),
						OutputErrorCode.PERSISTENCE_DETETE_ERROR.toString(),
						object.toString());
        } catch (HibernateOptimisticLockingFailureException e) {
			throw new ApplicationException(
					"Object Merge failed :" + e.getMessage(),
						OutputErrorCode.OPTIMISTIC_LOCKING_COLLISION.toString(),
						object.toString());
        }
    }

    /**
     * Updates the persistence object with the same identifier.s
     *
     * @param object
     */
    public void update(Object object) {

    	try {
            getHibernateTemplate().update(object);
        } catch (DataIntegrityViolationException e) {
			throw new ApplicationException(
					"Failed to Update Object:" + e.getMessage(),
						OutputErrorCode.PERSISTENCE_DETETE_ERROR.toString(),
						object.toString());
        } catch (HibernateOptimisticLockingFailureException e) {
        	throw new ApplicationException(
					"Failed to Update Object:" + e.getMessage(),
						OutputErrorCode.OPTIMISTIC_LOCKING_COLLISION.toString(),
						object.toString());
        }
    }
}
