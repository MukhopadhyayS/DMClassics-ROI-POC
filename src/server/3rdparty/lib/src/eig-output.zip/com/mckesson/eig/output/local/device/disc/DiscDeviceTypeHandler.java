package com.mckesson.eig.output.local.device.disc;

import com.mckesson.eig.output.local.AbstractTypeHandler;

public class DiscDeviceTypeHandler extends AbstractTypeHandler {

}
