/*
 * Copyright 2009-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement (name = "property")
@XmlType(name = "mapModel")
public class MapModel implements Serializable {

    private Object _key;
    private Object _value;

    public MapModel() {
    }

    public MapModel(Object key, Object value) {
        this._key = key;
        this._value = value;
    }

    public Object getKey() {
        return _key;
    }

    @XmlElement (name = "key", type = String.class)
    public void setKey(Object key) {
        this._key = key;
    }

    public Object getName() {
        return _key;
    }

    @XmlElement (name = "name", type = String.class)
    public void setName(Object key) {
        this._key = key;
    }

    public Object getValue() {
        return _value;
    }

    @XmlElement (name = "value", type = String.class)
    public void setValue(Object value) {
        this._value = value;
    }
}
