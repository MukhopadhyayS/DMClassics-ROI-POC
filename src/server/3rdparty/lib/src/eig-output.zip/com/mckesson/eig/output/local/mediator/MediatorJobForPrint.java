package com.mckesson.eig.output.local.mediator;

public interface MediatorJobForPrint extends MediatorJob {
	
    Thread getPrintThread();
}
