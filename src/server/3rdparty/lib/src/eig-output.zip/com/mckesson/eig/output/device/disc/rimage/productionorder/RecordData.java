/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage.productionorder;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAttribute;

@XmlRootElement(name = "Data")
public class RecordData {
    
    private static final String MODE1 = "Mode1";
    
    private String type;
    private Boolean mergeSessions;
    
    
    public RecordData() {
        super();
        this.type = MODE1;
        this.mergeSessions = Boolean.TRUE; 
    }


    public String getType() {
        return type;
    }
    
    @XmlAttribute(name = "Type")
    public void setType(String type) {
        this.type = type;
    }


    public Boolean getMergeSessions() {
        return mergeSessions;
    }

    @XmlAttribute(name = "MergeSessions")
    public void setMergeSessions(Boolean mergeSessions) {
        this.mergeSessions = mergeSessions;
    }

    
    

}
