/*
 * Copyright 2009-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.model;

import java.io.StringWriter;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.mckesson.eig.output.util.OutputUtil;

/**
 * @author Pranav Amarasekaran
 * @date   May 4, 2009
 * @since  Output 1.0; May 4, 2009
 *
 * This model class holds the list of file names associated to the OutputJob.
 */

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "outputJobFiles")
@XmlType(name = "outputJobFiles")
public class OutputJobFiles {

	private int _jobID;
	private List<String> _fileNames;
	private Date _completedDate;
	private String _jobDirectory;
	private String _orderId;
	private String _clientId;

	public OutputJobFiles() {
		super();
	}

	public List<String> getFileNames() {
		return _fileNames;
	}

	@XmlElementWrapper (name = "fileNames")
	@XmlElement (name = "file", type=String.class)
	public void setFileNames(List<String> fileNames) {
		_fileNames = fileNames;
	}

	public String getClientId() {
		return _clientId;
	}

	@XmlElement (name = "clientId")
	public void setClientId(String clientId) {
		_clientId = clientId;
	}

	public String getOrderId() {
		return _orderId;
	}

	@XmlElement (name = "orderId")
	public void setOrderId(String orderId) {
		_orderId = orderId;
	}

	public int getJobID() {
		return _jobID;
	}

	@XmlElement (name = "jobID")
	public void setJobID(int jobID) {
		_jobID = jobID;
	}

	@XmlElement (name = "completedDate")
	public void setCompletedDate(Date completedDate) {
	    _completedDate = completedDate;
	}

	public Date getCompletedDate() {
	    return _completedDate;
	}
	
	@XmlElement (name = "jobDirectory")
	public void setJobDirectory(String jobDirectory) {
		_jobDirectory = jobDirectory;
	}
	
	public String getJobDirectory() {
		return _jobDirectory;
	}
	
    /**
     * This method is used to return the XML representation of the
     * object.
     *
     * @return the xml representation of the object.
     */
	public String getXML() {

	    StringWriter writer = new StringWriter();
		OutputUtil.getXML(this, writer);
		return writer.toString();
	}	
}


