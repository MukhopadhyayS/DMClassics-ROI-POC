/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.security;


import com.mckesson.eig.iws.security.Ticket;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.exception.ClientErrorCodes;
import com.mckesson.eig.utility.util.SpringUtilities;
import com.mckesson.eig.utility.util.StringUtilities;
import com.mckesson.eig.wsfw.model.authentication.AuthenticatedResult;
import com.mckesson.eig.wsfw.security.AuthenticationStrategy;
import com.mckesson.eig.wsfw.security.service.Authenticator;
import com.mckesson.eig.wsfw.session.WsSession;



/**
 * @author Ghazni
 * @date   Aug 16, 2010
 * @since  HPF 13.1 [ROI]; Feb 17, 2009
 */
public abstract class AbstractAuthenticator
implements Authenticator {

    /**
     * Indicates the name of Authentication service locator
     */
    private static final String AUTHENTICATION_SERVICE_LOADER = "HPFAuthenticationServiceLoader";

    /**
     * Checks the ticket from request is valid or not. First the authentication
     * is based on ticket id. if the ticket is valid then the user already
     * authenticated, otherwise authentication process starts with the username
     * and password.
     *
     */
    public void validate() {

        try {

            String ticket   = (String) WsSession.getSessionData(KEY_TICKET);
            String userName = (String) WsSession.getSessionData(KEY_USERNAME);

            if (isTicketValid(ticket, userName)) {
                return;
            }

            String password = (String) WsSession.getSessionData(KEY_PASSWORD);
            if (StringUtilities.isEmpty(userName) || StringUtilities.isEmpty(password)) {
                throw new ApplicationException("Invalid user credientials");
            }

            AuthenticatedResult result = doAuthenticate(userName, password);
            if ((result == null) || !result.isAuthenticated()) {
                throw new ApplicationException("Authentication Failed for the user '" 
                                               + userName + "'");
            }

            WsSession.setSessionData(WsSession.AUTHRESULT, result);
            WsSession.setSessionData(WsSession.TICKET, result.getTicket());
        } catch (Throwable e) {
            throw new ApplicationException(e, ClientErrorCodes.SYSTEM_COULD_NOT_LOG_YOU_ON);
        }
    }

    /**
     * This method authenticates the user
     *
     * @param user
     *             Indicates the username
     * @param password
     *             Indicates the password
     *
     * @return <code>AuthenticationResult</code> if authentication succeed,
     *              otherwise null
     */
    private AuthenticatedResult doAuthenticate(String user, String password) {


        try {

            AuthenticationStrategy authenticationService
            = (AuthenticationStrategy) SpringUtilities.getInstance()
                                                      .getBeanFactory()
                                                      .getBean(AUTHENTICATION_SERVICE_LOADER);

            AuthenticatedResult result = authenticationService.authenticate(user, password);
            return result;
        } catch (Throwable e) {
            throw new ApplicationException(e, ClientErrorCodes.SYSTEM_COULD_NOT_LOG_YOU_ON);
        }
    }

    /**
     * Validate the ticket that is stored in the session.
     *
     * @param ticket
     *            String
     * @param userName
     *            String
     */
    private boolean isTicketValid(String ticket, String userName) {

        try {
            return Ticket.isValid(ticket, userName);
        } catch (Exception e) {
            return false;
        }
    }
}
