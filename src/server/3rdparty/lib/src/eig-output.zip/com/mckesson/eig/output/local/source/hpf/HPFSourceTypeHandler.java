package com.mckesson.eig.output.local.source.hpf;

import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.local.SourceTypeHandler;
import com.mckesson.eig.output.local.source.hpf.service.ContentWebServiceController;
import com.mckesson.eig.output.model.EndpointDef;

public class HPFSourceTypeHandler extends SourceTypeHandler {
	private ContentWebServiceController _controller;

	public ContentWebServiceController getController() {
		return _controller;
	}

	public void setController(ContentWebServiceController controller) {
		_controller = controller;
	}

	public HPFSourceTypeHandler(String enabled,
			String endpointClass,
			String endpointCategory,
			String headFooterClass) {
		super(enabled, endpointClass, endpointCategory, headFooterClass);
	}

	public OutputEndpoint createEndpoint(EndpointDef endpointDef) {
		HpfSource source = (HpfSource) super.createEndpoint(endpointDef);
		source.setController(_controller);
		return source;
	}

	public OutputEndpoint createEndpointWithoutController(EndpointDef endpointDef) {
		HpfSource source = (HpfSource) super.createEndpoint(endpointDef);
		return source;
	}

}
