/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;

/**
 * <code>DestTypeHandler</code> serves as a factory and manager for
 * <code>OutputEndpoint</code>s. Each handler is responsible for a set
 * of destination "types" for which it can create <code>OutputEndpoint</code>s.
 * Within the Output Service, a type will only be associated to a single
 * handler.
 *
 * @author Jon Anderson
 */
public interface DestTypeHandler extends EndpointTypeHandler {

	/**
	 * Query the unique identifiers for the given of all known devices
	 *
	 * @return should not be <code>null</code>
	 */
	Collection<String> queryDeviceIDs();

	/**
	 * Return the status information for the device identified by <code>deviceID</code>
	 *
	 * @param deviceID unique identifier of device. not <code>null</code>
	 * @return not <code>null</code> an exception should be thrown if
	 * <code>deviceID</code> is invalid
	 */
	StatusInfo  queryDeviceStatus(String deviceID);

	/**
	 * These properties should reflect the underlying device's current settings. If an
	 * <code>OutputEndpoint</code> object exists for the device and has settings used by
	 * the code for that destination which are not used by the underlying device, they
	 * will not be returned here.
	 *
	 * @param deviceID not <code>null</code>
	 * @return should not be <code>null</code>
	 */
	Map<String, Object> queryDeviceProperties(String deviceID);

	/**
	 * TODO
	 * @param deviceID
	 * @return not <code>null</code>
	 */
	PropertyDef[] getDevicePropertyDefs(String  deviceID);
	
    OutputManager getOutputManager();
    
    void updateJobStatusInfoWithEndpointStatus(Collection<ActiveEndpoint> endpoints, List<OutputJob> outputJobs);


}
