/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.utility.util.CollectionUtilities;
import com.mckesson.eig.utility.util.StringUtilities;

/**
 * Base class for OutputJob and OutputRequest. OutputJobs are created from OutputRequests
 * and contain additional status and processing information to be used by the OutputService.
 * As such, an OutputJob's  parts member will contain OutputJobParts as opposed to OutputParts
 * used in OutputRequests. Like OutputJobs, OutputJobParts are created from source OutputParts
 * and contain additional status and processing information.
 *
 * @author OFS
 * @author Jon Anderson
 * @param <T> Type of OutputParts this request contains. OutputJob will contain OutputJobParts
 * where as OutputRequest contains OutputParts
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "abstractOutputRequest")
@XmlType(name = "abstractOutputRequest")
public abstract class AbstractOutputRequest<T extends RequestPart>
	implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 11;
    private static final int HASH_INIT = 87;

    private Map<String, String> _properties;
    private String _requestId;
    private int _destID;
	private String _destName;
	private String _destType;
    private SubmitInfo _submitInfo;
    private List<OutputTransform> _transforms;

    // Newly added for refactor COS service params
    private List<MapModel> _searchableData;

    //added for cxf migration
    private List<MapModel> _propertyList;
    
    private List<MapModel> _labelData; 

   /**
    *
    */
   public AbstractOutputRequest() {
       super();
   }

   @Override
   public boolean equals(Object o) {

       AbstractOutputRequest< ? > request = (AbstractOutputRequest< ? >) o;

       if (!ObjectUtils.equals(request._requestId, _requestId)) {
           return false;
      }

      if (request._destID != _destID) {
           return false;
      }
       if (!ObjectUtils.equals(request._submitInfo, _submitInfo)) {
           return false;
       }
       if (!ObjectUtils.equals(request._transforms, _transforms)) {
           return false;
       }
       if (!ObjectUtils.equals(request._properties, _properties)) {
           return false;
       }

       return true;
   }

   @Override
   public int hashCode() {

       HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
       builder.append(_requestId);
       builder.append(_destID);
       builder.append(_submitInfo);
       builder.append(_transforms);
       builder.append(_properties);
       return builder.toHashCode();
   }

   /**
    * Return the parts that belong to this request
    *
    * @return the _parts member
    */
   public abstract List<T> getParts();

   /**
    * @param outputParts
    */
   @XmlTransient
   public abstract void setParts(List<T> outputParts);

    /**
     * Information about the source of the request
     *
     * @return the _submitInfo member
     */
    public SubmitInfo getSubmitInfo() {

    	if (_submitInfo == null) {
    		_submitInfo = new SubmitInfo();
    	}
        return _submitInfo;
    }

    /**
     * @param submitInfo
     */
    @XmlElement (name = "submitInfo", type = SubmitInfo.class)
    public void setSubmitInfo(SubmitInfo submitInfo) {
        _submitInfo = submitInfo;
    }

    /**
     * Return the unique requestId
     * @return the _requestId member
     */
    public String getRequestId() {
        return _requestId;
    }
     /**
     * @param requestid
     */
    @XmlElement (name = "requestId")
    public void setRequestId(String requestId) {
        _requestId = requestId;
    }


    /**
     * Holds the destination ID to which the job is related to.
     *
     * @return
     */
    public int getDestID() {
        return _destID;
    }

    /**
     * @param destID
     * This holds the destination id, which is a reference to the LOV table where the
     * endpoints are stored.
     */
    @XmlElement (name = "destId")
    public void setDestID(int destID) {
        _destID = destID;
    }

    /**
     * Return the name the destination to which this request should ultimately be delivered
     * @return the _destName member
     */
    public String getDestName() {
        return _destName;
    }
     /**
     * @param destination
     */
    @XmlElement (name = "destName")
    public void setDestName(String destName) {
        _destName = destName;
    }

    /**
     * Return the type of the destination to which this request should ultimately be delivered
     * @return the _destType member
     */
    public String getDestType() {
        return _destType;
    }
     /**
     * @param destination
     */
    @XmlElement (name = "destType")
    public void setDestType(String destType) {
        _destType = destType;
    }


    /**
     * The list of transforms to be applied to the request as a whole after all parts have
     * been retrieved and processed and before being sent to a destination
     *
     * @return the _transforms member
     */
    public List<OutputTransform> getTransforms() {
        return _transforms;
    }

    /**
     * @param transforms
     */
    @XmlElementWrapper (name = "transforms")
    @XmlElement (name = "outputTransform", type = OutputTransform.class)
    public void setTransforms(List<OutputTransform> transforms) {
        _transforms = transforms;
    }

    /**
	 * @return the _properties
	 */
	public Map<String, String> getProperties() {

        if (CollectionUtilities.hasContent(_properties)) {
            return _properties;
        }
        
        if (CollectionUtilities.hasContent(_propertyList)) {

            Map<String, String> prop = new HashMap<String, String>();
            for (MapModel mapModel : _propertyList) {
            	
            	// Since the properties does not allows null value
            	// validates whether the value is null, if the value is null assigns the empty string to the value
                String value = StringUtilities.EMPTYSTRING;
                if  (StringUtilities.hasContent((String) mapModel.getValue())) {
                	value = (String) mapModel.getValue();
                }
				
				prop.put(mapModel.getKey().toString(), value);
            }
            setProperties(prop);
        }
        return _properties;
	}

	/**
	 * @param properties the _properties to set
	 */
	@XmlTransient
	public void setProperties(Map<String, String> properties) {

        if (properties != null) {

            if (CollectionUtilities.hasContent(_propertyList)) {
                _propertyList.clear();
            } else {
                _propertyList = new ArrayList<MapModel>();
            }

            for (Map.Entry<String, ? extends Object> e : properties.entrySet()) {
                _propertyList.add(new MapModel(e.getKey(), e.getValue()));
            }
            _properties = properties;
        }
	}

	/**
	 * @param property
	 * @return
	 */
	public String getPropertyValue(String property) {
		if (_properties == null) {
			return null;
		}
		return _properties.get(property);
	}

    /**
     * Get searchableData.
     * 
     * @return the _searchableData
     */
	public List<MapModel> getSearchableData() {
		return _searchableData;
	}

	/**
	 * Set searchableData.
	 * 
	 * @param searchableData the _searchableData to set
	 */
	@XmlElementWrapper(name = "searchableData")
    @XmlElement(name = "property", type = MapModel.class)
	public void setSearchableData(List<MapModel> searchableData) {
		_searchableData = searchableData;
	}

	@XmlElementWrapper (name = "properties")
    @XmlElement(name = "property", type = MapModel.class)
    public void setPropertiesList(List<MapModel> properties) {
        _propertyList = properties;
    }

    public List<MapModel> getPropertiesList() {
        
        if (_properties != null) {
            _propertyList = new ArrayList<MapModel>();
            for (Map.Entry<String, ? extends Object> e : _properties.entrySet()) {
                _propertyList.add(new MapModel(e.getKey(), e.getValue()));
            }
        }
        return _propertyList;
    }
    
    /**
     * Get label data.
     * 
     * @return the _labelDate
     */
	public List<MapModel> getLabelData() {
		return _labelData;
	}

	/**
	 * Set label data.
	 * 
	 * @param labelData the _labelData to set
	 */
	@XmlElementWrapper(name = "label")
    @XmlElement(name = "property", type = MapModel.class)
	public void setLabelData(List<MapModel> labelData) {
		_labelData = labelData;
	}    
}
