/**
 * 
 */
package com.mckesson.eig.output.local.dao.hibernate;

import java.util.List;
import java.util.Set;

import com.mckesson.eig.output.local.dao.OutputSearchLoVDAO;
import com.mckesson.eig.output.model.OutputSearchLoV;
import com.mckesson.eig.utility.util.CollectionUtilities;

/**
 * This class holds the data access implementation for OutputSearchLoV.
 * 
 * @author OFS
 * @since  Output 3.0; Nov 19, 2009
 */
public class OutputSearchLoVDAOImpl extends AbstractHibernateOutputDAO
		implements OutputSearchLoVDAO {

	/**
	 * Add set of outputSearchLov to DB.
	 * 
	 *  @param lovs
	 *  	   the lovs
	 * (non-Javadoc)
	 * @see com.mckesson.eig.output.local.dao.OutputSearchLoVDAO#
	 * createOutputSearchLoVs(java.util.Set)
	 */
	public void createOutputSearchLoVs(Set<OutputSearchLoV> lovs) {

		if (lovs != null) {
			for (OutputSearchLoV lov : lovs) {

			    lov.setCreatedDate(getDate());
				lov.setModifiedDate(getDate());
				create(lov);
			}
		}
	}

	/**
	 * Delete the outputSearchLov from DB.
	 * @param jobId
	 * 	      the jobId
	 *  (non-Javadoc)
	 * @see com.mckesson.eig.output.local.dao.
	 * 				OutputSearchLoVDAO#deleteOutputSearchLoVs(int)
	 */
	@SuppressWarnings("unchecked")
	public void deleteOutputSearchLoVs(int jobId) {

		List<OutputSearchLoV> result = getHibernateTemplate()
				.findByNamedQuery("retrieveSearchLoVByID", new Integer(jobId));
		if (!CollectionUtilities.isEmpty(result)) {

			OutputSearchLoV lov = result.get(0);
	        delete(lov);
		}
	}

	/**
	 * This method is used to fetch the output search LoVs based on the jobId.
	 * 
	 * @param jobId
	 * 
	 * @return List<OutputSearchLoV>
	 * 
	 * @see com.mckesson.eig.output.local.dao.OutputSearchLoVDAO#readOutputSearchLoVs(int)
	 */
    @SuppressWarnings("unchecked")
    public List<OutputSearchLoV> readOutputSearchLoVs(int jobId) {

        List<OutputSearchLoV> result =
               getHibernateTemplate().findByNamedQuery("retrieveSearchLoVByID", new Integer(jobId));
        
        return result;
    }
}
