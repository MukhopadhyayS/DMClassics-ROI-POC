/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.transformers;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;

public class ROIPdfConcatenate extends PdfConcatenate {
    
    private static final Log LOG = LogFactory.getLogger(ROIPdfConcatenate.class);
    
	public ROIPdfConcatenate() {
		super();
	}

	public List<String> concatenate(OutputJob job, long size) {
		List<String> result = super.concatenate(job, size);
		List<String> attachments = processAttachments(job, size);
		if (!CollectionUtilities.isEmpty(attachments)) {
			result.addAll(attachments);
		}
		return result;
	}

	protected List<JobPart> getAttachmentJobParts(OutputJob job) {
		List<JobPart> result = null;
		Iterator<JobPart> iter = job.getParts().iterator();
		while (iter.hasNext()) {
			JobPart jobPart = iter.next();
			if (!jobPart.getAttachments().isEmpty()) {
				if (result == null) {
					result = new ArrayList<JobPart>();
				}
				result.add(jobPart);
			}
		}
		return result;
	}

	protected List<String> processAttachments(OutputJob job, long maxSize) {
		List<JobPart> jobParts = getAttachmentJobParts(job);
		if (CollectionUtilities.isEmpty(jobParts)) {
		    LOG.error("Can not process attachments; job parts are NULL or empty"); 
			return null;
		}
		Map<String, List<JobPart>> map = getPatientMap(jobParts);
		Iterator<List<JobPart>> i = map.values().iterator();
		List<String> result = new ArrayList<String>();
		while (i.hasNext()) {
			List<JobPart> parts = i.next();
			List<String> list = processAttachments(job, parts, maxSize);
			result.addAll(list);
		}
		return result;
	}
	
	protected List<String> getAttachmentsName(OutputJob job, JobPart part, List<String> fileNames) throws Exception {
		Iterator<String> attachmentIter = part.getAttachmentsIterator();
		List<String> files = new ArrayList<String>();
		String location = getTempDirectory(job);
		while (attachmentIter.hasNext()) {
			String partFileName = _nameStrategy.createPartAttachmentName(job, part);
			String ext = part.getProperties().get(
					OutputConstants.OUTPUT_ATTACHMENT_EXT);
			partFileName = _nameStrategy.generateFileNameWithVersionNumber(partFileName, ext, fileNames);
			File srcFile = new File(attachmentIter.next());
			File destFile = new File(location + partFileName + "." + ext);
			FileUtils.copyFile(srcFile, destFile);
			files.add(destFile.getAbsolutePath());
			fileNames.add(destFile.getName());
		}
		return files;
	}


	protected List<String> processAttachments(OutputJob job, List<JobPart> jobParts, long maxSize) {
		if (CollectionUtilities.isEmpty(jobParts)) {
		    LOG.error("Can not process attachments; job parts are NULL or empty"); 
			return null;
		}
		String location = getTempDirectory(job, ATTACHMENTS);
		List<String> files = new ArrayList<String>();
		List<String> fileNames = new ArrayList<String>();
		try {
			for (JobPart part : jobParts) {
				files.addAll(getAttachmentsName(job, part, fileNames));
			}
		} catch (Exception e) {
		    LOG.error(e.toString());
			throw new OutputException(e.toString(), OutputErrorCode.RUNTIME_ERROR);
		}
		String baseFileName = _nameStrategy.createPartAttachmentCollectionName(job, jobParts.get(0));
		List<String> result = addFilesToPdfAsContainer(location, baseFileName, files, maxSize, true, false);
		return result;
		
	}

}
