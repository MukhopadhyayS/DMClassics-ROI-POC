/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;


import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.ArrayList;
import java.text.SimpleDateFormat;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.StatefulJob;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.mckesson.eig.output.local.LocationStrategy;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.service.OutputBaseService;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * TODO
 * @author Jon Anderson
 *
 */
public class OutputCleanupJob extends QuartzJobBean implements StatefulJob {

	private static final Log LOG = LogFactory.getLogger(OutputCleanupJob.class);

	public static final String QUARTZ_SCHEDULE_NAME = "TempFileCleanup";

	public static final String EXPIRES_PROP_NAME_PROP = "ExpireTimeServiceProp";

    public static final long DEFAULT_EXPIRE_MINS = 420;
    public static final long DEFAULT_EXPIRE_HRS = 8;

	public static final long MILLIS_IN_MIN = 60000;

	public static final long MIN_IN_HRS = 60;


	public OutputCleanupJob() {
		super();
	}

	/**
	 * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
	 */
	@Override
    public void executeInternal(JobExecutionContext context) {

		if (context == null) {
			throw new IllegalArgumentException("context argument is null");
		}

        JobDataMap map = context.getMergedJobDataMap();
        OutputManager outputManager =
            (OutputManager) map.get(OutputConstants.OUTPUT_MANAGER_BEAN_NAME_PROP);

        String expireTimeHrs = (String) outputManager.
        getProperty(OutputConstants.KEY_SAVE_COMPLETED_JOBS_IN_HRS);
        if (expireTimeHrs == null) {
        expireTimeHrs = Long.toString(DEFAULT_EXPIRE_HRS);
        }

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR_OF_DAY, Integer.parseInt(expireTimeHrs) * -1);
        long lastPurgeTime = cal.getTimeInMillis();


        StatusInfo tmpStatus = new StatusInfo();
        //remove completed jobs
        tmpStatus.setStatus(OutputConstants.RequestStatus.COMPLETED.toString());
        tmpStatus.setStatusCode(OutputConstants.RequestStatus.COMPLETED.statusCode());
	    purgeJobs(tmpStatus, cal.getTime(), outputManager.getLocationStrategy());

	    //remove Canceled Jobs
        tmpStatus.setStatus(OutputConstants.RequestStatus.CANCELED.toString());
        tmpStatus.setStatusCode(OutputConstants.RequestStatus.CANCELED.statusCode());
        purgeJobs(tmpStatus, cal.getTime(), outputManager.getLocationStrategy());

        //remove Failed Jobs
        tmpStatus.setStatus(OutputConstants.RequestStatus.ERROR.toString());
        tmpStatus.setStatusCode(OutputConstants.RequestStatus.ERROR.statusCode());
        purgeJobs(tmpStatus, cal.getTime(), outputManager.getLocationStrategy());
	}


	private void purgeJobs(StatusInfo statusInfo,
	                       Date endTime,
	                       LocationStrategy locationStrategy) {

        SimpleDateFormat dateFormatter = new SimpleDateFormat();
	    LOG.info("Purging Jobs with status: " + statusInfo.getStatusCode()
	             + " completed before: "
	             + dateFormatter.format(endTime));
        OutputBaseService baseService = new OutputBaseService();
        OutputJobDAO dao = baseService.getOutputJobDAO();

        Collection<OutputJob> purgeJobs =
           dao.fetchJobsByStatus(statusInfo, null, endTime);
        ArrayList<Integer> purgeJobsSeq = new ArrayList<Integer>();
        ArrayList<Integer> purgeErrJobsSeq = new ArrayList<Integer>();
        for (OutputJob job : purgeJobs) {
            try {
                locationStrategy.cleanUpJobLocations(job);
                purgeJobsSeq.add(job.getJobSeq());
            } catch (Exception ex) {
                purgeErrJobsSeq.add(job.getJobSeq());
                LOG.error("error cleaning up job: "
                        + job.getJobSeq(), ex);
            }
        }

        dao.deleteJob(purgeJobsSeq);
        dao.deleteJob(purgeErrJobsSeq);

	}
}
