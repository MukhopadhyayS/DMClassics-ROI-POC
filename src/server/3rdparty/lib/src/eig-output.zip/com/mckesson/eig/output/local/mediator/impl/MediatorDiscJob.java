/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

 * Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
 * Use of this software and related documentation is governed by a license agreement.
 * This material contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States
 * and international copyright and other intellectual property laws.
 * Use, disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without the
 * prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
 */

package com.mckesson.eig.output.local.mediator.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.disc.DiscDestination;
import com.mckesson.eig.output.local.disc.DiscTypeHandler;
import com.mckesson.eig.output.local.file.FileConstants;
import com.mckesson.eig.output.local.transformers.Concatenate;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.utility.exception.ApplicationException;

public class MediatorDiscJob extends MediatorFileJob {

	private int _dvdSize = FileConstants.DEFAULT_DVD_SIZE
			* FileConstants.GB_TO_MB;
	private int _cdSize = FileConstants.DEFAULT_CD_SIZE;

	// private static AESEncryptor _encryptor = null;

	public MediatorDiscJob(OutputJob job, Destination d, DestTypeHandler handler) {
		super(job, d, handler);
	}

	public void setDiscSize(int cdSize, int dvdSize) {
		_dvdSize = dvdSize;
		_cdSize = cdSize;
	}

	public void doneWithJob() throws IOException, InterruptedException {
		DiscTypeHandler handler = (DiscTypeHandler) getHandler();
		DiscDestination destination = (DiscDestination) getDestination();
		OutputJob job = getJob();

		try {
			Concatenate pdfConcatenate = handler.getConcatenateStrategy();
			long size = getFileMaxSizeInByte(job);
			generateBookmarks(job, handler.getBookmarkStrategy(), size);
			List<String> files = pdfConcatenate.concatenate(job, size);
			Properties p = handler.getCryptoProperties();
			// if encryption required encrypt files
			// owner password is always the request password
			// password is the given at the time of release
			String ownerPassword = destination.getRequestPassword(job);
			String password = destination.getQueuePassword(job);

			if (destination.isPasswordEncrypted(job)) {
				ownerPassword = decryptPassword(ownerPassword);
				password = decryptPassword(password);
			}

			encryptFiles(files, password, ownerPassword, p);

			// add hash file for the output file
			List<String> hashFiles = addHashFile(files, p);

			File jobDirectory = getJobDirectory(job);

			// copy to destination
			copytoDestination(files, jobDirectory);
			copytoDestination(hashFiles, jobDirectory);

			List<String> allFiles = new ArrayList<String>();
			allFiles.addAll(files);
			allFiles.addAll(hashFiles);
			Calendar completedDate = Calendar.getInstance();
			updateJobResults(job.getJobSeq(), jobDirectory, allFiles,
					completedDate);

			// update status after the resulting job files has been updated to
			// the database,
			updateStatus(job.getJobSeq(), RequestStatus.DISC_PREPARING_READY,
					OutputConstants.MSG_DISC_READY_TO_CREATE);

		} catch (Exception e) {
			updateStatus(job.getJobSeq(), RequestStatus.ERROR,
					OutputConstants.MSG_FILE_ERROR + ":" + e.toString());
			// LOG.error("Save to File error");
			// create error message file
			throw new ApplicationException(e);
		}
	}

	public long getFileMaxSizeInByte(OutputJob job) {
		long result = _cdSize;
		if (job.getPropertyValue(OutputConstants.OUTPUT_DISC_MEDIA) != null) {
			if (job.getPropertyValue(OutputConstants.OUTPUT_DISC_MEDIA)
					.equalsIgnoreCase("DVD")) {
				result = _dvdSize;
			}
		}
		return result * FileConstants.MB_SIZE;
	}

	private File getJobDirectory(OutputJob job) {
		DiscDestination destination = (DiscDestination) getDestination();
		File jobDirectory = new File(destination.getDiscdevice()
				.getTemporaryLocation()
				+ File.separator
				+ OutputConstants.DISC_PDF_TEMP,
				String.valueOf(job.getJobSeq()));
		return jobDirectory;
	}

}
