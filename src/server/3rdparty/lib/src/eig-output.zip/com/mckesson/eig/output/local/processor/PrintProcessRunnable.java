/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.mediator.OutputJobMediator;
import com.mckesson.eig.output.local.printer.PrintDestination;
import com.mckesson.eig.output.local.printer.PrintListener;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.status.StatusUtils;

public class PrintProcessRunnable extends JobProcessRunnable {
    private final PrintListener _printListener;

    public PrintProcessRunnable(DefaultTypeHandlerFactory factory, EndpointDAO dao,
            OutputManager outputManager, PrintListener printListener,
            OutputJob job) {
    	super(factory, dao, outputManager, job);
        _printListener = printListener;
    }

    private PrintDestination getPrintDestination(int id) {
        EndpointDef def = _dao.getEndpointDef(id);
        return (PrintDestination) _handler.createEndpoint(def);
    }

    public void start(OutputJob job) {
        int destId = job.getDestID();
        PrintDestination d = getPrintDestination(destId);
        job.setDestination(d);
        try {
            _mJob = OutputJobMediator.createJob(job, d, _handler);
            _mJob.initializeJob(_printListener);
        } catch (Exception e) {
            _outputManager.updateJobStatus(job.getJobSeq(), StatusUtils
                    .createRequestStatus(RequestStatus.ERROR, e.getMessage()));
        }
    }
}
