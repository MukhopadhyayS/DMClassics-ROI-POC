/*
 * Copyright 2008-2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.fax;

import java.util.Map;

import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.status.StatusUtils;

public abstract class FaxDestination extends Destination {

	private String _name;
	private FaxTypeHandler _handler;

	private StatusInfo _status;
    private String _location;	

    public FaxDestination() {
        super();
    }

    /**
     * This method can be overridden by the extending classes
     * to get the configurable properties from the Map queueProperties
     * to configure their Fax Implementation
     * @param handler
     * @param queueProperties
     * @param name
     */
	public void configureFaxDestination(FaxTypeHandler handler,
	                                    Map<String, String> queueProperties,
	                                    String name) {
	    _name = name;
	    _handler = handler;
        _status = StatusUtils.createEndpointStatus(EndpointStatus.OK, null);
	}

	public PropertyDef[] getJobOptionDefs() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
     * Process the output job and sends it to the fax destination
     *
     * @param job
     *
     * @see com.mckesson.eig.output.local.fax#processJob(com.mckesson.eig.output.model.OutputJob)
     */
	public abstract void processJob(OutputJob job);

	public StatusInfo queryEndpointStatus() {
		return _status;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

	public FaxTypeHandler getHandler() {
        return _handler;
    }

	public void setHandler(FaxTypeHandler handler) {
        _handler = handler;
    }
    @OutputProperty(
            defaultValue = "",
            description = "Location of the fax",
            label = "Location",
            required = "false",
            index = "1")
    public String getLocation() {
        return _location;
    }

    /**
     * TODO
     *
     * @param location
     *            the location to set
     */
    public void setLocation(String location) {
        if (location != null) {
            _location = location;
        } else {
            _location = "";
        }
    }   	
}
