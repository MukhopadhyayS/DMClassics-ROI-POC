/*
 * Copyright 2009-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * Property key value pair
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "property")
@XmlType(name = "property")
public class Property extends Object implements Serializable {

    private String _name;
    private String _value;

    public Property(String name, String value) {

        _name  = name;
        _value = value;
    }

    /**
     *
     */
    public Property() {
        super();
    }

    /**
     * @return the name
     */
    public String getName() {
        return _name;
    }

    /**
     * @param name the name to set
     */
    @XmlElement (name = "name")
    public void setName(String name) {
        _name = name;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return _value;
    }

    /**
     * @param value the value to set
     */
    @XmlElement (name = "value")
    public void setValue(String value) {
        _value = value;
    }


}
