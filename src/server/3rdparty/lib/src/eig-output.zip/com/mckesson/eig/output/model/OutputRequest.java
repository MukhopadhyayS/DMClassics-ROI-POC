/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.model;

import java.io.StringWriter;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.util.OutputUtil;
/**
 * AbstractOutputRequest that whose parts are OutputParts. OutputRequests represent a request to
 * the OutputService to retrieve and optional transform some content and then delivery it to
 * an OutputEndpoint
 *
 * @author OFS
 * @author Jon Anderson
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "outputRequest")
@XmlType(name = "outputRequest")
public class OutputRequest extends AbstractOutputRequest<RequestPart> {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 9;
    private static final int HASH_INIT = 9;

    private List<RequestPart> _parts;

    private boolean _delegateOnFailure;
    private List<DestDef> _delegationList;
    private int _createdBy;
    private int _modifiedBy;
    
	/**
	 * OutputRequest
	 */
	public OutputRequest() {
		super();
	}

    @Override
    public boolean equals(Object o) {

        if (!super.equals(o)) {
            return false;
        }

        OutputRequest request = (OutputRequest) o;
        if (!ObjectUtils.equals(request._parts, _parts)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {

        HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
        builder.appendSuper(super.hashCode());
        builder.append(_parts);
        return builder.toHashCode();
    }

    @Override
    public List<RequestPart> getParts() {
        return _parts;
    }

    @Override
    @XmlElementWrapper (name = "parts")
    @XmlElement(name = "requestPart", type = RequestPart.class)
    public void setParts(List<RequestPart> parts) {
        _parts = parts;
    }

    /**
     * This method is used to return the XML representation of the 
     * object.
     *
     * @return
     */
	public String getXML() {

	    StringWriter writer = new StringWriter();
        OutputUtil.getXML(this, writer);
        return writer.toString();
	}
	
	   
    public List<DestDef> getDelegationList() {
        return _delegationList;
    }

    @XmlElement (name = "delegationList", type = DestDef.class)
    public void setDelegationList(List<DestDef> deligationList) {
        _delegationList = deligationList;
    }

    public boolean isDelegateOnFailure() {
        return _delegateOnFailure;
    }

    @XmlElement (name = "delegateOnFailure")
    public void setDelegateOnFailure(boolean delegateOnFailure) {
        _delegateOnFailure = delegateOnFailure;
    }

    /**
     * 
     * @return
     */
    public int getCreatedBy() {
        return _createdBy;
    }

    /**
     * 
     * @param createdBy
     */
    @XmlElement (name = "createdBy")
    public void setCreatedBy(int createdBy) {
        _createdBy = createdBy;
    }

    /**
     * 
     * @return
     */
    public int getModifiedBy() {
        return _modifiedBy;
    }

    /**
     * 
     * @param modifiedBy
     */
    @XmlElement (name = "modifiedBy")
    public void setModifiedBy(int modifiedBy) {
        _modifiedBy = modifiedBy;
    }
}
