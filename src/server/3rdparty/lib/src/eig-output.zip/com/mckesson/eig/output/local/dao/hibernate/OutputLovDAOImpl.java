/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.dao.hibernate;

import java.io.Serializable;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.mckesson.eig.output.local.dao.OutputLovDAO;
import com.mckesson.eig.output.model.JobFileList;
import com.mckesson.eig.output.model.OutputLoV;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class OutputLovDAOImpl extends AbstractHibernateOutputDAO implements
		OutputLovDAO {
	private static final Log LOG = LogFactory.getLogger(OutputLovDAOImpl.class);
	private static final int NAME_FIELD_LENGTH = 50;

	/**
	 * This method is used for storing individual objects and handling data
	 * integrity violation exceptions.
	 *
	 * @param object
	 *            Object to create in the database.
	 * @return The primary key value of the object inserted.
	 */
	public Serializable create(OutputLoV lov) {
		lov.setCreatedDate(getDate());
		lov.setModifiedDate(getDate());
		lov.setOrganization(1);
		lov.setChildId(0);
		return super.create(lov);
	}

	/**
	 * This method is used for updating the object passed.
	 *
	 * @param object
	 *            -Object to be merged in the database.
	 */
	public OutputLoV merge(OutputLoV lov) {
		lov.setModifiedDate(getDate());
		return (OutputLoV) super.merge(lov);
	}

    /**
     * This method fetches an outputLoV.
     *
     * @param object
     */
	@SuppressWarnings("unchecked")
	public OutputLoV retrieveLoV(String name, int parentId) {
        Object[] values = {name, new Integer(parentId)};
        List<OutputLoV> result = getHibernateTemplate().findByNamedQuery(
                                                         "retrieveLoV", values);

        if ((result == null) || (result.size() == 0)) {
            return null;
        }
        return result.get(0);
    }


	/**
	 * This method fetches an output configuration from cabinet database.
	 *
	 * @return OutputLov
	 */
	@SuppressWarnings("unchecked")
	public OutputLoV retrieveOutputConfiguration() {
		List<OutputLoV> result = getHibernateTemplate().findByNamedQuery(
				"retrieveOutputConfiguration");
		LOG.debug("retrieve Output Configuration");
		if ((result == null) || (result.size() == 0)) {
			return null;
		}
		if (result.size() > 1) {
			throw new OutputException(
					OutputErrorCode.PERSISTENCE_DUPLICATE_DATA);
		}
		return result.get(0);
	}

	/**
	 * This method fetches an endpointType from cabinet database.
	 *
	 * @return list of departments
	 */
	@SuppressWarnings("unchecked")
	public OutputLoV retrieveEndpointType(String name) {
		List<OutputLoV> result = getHibernateTemplate().findByNamedQuery(
				"retrieveEndpointType", name);
		LOG.debug("retrieve EndpointType for type name:" + name);
		if ((result == null) || (result.size() == 0)) {
			return null;
		}
		if (result.size() > 1) {
			throw new OutputException(
					OutputErrorCode.PERSISTENCE_DUPLICATE_DATA);
		}
		return result.get(0);
	}

	/**
	 * This method fetches a list of endpoint from cabinet database.
	 *
	 * @return list of endpoint
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List retrieveEndpoints(int parentId) {
		List<OutputLoV> result = getHibernateTemplate().findByNamedQuery(
				"retrieveEndpoints", new Integer(parentId));
		LOG.debug("retrieve Endpoints for parentId:" + parentId);
		if ((result == null) || (result.size() == 0)) {
			return null;
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public OutputLoV retrieveEndpoint(int id) {
		List<OutputLoV> result = getHibernateTemplate().findByNamedQuery(
				"retrieveEndpoint", new Integer(id));
		LOG.debug("retrieve Endpoint id:" + id);
		if ((result == null) || (result.size() == 0)) {
			return null;
		}
		return result.get(0);
	}

	/**
	 * This method fetches the id for queue type/name.
	 *
	 * @return id of queue
	 * TODO:  hibernate query should take endpointName as first parameter-
	 *        need to correct and test across all apps

	 */
	@SuppressWarnings("unchecked")
	public int getEndpointId(String endpointType, String endpointName) {
		Object[] values = {endpointName,endpointType};
		List<Integer> endpointId = getHibernateTemplate().findByNamedQuery(
				"getEndpointIds", values);
		LOG.debug("retrieve Endpoint id for endpointType: " + endpointType + " endpointName: " + endpointName);
		if ((endpointId == null) || (endpointId.size() == 0)) {
			return 0;
		}
		return endpointId.get(0);
	}

	/**
	 * This method fetches the id for queue type/name.
	 *
	 * @return id of queue
	 */
	@SuppressWarnings("unchecked")
	public List<OutputLoV> getAllEndpointsByType(String endpointType) {
		Object[] values = { endpointType };
		List<OutputLoV> endpoints = getHibernateTemplate().findByNamedQuery(
				"getEndpointsLovByType", values);
		LOG.debug("retrieve Endpoints for endpointType: " + endpointType);
		if ((endpoints == null) || (endpoints.size() == 0)) {
			return null;
		}
		return endpoints;
	}
	
	/**
	 * This method fetches the id for queue type/name.
	 *
	 * @return id of queue
	 */
	@SuppressWarnings("unchecked")
	public List<Integer> getAllEndpointIdsByType(String endpointType) {
		Object[] values = { endpointType };
		List<Integer> endpointId = getHibernateTemplate().findByNamedQuery(
				"getEndpointIdsByType", values);
		LOG.debug("retrieve Endpoints Ids for endpointType: " + endpointType);
		if ((endpointId == null) || (endpointId.size() == 0)) {
			return null;
		}
		return endpointId;
	}

	/**
	 * This method creates the file information for the specified destination.
	 */
	public int createFileInfoForDestination(JobFileList fileList, int destID) {

		String xmlStr = fileList.getXML();
		OutputLoV lov = new OutputLoV();

		lov.setParentId(destID);
		String name = "PURGE_FILE" + UUID.randomUUID();
		if (name.length() > NAME_FIELD_LENGTH) {
		    name = name.substring(0, NAME_FIELD_LENGTH - 1);
		}
        lov.setName(name);
		lov.setData(xmlStr);
		create(lov);
		return lov.getId();
	}

	/**
	 * This method creates the file information for the specified destination.
	 */
	public JobFileList readFileInfoForDestination(int destID) {

		Object[] values = {"PURGE_FILE", new Integer(destID)};
		OutputLoV lov = (OutputLoV) getHibernateTemplate()
		.findByNamedQuery("retrieveLoV", values).get(0);
		JobFileList list = new JobFileList();
		list = (JobFileList) OutputUtil.getObject(new StringReader(lov.getData()));
		list.setListID(lov.getId());
		return list;
	}

    @SuppressWarnings("unchecked")
    public List<JobFileList> readAllFileInfoForDestination(int destID,
                                                                 Date toDate) {
       ArrayList<JobFileList> fileList = new ArrayList<JobFileList>();
       Object[] values = new Object[] {"PURGE_FILE",
                                       new Integer(destID),
                                        toDate};
        List<OutputLoV> lovList = getHibernateTemplate()
            .findByNamedQuery("retrieveAllFileInfoForDestination", values);
        for (OutputLoV outputLoV : lovList) {
            JobFileList list = new JobFileList();
            list = (JobFileList) OutputUtil.getObject(new StringReader(outputLoV.getData()));
            list.setListID(outputLoV.getId());
            fileList.add(list);
        }
        return fileList;
    }

    @SuppressWarnings("unchecked")
    public void deleteAllFileInfoForDestination(int destID,
                                                Date toDate) {

        Object[] values = new Object[] {"PURGE_FILE",
                                        new Integer(destID),
                                        toDate};
        List<OutputLoV> lovList = getHibernateTemplate()
            .findByNamedQuery("retrieveAllFileInfoForDestination", values);
        for (OutputLoV outputLoV : lovList) {
            delete(outputLoV);
        }
    }


	/**
	 * This method modifies the file information for the specified destination.
	 */
	public void updateFileInfoForDestination(JobFileList fileList) {

		String xmlStr = fileList.getXML();
		OutputLoV lov = new OutputLoV();

		lov = retrieveEndpoint(fileList.getListID());
		lov.setModifiedDate(getDate());
		lov.setData(xmlStr);
		update(lov);
	}
}
