/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * Default implementation which creates a directory for each job
 * and each endpoint
 *
 * @author Jon Anderson
 */
public class DefaultLocationStrategy
	extends BaseComponent implements LocationStrategy {

	private static final Log LOG =
		LogFactory.getLogger(DefaultLocationStrategy.class);

	/** /tmp/output */
	public static final String DEFAULT_STAGING_DIR
		= IOUtils.DIR_SEPARATOR + "tmp" + IOUtils.DIR_SEPARATOR + "output";

	/**
	 * TODO
	 */
	public DefaultLocationStrategy() {
		super();
		setProperty(OutputConstants.STAGING_DIR, DEFAULT_STAGING_DIR);
	}

	/**
	 * @see LocationStrategy#cleanUpJobLocations(OutputJob)
	 */
	public void cleanUpJobLocations(OutputJob outputJob) {

	    String stagingDir = (String) getProperty(OutputConstants.STAGING_DIR);
		if (outputJob == null) {
			throw new IllegalArgumentException("outputJob is null");
		}

		if (!FileUtils.deleteQuietly(new File(stagingDir,
		                                      new Long(outputJob.getJobSeq())
		                                      .toString()))) {
			LOG.error("failed to clean up directory: "
					+ stagingDir
					+ IOUtils.DIR_SEPARATOR
                    + new Long(outputJob.getJobSeq()).toString());
		}
	}

	/**
	 * @see LocationStrategy#setJobLocations(OutputJob)
	 */
	public void setJobLocations(OutputJob outputJob) {
        String stagingDir = (String) getProperty(OutputConstants.STAGING_DIR);

		if (outputJob == null) {
			throw new IllegalArgumentException("outputJob is null");
		}

		try {
			File dir = new File(stagingDir,
					new Long(outputJob.getJobSeq()).toString());

			FileUtils.forceMkdir(dir);
			String location = dir.getCanonicalPath();
			outputJob.setCurrentLocation(location);
			outputJob.setBaseLocation(location);

			LOG.debug("created directory: " + location + " for job "
					+  outputJob.getJobSeq());

//			for (JobPart part : outputJob.getParts()) {
//
//				File subdir = new File(dir,
//						new Long(part.getPartID()).toString());
//				FileUtils.forceMkdir(subdir);
//				part.setCurrentLocation(subdir.getCanonicalPath());
//				part.setBaseLocation(subdir.getCanonicalPath());
//			}

		} catch (IOException e) {
			throw new OutputException(OutputConstants.OutputErrorCode.RUNTIME_ERROR, e);
		}
	}

	/**
	 * Returns the directory under which job and part directories will be
	 * created
	 *
	 * @return the _stagingDir
	 */
	public String getStagingDir() {
		return (String) getProperty(OutputConstants.STAGING_DIR);
	}

}
