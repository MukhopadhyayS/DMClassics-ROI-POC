/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.printer.impl;

import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

import com.mckesson.eig.output.local.printer.PrintDestination;
import com.mckesson.eig.output.local.printer.PrintListener;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.utility.io.ExecUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * Facade for printing on windows.
 * 
 * @author Srini Paduri
 * 
 * @since 13.5.2
 * 
 */
public class WinPrintFacade extends AbstractPrintFacade {

    private static final Log LOG = LogFactory.getLogger(WinPrintFacade.class);
    private static final int DEFAULT_THRESHOLD = 5;
    private static final String PRINTER_NAME = "-printer=";
    private static final String JOB_NAME = "-jobName=";
    private static final String IN_PREFIX = "-in=";
    private static final int FOUR = 4;
    private static final int THREE = 3;
    private static Integer _threshold = DEFAULT_THRESHOLD;

    private boolean _processed = false;
    private final PrintListener _listener;
    private final ArrayList<String> _files;
    private OutputStreamWriter _processOutputStream;
    private Process _pdfPrintProcess;

    /**
     * Sends job to print destination based on strategy to be used.
     * 
     * @param job
     * @param destinationName
     * @throws InterruptedException
     * @throws IOException
     */
    public WinPrintFacade(OutputJob job, Object listener) {
        super(job);
        _files = new ArrayList<String>();
        _listener = (PrintListener) listener;
    }

    public void addFile(String fileName) throws IOException, InterruptedException {

        synchronized (_files) {
            _files.add(fileName);
        }

        String f;
        if (_processed) {
            synchronized (_files) {
                f = _files.remove(0);
            }
            f = new File(f).getAbsolutePath();
            _processOutputStream.write("FILE\t" + f + "\n");
            LOG.debug("File passed:" + "FILE\t" + f + "\n");
        } else if (!_processed && evaluateReady(_files.size())) {
            _processOutputStream = print();
            while (!_files.isEmpty()) {
                synchronized (_files) {
                    f = _files.remove(0);
                }
                f = new File(f).getAbsolutePath();
                _processOutputStream.write("FILE\t" + f + "\n");
                LOG.debug("File passed:" + "FILE\t" + f + "\n");
            }
            _processed = true;
        }
    }
    public void donewithJob() throws IOException, InterruptedException {

        if (_processed) {
            _processOutputStream.write("DONE\n");
            _processOutputStream.close();
            int returnValue = _pdfPrintProcess.waitFor();
            evaluate(returnValue);
        } else if (1 == _files.size()) {
            print(_files.get(0));
            _processed = true;
        } else {
            String f;
            _processOutputStream = print();
            while (!_files.isEmpty()) {
                synchronized (_files) {
                    f = _files.remove(0);
                }
                f = new File(f).getAbsolutePath();
                _processOutputStream.write("FILE\t" + f + "\n");
                LOG.debug("File passed:" + "FILE\t" + f + "\n");
            }
            _processOutputStream.write("DONE\n");
            _processOutputStream.close();
            int returnValue = _pdfPrintProcess.waitFor();
            evaluate(returnValue);
            _processed = true;
        }
    }
    /**
     * Prints PDF document. Supports postscript or pcl drivers.
     * 
     * @since 13.5.2
     */
    private void print(String inputFileName) throws IOException,
            InterruptedException {

        getJob().logMetric("Start print spooling");
        int val;
        List<String> list = getPrintProperties(getCopies(), getDuplex(), isReversePrintOrder());
        int args = FOUR + list.size();
        String[] cmdarray = new String[args];
        int i = 0;
        cmdarray[i++] = getPdfExePath();
        cmdarray[i++] = PRINTER_NAME + ((PrintDestination) getJob()
                .getDestination()).getPrinterName();
        cmdarray[i++] = IN_PREFIX + inputFileName;
        cmdarray[i++] = JOB_NAME + getJob().getJobName() + "-" + getJob().getJobSeq();
        for (int j = 0; j < list.size(); j++) {
            cmdarray[i + j] = list.get(j);
        }

        _listener.printingStart(getJob().getJobSeq());

        val = ExecUtilities.execAndWaitFor("pdf printing", cmdarray,
                null, getPdfExeWorkingDir());

        String parameters = "";
        for (String element : cmdarray) {
            parameters += " " + element;
        }
        LOG.debug(getPdfExePath() + parameters + " execution returned: " + val);
        evaluate(val);
    }

    /**
     * Prints PDF document. Supports postscript or pcl drivers.
     * 
     * @since 13.5.2
     */
    private OutputStreamWriter print() throws IOException,
            InterruptedException {

        getJob().logMetric("Start print spooling");
        List<String> list = getPrintProperties(getCopies(), getDuplex(), isReversePrintOrder());
        int args = THREE + list.size();
        String[] cmdarray = new String[args];
        int i = 0;
        cmdarray[i++] = getPdfExePath();
        cmdarray[i++] = PRINTER_NAME + ((PrintDestination) getJob()
                .getDestination()).getPrinterName();
        cmdarray[i++] = JOB_NAME + getJob().getJobName() + "-" + getJob().getJobSeq();
        for (int j = 0; j < list.size(); j++) {
            cmdarray[i + j] = list.get(j);
        }

        _listener.printingStart(getJob().getJobSeq());

        _pdfPrintProcess = ExecUtilities.execAndPipeinput("pdf printing", cmdarray,
                null, getPdfExeWorkingDir());

        String parameters = "";
        for (String element : cmdarray) {
            parameters += " " + element;
        }
        LOG.debug(getPdfExePath() + parameters + " is executed");

        return new OutputStreamWriter(_pdfPrintProcess.getOutputStream());
    }

    private void evaluate(int returnValue) {
        if (returnValue == 0) {
            _listener.printingCompleted(getJob().getJobSeq());
            LOG.debug("Completed spooling");
            getJob().logMetric("Finished Print spooling");
        } else {
            _listener.printingFailed(getJob().getJobSeq());
            LOG.debug("Failed spooling print job");
            getJob().logMetric("Printing failed");
        }
        getJob().printMetric();
    }

    private int getThreshold() {
        return _threshold;
    }

    public void setThreshold(int threshold) {
        if (threshold > 0) {
            _threshold = threshold;
        }
    }

    /**
     * Evaluates if a job is ready for processing by printer. When a print job
     * is in streaming mode, a job is sent to printer only after it has reached
     * specified threshold.
     * 
     * @param job
     * @param fileCount
     * @return
     */
    private boolean evaluateReady(int fileCount) {
        if (fileCount > getThreshold()) {
            return true;
        }
        return false;
    }

}
