/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;

/**
 * TODO
 * @author Jon Anderson
 *
 */
public class InvalidDefinitionException extends OutputException {

	private static final long serialVersionUID = 1L;

	/**
	 * TODO
	 * @param message
	 */
	public InvalidDefinitionException(String message) {
		super(message, OutputErrorCode.GENERAL_APP_ERROR);
	}

	/**
	 * TODO
	 * @param message
	 * @param errorCode
	 */
	public InvalidDefinitionException(
			String message,
			OutputErrorCode errorCode) {
		super(message, errorCode);
	}


}
