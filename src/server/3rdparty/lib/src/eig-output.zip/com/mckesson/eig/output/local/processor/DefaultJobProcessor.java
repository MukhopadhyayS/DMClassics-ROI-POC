/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants.DestinationType;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.OutputSettingConstants;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;

public class DefaultJobProcessor extends  AbstractJobProcessor {

    private static final int DEFAULT_JOB_SIZE = 3;

    private static final Log LOG = LogFactory.getLogger(DefaultJobProcessor.class);
	private static final String FILE_QUEUE = DestinationType.FILE.toString();
	private static final String FAX_QUEUE = DestinationType.FAX.toString();
	private static final String EMAIL_QUEUE = DestinationType.EMAIL.toString();
	private static final String SOCKET_QUEUE = DestinationType.SOCKET.toString();

	private final List<Integer> _avaiableQueues = new ArrayList<Integer>();

	public DefaultJobProcessor(DefaultTypeHandlerFactory factory,
			OutputManager outputManger, EndpointDAO dao, OutputJobDAO jobDao, JobProcessorHelper helper) {
		super(factory, outputManger, dao, jobDao, helper);
		setExecutorSize(DEFAULT_JOB_SIZE);
	}

	/**
	 * This method is used to set the properties
	 *
	 */
	public void setProperties(Properties p) {
		super.setProperties(p);
		try {
			String value = p.getProperty(OutputSettingConstants.CONCURRENT_DEFAULT_JOB);
			if (value != null) {
				setExecutorSize(Integer.parseInt(value));
			}
	    } catch (Exception e) {
	    	LOG.info("Fail to set default processor properties. Use Default. Msg: " + e.getMessage());
	    }
	}
	
	protected void preStartProcessing() {
		configQueueList();
	}
	
	/**
	 * This method is used to refresh the queue
	 *
	 */
	public void refreshQueueList() {
		configQueueList();
	}

	/**
	 * This method is used to process the output job
	 *
	 */
	public boolean processJob() {
    	try {
	        Integer jobId = getNextAvailableJob(_avaiableQueues, RequestStatus.READY, RequestStatus.PROCESSING);
        	if (jobId != null) {
    			LOG.debug("Start retieveing source for Job:" + jobId);
        		JobProcessRunnable p = creatJobProcessorTask(jobId);
        		_executor.execute(p);
        		return true;
        	}
    	} catch (Exception e) {
    		LOG.error("DefaultJobProcessor-start-Exception: " + e.getMessage());
    	}
       	return false;
	}

	public void configQueueList() {
		LOG.debug("Update Queue List");
		_avaiableQueues.clear();
		List<String> queues = new ArrayList<String>();
		queues.add(EMAIL_QUEUE);
		queues.add(FAX_QUEUE);
		queues.add(FILE_QUEUE);
		queues.add(SOCKET_QUEUE);
		List<Integer> result =  _dao.getEndpointIds(queues);
		if (!CollectionUtilities.isEmpty(result)) {
			_avaiableQueues.addAll(result);
		}
	}

	private JobProcessRunnable creatJobProcessorTask(Integer jobId) {
		OutputJob job = createJob(jobId);
		JobProcessRunnable processor = new JobProcessRunnable(_factory,
				_dao, _outputManger, job);
		job.logMetric("Start Processing Job:" + jobId);
		return processor;
	}
	
}
