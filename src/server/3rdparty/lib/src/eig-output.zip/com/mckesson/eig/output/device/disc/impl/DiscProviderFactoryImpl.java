package com.mckesson.eig.output.device.disc.impl;

import java.util.HashMap;
import java.util.Map;

import com.mckesson.eig.output.device.disc.DiscProviderFactory;
import com.mckesson.eig.output.device.disc.DiscProviderManager;
import com.mckesson.eig.output.local.device.disc.DiscDeviceStatusListener;

public class DiscProviderFactoryImpl implements DiscProviderFactory {
	Map<String, DiscProviderManager> _discProviderManagerMap = new HashMap<String, DiscProviderManager>();

	@Override
	public DiscProviderManager getDiscProviderManager(String vendor) {
		return _discProviderManagerMap.get(vendor.toLowerCase());
	}
	
	@Override
	public void addDiscProviderManager(String vendor, DiscProviderManager discProviderManager) {
		_discProviderManagerMap.put(vendor.toLowerCase(), discProviderManager);
	}

	@Override
	public Map<String, DiscProviderManager> getDiscProviderManagerMap() {
		if(this._discProviderManagerMap == null){
			_discProviderManagerMap = new HashMap<String, DiscProviderManager>();
		}
		return _discProviderManagerMap;
	}

	@Override
	public void setDiscProviderManagerMap(
			Map<String, DiscProviderManager> discProviderManagerMap) {
		_discProviderManagerMap = discProviderManagerMap;
	}
	
	@Override
	public void setDiscDeviceStatusListener(DiscDeviceStatusListener listener) {
		for (DiscProviderManager manager : _discProviderManagerMap.values()) {
			manager.setDiscDeviceStatusListener(listener);
		}
    	
    }

}
