package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.Date;

public class OutputLoV implements Serializable {
    private int  _id;
    private int _parentId;
    private int _childId;
    private int  _recordVersion;
    private String _data;
    private int _createdBy;
    private int _modifiedBy;
    private Date _createdDate;
    private Date _modifiedDate;
    private int _organization;
    private String _name;

	public int getId() {
		return _id;
	}

	public void setId(int id) {
		_id = id;
	}

	public int getRecordVersion() {
		return _recordVersion;
	}

	public void setRecordVersion(int recordVersion) {
		_recordVersion = recordVersion;
	}

	public String getData() {
		return _data;
	}

	public void setData(String data) {
		_data = data;
	}
	public int getCreatedBy() {
		return _createdBy;
	}

	public void setCreatedBy(int createdBy) {
		_createdBy = createdBy;
	}

	public int getModifiedBy() {
		return _modifiedBy;
	}

	public void setModifiedBy(int modifiedBy) {
		_modifiedBy = modifiedBy;
	}

	public Date getCreatedDate() {
		return _createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		_createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	public int getOrganization() {
		return _organization;
	}

	public void setOrganization(int organization) {
		_organization = organization;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

	public int getParentId() {
		return _parentId;
	}

	public void setParentId(int parentId) {
		_parentId = parentId;
	}

	public int getChildId() {
		return _childId;
	}

	public void setChildId(int childId) {
		_childId = childId;
	}
}
