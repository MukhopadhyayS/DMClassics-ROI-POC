/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Corporation and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Corporation.
 */
package com.mckesson.eig.output.local.fax;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.mckesson.eig.output.local.AbstractTypeHandler;
import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.output.util.UnknownObjectException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * This class provides implementations for Fax destination type handlers
 *
 * @author OFS
 * @since Dec 4, 2009
 */
public class FaxTypeHandler extends AbstractTypeHandler {

    private static final String STATUS_QUEUE_NAME = "StatusQueueName";
	private static final Log LOG = LogFactory.getLogger(FaxTypeHandler.class);

    private final Map<String, FaxDestination> _faxDestMap
        = new HashMap<String, FaxDestination>();

    private Class<OutputEndpoint> _endpointClass;

    private EndpointCategory _endpointCategory;

    private Map<String, String> _faxConfigProps = new HashMap<String, String>();

	private FaxStatusListener _listener = null;

    public FaxTypeHandler(String enabled,
                          String endPointClass,
                          String endPointCategory,
                          Map<String, String> queueConfigProps) {

        setEnabled(enabled);
        setEndpointClass(endPointClass);
        setEndpointCategory(endPointCategory);
        _faxConfigProps = queueConfigProps;
    }

    @Override
    public PropertyDef[] getPropertyDefs() {
        return PropertySupport.extractAnnotatedProperties(_endpointClass);
    }

    public PropertyDef[] getDevicePropertyDefs(String deviceID) {
        FaxDestination dest = _faxDestMap.get(deviceID);
        if (dest != null) {
            return dest.getPropertyDefs();
        }
        return null;
    }

    public Collection<String> queryDeviceIDs() {
        return _faxDestMap.keySet();
    }

    /**
     * Returns the device properties as a map
     *
     * @see com.mckesson.eig.output.local.DestTypeHandler#queryDeviceProperties(java.lang.String)
     */
    public Map<String, Object> queryDeviceProperties(String deviceID) {
        FaxDestination dest = _faxDestMap.get(deviceID);
        if (dest != null) {
            return PropertySupport.createDefaultValuesMap(dest.getPropertyDefs());
        }
        return null;
    }

    public StatusInfo queryDeviceStatus(String deviceID) {
        FaxDestination dest = _faxDestMap.get(deviceID);
        if (dest != null) {
            return dest.queryEndpointStatus();
        }
        return null;
    }

    public void cleanUp() {
        // TODO Auto-generated method stub
    }

    /**
     * Create Endpoint for Fax destination
     *
     * @param endpointDef
     *
     * @see
     * com.mckesson.eig.output.local.fax#createEndpoint(com.mckesson.eig.output.model.EndpointDef)
     */
    public OutputEndpoint createEndpoint(EndpointDef endpointDef) {

        try {

            FaxDestination endpoint = (FaxDestination) getEndpointClass().newInstance();

            endpoint.configureFaxDestination(this, _faxConfigProps, endpointDef.getName());

            if (endpointDef.getProperties() != null && endpointDef.getProperties().size() > 0) {
                endpoint.getProperties().setProperties(endpointDef.getProperties());
            }
            _faxDestMap.put(endpointDef.getName(), endpoint);
            return endpoint;
        } catch (Exception e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

    /**
     * Destroy Endpoint for Fax destination
     *
     * @param endpointDef
     *
     * @see
     * com.mckesson.eig.output.local.fax#createEndpoint(com.mckesson.eig.output.model.EndpointDef)
     */
    public void destroyEndpoint(OutputEndpoint endpoint) {
        if (_faxDestMap.containsValue(endpoint)) {
            FaxDestination dest = (FaxDestination) endpoint;
            String name  = dest.getName();
            _faxDestMap.remove(name);
        }
    }

    public String[] getEndpointContentTypes() {
        return OutputConstants.ANY_CONTENT_TYPE;
    }

    public EndpointCategory getEndpointCategory() {
        return _endpointCategory;
    }

    public void updateJobStatus(int jobId, StatusInfo statusInfo) {
    	try {
	        if (_outputManager != null) {
	            _outputManager.updateJobStatus(jobId, statusInfo);
	        }
    	} catch (UnknownObjectException e) {
 			LOG.error("Unable to update job: " + jobId + " - " + e);
    	}
    }

    public void setEndpointCategory(String endpointCategory) {
        _endpointCategory = EndpointCategory.valueOf(endpointCategory);
    }

    public Class<OutputEndpoint> getEndpointClass() {
        return _endpointClass;
    }

    /**
     * Sets the Class object associated with the class with the given string name
     *
     * @param endpointClass
     */
    @SuppressWarnings("unchecked")
    public void setEndpointClass(String endpointClass) {

        if (endpointClass == null) {
            throw new IllegalArgumentException(
                    "endpointClass argument is null");
        }

        try {
            _endpointClass =
                (Class<OutputEndpoint>) Class.forName(endpointClass);

        } catch (ClassNotFoundException e) {
            throw new InvalidDefinitionException(
                    "endpointClass: " + endpointClass,
                    OutputErrorCode.REFERENCE_INVALID);
        }
    }

    public void setUpListener() {
        if (_listener == null)  {
        	if (_faxConfigProps != null && _faxConfigProps.get(STATUS_QUEUE_NAME) != null) {
        		_listener = new FaxStatusListener(this,
        				_faxConfigProps.get(STATUS_QUEUE_NAME));
        	}
        }
    }
}
