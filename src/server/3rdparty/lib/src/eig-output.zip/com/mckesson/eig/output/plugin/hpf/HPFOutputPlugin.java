/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.plugin.hpf;

import java.rmi.RemoteException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;
import org.apache.axis.transport.http.HTTPConstants;

import com.mckesson.eig.CodeList;
import com.mckesson.eig.SigninPortType;
import com.mckesson.eig.SigninServiceLocator;
import com.mckesson.eig.User;
import com.mckesson.eig.UserList;
import com.mckesson.eig.output.local.source.hpf.service.ConfigurationWebServiceCaller;
import com.mckesson.eig.output.model.OutputUser;
import com.mckesson.eig.output.plugin.OutputPlugin;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.wsfw.security.service.Authenticator;
import com.mckesson.eig.wsfw.session.WsSession;

/**
 * @author Pranav Amarasekaran
 * @date   Jul 28, 2009
 * @since  Output 1.0; Jul 28, 2009
 *
 * This class is the output plugin implementation of HPF application. This class is
 * not made abstract if any application using output service requires all the HPF
 * users can use this implementation. 
 */
public abstract class HPFOutputPlugin implements OutputPlugin {
	
	private static final Log LOG = LogFactory.getLogger(HPFOutputPlugin.class);
	private static final String SERVICE_URL = "{0}://{1}:{2}/portal/eig/iservices";
	private static final String TIME_URL = "{0}://{1}:{2}";
	private static final String CONFIG_SERVICE_NAME = "/configuration";
	private static final String SIGN_IN_SERVICE_NAME = "/signin";
	private static final String PRIVATE_KEY = "ci.security.privateKey";
	
	/**
	 * This holds the protocol which this client uses to communicate to the HPF web 
	 * service.
	 */
    private String _protocol;
    
    /**
     * This holds the server where the HPF web service resides.
     */
    private String _server;
    
    /**
     * This holds the port in which the HPF service is up.
     */
    private String _port;	
	
	/**
	 * This constructor is invoked from the spring configuration. The application which
	 * uses the service is responsible to specify these parameters as they are used by 
	 * the class to communicate to the web service.
	 * 
	 * @param protocol
	 * @param server
	 * @param hostName
	 */
	public HPFOutputPlugin(String protocol, String server, String port) {
		
		super();
		_protocol = protocol;
		_server = server;
		_port = port; 
	}	
	
	/**
	 * This method is used to get the protocol which this client uses to 
	 * communicate to the HPF web service.
	 * 
	 * @return
	 */
    public String getProtocol() { 
    	return _protocol; 
    }
    
    /**
     * This method is used to set the protocol which this client uses to 
     * communicate to the HPF web service.
     * 
     * @param protocol
     */
    public void setProtocol(String protocol) { 
    	_protocol = protocol; 
    }
    
    /**
     * This method is used to get the server where the HPF web service resides
     * 
     * @return
     */
	public String getServer() {
		return _server;
	}
	
	/**
	 * This method is used to set the server where the HPF web service resides.
	 * 
	 * @param server
	 */
	public void setServer(String server) {
		_server = server;
	}
	
	/**
	 * This method is used to get the port in which the HPF service is up.
	 * 
	 * @return
	 */
	public String getPort() {
		return _port;
	}
	
	/**
	 * This method is used to set the port in which the HPF service is up.
	 * 
	 * @param port
	 */
	public void setPort(String port) {
		_port = port;
	}
	
	/**
	 * This method has to be overriden in a subclass of the application using output
	 * service, to filter users based on the security rights.  
	 * 
	 * @return
	 */
	protected abstract CodeList getOutputRights();

	/**
	 * This method returns all the HPF users and converts them to list
	 * of output users.
	 */
	public List<OutputUser> getAllOutputUsers() {
		
        SigninServiceLocator loc = new SigninServiceLocator();
        String url = getServiceUrl(SIGN_IN_SERVICE_NAME);
        loc.setsigninEndpointAddress(url);

        try {
	        SigninPortType service = loc.getsignin();

	        setSessionInfo((Stub) service, WsSession.getSessionId());

	        String userID = (String) WsSession.getSessionData(Authenticator.KEY_USERNAME);
	        String password = (String) WsSession.getSessionData(Authenticator.KEY_PASSWORD);
	        
	        /**
             * Here userName would be like "Domain name\User name" if authentication is
             * ladap authentication.
             */
            StringTokenizer st = new StringTokenizer(userID, "\\");
            String tempUserID = null;
            if (st.countTokens() == 2) {

                String[] userInfo = userID.split("~");
                tempUserID = userInfo[1];	
            } else {
            	tempUserID = userID;
            }
	        
	        String key = getConfigurationKey(tempUserID, password);
	        CodeList codeList = getOutputRights();
	        
	        UserList list = null;
	        boolean recall = false;
			// CR# 353,945 - MonitorJobs Session Expired Fix 
			try {
				list = service.getUsers(tempUserID, password,
						getServerTime(), key, codeList);
			} catch (Exception e) {
				// Just to re authenticate in case hpfw is restarted. Need to create a new session with the
				// same session id. 
				reAuthenticate(service, userID, password);
				recall = true;
			}		
			if (recall) {
				key = getConfigurationKey(tempUserID, password);
				list = service.getUsers(tempUserID, password, getServerTime(), key, codeList);
				recall = false;
			}
		
			return convertUserListtoOutputList(list);
        } catch (Throwable e) {
            throw new OutputException(OutputErrorCode.SERVICE_ERROR, e);
        }
	}

	// CR# 353,945 - MonitorJobs Session Expired Fix 
	/*
	 * Authenticate the HPFW if the session has been expired.
	 */
	private void reAuthenticate(SigninPortType service, String userID,
			String password) throws RemoteException {
		
		StringTokenizer st = new StringTokenizer(userID, "\\");
		
		if (st.countTokens() == 2) {

		    String[] userInfo = userID.split("~");
		    service.signinWithLdap(userInfo[0], password, userInfo[1]);
        } else {
            service.signin(userID, password);
        }
	}
		 
	
	/**
	 * Helper method used to set the session info, which helps to maintain the session.
	 *  
	 * @param stub
	 * @param sessionId
	 * @throws Exception
	 */
	 private void setSessionInfo(Stub stub, String sessionId) 
	 throws Exception {
	  
	        //For Axis to maintain session
	        stub.setMaintainSession(true);
	        stub._setProperty(HTTPConstants.HEADER_COOKIE, "JSESSIONID=" + sessionId);
	        // This trackSession property is used to track session for HPF Server with respect any
	        // client application.
	        SOAPHeaderElement elem = new SOAPHeaderElement("urn:eig.mckesson.com", "trackSession");
	        elem.addTextNode("true");
	        
	        stub.setHeader(elem);
	 }

	/**
	 * This method is used to fetch the time of the server in the HPF
	 * service is residing. This is required for the HPF to process further
	 * service request.
	 * 
	 * @return
	 */
	private String getServerTime() {
		
		ConfigurationWebServiceCaller caller = new ConfigurationWebServiceCaller();
		Object[] args = { getProtocol(), getServer(), getPort() };
		return caller.createTime(new MessageFormat(TIME_URL).format(args));
	}
	
	/**
	 * This method is used to create a web service URL which can be used to communicate 
	 * to the HPF service. This creates the URL based on the service name passed to it.
	 * The web service URL is created based on the protocol, server and port which are 
	 * configured in the spring configuration.
	 * 
	 * @param serviceName
	 * 
	 * @return web service URL
	 */
	private String getServiceUrl(String serviceName) {

		Object[] args = { getProtocol(), getServer(), getPort() };
		MessageFormat mf = new MessageFormat(SERVICE_URL + serviceName);
		return mf.format(args);
	}
	
	/**
	 * This method is used to fetch the key which is required by the sign in service 
	 * to fetch the list of users.
	 * 
	 * @param userName
	 * @param password
	 * 
	 * @return configuration key
	 */
	private String getConfigurationKey(String userName, String password) {

		ConfigurationWebServiceCaller caller = new ConfigurationWebServiceCaller();
        String url = getServiceUrl(CONFIG_SERVICE_NAME);
		try {
			return caller.getConfiguration(url, userName, password).get(PRIVATE_KEY);
		} catch (Exception e) {
			LOG.error("getConfiguration" + e.getMessage());
			return null;
		}
	}

	/**
	 * This method is used to convert the list of HPF users to list of output
	 * users.
	 * 
	 * @param list of HPF users.
	 * 
	 * @return list of output users.
	 */
	private List<OutputUser> convertUserListtoOutputList(UserList list) {
		
		User[] users = list.getUsers();
		int noOfUsers = users.length;
		List<OutputUser> outputUsers = new ArrayList<OutputUser>(noOfUsers);
		
		for (int i = 0; i < noOfUsers; i++) {
			
			OutputUser user = new OutputUser();
			user.setId(users[i].getInstanceId());
			user.setUserID(users[i].getLoginId());
			user.setFullName(users[i].getFullName());
			outputUsers.add(user);
		}
		return outputUsers;
	}
}
