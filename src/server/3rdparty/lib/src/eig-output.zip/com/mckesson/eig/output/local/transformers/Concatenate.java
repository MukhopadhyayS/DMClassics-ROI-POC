package com.mckesson.eig.output.local.transformers;

import java.util.List;

import com.mckesson.eig.output.model.OutputJob;

public interface Concatenate {
	public List<String> concatenate(OutputJob job, long size);
	public List<String> concatenate(OutputJob job);
	

}
