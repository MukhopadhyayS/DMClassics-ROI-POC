/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.device.disc.rimage;

import java.io.StringWriter;
import java.io.Writer;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class ObjectMarshaller {

    
    private static final String HEADER_PROPERTY = "com.sun.xml.bind.xmlHeaders";
    private static final String JAXB_FRAGMENT = "jaxb.fragment";
    private static final String XML_DECLARATION = "com.sun.xml.bind.xmlDeclaration";
    private static final String XML = "<?xml version=\"1.0\"?>";
    
    public static final Log LOG = LogFactory.getLogger(ObjectMarshaller.class);
    
    
    public static String marshalObject(Object object, String doctype) throws Exception {
        return marshalObject(object, doctype, Boolean.FALSE);
    }

    
    public static String marshalAsFragment(Object object) throws Exception{
        return marshalObject(object, "", Boolean.TRUE);
    }
    
    private static String marshalObject(Object object, String doctype, boolean isFragment) throws Exception {

        Writer writer = new StringWriter();
        String header = "";
        
        try {
        
            JAXBContext jaxbContext = JAXBContext.newInstance(object.getClass());
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            jaxbMarshaller.setProperty(XML_DECLARATION, Boolean.FALSE);
            if(isFragment){
                jaxbMarshaller.setProperty(JAXB_FRAGMENT, Boolean.TRUE);    
            }else{
                header = new StringBuffer(XML).append(doctype).toString();
                jaxbMarshaller.setProperty(HEADER_PROPERTY, header);
                
            }
            
            jaxbMarshaller.marshal(object, writer);
        } catch (Exception ex) {
            LOG.error("Can not marshal object, object type: " + object.getClass() +"; reason: "  + ex.getMessage());
            throw new Exception("Can not marshal object, object type: " + object.getClass() +"; reason: "  + ex.getMessage());
        }
        
        return new StringBuffer(header).append(writer).toString();

    }

}
