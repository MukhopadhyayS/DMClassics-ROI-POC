/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.EndpointDefList;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.model.EndpointTypeDefList;
import com.mckesson.eig.output.util.UnknownObjectException;

/**
 * DAO implementation that doesn't really persist but keeps objects in memory.
 * This implementation is not thread safe.
 *
 * @author Jon Anderson
 */
public class MemoryDAO implements EndpointDAO {

    private Map<String, EndpointDef> _endpointDefs;
    private Map<String, EndpointTypeDef> _endpointTypeDefs;

    /**
     * Simple construction
     */
    public MemoryDAO() {
        _endpointDefs = new HashMap<String, EndpointDef>();
        _endpointTypeDefs = new HashMap<String, EndpointTypeDef>();
    }


    /**
     * @see EndpointDAO#createOrUpdateEndpointDef(EndpointDef)
     */
    public EndpointDef createOrUpdateEndpointDef(Integer userId, EndpointDef endpointDef) {
        if (endpointDef == null) {
            throw new IllegalArgumentException("endpointDef argument is null");
        }
        String name = endpointDef.getName();
        _endpointDefs.put(name, endpointDef);

        return endpointDef;
    }

    /**
     * @see EndpointDAO#createOrUpdateEndpointTypeDef(EndpointTypeDef)
     */
    public EndpointTypeDef updateEndpointTypeDef(
            Integer userId, EndpointTypeDef endpointTypeDef) {

        if (endpointTypeDef == null) {
            throw new IllegalArgumentException(
                    "endpointTypeDef argument is null");
        }
        String type = endpointTypeDef.getType();
        _endpointTypeDefs.put(type, endpointTypeDef);
        return endpointTypeDef;
    }

    /**
     * @see EndpointDAO#deleteEndpointDef(String)
     */
    public void deleteEndpointDef(String endpointName) {
        _endpointDefs.remove(endpointName);
    }

    /**
     * @see EndpointDAO#deleteEndpointTypeDef(String)
     */
    public void deleteEndpointTypeDef(String endpointTypeName) {
        _endpointTypeDefs.remove(endpointTypeName);
    }

    /**
     * @see EndpointDAO#readAllEndpointDefs()
     */
    public EndpointDefList readAllEndpointDefs() {
        EndpointDefList endpointDefList = new EndpointDefList();
        endpointDefList.addAll(_endpointDefs.values());
        return endpointDefList;
    }

    /**
     * @see EndpointDAO#readAllEndpointTypeDefs()
     */
    public EndpointTypeDefList readAllEndpointTypeDefs() {
        EndpointTypeDefList endpointTypeDefList = new EndpointTypeDefList();
        endpointTypeDefList.addAll(_endpointTypeDefs.values());
        return endpointTypeDefList;
    }

    /**
     * @see EndpointDAO#updateEndpointDef(EndpointDef)
     */
    public EndpointDef updateEndpointDef(Integer userId, EndpointDef endpointDef) {

        if (endpointDef == null) {
            throw new IllegalArgumentException("endpointDef argument is null");
        }
        String name = endpointDef.getName();
        if (!_endpointDefs.containsKey(name)) {
            throw new UnknownObjectException(name);
        }

        _endpointDefs.put(name, endpointDef);
        return endpointDef;
    }

	public EndpointTypeDef getEndpointTypeDef(String name) {
		return _endpointTypeDefs.get(name);
	}

	public EndpointDef createEndpointDef(EndpointDef endpointDef) {
        String name = endpointDef.getName();
        _endpointDefs.put(name, endpointDef);
        return endpointDef;
	}

	public void deleteEndpointDef(EndpointDef endpointDef) {
        String name = endpointDef.getName();
        if (_endpointDefs.get(name) != null) {
        	_endpointDefs.remove(name);
        }
	}

	public EndpointDefList getEndpointDefByType(EndpointTypeDef endpointTypeDef) {
		EndpointDefList list = new EndpointDefList();
		for (EndpointDef def : _endpointDefs.values()) {
			if (def.getType().equals(endpointTypeDef.getType())) {
				list.add(def);
			}
		}
		return list;
	}

    public EndpointDef getEndpointDef(String name, String defType) {

        for (EndpointDef def : _endpointDefs.values()) {
            if (def.getType().equals(defType)
            && def.getName().equals(name)) {
                return def;
            }
        }
        return null;
    }

	public EndpointDef getEndpointDef(int id) {
		return null;
	}

	public List<Integer> getEndpointIds(List<String> endpointTypes) {
		return null;
	}

	public List<EndpointDef> getEndpoints(List<String> endpointTypes) {
		return null;
	}
}
