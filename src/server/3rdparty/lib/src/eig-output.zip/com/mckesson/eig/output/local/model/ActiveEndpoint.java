/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.model;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.mckesson.eig.output.local.BaseComponent;
import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputPropertyMap;


/**
 * Object which represents an Endpoint that has been activated in system.
 * Holds internal state information and other data that does not need to
 * be persisted across the wire and also manages a single place for maintaining
 * an object's properties.
 *
 * @author Jon Anderson
 */
public class ActiveEndpoint {

	private static final long serialVersionUID = 1L;
    private static final int HASH_MULTIPLY = 37;
    private static final int HASH_INIT = 15;
	private OutputEndpoint _endpoint;
	private boolean _explicitPause;
	private EndpointDef _endpointDef;
	private OutputPropertyMap _properties;
	private String _camelUri;
	private String _camelErrorUri;

	/**
	 * Constructor which requires an EndpointDef and an actual OutputEndpoint.
	 * This enforces that the metadata is married to the processor
	 *
	 * @param endpointDef not <code>null</code>
	 * @param endpoint not <code>null</code>
	 */
	public ActiveEndpoint(
			EndpointDef endpointDef,
			OutputEndpoint endpoint) {

	    if (endpointDef == null) {
	        throw new IllegalArgumentException("endpointDef argument is null");
	    }
		if (endpoint == null) {
			throw new IllegalArgumentException("destination argument is null");
		}

		_endpoint = endpoint;

		if (endpoint instanceof BaseComponent) {

		    _properties = ((BaseComponent) endpoint).getProperties();

		} else {

    		PropertyDef[] propertyDefs = endpoint.getPropertyDefs();

    		if (propertyDefs == null) {
    			_properties = new OutputPropertyMap();
    		} else {
    		    _properties = new OutputPropertyMap(propertyDefs);
    		}

    	    _properties.addPropertyChangeListener(new ProxyPropertyListener());
		}

		setEndpointDef(endpointDef);
	}

    @Override
    public boolean equals(Object o) {

        ActiveEndpoint activeEndpoint = (ActiveEndpoint) o;

        if (!ObjectUtils.equals(_endpoint, activeEndpoint._endpoint)) {
            return false;
        }
        if (!ObjectUtils.equals(_endpointDef, activeEndpoint._endpointDef)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {

        HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
        builder.append(_endpointDef.getName());
        builder.append(_endpointDef.getType());
        return builder.toHashCode();
    }



	/**
	 * Returns the metadata which describes the endpoint
	 *
	 * @return not <code>null</code>
	 */
	public EndpointDef getEndpointDef() {
	    return _endpointDef.clone();
	}

	/**
	 * Sets the metadata which describes the endpoint. This may have a cascading
	 * effect of setting properties on the endpoint as well.
	 *
	 * @param endpointDef not <code>null</code>
	 */
	public void setEndpointDef(EndpointDef endpointDef) {
	    if (endpointDef == null) {
	        throw new IllegalArgumentException("endpointDef argument is null");
	    }

	    Map<String, ? extends Object> properties = endpointDef.getProperties();
	    _properties.setProperties(properties);
	    _endpointDef = endpointDef.clone();
	}

	/**
	 * Return the OutputPropertyMap properties which supports adding listeners
	 * etc.
	 *
	 * @return not <code>null</code>
	 */
	public OutputPropertyMap getProperties() {
	    return _properties;
	}

    /**
     * Returns the OutputEndpoint which is the object responsible for doing the
     * actual processing of OutputJobs
     *
     * @return not <code>null</code>
     */
	public OutputEndpoint getEndpoint() {
		return _endpoint;
	}

	public void setEndpoint(OutputEndpoint endpoint) {
		_endpoint = endpoint;
	}

	/**
	 *  Returns the current status for the Endpoint
	 *
	 * @return the statusInfo not <code>null</code>
	 */
	public StatusInfo getStatusInfo() {
		return _endpoint.queryEndpointStatus();
	}

	/**
	 * Sets the current status for the Endpoint
	 *
	 * @param statusInfo not <code>null</code>
	 */
	public void setStatusInfo(StatusInfo statusInfo) {

	    if (statusInfo == null) {
	        throw new IllegalArgumentException("statusInfo argument is null");
	    }
		_endpointDef.setStatusInfo(statusInfo);
	}

	/**
	 * Has pauseEndpoint() been called in the EndpointManager for this endpoint
	 *
	 * @return the explicitPause
	 */
	public boolean isExplicitPause() {
		return _explicitPause;
	}

	/**
	 * Set whether pauseEndpoint() has been called in the EndpointManager for
	 * this endpoint
	 *
	 * @param explicitPause the explicitPause to set
	 */
	public void setExplicitPause(boolean explicitPause) {
		_explicitPause = explicitPause;
	}

    public String getCamelUri() {
        return _camelUri;
    }

    public void setCamelUri(String camelUri) {
        _camelUri = camelUri;
    }
    public String getCamelErrorUri() {
        return _camelErrorUri;
    }

    public void setCamelErrorUri(String camelErrorUri) {
        _camelErrorUri = camelErrorUri;
    }

	public
	// Forward the property changes on the actual endpoint
	class ProxyPropertyListener implements PropertyChangeListener {

        /**
         * @see PropertyChangeListener#propertyChange(PropertyChangeEvent)
         */
        public void propertyChange(PropertyChangeEvent evt) {

            if (evt == null) {
                throw new IllegalArgumentException("evt argument is null");
            }

            String propertyName = evt.getPropertyName();
            Object value = evt.getNewValue();

            getEndpoint().setProperty(propertyName, value);

        }

	}
}
