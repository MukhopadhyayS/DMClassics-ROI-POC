/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


/**
 * General support and utility methods for dealing with the file storage of objects
 * used extensively in the output service
 *
 * @author Latonia Howard
 */

public final class LocationSupport {

    private static final Log LOG =
        LogFactory.getLogger(LocationSupport.class);

    private LocationSupport() {
        super();
    }

/*
 * Utility to clean job/part directory
 */
    public static void cleanJobLocation(OutputJob outputJob) {
        if (outputJob == null) {
            throw new IllegalArgumentException("outputJob is null");
        }

        try {
            File dir = new File(outputJob.getBaseLocation());
            FileUtils.cleanDirectory(dir);

        } catch (IOException e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

/*
 * Utility to create a sub directory under the job/part current directories and
 * set created sub directory as next location.
 */
    public static void setNextLocation(OutputJob outputJob, String dirName) {

        if (outputJob == null) {
            throw new IllegalArgumentException("outputJob is null");
        }

        if (StringUtils.isEmpty(outputJob.getCurrentLocation()))  {
            throw new IllegalArgumentException("outputJob current location is null or empty");
        }

        if (StringUtils.isEmpty(dirName)) {
            throw new IllegalArgumentException(
                 "outputJob next location directory name is null or empty");
        }

        try {
            File dir = new File(outputJob.getCurrentLocation(), dirName);

            FileUtils.forceMkdir(dir);
            String location = dir.getCanonicalPath();
            outputJob.setNextLocation(location);

            LOG.debug("created next directory: " + location + " for job "
                    +  outputJob.getJobSeq());

            for (JobPart part : outputJob.getParts()) {
                setNextLocation(part, dirName);
            }

        } catch (IOException e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }
    }

    public static void cleanNextLocation(OutputJob outputJob) {
        if (outputJob == null) {
            throw new IllegalArgumentException("outputJob is null");
        }

        try {
            File dir = new File(outputJob.getNextLocation());
            FileUtils.cleanDirectory(dir);

            for (JobPart part : outputJob.getParts()) {
                cleanNextLocation(part);
            }

        } catch (IOException e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }

    }

    /*
     * Utility to create a sub directory under the job/part current directories and
     * set created sub directory as next location.
     */
        public static void setNextLocation(JobPart jobPart, String dirName) {

            if (jobPart == null) {
                throw new IllegalArgumentException("jobPart is null");
            }

            if (StringUtils.isEmpty(jobPart.getCurrentLocation()))  {
                throw new IllegalArgumentException("jobPart current location is null or empty");
            }

            if (StringUtils.isEmpty(dirName)) {
                throw new IllegalArgumentException(
                     "jobPart next location directory name is null or empty");
            }

            try {
                File dir = new File(jobPart.getCurrentLocation(), dirName);

                FileUtils.forceMkdir(dir);
                String location = dir.getCanonicalPath();
                jobPart.setNextLocation(location);

                LOG.debug("created next directory: " + location + " for part "
                        +  jobPart.getPartID());

            } catch (IOException e) {
                throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
            }
        }

        public static void cleanNextLocation(JobPart jobPart) {
            if (jobPart == null) {
                throw new IllegalArgumentException("jobPart is null");
            }

            try {
                File dir = new File(jobPart.getNextLocation());
                FileUtils.cleanDirectory(dir);
            } catch (IOException e) {
                throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
            }

        }



    public static void setNextLocationAsCurrentLocation(OutputJob outputJob) {
        if (outputJob == null) {
            throw new IllegalArgumentException("outputJob is null");
        }

        try {
            File dir = new File(outputJob.getNextLocation());
            FileUtils.forceMkdir(dir);
            outputJob.setCurrentLocation(dir.getCanonicalPath());

            for (JobPart part : outputJob.getParts()) {
                setNextLocationAsCurrentLocation(part);
            }

        } catch (IOException e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }


    }

    public static void setNextLocationAsCurrentLocation(JobPart jobPart) {
        if (jobPart == null) {
            throw new IllegalArgumentException("jobPart is null");
        }

        try {
            File dir = new File(jobPart.getNextLocation());
            FileUtils.forceMkdir(dir);
            jobPart.setCurrentLocation(dir.getCanonicalPath());

        } catch (IOException e) {
            throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
        }


    }

    public static void removeFile(String fileName) {
        File file = new File(fileName);
        FileUtils.deleteQuietly(file);
    }

}
