/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;

import java.io.FileOutputStream;
import java.util.Map;

import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputException;

/*
 * Usage Notes: header/footer template is set for absolute position of fields
 * Default Left:AbsolutePage# Center:Content Right:RelativePage#
 * TODO :  modify to use templates (rtf or acroforms)
 */
public class PdfHeaderFooter {

	private static final int FONT_SIZE_9 = 9;
	private static final Font FONT_9 = FontFactory.getFont(
			FontFactory.COURIER_BOLD, FONT_SIZE_9);
	private static final float RIGHT_CELL_SIZE = 0.20f;
	private static final float LEFT_CELL_SIZE = 0.20f;
	private static final float CENTER_CELL_SIZE = 0.60f;

	public PdfHeaderFooter() {

	}

	public void addHeaderFooter(Map<String, String> properties,
			String soureFileName, String ouputFileName) {
		try {
			PdfReader reader = new PdfReader(soureFileName);
			PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(ouputFileName));
			int n = reader.getNumberOfPages();
			for (int i = 1; i <= n; i++) {
			    getHeaderTable(properties, i).writeSelectedRows(
			            0, -1, 34, reader.getPageSize(i).getHeight(), stamper.getOverContent(i));
			    getFooterTable(properties, i).writeSelectedRows(
			            0, -1, 34, 15, stamper.getOverContent(i));
			}
			// Close the stamper
			stamper.close();   
			reader.close();
        } catch (Exception e) {
        	throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
		}
	}

	public PdfPTable getHeaderTable(Map<String, String> properties, int i) {
		float[] widths3 = { RIGHT_CELL_SIZE, CENTER_CELL_SIZE, LEFT_CELL_SIZE };
		PdfPTable table = new PdfPTable(widths3);
        table.setTotalWidth(527);
        table.setLockedWidth(true);
        table.getDefaultCell().setFixedHeight(0);
        table.getDefaultCell().setBorder(0);
		setRelativePage(table,
			properties.get(OutputConstants.HEADER_RIGHT),
			Integer.parseInt(properties.get(
			OutputConstants.PART_CURRENT_PAGE_NUM))
			+ i,
			Integer.parseInt(properties.get(OutputConstants.PART_TOTAL_PAGES)));
		setCenterCell(table,
			properties.get(OutputConstants.HEADER_CENTER));
		 setAbsolutePage(table,
			 properties.get(OutputConstants.HEADER_LEFT),
			 properties.get(OutputConstants.JOB_TOTAL_PAGES),
			 properties.get(OutputConstants.JOB_CURRENT_PAGE_NUM),
			 i
			 + Integer.parseInt(properties.get(
			 OutputConstants.PART_CURRENT_PAGE_NUM)));
        return table;
    }	
	
	public PdfPTable getFooterTable(Map<String, String> properties, int i) {
		float[] widths3 = { RIGHT_CELL_SIZE, CENTER_CELL_SIZE, LEFT_CELL_SIZE };
		PdfPTable table = new PdfPTable(widths3);
        table.setTotalWidth(527);
        table.setLockedWidth(true);
        table.getDefaultCell().setFixedHeight(0);
        table.getDefaultCell().setBorder(0);
    	setRelativePage(table,
	    	properties.get(OutputConstants.FOOTER_RIGHT),
	    	Integer.parseInt(properties.get(
	    	 OutputConstants.PART_CURRENT_PAGE_NUM))
	    	 + i,
	    	 Integer.parseInt(properties.get(OutputConstants.PART_TOTAL_PAGES)));
    	 setCenterCell(table,
	    	 properties.get(OutputConstants.FOOTER_CENTER));
	    	 setAbsolutePage(table,
	    	 properties.get(OutputConstants.FOOTER_LEFT),
	    	 properties.get(OutputConstants.JOB_TOTAL_PAGES),
	    	 properties.get(OutputConstants.JOB_CURRENT_PAGE_NUM),
	    	 i
	    	 + Integer.parseInt(properties.get(
	    	 OutputConstants.PART_CURRENT_PAGE_NUM)));
	    return table;
    }
	

	// public void addHeaderFooter(Map<String, String> properties,
	// String soureFileName,
	// String ouputFileName) {
	// try {
	//
	// float pageHeight = 0;
	// float pageWidth = 0;
	// PdfPCell defaultEmptyCell;
	// defaultEmptyCell = new PdfPCell();
	// defaultEmptyCell.setBorder(0);
	// PdfReader reader = new PdfReader(soureFileName);
	//
	// //does not support documents with interactive content
	// float[] widths3 = {RIGHT_CELL_SIZE, CENTER_CELL_SIZE, LEFT_CELL_SIZE};
	// int totalPages = reader.getNumberOfPages();
	// pageHeight = reader.getPageSize(1).getHeight();
	// pageWidth = reader.getPageSize(1).getWidth();
	// Rectangle documentSize = new Rectangle(0,
	// 0,
	// pageWidth,
	// pageHeight);
	// Document document = new Document(documentSize);
	// PdfWriter writer = PdfWriter.getInstance(document, new
	// FileOutputStream(ouputFileName));
	//
	// document.setMargins(-32, -32, -32, -64);
	// document.open();
	// PdfContentByte directcontent = writer.getDirectContent();
	// PdfImportedPage page;
	// Image image;
	// for (int i = 1; i <= totalPages; i++) {
	// page = writer.getImportedPage(reader, i);
	//
	// PdfPTable header = new PdfPTable(widths3);
	// // 20: 20 pixels 10 on either side - maximum allowed for print area
	// header.setTotalWidth(page.getWidth()
	// - document.leftMargin()
	// - document.rightMargin());
	// header.setSpacingAfter(MARGIN_10);
	//
	// PdfPTable footer = new PdfPTable(widths3);
	// footer.setTotalWidth(page.getWidth()
	// - document.leftMargin()
	// - document.rightMargin());
	// footer.setSpacingBefore(MARGIN_10);
	//
	// setRelativePage(header,
	// properties.get(OutputConstants.HEADER_RIGHT),
	// Integer.parseInt(properties.get(
	// OutputConstants.PART_CURRENT_PAGE_NUM))
	// + i,
	// Integer.parseInt(properties.get(OutputConstants.PART_TOTAL_PAGES)),
	// defaultEmptyCell);
	// setCenterCell(header,
	// properties.get(OutputConstants.HEADER_CENTER),
	// defaultEmptyCell);
	// setAbsolutePage(header,
	// properties.get(OutputConstants.HEADER_LEFT),
	// properties.get(OutputConstants.JOB_TOTAL_PAGES),
	// properties.get(OutputConstants.JOB_CURRENT_PAGE_NUM),
	// i
	// + Integer.parseInt(properties.get(
	// OutputConstants.PART_CURRENT_PAGE_NUM)),
	// defaultEmptyCell);
	//
	// setRelativePage(footer,
	// properties.get(OutputConstants.FOOTER_RIGHT),
	// Integer.parseInt(properties.get(
	// OutputConstants.PART_CURRENT_PAGE_NUM))
	// + i,
	// Integer.parseInt(properties.get(OutputConstants.PART_TOTAL_PAGES)),
	// defaultEmptyCell);
	// setCenterCell(footer,
	// properties.get(OutputConstants.FOOTER_CENTER),
	// defaultEmptyCell);
	// setAbsolutePage(footer,
	// properties.get(OutputConstants.FOOTER_LEFT),
	// properties.get(OutputConstants.JOB_TOTAL_PAGES),
	// properties.get(OutputConstants.JOB_CURRENT_PAGE_NUM),
	// i
	// + Integer.parseInt(properties.get(
	// OutputConstants.PART_CURRENT_PAGE_NUM)),
	// defaultEmptyCell);
	//
	//
	//
	// if (header.getTotalHeight() > 0) {
	// header.writeSelectedRows(0,
	// -1,
	// document.leftMargin() + .1f,
	// page.getHeight()
	// - document.topMargin(),
	// directcontent);
	// }
	//
	//
	// if (footer.getTotalHeight() > 0) {
	// footer.writeSelectedRows(0,
	// -1,
	// document.leftMargin() + .1f,
	// document.bottomMargin()
	// + footer.getTotalHeight(),
	// directcontent);
	// }
	//
	//
	// image = Image.getInstance(page);
	// float height = image.getPlainHeight();
	// float width = image.getPlainWidth();
	//
	// image.scalePercent(pageWidth/width * 100, pageHeight/height * 100);
	// // - (document.topMargin() + document.bottomMargin()
	// // + footer.getTotalHeight()
	// // + header.getTotalHeight()));
	// image.setAbsolutePosition(-32, 0);
	// directcontent.addImage(image);
	// document.newPage();
	// }
	// document.close();
	// if (reader != null) {
	// reader.close();
	// }
	//
	// } catch (Exception e) {
	// throw new OutputException(OutputErrorCode.RUNTIME_ERROR, e);
	// }
	// }

	// content is the key. if this key is not present this item will
	// not appear in the header
	private void setCenterCell(PdfPTable pTable, String content) {
		PdfPCell defaultEmptyCell = new PdfPCell();
		defaultEmptyCell.setBorder(0);
		if (content == null) {
			pTable.addCell(defaultEmptyCell);

		} else {
			Phrase tmpPhrase = new Phrase(content, FONT_9);
			PdfPCell cell = new PdfPCell(tmpPhrase);
			cell.setBorder(0);
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			pTable.addCell(cell);
		}
	}

	private void setRelativePage(PdfPTable pTable, String content,
			int currentPage, int totalPages) {
		PdfPCell defaultEmptyCell = new PdfPCell();
		defaultEmptyCell.setBorder(0);
		if (content == null) {
			pTable.addCell(defaultEmptyCell);

		} else {
			Phrase tmpPhrase = new Phrase("Page " + currentPage + " of "
					+ totalPages, FONT_9);

			PdfPCell cell = new PdfPCell(tmpPhrase);
			cell.setBorder(0);
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			pTable.addCell(cell);

		}

	}

	private void setAbsolutePage(PdfPTable pTable, String content,
			String jobTotalPage, String lastPageNum, int currPage) {
		PdfPCell defaultEmptyCell = new PdfPCell();
		defaultEmptyCell.setBorder(0);
		if (content == null) {
			pTable.addCell(defaultEmptyCell);
		} else {
			int pageNum = Integer.parseInt(lastPageNum);

			Phrase tmpPhrase = new Phrase(pageNum + currPage + " of "
					+ jobTotalPage, FONT_9);

			PdfPCell cell = new PdfPCell(tmpPhrase);
			cell.setBorder(0);
			cell.setVerticalAlignment(Element.ALIGN_TOP);
			cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			pTable.addCell(cell);
		}

	}

}
