/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.model;

/**
 * @author Pranav Amarasekaran
 * @date   Jul 28, 2009
 * @since  Output 1.0; Jul 28, 2009
 *
 * This model class is used to hold the user details which the output service
 * requires. 
 */
public class OutputUser {
	
	private long _id;
	private String _userID;
	private String _fullName;
	
	public long getId() {
		return _id;
	}
	
	public void setId(long id) {
		_id = id;
	}
	
	public String getUserID() {
		return _userID;
	}

	public void setUserID(String userID) {
		_userID = userID;
	}

	public String getFullName() {
		return _fullName;
	}

	public void setFullName(String fullName) {
		_fullName = fullName;
	}
}
