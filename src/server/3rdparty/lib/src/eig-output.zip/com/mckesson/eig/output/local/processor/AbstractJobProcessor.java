/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputRequest;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.model.RequestPart;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public abstract class AbstractJobProcessor implements Runnable {
	protected final DefaultTypeHandlerFactory _factory;
	protected final EndpointDAO _dao;
	protected final OutputJobDAO _jobDao;
	protected final OutputManager _outputManger;
	protected static final int DEFAULT_JOB_SIZE = 3;
    private static final int REFRESH_QUEUE_LIST_TIME = 300 * 1000;
	private long _previousUpdateTime = 0;

    protected String _processServer;
	protected static final int DEFAULT_SLEEP_TIME = 10 * 1000;
	protected int _sleepTime = DEFAULT_SLEEP_TIME; 
	protected ThreadPoolTaskExecutor _executor = new ThreadPoolTaskExecutor();
	protected static final Log LOG = LogFactory.getLogger(AbstractJobProcessor.class);
	protected boolean _done;
	protected int _executorSize = DEFAULT_JOB_SIZE;
	protected JobProcessorHelper _helper;
	protected boolean _moreWork;
    protected static final int CHECK_PROCESSING_IDLE_TIME = 300	* 1000;
    protected long _previousCheckingIdleTime = 0;
    

	public AbstractJobProcessor(DefaultTypeHandlerFactory factory,
			OutputManager outputManger, EndpointDAO dao, OutputJobDAO jobDao, JobProcessorHelper helper) {
		_factory = factory;
		_dao = dao;
		_jobDao = jobDao;
		_outputManger = outputManger;
		_helper = helper;
	}

	/**
	 * This method is used to pre-process before the processor start processing
	 *
	 */
	public void preStartupProcess() {
		// default nothing to reset
	}
	
	private void sleep() {
		try {
			// remove lock
			Thread.sleep(getSleepTime());
		} catch (InterruptedException ie) {
			// ignored
		}
	}
	
	

	protected void initExecutors() {
		setJobSize();
		_executor.initialize();
	}
	
	protected void setJobSize() {
		_executor.setCorePoolSize(getExecutorSize());
		_executor.setMaxPoolSize(getExecutorSize());
	}
	
	protected void preStartProcessing() {
		// default nothing to reset
	}
	
	protected void preShutdownProcess() {
		// default nothing to reset
	}
	
	protected boolean isReadyToShutdown() {
		return _executor.getActiveCount() == 0;
	}
	
	/**
	 * This method is used to process before the server is shutdown
	 *
	 */
	public void shutdown() {
		setDone(true);
		preShutdownProcess();
		_executor.shutdown();
	}

	/**
	 * This method is used to process the output job
	 *
	 */
	public abstract boolean processJob();
	
	/**
	 * This method is used to refresh the queue
	 *
	 */
	public abstract void refreshQueueList();
	
	private void updateQueueList() {
		long current = System.currentTimeMillis();
		if (current - _previousUpdateTime > REFRESH_QUEUE_LIST_TIME) {
			refreshQueueList();
			_previousUpdateTime = current;
		}
	}
	
	/**
	 * This method is used to set the properties
	 *
	 */
	public void setProperties(Properties p) {
	}
	
	protected String getProcessingServer() {
		if (_processServer == null) {
			_processServer = OutputUtil.getUniqueServerName();
		}
		return _processServer;
	}
	
	public void run() {
		startProcessing();
    }

	protected boolean isExecutorAvaiable(ThreadPoolTaskExecutor executor) {
		return (executor.getActiveCount() < executor.getMaxPoolSize())
        		&& (!isDone());
	}
	
	/**
	 * This method is used to start processing the output job
	 *
	 */
	public void startProcessing() {
        setDone(false);
        preStartProcessing();
        initExecutors();
        while (!isDone()) {
        	updateQueueList();
        	boolean moreWork = processJob();
        	if(!moreWork) {
        		sleep();
        	}
        }
       	while (!isReadyToShutdown()) {
       		sleep();
        }
	}

	public boolean isDone() {
		return _done;
	}

	public void setDone(boolean done) {
		_done = done;
	}

	protected OutputJob createJob(Integer jobId) {
		OutputJob job = _jobDao.readOutputJob(jobId);
		OutputRequest req = new OutputRequest();
        req = (OutputRequest) OutputUtil.getObject(new StringReader(job.getRequestXML()));
		mapOutputRequestToOutputJob(job, req);
		job.setParts(mapOutputRequestToJobPart(job, req));
        return job;
	}

	protected void mapOutputRequestToOutputJob(OutputJob job, OutputRequest req) {
        job.setDestID(req.getDestID());
        job.setDestName(req.getDestName());
        job.setDestType(req.getDestType());
        job.setJobName(req.getRequestId());
        job.setRequestId(req.getRequestId());
        job.setProperties(req.getProperties());
        job.setSubmitInfo(req.getSubmitInfo());
        job.setLabelData(req.getLabelData());
	}

	protected List<JobPart> mapOutputRequestToJobPart(OutputJob job,
			OutputRequest req) {

        List<OutputTransform> transforms = req.getTransforms();
        job.setTransforms(transforms);

		List<RequestPart> requestParts = req.getParts();
		if ((requestParts == null) || (requestParts.size() == 0)) {
			throw new InvalidDefinitionException(
					"requestParts: " + requestParts,
					OutputErrorCode.MISSING_DATA);
		}

		List<JobPart> jobParts = new ArrayList<JobPart>();
		for (RequestPart part : requestParts) {

            JobPart jobPart = new JobPart();
            jobPart.setOutputJob(job);
            jobPart.setContentID(part.getContentID());
            jobPart.getStatusInfo().setStatusCode(job.getStatusInfo().getStatusCode());

            String contentSourceName = part.getContentSourceName();
            String contentSourceType = part.getContentSourceType();

            jobPart.setContentSourceName(contentSourceName);
            jobPart.setContentSourceType(contentSourceType);
            jobPart.setProperties(part.getProperties());
            jobPart.setPages(0);

            transforms = part.getTransforms();
            jobPart.setTransforms(part.getTransforms());
            jobParts.add(jobPart);
        }

        job.setParts(jobParts);
        job.setRequestXML(req.getXML());

        return jobParts;
	}

	/**
	 * This method is used get the sleep time.
	 */
	public int getSleepTime() {
		return _sleepTime;
	}

	/**
	 * This method is used to set the sleep time.
	 *
	 */
	public void setSleepTime(int sleepTime) {
		_sleepTime = sleepTime;
	}

	/**
	 * This method is used to get the executor size.
	 */
	public int getExecutorSize() {
		return _executorSize;
	}

	/**
	 * This method is used to set the executor size.
	 */
	public void setExecutorSize(int executorSize) {
		_executorSize = executorSize;
	}
	
	protected OutputManager getOutputManager() {
		return _outputManger;
	}
	
	protected Integer getNextAvailableJobForOnePerQueue(List<Integer> queues, RequestStatus checkStatus, RequestStatus processStatus) {
		return getJobProcessorHelper().getNextAvailableJobForOnePerQueue(queues, checkStatus, processStatus);
	}

	protected boolean processIdleJobByChangeStatus(List<Integer> queues, RequestStatus checkStatus, RequestStatus resetStatus, int idleInMin, String errorMsg) {
		return getJobProcessorHelper().processIdleJobByChangeStatus(queues, checkStatus, resetStatus, idleInMin, errorMsg);
	}
	
	protected boolean processIdleJobByRemoveServerName(List<Integer> queues, RequestStatus checkStatus, int idleInMin, String errorMsg) {
		return getJobProcessorHelper().processIdleJobByRemoveServerName(queues, checkStatus, idleInMin, errorMsg);
	}

	protected Integer getNextAvailableJob(List<Integer> queues, RequestStatus checkStatus, RequestStatus setStatus) {
		return getJobProcessorHelper().getNextAvailableJob(queues, checkStatus, setStatus);
	}

	protected Integer getCurrentProcessingJob(List<Integer> queues, RequestStatus checkStatus, boolean hostNameOnly) {
		return getJobProcessorHelper().getCurrentProcessingJob(queues, checkStatus, hostNameOnly);
	}

	/**
	 * This method is used to set JobProcessorHelper for AOP.
	 */
	public JobProcessorHelper getJobProcessorHelper() {
		return _helper;
	}

	/**
	 * This method is used to set JobProcessorHelper for AOP.
	 */
	public void setJobProcessorHelper(JobProcessorHelper helper) {
		_helper = helper;
	}

}
