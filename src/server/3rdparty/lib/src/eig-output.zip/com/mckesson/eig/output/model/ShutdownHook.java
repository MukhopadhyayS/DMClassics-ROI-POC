package com.mckesson.eig.output.model;

public interface ShutdownHook {
	void shutdown();
}
