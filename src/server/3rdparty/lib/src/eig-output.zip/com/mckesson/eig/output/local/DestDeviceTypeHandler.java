/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.local.dao.XMLEndpointDAO;
import com.mckesson.eig.output.local.device.disc.DiscLabelStrategy;
import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.DeviceType;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


/**
 * @author Latonia Howard
 * @date   Sept 4, 2013
 * @since  
 * 
 * Note:  devices are different than typical output service endpoints, however
 *        because the structure of typical output service endpoints are very generic
 *        we have decided to NOT introduce another layer of complexity in the output 
 *        service model and simply reuse the existing patterns to represent devices.
 *        The existing "destination" patterns will be used to create/update/delete devices
 *        from the Output_ListOfValue table
 *        
 *        The main difference between DEVICES and DESTINATION is the introduction of a second
 *        parent hierarchy: VENDOR.  Vendors will be identified simply as a property value
 *        but will be used the handler to retrieve the correct device definition.
 */
public class DestDeviceTypeHandler extends BaseComponent implements EndpointTypeHandler, DiscLabelStrategy {
	//Device Type Handler contains mappings for each of its vendors

	private HashMap<String, EndpointTypeHandler> _vendorMap;
	private XMLEndpointDAO endpointDao;	
	private static final Log LOG = LogFactory.getLogger(DestDeviceTypeHandler.class);
	private Object _semaphore;

	public DestDeviceTypeHandler(Map<String, EndpointTypeHandler> vendorMap) {
		_semaphore = new Object();
		_vendorMap = new  HashMap<String, EndpointTypeHandler>();
		setVendorMappings(vendorMap);
		setVendorNames();
	}

	public DestDeviceTypeHandler(String enabled,
			Map<String, EndpointTypeHandler> vendorMap) {

		this(vendorMap);
		setEnabled(enabled);
	}
	
	/**
	 * Returns the set of vendor mappings for this device type
	 * 
	 * @return not <code>null</code>
	 */
	@SuppressWarnings("unchecked")
    public Map<String, EndpointTypeHandler> getVendorMappings() {
	    return (Map<String, EndpointTypeHandler>) _vendorMap.clone();
	}

    /**
     * Sets the set of vendor mappings for this device type
     *
     * @param vendorMappings may be <code>null</code>
     */
    public void setVendorMappings(
            Map<String, EndpointTypeHandler> vendorMappings) {

    	synchronized(_semaphore) {
	        _vendorMap.clear();
	
	        if (vendorMappings != null) {
	            _vendorMap.putAll(vendorMappings);
	        }
    	}
    }	

    //Can only handle types of DeviceInfo
    //throws error for all other types of endpointDefs
	@Override
	public OutputEndpoint createEndpoint(EndpointDef endpointDef) {
		
		DeviceInfo deviceInfo = getDeviceInfo(endpointDef);
		return _vendorMap.get(deviceInfo.getVendor()).createEndpoint(deviceInfo);
	}

	@Override
	public void destroyEndpoint(OutputEndpoint endpoint) {
		//do nothing.  these endpoints will not be destroyed because they are not kept in memory.
		LOG.debug(endpoint.getProperties().toString());
	}

	@Override
	public void cleanUp() {
		//do nothing.  
		LOG.debug("Cleanup requested");
		
	}

	@Override
	public String[] getEndpointContentTypes() {
		return OutputConstants.ANY_CONTENT_TYPE;
	}

	@Override
	public EndpointCategory getEndpointCategory() {
		return EndpointCategory.DESTINATION_DEVICE;
	}

	@Override
	/*
	 * NOTE:  usually the getPropertyDefs() method returns the
	 * 		  properties that define a type.  However, for this case
	 * 		  the DestDeviceTypeHandler is a container for all "types" meanining
	 * 		  vendors for a device type.  Thus, the property for the container is
	 *        a list of the vendors
	 */
    public PropertyDef[] getPropertyDefs() {

		List<PropertyDef> propertyDefs = new ArrayList<PropertyDef>();
		synchronized (_semaphore) {
			String[] vendorNameStrings = new String[_vendorMap.size()];
		
			
			PropertyDef vendorProperty = new PropertyDef();
			vendorProperty.setLabel("Vendor Name");
			vendorProperty.setPossibleValues(_vendorMap.keySet().toArray(vendorNameStrings));
			vendorProperty.setDescription("Vendors");
		
			propertyDefs.add(vendorProperty);
		}
		
		PropertyDef[] defsArray = new PropertyDef[propertyDefs.size()];
		return propertyDefs.toArray(defsArray);
	}

	private void setVendorNames() {
		String vendorNames = "";
		for (String vendorName : _vendorMap.keySet()) {
			vendorNames += vendorName + "|";
		}
		
		vendorNames = StringUtils.removeEnd(vendorNames, "|");
		this.setProperty(OutputConstants.DEVICE_VENDOR, vendorNames);

	}

	@Override
	public Map<String, EndpointTypeHandler> getSubHandlers() {
		return _vendorMap;
	}
	
	public XMLEndpointDAO getEndpointDao() {
		return endpointDao;
	}

	public void setEndpointDao(XMLEndpointDAO endpointDao) {
		this.endpointDao = endpointDao;
	}		
	
	private DeviceInfo getDeviceInfo(EndpointDef endpointDef) {
		if (! (endpointDef instanceof DeviceInfo)) {
			throw new InvalidDefinitionException(
					"Cannot create device" ,
					OutputErrorCode.RUNTIME_ERROR);			
		}
		
		return (DeviceInfo) endpointDef;		
	}

	/*
	 * Method returns the deviceProperty Defs
	 */
	public PropertyDef[] getDevicePropertyDefs(String deviceID) {
		EndpointDef device = this.endpointDao.getEndpointDef(deviceID, DeviceType.DISC_DEVICE.name());
		
		synchronized (_semaphore) {
			if (device != null){
				if (device instanceof DeviceInfo) {
					DeviceInfo deviceInfo = (DeviceInfo) device;
					EndpointTypeHandler deviceHandler = _vendorMap.get(deviceInfo.getVendor());
					return deviceHandler.getPropertyDefs();
				}
			}
		}

		return this.getPropertyDefs();
	}

	/*
	 * (non-Javadoc)
	 * @see com.mckesson.eig.output.local.device.disc.DiscLabelStrategy#getLabelTemplates(com.mckesson.eig.output.model.DeviceInfo)
	 * returns the label templates for the device
	 */
	@Override
	public List<String> getLabelTemplates(DeviceInfo info) {
		if (info != null){
			if (_vendorMap.get(info.getVendor()) instanceof DiscLabelStrategy) {
				DiscLabelStrategy labelStrategy = (DiscLabelStrategy) _vendorMap.get(info.getVendor());
				return labelStrategy.getLabelTemplates(info);
			}
		}
		return null;
	}
	
	/*
	 * returns the DeviceInfo object for the input parameter deviceId
	 */
	public DeviceInfo getDeviceInfo(int deviceId) {
		EndpointDef deviceInfo =this.endpointDao.getEndpointDef(deviceId);	
		if (deviceInfo != null) {		
			//Set properties from property list
			deviceInfo.getProperties();
			if (deviceInfo instanceof DeviceInfo) {
				return (DeviceInfo) deviceInfo;
			}
		}
		return null;	
	}

	/*
	 * (non-Javadoc)
	 * @see com.mckesson.eig.output.local.EndpointTypeHandler#updateEndpoints(java.util.List)
	 * Updates all the active destdevicetype endpoints
	 */
	@Override
	public void updateEndpoints(List<ActiveEndpoint> endpointArr) {
		//do nothing; not required because DESTDEVICETYPES are not active endpoints
		LOG.debug("Update endpoints");
	}
}
