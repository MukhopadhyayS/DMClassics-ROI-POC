/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!

* Author: Latonia Howard
*/


/*
 * Server and System Listener for Rimage Devices
 * Handles callbacks from the Rimage system  :  alert boxes, dialog boxes, systems status(ie. shutting down, resuming, pausing,etc.)
 * Implements the Rimage Server/System Listener interface : please refer to Rimage documentation for interface details
 */

package com.mckesson.eig.output.device.disc.rimage;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.mckesson.eig.output.local.device.disc.DiscDeviceStatusListener;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.rimage.client.api.MultiConnectionServerEventListener;
import com.rimage.client.api.MultiConnectionSystemListener;
import com.rimage.client.api.exception.SystemException;
/**
 * @author Shahm Nattarshah
 * @author Latonia Howard 
 * @date  Sep 2013
 * @since  MPF 16.1
 *
 * This class is used as a Listener for getting the System and Server status for RIMAGE 
 * device. Used in RImageConnection class.
 * Device is offline, Online, Any Dialog Acknowledged.
 *
 */
public class ServerAndSystemListener implements MultiConnectionSystemListener,
MultiConnectionServerEventListener {

	private RimageConnection _rimageConnection;
	private DiscDeviceStatusListener _ddsListener;
	
	protected static final Log LOG = LogFactory.getLogger(ServerAndSystemListener.class);

	/*
	 * Constructor
	 * DiscDeviceStatusListener : hold discDeviceStatusListner object - updates the deviceInfo status data in the database
	 * RimageConnection: hold RimageConnection object
	 */
	public ServerAndSystemListener(DiscDeviceStatusListener discDeviceStatusListener, RimageConnection rimageConnection) {
		try {
			if (discDeviceStatusListener == null) {
				LOG.error("Status Listener is undefined.  Unable to update System and Server status for RIMAGE system - Hostname/IpAddress: " + 
						rimageConnection.getIpAddress()
						+ " Port: " + rimageConnection.getPort());			
			}
	 		this._ddsListener = discDeviceStatusListener;
			this._rimageConnection = rimageConnection;
		}catch (Exception e) {
			LOG.error("Unable to update System and Server status for RIMAGE system - Hostname/IpAddress: " + rimageConnection.getIpAddress()
					+ " Port: " + rimageConnection.getPort() + " ErrorMsg:" + e.getMessage());			
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionServerEventListener#onServerAlert(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 * Rimage Server callback to handle alert and error dialog messages
	 */
	@Override
	public void onServerAlert(String connectionId, String serverId, java.lang.String alertId, java.lang.String xmlAlert) {
		Document document = parseXML(xmlAlert);
		String alertMessage = "";
		
		LOG.debug("Server alert.  Connection: " + connectionId
				+ " serverId:" + serverId + " alertId:" + alertId + " xmlAlert:" + xmlAlert);	
		
		
		if (xmlAlert.contains("<AlertDialog")) {
			alertMessage = getElementAt(document, "AlertDialog", "Message");
		}
		if (xmlAlert.contains("<ErrorDialog")) {
			alertMessage = getElementAt(document, "ErrorDialog", "Message");
		}		
		
		if (_ddsListener != null) {
			_ddsListener.deviceStatusPropertyChanged(_rimageConnection.getDeviceIds(), alertId, alertMessage);	
		} 
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionServerEventListener#onServerAlertAcknowledged(java.lang.String, java.lang.String, java.lang.String)
	 * Rimage callback used to receive notification when a user has intervened and performed action on an alert or error dialog box
	 */
	@Override
	public void onServerAlertAcknowledged(String connectionId, String serverId, java.lang.String alertId) {
		LOG.debug("User acknowledged alert or error dialog.  Connection: " + connectionId
				+ " serverId:" + serverId + " alertId:" + alertId);	
		
		if (_ddsListener != null) {
			_ddsListener.deviceStatusPropertyChanged(_rimageConnection.getDeviceIds(), alertId, null);	
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionServerEventListener#onServerConfig(java.lang.String, java.lang.String, java.lang.String)
	 * Rimage callback used to notify when server configuration changes are made
	 */
	@Override
	public void onServerConfig(String connectionId, String serverId, String xmlServerInfo) {
		LOG.warn("RimageSystem: serverConfig Notification: " + "connectionId: " + connectionId
					+ " serverId: " + serverId + "    xmlServerInfo: " + xmlServerInfo);
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionServerEventListener#onServerPause(java.lang.String, java.lang.String)
	 * Rimage call used to notify when server is pausing
	 */
	@Override
	public void onServerPause(String connectionId, String serverId) {
		
		if (_ddsListener != null) {
		    StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.PAUSED, OutputConstants.DEVICE_PAUSING);	
			_ddsListener.deviceStatusChanged( _rimageConnection.getDeviceIds(), statusInfo);	
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionServerEventListener#onServerPausePending(java.lang.String, java.lang.String)
	 * Rimage callback used to notify when server pause is pending
	 */
	@Override
	public void onServerPausePending(String connectionId, String serverId) {
		if (_ddsListener != null) {
		    StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.PAUSED, OutputConstants.DEVICE_PAUSING);	
			_ddsListener.deviceStatusChanged( _rimageConnection.getDeviceIds(), statusInfo);	
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionServerEventListener#onServerResume(java.lang.String, java.lang.String)
	 * Rimage callback used to notify when server is resuming
	 */
	@Override
	public void onServerResume(String connectionId, String serverId) {
		if (_ddsListener != null) {
		    StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.OK, OutputConstants.DEVICE_ONLINE);	
			_ddsListener.deviceStatusChanged( _rimageConnection.getDeviceIds(), statusInfo);	
		}	
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionServerEventListener#onServerShutdown(java.lang.String, java.lang.String)
	 * Rimage callback used to notify when server is shutting down
	 */
	@Override
	public void onServerShutdown(String connectionId, String serverId) {
		if (_ddsListener != null) {
		    StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.STOPPED, OutputConstants.DEVICE_SHUTTING_DOWN);	
			_ddsListener.deviceStatusChanged( _rimageConnection.getDeviceIds(), statusInfo);	
		}	
	
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionServerEventListener#onServerShutdownPending(java.lang.String, java.lang.String)
	 * Rimage callback used to notify when server is shutdown is pending
	 */
	@Override
	public void onServerShutdownPending(String connectionId, String serverId) {
		if (_ddsListener != null) {
		    StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.STOPPED, OutputConstants.DEVICE_SHUTTING_DOWN);	
			_ddsListener.deviceStatusChanged( _rimageConnection.getDeviceIds(), statusInfo);	
		}		}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionServerEventListener#onServerStartPending(java.lang.String, java.lang.String)
	 * Rimage callback used to notify when server start is pending
	 */
	@Override
	public void onServerStartPending(String connectionId, String serverId) {
		if (_ddsListener != null) {
		    StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.OK, OutputConstants.DEVICE_RESUMING);	
			_ddsListener.deviceStatusChanged( _rimageConnection.getDeviceIds(), statusInfo);	
		}		}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionServerEventListener#onServerStartupMessage(java.lang.String, java.lang.String, java.lang.String)
	 * Rimage callback used to notify server connection initial message
	 */
	@Override
	public void onServerStartupMessage(String connectionId, String serverId, String message) {
		//Server is started
		if (_ddsListener != null) {
		    StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.OK, OutputConstants.DEVICE_ONLINE);	
			_ddsListener.deviceStatusChanged( _rimageConnection.getDeviceIds(), statusInfo);	
		}			
		
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionSystemListener#onClusterCreated(java.lang.String, java.lang.String, int)
	 * Rimage callback used to notify when cluster is created
	 */
	@Override
	public void onClusterCreated(String arg0, String arg1, int arg2) {
		LOG.warn("RimageSystem: clusterCreated Notification: " + "arg0: " + arg0
				+ " arg1: " + arg1 + "    arg2: " + arg2);
		
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionSystemListener#onClusterDeleted(java.lang.String, java.lang.String, int)
	 * Rimage callback used to notify when cluster is deleted
	 */
	@Override
	public void onClusterDeleted(String arg0, String arg1, int arg2) {
		LOG.warn("RimageSystem: clusterDeleted Notification: " + "arg0: " + arg0
				+ " arg1: " + arg1 + "    arg2: " + arg2);
		
	}

	/*
	 * (non-Javadoc)
	 * @see com.rimage.client.api.MultiConnectionSystemListener#onSystemException(java.lang.String, com.rimage.client.api.exception.SystemException)
	 * Rimage callback used to notify when there is a Rimage server system exception
	 * Refer to Rimage manual for additional information
	 */
	@Override
	public void onSystemException(String connectionId, SystemException e) {
		if (_ddsListener != null) {
		    StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.ERR_HELP, "Device system error: " + e.getMessage() + 
		    											" Contact your system administrator.");	
			_ddsListener.deviceStatusChanged( _rimageConnection.getDeviceIds(), statusInfo);	
		}			
	}

	/*
	 * Method used to update the device status if OutputService fails to connect to Rimage server
	 */
	public void onServerConnectionFailed(String statusDetails) {
		if (_ddsListener != null) {
			String detailMsg = OutputConstants.DEVICE_OFFLINE;
			if (StringUtils.isNotBlank(statusDetails)) {
				detailMsg = statusDetails;
			}
			
		    StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.STOPPED, detailMsg);	
			_ddsListener.deviceStatusChanged( _rimageConnection.getDeviceIds(), statusInfo);		
		}
		
	}

	/*
	 * Method used to update the device status if OutputService successfully connects to Rimage server
	 */	
	public void onServerConnectionSuccess() {
		if (_ddsListener != null) {
			String detailMsg = OutputConstants.DEVICE_ONLINE;
			
		    StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.OK, detailMsg);	
			_ddsListener.deviceStatusChanged( _rimageConnection.getDeviceIds(), statusInfo);	
		}
		
	}	
	
	
	/*-----------------------------------------------------------------------------
	Function: parseXML(): Constructs an XML document(tree structure) in memory.
	Input: XML string conforming to either ProductionOrder.DTD or ImageOrder.DTD.
	Output: Returns Parsed Document.
	------------------------------------------------------------------------------*/
	protected Document parseXML(String xmlOrderStatus) {
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    Document document = null;
	
	    // Specifies that the parser produced by this code will validate
	    factory.setValidating(true);
	
	    try {
	      DocumentBuilder builder = factory.newDocumentBuilder();
	      builder.setEntityResolver(new EntityResolver()  {
	            public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
	                if (systemId.contains(".dtd")) {
	                	String id = systemId;
	                	if (id.startsWith("file://")) {
	                		id = id.substring(5);
	                		id = id.replace("/", "\\");
	                	}
	                    InputStream dtdStream = new FileInputStream(id);
	                    return new InputSource(dtdStream);
	                } else {
	                    return null;
	                }
	            }
	      });	      
	      document = builder.parse(new InputSource((Reader)new StringReader(xmlOrderStatus)));
	    } catch (Exception spe) {
	    	LOG.error("Failed to parseXML:" + spe.getMessage());
	    	return null;
	    }
	    return document;
	}
	
  /*-----------------------------------------------------------------------------
  Function: getElementAt(): Searches the DOM tree to find a text value of a
            specific attribute within a specific element.
  Input: Parsed XML Document, Element name, Attribute name.
  Output: Returns the text value (if one was found) of that attribute.
	-------------------------------------------------------------------------------*/
	protected String getElementAt(Document document, String tagName, String attribute)	{
	  NodeList list = document.getElementsByTagName(tagName);
	  Node thisStatusNode;
	  NamedNodeMap thisNamedNodeMap;
	  // Loop through the list
	  for (int i=0; i<list.getLength(); i++) {
	      thisStatusNode = list.item(i);
	      thisNamedNodeMap = thisStatusNode.getAttributes();
	      if (thisNamedNodeMap == null) continue;
	      if (thisNamedNodeMap.getNamedItem(attribute) == null) continue;
	      if (thisNamedNodeMap.getNamedItem(attribute) instanceof org.w3c.dom.Node) {
	         return thisNamedNodeMap.getNamedItem(attribute).getNodeValue();
	      }
	  }
	  return "";
	}
	
	
}
