/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.MDC;

import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.DestDeviceTypeHandler;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.device.disc.DiscDevice;
import com.mckesson.eig.output.local.disc.DiscDestination;
import com.mckesson.eig.output.local.disc.DiscTypeHandler;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;

public class DiscCleanupJobProcessRunnable extends JobProcessRunnable {

	public DiscCleanupJobProcessRunnable(DefaultTypeHandlerFactory factory, EndpointDAO dao,
			OutputManager outputManager, OutputJob job) {
		super(factory, dao, outputManager, job);
	}
	
	/**
	 * This method is used to start run the clean up job
	 *
	 */
	public void run() {
		try {
			long startTime = System.currentTimeMillis();
			LOG.debug("Start clean up for Job:" + _job.getJobSeq());
			process();
			long finishTime = System.currentTimeMillis();
			LOG.debug("Finished clean up :" + _job.getJobSeq()
					+ " in: " + (finishTime - startTime) + " milliseconds");
		} catch (Exception e) {
			error(_job, e.getMessage());
		} finally {
			MDC.remove(JOB_ID);
		}
	}
	
	private void process() {
    	DiscDestination d = setDestination(_job);
		File dir = getDiscJobDirectory(d);
		FileUtils.deleteQuietly(dir);
	}
	
    private File getDiscJobDirectory(DiscDestination d) {
		File jobDirectory = new File(d.getDiscdevice().getTemporaryLocation() + File.separator + OutputConstants.DISC_PDF_TEMP, String.valueOf(_job.getJobSeq()));
		return jobDirectory;
	}

    private DiscDestination setDestination(OutputJob job) {
		int destId = job.getDestID();
		DiscDestination d = getDiscDestination(destId);
		DiscDevice device = getDiscDevice(d.getDevice());
		d.setDiscdevice(device);
        job.setDestination(d);
        return d;
    }
	
    private DiscDestination getDiscDestination(int id) {
        EndpointDef def = _dao.getEndpointDef(id);
        return (DiscDestination) _handler.createEndpoint(def);
    }

    private DiscDevice getDiscDevice(String deviceId) {
        EndpointDef def = _dao.getEndpointDef(Integer.valueOf(deviceId));
        DestDeviceTypeHandler handler = ((DiscTypeHandler) _handler).getDestDeviceHandler();
        return (DiscDevice) handler.createEndpoint(def);
    }


}
