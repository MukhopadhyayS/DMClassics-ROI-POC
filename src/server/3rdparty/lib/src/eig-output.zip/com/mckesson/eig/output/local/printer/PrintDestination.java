/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
 * Use of this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * author: Latonia
 */

/*
 * TO DO: Dynamically build properties
 */

package com.mckesson.eig.output.local.printer;

import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.print.DocFlavor;
import javax.print.MultiDocPrintService;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.attribute.Attribute;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.PrintServiceAttribute;
import javax.print.attribute.standard.Chromaticity;
import javax.print.attribute.standard.ColorSupported;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.MediaSizeName;
import javax.print.attribute.standard.MediaTray;
import javax.print.attribute.standard.NumberUp;
import javax.print.attribute.standard.OrientationRequested;
import javax.print.attribute.standard.PageRanges;
import javax.print.attribute.standard.PrinterIsAcceptingJobs;
import javax.print.attribute.standard.PrinterLocation;
import javax.print.attribute.standard.PrinterStateReasons;
import javax.print.attribute.standard.QueuedJobCount;
import javax.print.attribute.standard.SheetCollate;
import javax.print.attribute.standard.Sides;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputConstants.MediaSizeConstants;
import com.mckesson.eig.output.util.OutputConstants.MediaTrayConstants;
import com.mckesson.eig.output.util.OutputConstants.PageOrientationConstants;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.OutputProperty.PropertyFlag;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * This class provides the business methods implementations for printer
 * destinations
 *
 * @author OFS
 * @author Latonia Howard
 */
public class PrintDestination extends Destination {

	private static final String PDF_EXT = "pdf";
	public static final String POSTSCRIPT = "ps";
	public static final String PCL = "pcl";

	private static final Log LOG = LogFactory.getLogger(PrintDestination.class);
	private static final String ALL = "All";
	private final PrintTypeHandler _typeHandler;
	private String _printerName;
	private final PrintService _printService;
	private PrintListener _printListener;

	private boolean _color;
	private boolean _collate;
	private boolean _duplex;
	private boolean _pageSeparator;
	private int _scaling;
	private String _pageOrientation;
	private int _copies;
	private int _pagePerSheet;
	private int _pageRange;
	private Collection<String> _availablePrinters;
    private String _location;	

	private static Map<String, MediaSizeName> _mediaSizeNames =
		new HashMap<String, MediaSizeName>();
	private static Map<String, MediaTray> _mediaTray =
		new HashMap<String, MediaTray>();
	private static Map<String, OrientationRequested> _pageOrientations =
		new HashMap<String, OrientationRequested>();
	private static Map<String, Integer> _pageFormat = new HashMap<String, Integer>();

	static {

		Map<String, MediaSizeName> mediaSizeConstants =
			new HashMap<String, MediaSizeName>();
		mediaSizeConstants.put(MediaSizeConstants.NA_10X13_ENVELOPE.toString(),
				MediaSizeName.NA_10X13_ENVELOPE);
		mediaSizeConstants.put(MediaSizeConstants.NA_10X14_ENVELOPE.toString(),
				MediaSizeName.NA_10X14_ENVELOPE);

		mediaSizeConstants.put(MediaSizeConstants.NA_10X15_ENVELOPE.toString(),
				MediaSizeName.NA_10X15_ENVELOPE);
		mediaSizeConstants.put(MediaSizeConstants.NA_5X7.toString(),
				MediaSizeName.NA_5X7);
		mediaSizeConstants.put(MediaSizeConstants.NA_6X9_ENVELOPE.toString(),
				MediaSizeName.NA_6X9_ENVELOPE);

		mediaSizeConstants.put(MediaSizeConstants.NA_7X9_ENVELOPE.toString(),
				MediaSizeName.NA_7X9_ENVELOPE);
		mediaSizeConstants.put(MediaSizeConstants.NA_8X10.toString(),
				MediaSizeName.NA_8X10);
		mediaSizeConstants.put(MediaSizeConstants.NA_9X11_ENVELOPE.toString(),
				MediaSizeName.NA_9X11_ENVELOPE);

		mediaSizeConstants.put(MediaSizeConstants.NA_9X12_ENVELOPE.toString(),
				MediaSizeName.NA_9X12_ENVELOPE);
		mediaSizeConstants.put(MediaSizeConstants.NA_LEGAL.toString(),
				MediaSizeName.NA_LEGAL);
		mediaSizeConstants.put(MediaSizeConstants.NA_LETTER.toString(),
				MediaSizeName.NA_LETTER);

		mediaSizeConstants.put(MediaSizeConstants.NA_NUMBER_10_ENVELOPE
				.toString(), MediaSizeName.NA_NUMBER_10_ENVELOPE);
		mediaSizeConstants.put(MediaSizeConstants.NA_NUMBER_11_ENVELOPE
				.toString(), MediaSizeName.NA_NUMBER_11_ENVELOPE);
		mediaSizeConstants.put(MediaSizeConstants.NA_NUMBER_12_ENVELOPE
				.toString(), MediaSizeName.NA_NUMBER_12_ENVELOPE);

		mediaSizeConstants.put(MediaSizeConstants.NA_NUMBER_14_ENVELOPE
				.toString(), MediaSizeName.NA_NUMBER_14_ENVELOPE);
		mediaSizeConstants.put(MediaSizeConstants.NA_NUMBER_9_ENVELOPE
				.toString(), MediaSizeName.NA_NUMBER_9_ENVELOPE);
		_mediaSizeNames = Collections.unmodifiableMap(mediaSizeConstants);

		Map<String, MediaTray> mediaTrayConstants = new HashMap<String, MediaTray>();
		mediaTrayConstants.put(MediaTrayConstants.BOTTOM.toString(),
				MediaTray.BOTTOM);
		mediaTrayConstants.put(MediaTrayConstants.ENVELOPE.toString(),
				MediaTray.ENVELOPE);

		mediaTrayConstants.put(MediaTrayConstants.LARGE_CAPACITY.toString(),
				MediaTray.LARGE_CAPACITY);
		mediaTrayConstants.put(MediaTrayConstants.MAIN.toString(),
				MediaTray.MAIN);
		mediaTrayConstants.put(MediaTrayConstants.MANUAL.toString(),
				MediaTray.MANUAL);

		mediaTrayConstants.put(MediaTrayConstants.MIDDLE.toString(),
				MediaTray.MIDDLE);
		mediaTrayConstants.put(MediaTrayConstants.SIDE.toString(),
				MediaTray.SIDE);
		mediaTrayConstants
				.put(MediaTrayConstants.TOP.toString(), MediaTray.TOP);

		_mediaTray = Collections.unmodifiableMap(mediaTrayConstants);

        Map<String, OrientationRequested> pageOrientationConstants =
                new HashMap<String, OrientationRequested>();
		pageOrientationConstants.put(PageOrientationConstants.LANDSCAPE
				.toString(), OrientationRequested.LANDSCAPE);
		pageOrientationConstants.put(PageOrientationConstants.PORTRAIT
				.toString(), OrientationRequested.PORTRAIT);

		pageOrientationConstants.put(PageOrientationConstants.REVERSE_LANDSCAPE
				.toString(), OrientationRequested.REVERSE_LANDSCAPE);
		_pageOrientations = Collections
				.unmodifiableMap(pageOrientationConstants);

		Map<String, Integer> pageFormats = new HashMap<String, Integer>();
		pageFormats.put(PageOrientationConstants.LANDSCAPE.toString(),
				PageFormat.LANDSCAPE);
		pageFormats.put(PageOrientationConstants.PORTRAIT.toString(),
				PageFormat.PORTRAIT);
		pageFormats.put(PageOrientationConstants.REVERSE_LANDSCAPE.toString(),
				PageFormat.REVERSE_LANDSCAPE);

		_pageFormat = Collections.unmodifiableMap(pageFormats);

	}

	/**
     * Constructor
     *
     * @param handler
     * @param printerName
     * @param convertQueue
     * @param imagesPerWorker
	 */
	public PrintDestination(PrintTypeHandler handler, String printerName) {

		super();
		if (handler == null) {
			throw new IllegalArgumentException("handler argument is null");
		}
		if (printerName == null) {
			throw new IllegalArgumentException("printerName argument is null");
		}
		_typeHandler = handler;
		_printerName = printerName;

		_printService = getNamedPrintService(_printerName);
		setSupportedAttributes();
		loadAvailablePrinters();
	}

	public void setPrinterName(String printerName) {

		_printerName = printerName;
	}

	@OutputProperty(defaultValue = "",
		description = "Name of the Printer",
		label = "Printer Name")
	public String getPrinterName() {

		return _printerName;
	}

	@OutputProperty(defaultValue = "Grayscale",
		description = "Color",
		label = "Color",
		possibleValues = {"Color", "Grayscale" },
		flags = PropertyFlag.JOB_DEFAULT, index = "6")
	public void setColor(boolean color) {
		_color = color;

	}

	public boolean getColor() {
		return _color;
	}

	public void loadAvailablePrinters() {

		_availablePrinters = new ArrayList<String>();

		PrintService[] prnSvcs;
		prnSvcs = PrintServiceLookup.lookupPrintServices(null, null);
		if (prnSvcs.length > 0) {
			int ii = 0;
			while (ii < prnSvcs.length) {
				_availablePrinters.add(prnSvcs[ii].getName());
				ii++;
			}
		}
	}

	@OutputProperty(defaultValue = "",
		description = "Available Printers",
		label = "Printers",
		required = "true",
		index = "1")
	public Collection<String> getAvailablePrinters() {

		loadAvailablePrinters();
		return _availablePrinters;
	}

	@OutputProperty(defaultValue = "No",
		description = "Page Separator",
		label = "Page Separator",
		possibleValues = {
			"Yes", "No" },
			flags = PropertyFlag.JOB_DEFAULT,
			index = "2")
	public void setPageSeparator(boolean pageSeparator) {

		_pageSeparator = pageSeparator;
	}

	public boolean getPageSeparator() {

		return _pageSeparator;
	}

	@OutputProperty(defaultValue = "No",
		description = "Collate",
		label = "Collate",
		possibleValues = {"Yes", "No" },
		flags = PropertyFlag.JOB_DEFAULT,
		index = "4")
	public void setCollate(boolean collate) {

		_collate = collate;
	}

	public boolean getCollate() {

		return _collate;
	}

	@OutputProperty(defaultValue = "Off",
		description = "Duplex",
		label = "Duplex",
		possibleValues = {"On", "Off" },
		flags = PropertyFlag.JOB_DEFAULT,
		index = "7")
	public void setDuplex(boolean duplex) {

		_duplex = duplex;
	}

	public boolean getDuplex() {

		return _duplex;
	}

	@OutputProperty(defaultValue = "100",
		description = "Manual Scaling",
		label = "Scaling",
		possibleValues = { "\\d+" },
		flags = PropertyFlag.JOB_DEFAULT,
		index = "8")
	public void setScaling(int scaling) {

		_scaling = scaling;
	}

	public int getScaling() {
		return _scaling;
	}

	@OutputProperty(defaultValue = "Landscape",
		description = "Page Orientation",
		label = "Page Orientation",
		possibleValues = {"Landscape", "Portrait" },
		flags = PropertyFlag.JOB_DEFAULT,
		index = "3")
	public void setPageOrientation(String pageOrientation) {

		_pageOrientation = pageOrientation;
	}

	public String getJobPageOrientation(String pageOrientation) {
		String tmpPageOrientation = _pageOrientation; // default page setting
		if (StringUtils.isNotEmpty(pageOrientation)) {
			tmpPageOrientation = pageOrientation;
		}

		return tmpPageOrientation;
	}

	public String getPageOrientation() {

		return _pageOrientation;
	}

	@OutputProperty(defaultValue = "1",
		description = "Enter a number to be used as a default for "
			+ "the number of copies whenever any user prints a job.",
		label = "Number of Copies",
		possibleValues = { "\\d+" },
		flags = PropertyFlag.JOB_DEFAULT,
		index = "5")
	public void setCopies(int copies) {

		_copies = copies;
	}

	public int getCopies() {

		return _copies;
	}

	@OutputProperty(defaultValue = "1",
			description = "Enter the number of pages to be imposed "
				+ "in a single sheet.",
			label = "Pages Per Sheet",
			possibleValues = { "\\d+" },
			flags = PropertyFlag.JOB_DEFAULT,
			index = "9")
	public int getPagePerSheet() {
		return _pagePerSheet;
	}

	public void setPagePerSheet(int pagePerSheet) {
		_pagePerSheet = pagePerSheet;
	}

	public int getPageRange() {
		return _pageRange;
	}

	public void setPageRange(int pageRange) {
		_pageRange = pageRange;
	}

	public boolean isSupportedAttribute(Class< ? extends Attribute> clazz) {
		if (_printService == null) {
			return false;
		}
		return _printService.isAttributeCategorySupported(clazz);
	}

	private void setSupportedAttributes() {

		if (!supportedAttribute(ColorSupported.class, "color")) {
			_color = false;
		}

		if (!supportedAttribute(SheetCollate.class, "collate")) {
			_collate = false;
		}

		if (!supportedAttribute(Sides.class, "duplex")) {
			_duplex = false;
		}
	}

	public boolean supportedAttribute(Class< ? extends Attribute> clazz,
			String propertyName) {

		if (!isSupportedAttribute(clazz)) {
			PropertyDef[] propDef = getPropertyDefs();
			for (PropertyDef tmpDef : propDef) {
				if (tmpDef.getPropertyName().equalsIgnoreCase(propertyName)) {
					/*
					 * TO DO Remove only JOB_DEFAULT flag
					 */
					tmpDef.setFlags(null);
				}
			}
			return false;
		}
		return true;
	}

	private boolean isSupportAttribute(MultiDocPrintService service,
			Class< ? extends Attribute> clazz) {

		return service.isAttributeCategorySupported(clazz);
	}

	private PrintServiceAttribute getSupportAttribute(
			MultiDocPrintService service,
			Class< ? extends PrintServiceAttribute> clazz) {

		return service.getAttribute(clazz);
	}

	public MultiDocPrintService getNamedMultiDocPrintService(String prnName) {

		MultiDocPrintService[] prnSvcs;
		MultiDocPrintService prnSvc = null;
		DocFlavor[] flavor = new DocFlavor[1];
		flavor[0] = DocFlavor.SERVICE_FORMATTED.PRINTABLE;
		prnSvcs = PrintServiceLookup.lookupMultiDocPrintServices(flavor, null);
		if (LOG.isDebugEnabled()) {
			if (prnSvcs.length > 0) {
				int ii = 0;
				while (ii < prnSvcs.length) {
					if (prnSvcs[ii].getName().equalsIgnoreCase(prnName)) {
						prnSvc = prnSvcs[ii];
						LOG.debug("Named Printer selected: "
							+ prnSvcs[ii].getName() + "*");
						LOG.debug("Copies supported:"
							+ isSupportAttribute(
							prnSvcs[ii],
							Copies.class));

						LOG.debug("Color supported:"
							+ isSupportAttribute(prnSvcs[ii],
							ColorSupported.class));

						LOG.debug("Chromaticity supported:"
							+ isSupportAttribute(prnSvcs[ii],
							Chromaticity.class));

						LOG.debug("SheetCollate:"
							+ isSupportAttribute(
							prnSvcs[ii],
							SheetCollate.class));

						LOG.debug("Sides supported:"
							+ isSupportAttribute(
							prnSvcs[ii],
							Sides.class));

						LOG.debug("Color: "
							+ getSupportAttribute(prnSvcs[ii],
							ColorSupported.class));

						LOG.debug("QueuedJobCount: "
							+ getSupportAttribute(prnSvcs[ii],
							QueuedJobCount.class));

						LOG.debug("PrinterState: "
							+ getSupportAttribute(prnSvcs[ii],
							PrinterIsAcceptingJobs.class));

						LOG.debug("PrinterStateReasons: "
							+ getSupportAttribute(prnSvcs[ii],
							PrinterStateReasons.class));

						LOG.debug("tostringvalue "
							+ getSupportAttribute(prnSvcs[ii],
							PrinterIsAcceptingJobs.class)
										.toString());

						Class< ? >[] supportedAttr = prnSvc
								.getSupportedAttributeCategories();

						Attribute[] tmpattr =
							prnSvc.getAttributes().toArray();

						int jj = 0;
						int kk = 0;
						while (jj < tmpattr.length) {
							LOG.debug(tmpattr[jj].getClass() + ","
								+ tmpattr[jj].getName() + ","
								+ tmpattr[jj].toString());
							jj++;
						}
						LOG.debug("SupportedAttr");
						while (kk < supportedAttr.length) {
							LOG.debug(supportedAttr[kk].getName() + ","
								+ supportedAttr[kk].toString());
							kk++;
						}
						LOG.debug("PrinterLocation: "
							+ prnSvcs[ii]
							.getAttribute(PrinterLocation.class));
						break;
					}
					ii++;
				}
			}
		}
		if (prnSvc == null) {
			throw new ApplicationException("Printer " + prnName
					+ " was not found on this system.");
		}
		return prnSvc;
	}

	private void setJobCollateAttr(String collate, PrintRequestAttributeSet aset) {

		if (StringUtils.isNotBlank(collate)) {
			if (new Boolean(collate)) {
				aset.add(SheetCollate.COLLATED);
			} else {
				aset.add(SheetCollate.UNCOLLATED);
			}
		} else {
			aset.add(getDefaultCollateAttr());
		}
	}

	private void setJobDuplexAttr(String duplex, PrintRequestAttributeSet aset) {

		if (StringUtils.isNotBlank(duplex)) {
			if (new Boolean(duplex)) {
				aset.add(Sides.DUPLEX);
			} else {
				aset.add(Sides.ONE_SIDED);
			}
		} else {
			aset.add(getDefaultDuplexAttr());
		}
	}

	public int getJobColor(String color) {

		int imageColor = BufferedImage.TYPE_BYTE_GRAY;
		if (isJobColor(color)) {
			imageColor = BufferedImage.TYPE_INT_ARGB;
		}

		return imageColor;
	}

	private void setJobColorAttr(String color, PrintRequestAttributeSet aset) {

		if (StringUtils.isNotBlank(color)) {
			if (new Boolean(color)) {
				aset.add(Chromaticity.COLOR);
			} else {
				aset.add(Chromaticity.MONOCHROME);
			}
		} else {
			aset.add(getDefaultColorAttr());
		}
	}

	private boolean isJobColor(String color) {
		boolean jobColor = false;
		if (StringUtils.isNotBlank(color)) {
			if (new Boolean(color)) {
				jobColor = true;
			}
		} else {
			if (_color) {
				jobColor = true;
			}
		}

		return jobColor;
	}

	private void setJobCopiesAttr(String copies, PrintRequestAttributeSet aset) {

		if (StringUtils.isNotBlank(copies)) {
			aset.add(new Copies(Integer.parseInt(copies)));
		} else {
			aset.add(new Copies(_copies));
		}
	}

	private void setPagePerSheet(String pagePerSheet, PrintRequestAttributeSet aset) {

		if (StringUtils.isNotBlank(pagePerSheet)) {
			aset.add(new NumberUp(Integer.parseInt(pagePerSheet.substring(0,1))));
		} else {
			aset.add(new NumberUp(_pagePerSheet));
		}
	}

    private void setPageRange(String pageRange, PrintRequestAttributeSet aset) {

        if (StringUtils.isNotBlank(pageRange)) {
            aset.add(new PageRanges(pageRange));
        }
    }

	/**
	 * Sets the job mediaSizeName attr.
	 *
	 * @param mediaSizeName
	 *            the media size name
	 * @param aset
	 *            the aset
	 */
	private void setJobMediaSizeNameAttr(String mediaSizeName,
			PrintRequestAttributeSet aset) {

		if (StringUtils.isNotBlank(mediaSizeName) &&
		        StringUtils.isNotBlank(_mediaSizeNames.get(mediaSizeName).toString())) {
			aset.add(_mediaSizeNames.get(mediaSizeName));
		}
	}

	/**
	 * Sets the media tray attribute.
	 *
	 * @param mediaTrayName
	 *            the media tray name
	 * @param aset
	 *            the aset
	 */
	private void setMediaTrayAttribute(String mediaTrayName,
			PrintRequestAttributeSet aset) {

		if (StringUtils.isNotBlank(mediaTrayName) &&
		        StringUtils.isNotBlank(_mediaTray.get(mediaTrayName).toString())) {
			aset.add(_mediaTray.get(mediaTrayName));
		}
	}

	/**
	 * Method to set the Page Orientation.
	 *
	 * @param pageOrientation
	 *            the page orientation
	 * @param aset
	 *            the aset
	 */
	private void setPageOrientation(String pageOrientation,
			PrintRequestAttributeSet aset) {

		if (StringUtils.isNotBlank(pageOrientation)) {
			aset.add(_pageOrientations.get(pageOrientation));
		}
	}

	public void setJobProperties(Map<String, String> jobProperties,
			PrintRequestAttributeSet aset) {
		setJobCollateAttr(jobProperties.get("collate"), aset);
		setJobDuplexAttr(jobProperties.get("duplex"), aset);
		setJobColorAttr(jobProperties.get("color"), aset);
		setJobCopiesAttr(jobProperties.get("copies"), aset);
		setJobMediaSizeNameAttr(jobProperties.get("MediaSizeName"), aset);
		setMediaTrayAttribute(jobProperties.get("MediaTray"), aset);
		setPageOrientation(jobProperties.get("PageOrientation"), aset);
		setPagePerSheet(jobProperties.get("pagePerSheet"), aset);
		if (!(ALL.equalsIgnoreCase(jobProperties.get("pageRange")))) {
			if (!"0".equalsIgnoreCase(jobProperties.get("pageRange"))) {
				setPageRange(jobProperties.get("pages"), aset);
			}
		}
	}

	public StatusInfo queryEndpointStatus() {
		return StatusUtils.createEndpointStatus(EndpointStatus.OK, null);
	}

	private Attribute getDefaultColorAttr() {
		if (_color) {
			return Chromaticity.COLOR;
		}
		return Chromaticity.MONOCHROME;
	}

	private Attribute getDefaultCollateAttr() {
		if (_collate) {
			return SheetCollate.COLLATED;
		}
		return SheetCollate.UNCOLLATED;
	}

	private Attribute getDefaultDuplexAttr() {
		if (_duplex) {
			return Sides.DUPLEX;
		}
		return Sides.ONE_SIDED;
	}

	public String getSupportedFlavor() {

		DocFlavor flavor = DocFlavor.INPUT_STREAM.POSTSCRIPT;
		if (getNamedPrintService(getPrinterName(), flavor) != null) {
			return POSTSCRIPT;
		} else {
			return PCL;
		}
	}

	private PrintService getNamedPrintService(String prnName, DocFlavor flavor) {
		PrintService[] prnSvcs;
		PrintService prnSvc = null; // get all print services for this machine
		prnSvcs = PrintServiceLookup.lookupPrintServices(flavor, null);
		if (prnSvcs.length > 0) {
			int ii = 0;
			while (ii < prnSvcs.length) {
				if (prnSvcs[ii].getName().equalsIgnoreCase(prnName)) {
					prnSvc = prnSvcs[ii];
					break;
				}
				ii++;
			}
		}
		return prnSvc;
	}

	/**
	 * Returns PrintService for the flavor requested.
	 *
	 * @param prnName
	 * @param flavor
	 * @return PrintService
	 *
	 * @since 13.5.2
	 */
	public PrintService getNamedPrintService(String prnName) {
		return getNamedPrintService(prnName, null);
	}
	
    @OutputProperty(
            defaultValue = "",
            description = "Location of the printer",
            label = "Location",
            required = "false",
            index = "10")
    public String getLocation() {
        return _location;
    }

    /**
     * TODO
     *
     * @param location
     *            the location to set
     */
    public void setLocation(String location) {
        if (location != null) {
            _location = location;
        } else {
            _location = "";
        }
    }	
}
