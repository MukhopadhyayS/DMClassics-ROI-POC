/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.printer.impl;

import java.io.File;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.net.URL;
import java.net.URLConnection;

import com.mckesson.eig.output.local.printer.PrintDestination;
import com.mckesson.eig.output.local.printer.PrintListener;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputSettingConstants;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.SpringUtilities;
import com.mckesson.eig.utility.util.StringUtilities;

/**
 * Facade for printing on Linux.
 * 
 * @author Srini Paduri
 * 
 * @since 13.5.2
 * 
 */
public class LinuxPrintFacade extends AbstractPrintFacade {

    private static final Log LOG = LogFactory.getLogger(LinuxPrintFacade.class);

    private static final String OUT = ".out";
    private MultiDocStreamingThread _mThread;
    private PrintThread _pThread;
    private Thread _pThreadInstance;
    private final Converter _converter;

    /**
     * Sends job to print destination based on strategy to be used.
     * 
     * @param job
     */
    public LinuxPrintFacade(OutputJob job, Object listener) {
        super(job);
        _converter = getPrintConversion();
        // Initialize streaming of files to printer.
        try {
            PipedOutputStream pos = new PipedOutputStream();
            PipedInputStream pis = new PipedInputStream(pos);

            _mThread = new MultiDocStreamingThread(pos, job);
            _pThread = new PrintThread(pis, job, (PrintListener) listener);

        } catch (IOException e) {
            LOG.error(e.getMessage());
        }
    }

    public void addFile(String file) throws IOException, InterruptedException {
        LOG.debug("File:" + file + " is added ");
        String type = getFileType(file);
        LOG.info("File is of type : " + type);
        String outFile = "";
        // Workaround added for Ovation to continue printing if the incoming document is not a pdf
        if (StringUtilities.hasContent(type) && !"application/pdf".equalsIgnoreCase(type)) {
            outFile = file;
        } else {
            convertToPS(file);
            outFile = file + OUT;
        }
        LOG.info("Adding " + outFile + " to streaming thread");
        _mThread.addFile(outFile);

        Thread mdst = new Thread(_mThread);
        _pThreadInstance = new Thread(_pThread);
        mdst.start();
        _pThreadInstance.start();
    }

    public void donewithJob() {
        LOG.debug("doneWithJob invoked");
        _mThread.setDone(true);
    }

    /**
     * Returns print thread for inspecting completion of thread.
     * 
     * @return
     */
    @Override
    public Thread getPrintThread() {
        return _pThreadInstance;
    }

    private void convertToPS(String inFile) throws IOException, InterruptedException {

        _converter.convert(inFile, inFile + OUT,
                ((PrintDestination) getJob().getDestination()).getPrinterName(),
                "ps", isReversePrintOrder(), getJob().getMetric());
    }

    private static Converter getPrintConversion() {
        return (Converter) SpringUtilities.getInstance().getBeanFactory()
                .getBean(OutputSettingConstants.PRINT_CONVERTER_BEAN);
    }

    public String getFileType(String file) {
        
        try {
            File f = new File(file);
            URL u = f.toURI().toURL();
            URLConnection uc = null;
            uc = u.openConnection();
            LOG.info("File type : " + uc.getContentType());
            return uc.getContentType();
        } catch (Exception e) {
            LOG.error("Unable to find file type : " + file);
        }
        return null;
    }
}
