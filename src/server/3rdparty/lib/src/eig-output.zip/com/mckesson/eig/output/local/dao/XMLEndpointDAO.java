/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.dao;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.mckesson.eig.output.model.DestDeviceTypeDef;
import com.mckesson.eig.output.model.DestTypeDef;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.EndpointDefList;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.model.EndpointTypeDefList;
import com.mckesson.eig.output.model.JobTransformTypeDef;
import com.mckesson.eig.output.model.OutputLoV;
import com.mckesson.eig.output.model.PartTransformTypeDef;
import com.mckesson.eig.output.model.SourceTypeDef;
import com.mckesson.eig.output.util.OutputConstants.DeviceType;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.OutputConstants.DestinationType;
import com.mckesson.eig.output.util.OutputConstants.JobTransformType;
import com.mckesson.eig.output.util.OutputConstants.PartTransformType;
import com.mckesson.eig.output.util.OutputConstants.SourceType;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.io.FileLoader;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;
import com.mckesson.eig.utility.util.XMLUtilities;

/**
 * DAO Implementation that reads and rights its data directly to XML file. The
 * implementation needs the full path of two files, one to store endpoint type
 * definitions and the other for endpoint definitions. Additional, the name of
 * the file which contains the Castor mapping for marshalling to and from XML
 * must be provided.
 *
 * @author Jon Anderson
 */
public class XMLEndpointDAO implements EndpointDAO {

	private static final Log LOG = LogFactory.getLogger(XMLEndpointDAO.class);
	private static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-16\"?>";

	private String _endpointDefaultFile;
	private OutputLovDAO _outputLovDAO;
	private EndpointDefList _endpointDefaultList;

	public XMLEndpointDAO() {
	}

	private Object unmarshal(String s) {
	    return OutputUtil.getObject(new StringReader(s));
	}

	private String marshal(Object dest) {
		StringWriter writer = new StringWriter();
		OutputUtil.getXML(dest, writer);
		String s = writer.toString();
		if (s.startsWith(XML_HEADER)) {
			return s.substring(XML_HEADER.length());
		}
		return s;
	}

	private EndpointTypeDefList readEndpointTypeDefData() {
		EndpointTypeDefList data = new EndpointTypeDefList();

		for (SourceType desc : SourceType.values()) {
			OutputLoV lov = getEndpointTypeLoV(desc.toString());
			SourceTypeDef def = null;
			if (lov == null) {
				def = new SourceTypeDef();
				def.setType(desc.toString());
				def.setEnabled(true);
				lov = createEndpointTypeLov(def);
			} else {
				String s = lov.getData();
				def = (SourceTypeDef) unmarshal(s);
			}
			def.setLov(lov);
			def.setId(lov.getId());
			data.add(def);
			checkDefaultSetting(def);
		}

		for (JobTransformType desc : JobTransformType.values()) {
			OutputLoV lov = getEndpointTypeLoV(desc.toString());
			JobTransformTypeDef def = null;
			if (lov == null) {
				def = new JobTransformTypeDef();
				def.setType(desc.toString());
				def.setEnabled(true);
				lov = createEndpointTypeLov(def);
			} else {
				String s = lov.getData();
				def = (JobTransformTypeDef) unmarshal(s);
			}
			def.setLov(lov);
			def.setId(lov.getId());
			data.add(def);
			checkDefaultSetting(def);
		}

		for (PartTransformType desc : PartTransformType.values()) {
			OutputLoV lov = getEndpointTypeLoV(desc.toString());
			PartTransformTypeDef def = null;
			if (lov == null) {
				def = new PartTransformTypeDef();
				def.setType(desc.toString());
				def.setEnabled(true);
				lov = createEndpointTypeLov(def);
			} else {
				String s = lov.getData();
				def = (PartTransformTypeDef) unmarshal(s);
			}
			def.setLov(lov);
			def.setId(lov.getId());
			data.add(def);
			checkDefaultSetting(def);
		}

		for (DestinationType desc : DestinationType.values()) {
			OutputLoV lov = getEndpointTypeLoV(desc.toString());
			DestTypeDef def = null;
			if (lov == null) {
				def = new DestTypeDef();
				def.setType(desc.toString());
				def.setEnabled(true);
				lov = createEndpointTypeLov(def);
			} else {
				String s = lov.getData();
				def = (DestTypeDef) unmarshal(s);
			}
			def.setLov(lov);
			def.setId(lov.getId());
			data.add(def);
			if (DestinationType.EMAIL.toString().equalsIgnoreCase(desc.toString())) {
			    checkDefaultSettingForEmail(def);
			}
		}
		
		for (DeviceType desc : DeviceType.values()) {
			OutputLoV lov = getEndpointTypeLoV(desc.toString());
			DestDeviceTypeDef def = null;
			if (lov == null) {
				def = new DestDeviceTypeDef();
				def.setType(desc.toString());
				def.setEnabled(true);
				lov = createEndpointTypeLov(def);
			} else {
				String s = lov.getData();
				def = (DestDeviceTypeDef) unmarshal(s);
			}
			def.setLov(lov);
			def.setId(lov.getId());	
			data.add(def);
		}
		return data;
	}

	public EndpointTypeDef getEndpointTypeDef(String name) {
		OutputLoV lov = getEndpointTypeLoV(name);
		if (lov == null) {
			return null;
		}
		EndpointTypeDef def = (EndpointTypeDef) unmarshal(lov.getData());
		def.setLov(lov);
		def.setId(lov.getId());
		return def;
	}

	/**
	 * @see EndpointDAO#createOrUpdateEndpointTypeDef(EndpointTypeDef)
	 */
	public EndpointTypeDef updateEndpointTypeDef(Integer userId,
			EndpointTypeDef endpointTypeDef) {
		if (endpointTypeDef == null) {
			throw new IllegalArgumentException(
					"endpointTypeDef argument is null");
		}
		OutputLoV lov = endpointTypeDef.getLov();
		if (lov == null) {
			lov = createEndpointTypeLov(endpointTypeDef);
			endpointTypeDef.setLov(lov);
		} else {
			updateEndpointTypeLov(userId, endpointTypeDef);
		}
		return endpointTypeDef;
	}

	/**
	 * @see EndpointDAO#deleteEndpointTypeDef(java.lang.String)
	 */
	public void enableEndpointTypeDef(EndpointTypeDef def, boolean enabled) {
		if (def != null) {
			OutputLoV lov = def.getLov();
			if (lov == null) {
				lov = getEndpointTypeLoV(def.getType());
				def.setLov(lov);
				def.setId(lov.getId());
			}
			def.setEnabled(enabled);
			updateEndpointTypeDef(new Integer(1), def);
		}
	}

	/**
	 * @see com.mckesson.eig.output.local.dao.EndpointDAO#readAllEndpointTypeDefs()
	 */
	public EndpointTypeDefList readAllEndpointTypeDefs() {
		return readEndpointTypeDefData();
	}

	private OutputLoV getEndpointTypeLoV(String name) {
		OutputLovDAO dao = getOutputLovDAO();
		return dao.retrieveEndpointType(name);
	}

	private OutputLoV createEndpointTypeLov(EndpointTypeDef def) {
		String data = marshal(def);
		OutputLoV lov = new OutputLoV();
		lov.setData(data);
		lov.setCreatedBy(0);
		lov.setModifiedBy(0);
		lov.setName(def.getType());
		createLoV(lov);
		def.setId(lov.getId());
		return lov;
	}

	private OutputLoV updateEndpointTypeLov(Integer userId, EndpointTypeDef def) {
		OutputLoV lov = def.getLov();
		if (lov == null) {
			lov = createEndpointTypeLov(def);
		} else {
			String data = marshal(def);
			lov.setData(data);
			lov.setModifiedBy(userId.intValue());
			lov = updateLoV(lov);
		}
		def.setLov(lov);
		return lov;
	}

	/**
	 * @see com.mckesson.eig.output.local.dao.EndpointDAO#readAllEndpointDefs()
	 */
	public EndpointDefList readAllEndpointDefs() {
		return null;
	}

	/**
	 * @see EndpointDAO#createOrUpdateEndpointDef(EndpointDef)
	 */
	public EndpointDef updateEndpointDef(Integer userId, EndpointDef endpointDef) {
		if (endpointDef == null) {
			throw new IllegalArgumentException(
					"endpointTypeDef argument is null");
		}
		OutputLoV lov = endpointDef.getLov();
		if (lov == null) {
			lov = createEndpointLov(endpointDef);
			endpointDef.setLov(lov);
		} else {
			updateEndpointLov(userId, endpointDef);
		}
		return endpointDef;
	}

	public EndpointDef createEndpointDef(EndpointDef endpointDef) {
		OutputLoV lov = createEndpointLov(endpointDef);
		endpointDef.setLov(lov);
		return endpointDef;
	}

	public void deleteEndpointDef(EndpointDef endpointDef) {
		OutputLoV lov = endpointDef.getLov();
		deleteLoV(lov);
	}

	@SuppressWarnings("unchecked")
    public EndpointDefList getEndpointDefByType(EndpointTypeDef endpointTypeDef) {
		EndpointDefList defList = new EndpointDefList();
		int id = endpointTypeDef.getId();
		List list = getEndpointLoVList(id);
		if ((list != null) && (list.size() > 0)) {
			Iterator i = list.iterator();
			while (i.hasNext()) {
				OutputLoV lov = (OutputLoV) i.next();
				String s = lov.getData();
				EndpointDef def = (EndpointDef) unmarshal(s);
				def.setId(lov.getId());
				def.setTypeId(lov.getParentId());
				def.setLov(lov);
				defList.add(def);
			}
		}
		return defList;
	}

	public EndpointDef getEndpointDef(int id) {
		OutputLoV lov = getEndpointLoV(id);
		if (lov == null) {
			return null;
		}
		String s = lov.getData();
		EndpointDef def = (EndpointDef) unmarshal(s);
		def.setId(lov.getId());
		def.setTypeId(lov.getParentId());
		def.setLov(lov);
		return def;
	}

    public EndpointDef getEndpointDef(String name, String defType) {
        OutputLovDAO dao = getOutputLovDAO();
        int endpointId = dao.getEndpointId(defType, name);
        return getEndpointDef(endpointId);
    }


	@SuppressWarnings("unchecked")
	private List getEndpointLoVList(int parentId) {
		OutputLovDAO dao = getOutputLovDAO();
		return dao.retrieveEndpoints(parentId);
	}

	@SuppressWarnings("unchecked")
	public List<Integer> getEndpointIds(List<String> endpointTypes) {
		List<Integer> result = new ArrayList<Integer>();
		OutputLovDAO dao = getOutputLovDAO();
		for(String s : endpointTypes) {
			List<Integer> list = dao.getAllEndpointIdsByType(s);
			if(!CollectionUtilities.isEmpty(list)) {
				result.addAll(dao.getAllEndpointIdsByType(s));
			}
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<EndpointDef> getEndpoints(List<String> endpointTypes) {
		List<EndpointDef> result = new ArrayList<EndpointDef>();
		OutputLovDAO dao = getOutputLovDAO();
		for(String s : endpointTypes) {
			List<OutputLoV> list = dao.getAllEndpointsByType(s);
			if ((list != null) && (list.size() > 0)) {
				Iterator<OutputLoV> i = list.iterator();
				while (i.hasNext()) {
					OutputLoV lov = i.next();
					String ss = lov.getData();
					EndpointDef def = (EndpointDef) unmarshal(ss);
					def.setId(lov.getId());
					def.setTypeId(lov.getParentId());
					def.setLov(lov);
					result.add(def);
				}
			}
		}
		return result;
	}

	private OutputLoV getEndpointLoV(int id) {
		OutputLovDAO dao = getOutputLovDAO();
		return dao.retrieveEndpoint(id);
	}

	private OutputLoV createEndpointLov(EndpointDef def) {
		String data = marshal(def);
		OutputLoV lov = new OutputLoV();
		lov.setData(data);
		lov.setCreatedBy(0);
		lov.setModifiedBy(0);
		lov.setName(def.getName());
		lov.setParentId(def.getTypeId());
		createLoV(lov);
		def.setId(lov.getId());
		return lov;
	}

	private OutputLoV updateEndpointLov(Integer userId, EndpointDef def) {
		OutputLoV lov = def.getLov();
		if (lov == null) {
			lov = createEndpointLov(def);
		} else {
			String data = marshal(def);
			lov.setData(data);
			lov.setModifiedBy(userId.intValue());
			lov.setName(def.getName());
			lov = updateLoV(lov);
		}
		def.setLov(lov);
		return lov;
	}

	private OutputLoV updateLoV(OutputLoV lov) {
		OutputLovDAO dao = getOutputLovDAO();
		return dao.merge(lov);
	}

	private void createLoV(OutputLoV lov) {
		OutputLovDAO dao = getOutputLovDAO();
		Integer i = (Integer) dao.create(lov);
		lov.setId(i.intValue());
	}

	private void deleteLoV(OutputLoV lov) {
		OutputLovDAO dao = getOutputLovDAO();
		dao.delete(lov);
	}

	public void setOutputLovDAO(OutputLovDAO outputLovDAO) {
		_outputLovDAO = outputLovDAO;
	}

	public OutputLovDAO getOutputLovDAO() {
		return _outputLovDAO;
	}

	public String getEndpointDefaultFile() {
		return _endpointDefaultFile;
	}

	public void setEndpointDefaultFile(String endpointDefaultFile) {
		_endpointDefaultFile = endpointDefaultFile;
	}

	@SuppressWarnings("unchecked")
	private void readFile(File f, List dest) {
		if (f.exists()) {
			FileReader reader = null;
			try {
				reader = new FileReader(f);
			    Document doc = XMLUtilities.parse(f, true);
			    NodeList childNodes = doc.getChildNodes().item(0).getChildNodes();
			    List<Object> list = new ArrayList<Object>();
			    for (int j = 0, count = childNodes.getLength() - 1; j < count;) {

		            Node node = childNodes.item(j).getNextSibling();
		            String xmlString = XMLUtilities.convertNodeToString(node);
		            list.add(OutputUtil.getObject(xmlString));
			        j += 2;
			    }

				dest.addAll(list);
			} catch (Exception ex) {

				throw new ApplicationException(ex);

			} finally {
				try {
					if (reader != null) {
						reader.close();
					}
				} catch (IOException iox) {
					LOG.debug("error closing: " + f, iox);
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void checkDefaultSetting(EndpointTypeDef typeDef) {
		List list  = getEndpointLoVList(typeDef.getId());
		if ((list == null) || (list.size() == 0)) {
			loadDefaultSetting(typeDef);
		} else {
			boolean isFound = false;
			Iterator i = list.iterator();
			while (!isFound && i.hasNext()) {
				OutputLoV lov = (OutputLoV) i.next();
				String s = lov.getData();
				EndpointDef def = (EndpointDef) unmarshal(s);
				if (def.getType().equals(typeDef.getType())) {
					isFound = true;
				}
			}
			if (!isFound) {
				loadDefaultSetting(typeDef);
			}
		}
	}
	
	/**
	 * Will create an entry in OUTPUT_LISTOFVALUE table 
	 * for the default EMAIL destination configured in endopoint-defs.xml
	 * 
	 * Added for requirement in Encore to load a 
	 * default email destination at the time of start up
	 * 
	 * @param typeDef
	 */
    private void checkDefaultSettingForEmail(EndpointTypeDef typeDef) {
        
        if (_endpointDefaultList == null) {
            loadDefaultFile();
        }
        
        for (EndpointDef endpointLov : _endpointDefaultList) {
            if (endpointLov.getType().equalsIgnoreCase(typeDef.getType())) {
                EndpointDef endpointDef = getEndpointDef(endpointLov.getName(), endpointLov.getType());
                if (endpointDef == null) {
                    endpointLov.setTypeId(typeDef.getId());
                    createEndpointLov(endpointLov);
                } else {
                    endpointDef.setName(endpointLov.getName());
                    endpointDef.setDescription(endpointLov.getDescription());
                    endpointDef.setPropertiesList(endpointLov.getPropertiesList());
                    updateEndpointLov(0, endpointDef);
                }
            }    
        }
    }

	private static File resolveToFile(String path) {
		File file = FileLoader.getResourceAsFile(path);
		if (file == null) {
			file = new File(path);
			if ((file.exists() && !file.canRead())
					|| !file.getParentFile().canWrite()) {
				throw new IllegalArgumentException(path + " is not valid");
			}
		}
		return file;
	}

	private void loadDefaultSetting(EndpointTypeDef typeDef) {
		if (_endpointDefaultList == null) {
			loadDefaultFile();
		}
        for (EndpointDef endpointType : _endpointDefaultList) {
        	if (endpointType.getType().equals(typeDef.getType())) {
        		endpointType.setTypeId(typeDef.getId());
        		createEndpointLov(endpointType);
        	}
        }
	}

	private void loadDefaultFile() {
		File f = resolveToFile(getEndpointDefaultFile());
		_endpointDefaultList = new EndpointDefList();
		readFile(f, _endpointDefaultList);
	}
}
