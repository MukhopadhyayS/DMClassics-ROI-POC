/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.disc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mckesson.eig.output.local.DestDeviceTypeHandler;
import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.local.dao.XMLEndpointDAO;
import com.mckesson.eig.output.local.file.FileTypeHandler;
import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.DestDef;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.DeviceType;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputConstants.PropertyType;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.output.util.status.StatusUtils;

/**
 * This class is used as a handler class for the devie type disc
 * 
 * @author Karthik, Easwaran (OFS)
 * @date Aug 26, 2013
 * @since Aug 26, 2013
 *
 */
public class DiscTypeHandler extends FileTypeHandler {
	
	// map of properties to hold the list os all availble disc destination
	private final Map<String, DiscDestination> _discDestinationsMap = new HashMap<String, DiscDestination>();
	private DestDeviceTypeHandler destDeviceHandler;

	private XMLEndpointDAO endpointDao;
	private Object _semaphore;
	
	public DiscTypeHandler() { 
		super(); 
		_semaphore = new Object();
	}
	
	/**
	 * constructor used to enable or disable the disc type
	 * if the argument is passed as false, it would would not list the disc type in the queue
	 * @param enabled - whether the queue tyep is enable
	 */
	public DiscTypeHandler(String enabled) {
        this();
    	setEnabled(enabled);
    }

	/**
	 * 
	 * @see com.mckesson.eig.output.local.AbstractTypeHandler#createEndpoint(com.mckesson.eig.output.model.EndpointDef)
	 */
	@Override
	public OutputEndpoint createEndpoint(EndpointDef endpointDef) {

		if (endpointDef == null) {
			throw new IllegalArgumentException("endpointDef argument is null");
		}

		DestDef destDef = (DestDef) endpointDef;
		DiscDestination discDestination = new DiscDestination(this, destDef);
		_discDestinationsMap.put(destDef.getName(), discDestination);
		return discDestination;
	}
	
	/**
	 * 
	 * retrieves the propertyDefinition for the given deviceId
	 * @param deviceId - the deviceId whose propertydefs is to be retrieved
	 */
	public PropertyDef[] getDevicePropertyDefs(String deviceID) {
		
		return destDeviceHandler.getDevicePropertyDefs(deviceID);
	}
	

	/**
	 * retrieves the list of all propertyDefs for the disc Queue 
	 * retrieves propertydefs defins the list of all available options of the disc queue
	 */
	public  PropertyDef[] getPropertyDefs() {
		
		PropertyDef[] propertyDefs = PropertySupport.extractAnnotatedProperties(DiscDestination.class);
		
		// to change the default template values from specified files
		for (PropertyDef currentPropertyDef : propertyDefs) {
			
			if ("labelTemplate".equalsIgnoreCase(currentPropertyDef.getPropertyName())) {
				
				currentPropertyDef.setDataType(PropertyType.COLLECTION.toString());
				
				
			} else  if ("device".equalsIgnoreCase(currentPropertyDef.getPropertyName())) {
				
				
				List<EndpointDef> listOfDevices = getListOfDiscDevices();	
				List<String> devicePossibleValues = new ArrayList<String>();

				for (EndpointDef device : listOfDevices) {
					devicePossibleValues.add(device.getId() + "||" + device.getName());
				}
	
				String[] deviceNameStrings = new String[devicePossibleValues.size()];
				currentPropertyDef.setPossibleValues(devicePossibleValues.toArray(deviceNameStrings));
				currentPropertyDef.setDataType(PropertyType.COLLECTION.toString());
			}
		}
		
		return propertyDefs;
	}
	
	
	/**
	 * @see com.mckesson.eig.output.local.AbstractTypeHandler#queryDeviceIDs()
	 */
	public Collection<String> queryDeviceIDs() {
		return _discDestinationsMap.keySet();
	}
	
	public StatusInfo queryDeviceStatus(String deviceID) {
		
		//TODO: Need to change this method to query current status of the given deviceID
		StatusInfo tmpStatus = new StatusInfo();
		return tmpStatus;
	}

	/**
	 * 
	 * @see com.mckesson.eig.output.local.AbstractTypeHandler#queryDeviceProperties(java.lang.String)
	 */
	public Map<String, Object> queryDeviceProperties(String deviceID) {
		
		return PropertySupport.createDefaultValuesMap(
                PropertySupport.extractAnnotatedProperties(DiscDestination.class));
	}

	private List<EndpointDef> getListOfDiscDevices() {
		ArrayList<String> deviceTypes = new ArrayList<String>();
		deviceTypes.add(DeviceType.DISC_DEVICE.name());
	    List<EndpointDef> endpoints = this.endpointDao.getEndpoints(deviceTypes);
	    
	    return endpoints;

	}
	
	public XMLEndpointDAO getEndpointDao() {
		return endpointDao;
	}

	public void setEndpointDao(XMLEndpointDAO endpointDao) {
		this.endpointDao = endpointDao;
	}	

	public DestDeviceTypeHandler getDestDeviceHandler() {
		return destDeviceHandler;
	}

	public void setDestDeviceHandler(DestDeviceTypeHandler destDeviceHandler) {
		this.destDeviceHandler = destDeviceHandler;
	}

	public List<String> retrieveDeviceLabels(int deviceId) {
		 DeviceInfo deviceInfo= destDeviceHandler.getDeviceInfo(deviceId);
		 if (deviceInfo != null ){
		
			 return destDeviceHandler.getLabelTemplates(deviceInfo);
		 }
		 return null;
	}
	
	@Override
	public void updateEndpoints(List<ActiveEndpoint> endpointArr) {
		//update Device Labels
		/*
		 * Cycle through and find unique device ids
		 * Get labels
		 * Update each queue
		 */
		if (endpointArr == null) {
			return;
		}
		
		synchronized (_semaphore) {
			HashMap<String, List<String>> deviceLabelMap = new HashMap<String, List<String>>();
			
			for (ActiveEndpoint activeEndpoint : endpointArr) {
				String deviceId = activeEndpoint.getProperties().getAsString(OutputConstants.KEY_DEST_DEVICE_ID);
				if (!deviceLabelMap.containsKey(deviceId)) {
					
					deviceLabelMap.put(deviceId, retrieveDeviceLabels(Integer.valueOf(deviceId)));
				}
				
				List<String> labels = deviceLabelMap.get(deviceId);
				 if (labels != null) {
					 PropertyDef[] propertyDefs = activeEndpoint.getProperties().getPropertyDefs();
					 			
					 for (PropertyDef currentPropertyDef : propertyDefs) {
				
						 if ("labelTemplate".equalsIgnoreCase(currentPropertyDef.getPropertyName())) {
					
							String[] labelStrings = new String[labels.size()];
							currentPropertyDef.setPossibleValues(labels.toArray(labelStrings));
							currentPropertyDef.setDataType(PropertyType.COLLECTION.toString());
						 }
					 }				 					
				}
			}
		}
		
	}
	
	/* 
	 * (non-Javadoc)
	 * @see com.mckesson.eig.output.local.AbstractTypeHandler#updateJobStatusInfoWithEndpointStatus(java.util.Collection, java.util.List)
	 * if endpoint status is paused or stopped, update status info to error
	 * if endpoint status has an error , update status info to info
	 * otherwise status endpoint is ok
	 */
    @Override
    public void updateJobStatusInfoWithEndpointStatus(Collection<ActiveEndpoint> endpoints, List<OutputJob> outputJobs) {
    	super.updateJobStatusInfoWithEndpointStatus(endpoints, outputJobs);
    	
    	//build map of endpoints by id
    	synchronized(_semaphore) {
	    	HashMap<Integer, ActiveEndpoint> endpointsMap = new HashMap<Integer, ActiveEndpoint>();
	    	//used to hold the statusInfo for endpoints
	    	HashMap<Integer, StatusInfo> endpointsStatusInfo = new HashMap<Integer, StatusInfo>();
	    	for (ActiveEndpoint activeEndpoint : endpoints) {
	    		endpointsMap.put(activeEndpoint.getEndpointDef().getId(), activeEndpoint);
	    	}
	
	    	/*
	    	 * Update output job if the job is in a processing state - ie. ready, printing, faxing, burning, etc.
	    	 */
	    	for (OutputJob outputJob : outputJobs) {
	    		if (OutputConstants.RequestStatus.isRequestInProcessingState(outputJob.getStatusID())) {
	    			
	    			//read from cache first. if not in cache retrieve status and add to cache
		    		StatusInfo statusInfo = endpointsStatusInfo.get(outputJob.getDestID());
		    		if (statusInfo == null) {
		    			ActiveEndpoint myEndpoint =  endpointsMap.get(outputJob.getDestID());
		    			statusInfo = getEndpointStatusInfo(myEndpoint);
		    			endpointsStatusInfo.put(outputJob.getDestID(), statusInfo);
		    		}
	
	    			updateJobStatus(statusInfo, outputJob);
	    		}
	    	}
    	}
    	

    }
    	
    private StatusInfo getEndpointStatusInfo(ActiveEndpoint myEndpoint) {
    	StatusInfo statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.OK, OutputConstants.DEVICE_ONLINE);
		if ( myEndpoint != null ) {
			statusInfo = myEndpoint.getStatusInfo();
		}
   	 	return statusInfo;
    }
    
    private void updateJobStatus(StatusInfo statusInfo, OutputJob outputJob) {
    	if (statusInfo == null) {
    		return;
    	}
    	
    	//only update outputJob is job is in an incomplete state
		outputJob.getStatusInfo().setStatusCode(OutputConstants.JobDetailStatus.OK.statusCode());
		outputJob.getStatusInfo().setStatus(OutputConstants.JobDetailStatus.OK.name());

		if (StatusUtils.isStatusPause(statusInfo)
				|| StatusUtils.isStatusStop(statusInfo)) {
			outputJob.getStatusInfo().setStatusCode(OutputConstants.JobDetailStatus.ERROR.statusCode());
			outputJob.getStatusInfo().setStatus(OutputConstants.JobDetailStatus.ERROR.name());
		} else 	if (StatusUtils.isStatusError(statusInfo) 
				|| statusInfo.getStatusData().size() > 0) {  //has alert or error dialog message
			outputJob.getStatusInfo().setStatusCode(OutputConstants.JobDetailStatus.INFO.statusCode());
			outputJob.getStatusInfo().setStatus(OutputConstants.JobDetailStatus.INFO.name()); 					
		}

		String statusInfoDetail = "";
		String statusInfoData = "";
		if (statusInfo != null) {
			statusInfoDetail = statusInfo.getDetail();
			statusInfoData =  statusInfo.getDataInfoText();
			
			if (statusInfoDetail == null) {
				statusInfoDetail ="";
			}
			
			statusInfoDetail.replace("<br />", "").replace("<br/>", "");
			statusInfoData.replace("<br />", "").replace("<br/>", "");
		}
		outputJob.getProperties().put(OutputConstants.ENDPOINT_STATUS_KEY, statusInfoDetail);
		outputJob.getProperties().put(OutputConstants.ENDPOINT_STATUS_ADDITIONAL_INFO_KEY, statusInfoData);    	
    }
}
