/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * author: Latonia
 */

package com.mckesson.eig.output.local.transformers;


import com.mckesson.eig.output.local.OutputJobEndpoint;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.status.StatusUtils;


/*
 * TO DO: Support dynamic route building and processing
 */

/*
 * Processes Job level Transformations
 */
public class PdfJobTransforms
extends PdfTransforms
implements
OutputJobEndpoint {

    public PdfJobTransforms() {

        super();
    }

    public void processJob(OutputJob job) {

        if (job == null) {
            throw new IllegalArgumentException("job argument is null");
        }

        // NOOP
    }

    public StatusInfo queryEndpointStatus() {

        return StatusUtils.createEndpointStatus(EndpointStatus.OK, null);
    }

    /**
     * @see com.mckesson.eig.output.local.OutputEndpoint#queryEndpointStatus()
     */
    public StatusInfo queryEndpointStatus(boolean validEndPoint) {
		return queryEndpointStatus();
	}
}
