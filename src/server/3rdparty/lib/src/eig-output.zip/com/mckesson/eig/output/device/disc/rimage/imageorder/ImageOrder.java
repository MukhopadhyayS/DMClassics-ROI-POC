/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */



package com.mckesson.eig.output.device.disc.rimage.imageorder;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "ImageOrder")
@XmlType( propOrder={"target","format","source","output" })
public class ImageOrder {
    
    private Target target;
    private Format format;
    private Source source;
    private Output output;
    private String orderId;
    private String clientId;
    private String originator;
    private String priority;
    
    public Target getTarget() {
        return target;
    }
    @XmlElement(name = "Target")
    public void setTarget(Target target) {
        this.target = target;
    }
    
    
    public Format getFormat() {
        return format;
    }
    @XmlElement(name = "Format")
    public void setFormat(Format format) {
        this.format = format;
    }
    

    public Source getSource() {
        return source;
    }
    
    @XmlElement(name = "Source")    
    public void setSource(Source source) {
        this.source = source;
    }
    
    
    public Output getOutput() {
        return output;
    }
    
    @XmlElement(name = "Output")
    public void setOutput(Output output) {
        this.output = output;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    @XmlAttribute(name = "OrderId")
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    
    public String getClientId() {
        return clientId;
    }
    
    @XmlAttribute(name = "ClientId")
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }
    
    public String getOriginator() {
        return originator;
    }
    
    @XmlAttribute(name = "Originator")
    public void setOriginator(String originator) {
        this.originator = originator;
    }
    
    public String getPriority() {
        return priority;
    }
    
    @XmlAttribute(name = "Priority")
    public void setPriority(String priority) {
        this.priority = priority;
    }

}
