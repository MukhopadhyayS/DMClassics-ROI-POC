/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.disc;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.local.device.disc.DiscDevice;
import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.model.DestDef;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.OutputProperty.PropertyFlag;
import com.mckesson.eig.output.util.status.StatusUtils;

/**
 * This class provides the business methods implementations for Disc
 * destinations
 * 
 * Based on the annotation dynamic property panel of the Disc Queue 
 * is constructed and shown.
 *
 * @author Karthik, Easwaran (OFS)
 * @date Aug 26, 2013
 * @since Aug 26, 2013
 *
 */
public class DiscDestination extends Destination {

	private StatusInfo _status;
	private DiscTypeHandler _handler;
	private String _device;
	private String _mediaType;
	private String _labelTemplate;
	private String _password;
	private boolean _passwordRequired;
	private String _name;
	private DiscDevice _discdevice;
	

	@Override
	public StatusInfo queryEndpointStatus() {
		//return device status:

		DeviceInfo deviceInfo = _handler.getDestDeviceHandler().getDeviceInfo(Integer.valueOf(_device));
		StatusInfo statusInfo = deviceInfo.getStatusInfo();
		
/*		if (StatusUtils.isStatusError(statusInfo)) {
			
			// instead of get the status info from the disc device (which may be old status),
			// retrieves the status info from the disc provider
			OutputEndpoint endpoint = _handler.getDestDeviceHandler().createEndpoint(deviceInfo);
			ActiveEndpoint activeEndpoint = new ActiveEndpoint(deviceInfo, endpoint);
			statusInfo = activeEndpoint.getStatusInfo();
		}
*/		if ( statusInfo == null) {
			statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.OK, null);
		}
		return statusInfo;
	}

	public DiscDestination(DiscTypeHandler handler, DestDef destDef) {
        super();

        _status = StatusUtils.createEndpointStatus(EndpointStatus.OK, null);
		if (handler == null || destDef == null) {
			throw new IllegalArgumentException("handler argument is null");
		}
		_name = destDef.getName();
		Map<String, ? extends Object> properties = destDef.getProperties();
		_device = (String) properties.get("device");
        _handler = handler;
        
	}

	public StatusInfo getStatus() { return _status;	}
	public void setStatus(StatusInfo status) { _status = status; }

	public DiscTypeHandler getHandler() { return _handler; }
	public void setHandler(DiscTypeHandler handler) { _handler = handler; }

	 @OutputProperty(
	            defaultValue = "",
	            description = "Device",
	            label = "Device",
				possibleValues = { " " },
	            required = "true",
	            index = "0",
	            jsAction = "onDevicePropertyChange(this)")
	public String getDevice() { return _device; }
	public void setDevice(String systemDescription) { _device = systemDescription; }

	@OutputProperty(
			defaultValue = "",
			description = "Default label Template",
			label = "Default Label Template",
			possibleValues = { " " },
			required = "false",
			index = "1")
	public String getLabelTemplate() { return _labelTemplate; }
	public void setLabelTemplate(String labelTemplate) { _labelTemplate = labelTemplate; }

	@OutputProperty(
			defaultValue = "CD",
			description = "Default Disc Type",
			label = "Default Disc Type",
			possibleValues = {"CD", "DVD" },
			required = "false",
			index = "2")
	public String getMediaType() { return _mediaType; }
	public void setMediaType(String mediaType) { _mediaType = mediaType; }

	@OutputProperty(
            defaultValue = "Yes",
            description = "Is a password required to open the files on the disc",
            label = "Password Required",
            possibleValues = {"Yes", "No" },
            bindingProperty = "password",
            index = "3")
	public boolean isPasswordRequired() { return _passwordRequired;	}
	public void setPasswordRequired(boolean passwordRequired) {
		_passwordRequired = passwordRequired;
	}

	@OutputProperty(
            defaultValue = "",
            description = "Enter a default password to be to protect the files.",
            label = "Default Password",
            flags = PropertyFlag.JOB_DEFAULT,
            index = "4",
            maxLength = "50")
	public String getPassword() { return _password; }
	public void setPassword(String password) { _password = password; }

	public String getName() { return _name; }
	public void setName(String name) { _name = name; }

	public DiscDevice getDiscdevice() {
		return _discdevice;
	}

	public void setDiscdevice(DiscDevice discdevice) {
		_discdevice = discdevice;
	}
	
	/**
	 * This method is used to get the queue password.
	 * @param job - outputjob
	 * @return
	 */
	public String getQueuePassword(OutputJob job) {

		// Default queue password
		String qPassword = job.getPropertyValue(OutputConstants.OUTPUT_DISC_PASSWORD);
		// custom queue password from output job
		boolean isNotBlank = StringUtils.isNotBlank(qPassword);
	    qPassword = (isNotBlank) ? qPassword : getPassword();

	    return (StringUtils.isNotBlank(qPassword) || isPasswordRequired()) ?
	    		StringUtils.trim(qPassword) : null;
	}

	/**
	 * This method is used to return the request level password in output job.
	 * @param job - outputjob
	 * @return if exists request level password it returns, otherwise null
	 */
	public String getRequestPassword(OutputJob job) {

		// Check whether the Request level password is available in outputjob.
		String reqPassword = job.getPropertyValue(OutputConstants.OUTPUT_FILE_REQUEST_PASSWORD);
		return !StringUtils.isNotBlank(reqPassword) ? null : reqPassword;
	}
	

}
