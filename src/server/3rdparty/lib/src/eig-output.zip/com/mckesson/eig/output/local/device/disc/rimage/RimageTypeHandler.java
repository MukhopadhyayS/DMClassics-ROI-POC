/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/
/**
 * @author Latonia Howard
 *
 */

package com.mckesson.eig.output.local.device.disc.rimage;


import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.device.disc.DiscProviderFactory;
import com.mckesson.eig.output.device.disc.DiscProviderManager;
import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.local.device.disc.DiscDeviceTypeHandler;
import com.mckesson.eig.output.local.device.disc.DiscLabelStrategy;
import com.mckesson.eig.output.local.disc.DiscLabelTemplateFilter;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.InvalidDefinitionException;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.utility.util.SpringUtilities;


/**
 * This class provides the business methods implementations for rimage device destination type handlers
 * TODO:  may need to refactor structure - disc type handler should be super class???
 */
public class RimageTypeHandler extends DiscDeviceTypeHandler implements DiscLabelStrategy {

    private final Collection <String> _deviceIDs;
    private final HashMap <String, Map <String, Object>> _deviceProperties;
	private Object _semaphore;
	private boolean _includeFileExtForLabel;
	private String _defaultShareLocation = "C:\\template";
	private DiscLabelTemplateFilter _discLabelTemplateFilter;
	

    public RimageTypeHandler() {
    	_semaphore = new Object();
        _deviceProperties = new HashMap <String, Map <String, Object>>();
        _deviceIDs = new ArrayList <String>();
    }

    public RimageTypeHandler(String enabled) {
        this();
    	setEnabled(enabled);
    }

    public void cleanUp() {

        // TODO Auto-generated method stub

        // destroy devices
    }
    
	public boolean isIncludeFileExtForLabel() { return _includeFileExtForLabel; }
	public void setIncludeFileExtForLabel(boolean includeFileExtForLabel) {
		_includeFileExtForLabel = includeFileExtForLabel;
	}

	/**
	 * From the given share location, covert the path to absolute path and used. 
	 * @param defaultShareLocation
	 */
	public void setDefaultShareLocation(String defaultShareLocation) {
		
		File tmpFile = new File(defaultShareLocation);
		_defaultShareLocation = tmpFile.getAbsolutePath();
	}
	public String getDefaultShareLocation() { return _defaultShareLocation; }

	public DiscLabelTemplateFilter getDiscLabelTemplateFilter() { return _discLabelTemplateFilter; }
	public void setDiscLabelTemplateFilter(DiscLabelTemplateFilter discLabelTemplateFilter) {
		_discLabelTemplateFilter = discLabelTemplateFilter;
	}

   

    public OutputEndpoint createEndpoint(EndpointDef endpointDef) {
		if (! (endpointDef instanceof DeviceInfo)) {
			throw new InvalidDefinitionException(
					"Cannot create device" ,
					OutputErrorCode.RUNTIME_ERROR);			
		}
		
		DeviceInfo deviceInfo = (DeviceInfo) endpointDef;
		
		RimageDiscDevice rimageDestination = new RimageDiscDevice(this, deviceInfo);
		
        return rimageDestination;
    }

    public void destroyEndpoint(OutputEndpoint destination) {

    }

    public String[] getEndpointContentTypes() {

        return OutputConstants.ANY_CONTENT_TYPE;
    }

    @Override
    public PropertyDef[] getPropertyDefs() {

    	PropertyDef[] propDef =
    		PropertySupport.extractAnnotatedProperties(RimageDiscDevice.class);

    	/*
    	for (PropertyDef element : propDef)
		{
			if (element.getPropertyName().equals("availablePrinters")) {
				element.setPossibleValues(printers);
			}
		}*/

        return propDef;

    }

 	public PropertyDef[] getDevicePropertyDefs(String deviceID) {
        return null;
    }

    public Collection <String> queryDeviceIDs() {
    	//no-op
    	return null;
    }

    public Map <String, Object> queryDeviceProperties(String deviceID) {
    	//no-op
    	
    	return null;
    }

    public StatusInfo queryDeviceStatus(String deviceID) {
    	
    	//no-op
    	return null;
    }

    public EndpointCategory getEndpointCategory() {
        return EndpointCategory.DESTINATION_DEVICE;
    }
    
    public void validateDestination(RimageDiscDevice dest) {
    	
    	String errorMsgs = "";
    	//Connection
    	try {
    		//Only one connection at any given time
    		synchronized (_semaphore) {
    			DiscProviderManager manager = getDiscProviderManager(dest.getVendorName());
    			manager.testConnection(dest.getDeviceId(),
    					dest.getProperties().getAsString(RimageDiscDevice.HOSTADDRESS), dest.getProperties().getAsString(RimageDiscDevice.PORT) );
    		}
    	} catch (Exception ce){
    		errorMsgs += ce.getMessage() + " <br \\><br \\>";
    	}
    	
    	/*TODO:
    	 * check for default location also 
    	 */
    	
    	//labelDirectory
    	try {
    		String labelDirectory = dest.getProperties().getAsString(RimageDiscDevice.LABEL_TMPL_DIR);
    		if (StringUtils.isNotBlank(labelDirectory)) {
    			validateDirectory(new File(labelDirectory));
    		}
    	} catch (Exception ce){
    		errorMsgs += ce.getMessage() + " <br \\><br \\>";
    	}
    	
    	//temporaryLocation
    	try {
    		String temporaryLocation = dest.getProperties().getAsString(RimageDiscDevice.TMP_FILE_DIR);
    		if (StringUtils.isNotBlank(temporaryLocation)) {
    			validateDirectory(new File(temporaryLocation));
    		}
    	} catch (Exception ce){
    		errorMsgs += ce.getMessage() + " <br \\><br \\>";
    	}
    	
    	if (errorMsgs.length() > 0) {
			throw new InvalidDefinitionException(
					errorMsgs,
					OutputErrorCode.RUNTIME_ERROR);   		
    	}
    }
    
    private DiscProviderManager getDiscProviderManager(String deviceName) {
    	return getDiscProviderFactory().getDiscProviderManager(deviceName);
    }
    
	private DiscProviderFactory getDiscProviderFactory() {
		return (DiscProviderFactory) SpringUtilities.getInstance().getBeanFactory()
				.getBean("com.mckesson.eig.output.device.disc.DiscProviderFactory");
	}

	public static final void validateDirectory(File dir) {
		if (dir == null) {
			throw new IllegalArgumentException("Dir argument is null");
		}

		String path = dir.getAbsolutePath();
		if (!dir.exists() && !"".equalsIgnoreCase(dir.getName())) {
				throw new InvalidDefinitionException(
						"Directory does not exists: " + path,
						OutputErrorCode.RUNTIME_ERROR);

		} else if (!dir.isDirectory()) {
			throw new InvalidDefinitionException(
					"Not a directory: " + path,
					OutputErrorCode.RUNTIME_ERROR);
		} else if (!dir.canRead() || !dir.canWrite()) {
			throw new InvalidDefinitionException(
					"Cannot read or write to " + path,
					OutputErrorCode.RUNTIME_ERROR);
		}
	}
	
	/****
	 * Method used to find the BTW files name from the specified location.
	 * @return fileNames.
	 */
	public  List<String> getLabelTemplatesFromShareLocation(String shareLocation) {
		//invalid shareLocation
		if (StringUtils.isBlank(shareLocation)) {
			return null;
		}
		
		try {
			File file = new File(shareLocation);
			File[] files = file.listFiles(getDiscLabelTemplateFilter());
			List<String> fileNames = new ArrayList<String>();
			if (files != null) {
				
				// removes the files extension
				for (int i = 0; i< files.length ; i++) {
					
					// gets the name of the file with extension
					String fileName = files[i].getName();
					if (!isIncludeFileExtForLabel()) {
						
						// replaces the characters after last "." (DOT)
						fileName = fileName.replaceFirst("[.][^.]+$", "");
					}
					
					fileNames.add(fileName);
				}
			}
			return fileNames;
		} catch (Exception e) {
			//for any type of exception return an empty template list
			//TODO:  how to handle properly - should we gave an error message to user that
			//template is invalid or should this be on device???
			return null;
		}
	}

	@Override
	public List<String> getLabelTemplates(DeviceInfo info) {
	
		return getLabelTemplatesFromShareLocation((String)info.getProperties().get(RimageDiscDevice.LABEL_TMPL_DIR));
	}
	
    
}
