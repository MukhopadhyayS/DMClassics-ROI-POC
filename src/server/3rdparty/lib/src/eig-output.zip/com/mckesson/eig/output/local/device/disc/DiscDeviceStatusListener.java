package com.mckesson.eig.output.local.device.disc;

import java.util.List;

import com.mckesson.eig.output.model.StatusInfo;

public interface DiscDeviceStatusListener {
	
	//DeviceId is multiple. Because we have different Devices created for same IP and port.
	void deviceStatusChanged(List<Integer> deviceIds, StatusInfo status);
	
	/*
	 * If value is null, key is removed from current status
	 * if value is not null, key/value pair is added to current status info
	 */
	void deviceStatusPropertyChanged(List<Integer> deviceIds, String key, String value);
}
