/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

/*
 * TODO :  this should be rewritten as an object to the PdfHeaderFooter class
 * PdfHeaderFooter class should call get properties from this object for processing
 *
 * OR:  this class should be added to route before processing to set properties
 */
package com.mckesson.eig.output.local.transformers;


import java.util.Map;

import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.OutputConstants.OutputTransforms;


public class ROIHeaderFooterJob
extends PdfHeaderFooterJob {

    public ROIHeaderFooterJob() {

        super();
    }

    @Override
    public Map <String, String> getHeaderFooterProperties(OutputJob job) {
        ROIHeaderFooter roiHF = new ROIHeaderFooter();

        OutputTransform transform = OutputUtil.lookupJobTransform(job,
                                               OutputTransforms.HEADER_FOOTER.toString());

        Map<String, String> properties = roiHF.getHeaderFooterProperties(
                                                                 getOutputManager(), transform);

        return properties;
    }
}
