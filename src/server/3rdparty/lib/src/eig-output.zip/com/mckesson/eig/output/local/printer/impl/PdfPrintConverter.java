/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.printer.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.mckesson.eig.output.util.OutputSettingConstants;
import com.mckesson.eig.utility.io.ExecUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.metric.Metric;

/**
 * PdfPrintConverter converts pdf document to printer supported format.
 * 
 * Works in conjunction with corresponding thread that consumes the stream.
 * 
 * @see PrintThread
 * 
 * @author Srini Paduri
 * 
 * @since 13.5.2
 */
public class PdfPrintConverter implements Converter {

    private static String _pdfExePath;

    private static File _pdfExeWorkingDir;

    private static final Log LOG = LogFactory
            .getLogger(PdfPrintConverter.class);

    private static final String DESCENDING = "-reverse";
    private static final String PRINTER_NAME = "-printer=";

    private static final int FOUR = 4;

    /**
     * Default inPrefix to -in; can be overridden externally in bean definition.
     */
    private String _inPrefix = " -in=";

    /**
     * Default outPrefix to -out; can be overridden externally in bean
     * definition.
     */
    private String _outPrefix = " -out=";

    /**
     * Constructor initializes external executable location and current working
     * directory.
     * 
     * @param exePath
     */
    public PdfPrintConverter(String exePath) {
        setPath(exePath);
    }

    private void setPath(String exePath) {
        File f = new File(exePath);
        try {
            _pdfExePath = f.getCanonicalPath();
            _pdfExeWorkingDir = new File(_pdfExePath).getParentFile();
        } catch (Exception e) {
            LOG.error("Invalid Printer converter Path:" + exePath + "-" + e.getMessage());
        }
    }

    public void setProperties(Properties p) {
        if (p != null) {
            try {
                String value = p.getProperty(
                        OutputSettingConstants.PRINT_CONVERTER_IN_PREFIX);
                if (value != null) {
                    setInPrefix(value);
                }
                value = p.getProperty(OutputSettingConstants.PRINT_CONVERTER_OUT_PREFIX);
                if (value != null) {
                    setOutPrefix(value);
                }
                value = p.getProperty(OutputSettingConstants.PRINT_CONVERTER_PATH);
                if (value != null) {
                    setPath(value);
                }
            } catch (Exception e) {
                LOG.info("Failed to set Print Converter properties. Msg: "
                        + e.getMessage());
            }
        }
    }

    /**
     * Converts PDF document to either postscript or pcl format and writes to
     * requested output file name.
     * 
     * @since 13.5.2
     */
    public void convert(String inputFileName, String outputFileName,
            String targetName, String flavor, boolean reverseOrder, Metric metric)
            throws IOException,
            InterruptedException {

        metric.logMetric("Start convert to " + flavor);
        int val;
        List<String> list = getPrintProperties(reverseOrder);
        int args = FOUR + list.size();
        String[] cmdarray = new String[args];
        int i = 0;
        cmdarray[i++] = _pdfExePath;
        cmdarray[i++] = PRINTER_NAME + targetName;
        cmdarray[i++] = _inPrefix + inputFileName;
        cmdarray[i++] = _outPrefix + outputFileName;
        for (int j = 0; j < list.size(); j++) {
            cmdarray[i + j] = list.get(j);
        }

        String parameters = "";
        for (String element : cmdarray) {
            parameters += " " + element;
        }

        LOG.debug("Executing: " + _pdfExePath + parameters);
        val = ExecUtilities.execAndWaitFor("pdf conversion", cmdarray,
                null, _pdfExeWorkingDir);
        LOG.debug(_pdfExePath + parameters + " execution returned: " + val);

        metric.logMetric("Finish convert to " + flavor);
        if (val != 0) {
            LOG.error("Could not convert " + inputFileName + " to" + flavor);
            throw new IOException("Could not convert " + inputFileName + " to" + flavor);
        }
        // produce a .ready file after conversion
        File f = new File(outputFileName + ".ready");
        f.createNewFile();
    }

    private List<String> getPrintProperties(boolean reverseOrder) {
        List<String> list = new ArrayList<String>();
        if (reverseOrder) {
            list.add(DESCENDING);
        }
        return list;
    }

    public String getConvertType() {
        return "pdf";
    }

    public void setInPrefix(String in) {
        _inPrefix = in;
    }

    public void setOutPrefix(String out) {
        _outPrefix = out;
    }
}
