package com.mckesson.eig.output.security.authorization;


import java.net.URL;
import java.util.NoSuchElementException;

import org.apache.commons.collections.ExtendedProperties;

import com.mckesson.eig.Security;
import com.mckesson.eig.utility.io.FileLoader;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.wsfw.model.authorization.AuthorizationException;
import com.mckesson.eig.wsfw.session.WsSession;

/**
 * @author OFS
 * @date   May 06, 2009
 * @since  HPF 13.1; Dec 29, 2008
 */
public class HPFAuthorizationTable {

    private static final Log LOG = LogFactory.getLogger(HPFAuthorizationTable.class);
    private static final boolean DO_DEBUG = LOG.isDebugEnabled();
    private static final String EIG_USER_SECURITY_RIGHTS = "EIG_USER_SECURITY_RIGHTS";

    public HPFAuthorizationTable() {
    }
    private ExtendedProperties _map;

    public void setMappingFile(String mappingFile) {

        try {

            URL url = FileLoader.getResourceAsUrl(mappingFile);
            _map = new ExtendedProperties(url.getPath());
            if (DO_DEBUG) {
                LOG.info("**** File loaded : " + url.getPath());
            }
        } catch (Exception e) {
            throw new AuthorizationException(e);
        }
    }

    private int getRightId(String key) {
        try {
            return _map.getInt(key);
        } catch (NoSuchElementException e) {
        	throw new AuthorizationException("No Authorization set up for:\t" + key);
        	// return 0; why?
        }
    }

	public boolean hasRights(String key) {

	    Security security = (Security) WsSession.getSessionData(EIG_USER_SECURITY_RIGHTS);
	    int requiredRight = getRightId(key);

	    // Why?
	    //if (requiredRight == 0) {
	    //    return true;
	    //}

	    for (int code : security.getCodes()) {
	        if (requiredRight == code) {
                return true;
            }
	    }
	   return false;
	}
}

