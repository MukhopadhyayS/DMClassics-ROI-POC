/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.builder.HashCodeBuilder;
import org.springframework.util.ObjectUtils;

import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.utility.util.CollectionUtilities;

/**
 * RequestPart represents some content that is to be retrieved to be sent to a destination.
 * Logically, this can be viewed as a single call to a content source along with a set of
 * transformations to be performed once the content is retrieved.
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "requestPart")
@XmlType(name = "requestPart")
public class RequestPart implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final int HASH_MULTIPLY = 27;
	private static final int HASH_INIT = 13;

    private String _contentID;
    private String _contentSourceName;
    private String _contentSourceType;
    private Map<String, String> _properties;
    private List<OutputTransform> _transforms;

    //added for cxf migration
    private List<MapModel> _propertyList;


	/**
     * Creates the part.
     */
    public RequestPart() {
        super();
    }

    @Override
    public boolean equals(Object o) {

        RequestPart part = (RequestPart) o;

        if (!ObjectUtils.nullSafeEquals(part._properties, _properties)) {
            return false;
        }
        if (!ObjectUtils.nullSafeEquals(part._contentID, _contentID)) {
            return false;
        }
        if (!ObjectUtils.nullSafeEquals(part._contentSourceName, _contentSourceName)) {
            return false;
        }
        if (!ObjectUtils.nullSafeEquals(part._contentSourceType, _contentSourceType)) {
            return false;
        }
        if (!ObjectUtils.nullSafeEquals(part._transforms, _transforms)) {
            return false;
        }
        
        return true;
    }

    @Override
    public int hashCode() {

        HashCodeBuilder builder = new HashCodeBuilder(HASH_INIT, HASH_MULTIPLY);
        builder.append(_properties);
        builder.append(_contentID);
        builder.append(_contentSourceName);
        builder.append(_contentSourceType);
        builder.append(_transforms);
        return builder.toHashCode();
    }

    /**
     * contentID represents the specific piece of content to be retrieved from the
     * content source represented by source
     *
     * @return the _contentID member
     */
    public String getContentID() {
        return _contentID;
    }

    /**
     * @param identifier
     */
    @XmlElement (name = "contentID")
    public void setContentID(String identifier) {
        _contentID = identifier;
    }

    /**
     * These properties represent unique options that may be applied for retrieving or
     * processing the content specific piece of content
     *
     * @return the _properties member
     */
    public Map<String, String> getProperties() {
        
        if (CollectionUtilities.hasContent(_properties)) {
            return _properties;
        }

        if (CollectionUtilities.hasContent(_propertyList)) {

            Map<String, String> prop = new HashMap<String, String>();
            for (MapModel mapModel : _propertyList) {
            	// the map model allows null, while getting key or values null should be validated
            	String key = (null != mapModel.getKey()) ? mapModel.getKey().toString() : null;
            	String value = (null != mapModel.getValue()) ? mapModel.getValue().toString() : null;
                prop.put(key, value);
            }
            setProperties(prop);
        }
        return _properties;
    }

    /**
     * @param properties
     */
    @XmlTransient
    public void setProperties(Map<String, String> properties) {
        
        if (properties != null) {

            if (CollectionUtilities.hasContent(_propertyList)) {
                _propertyList.clear();
            } else {
                _propertyList = new ArrayList<MapModel>();
            }

            for (Map.Entry<String, ? extends Object> e : properties.entrySet()) {
                _propertyList.add(new MapModel(e.getKey(), e.getValue()));
            }
            _properties = properties;
        }
    }

    /**
     * Transforms define the specific operations that are to be performed on this specific
     * part prior to the job level transforms being applied.
     *
     * @return the _transforms member
     */
    public List<OutputTransform> getTransforms() {
        return _transforms;
    }

    /**
     * Returns the name of the source from which the content is to be retrieved
     *
     * @return the _contentSource member
     */
    public String getContentSourceName() {
        return _contentSourceName;
    }

    /**
     * @param source the _contentSource to set
     */
    @XmlElement (name = "contentSourceName")
    public void setContentSourceName(String sourceName) {
        _contentSourceName = sourceName;
    }

    /**
     * Returns the source type from which the content is to be retrieved
     *
     * @return the _contentSourceType member
     */
    public String getContentSourceType() {
        return _contentSourceType;
    }

    /**
     * @param source the _contentSourceType to set
     */
    @XmlElement (name = "contentSourceType")
    public void setContentSourceType(String sourceType) {
        _contentSourceType = sourceType;
    }


    /**
     * Sets the  set of transforms that are to be applied to the part
     *
     * @param transforms
     */
    @XmlElementWrapper (name = "transforms")
    @XmlElement (name = "outputTransform", type = OutputTransform.class)
    public void setTransforms(List<OutputTransform> transforms) {
        _transforms = transforms;
    }

    @XmlElementWrapper (name = "properties")
    @XmlElement(name = "property", type = MapModel.class)
    public void setPropertiesList(List<MapModel> properties) {
        _propertyList = properties;
    }

    public List<MapModel> getPropertiesList() {
        
        if (_properties != null) {
            _propertyList = new ArrayList<MapModel>();
            for (Map.Entry<String, ? extends Object> e : _properties.entrySet()) {
                _propertyList.add(new MapModel(e.getKey(), e.getValue()));
            }
        }
        return _propertyList;
    }
}
