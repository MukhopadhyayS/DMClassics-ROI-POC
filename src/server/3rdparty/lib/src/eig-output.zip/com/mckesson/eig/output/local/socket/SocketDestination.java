/*
 * Copyright 2010 McKesson Corporation and/or one of its subsidiaries. 
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material 
 * contains confidential, proprietary and trade secret information of 
 * McKesson Corporation and is protected under United States and 
 * international copyright and other intellectual property laws. Use, 
 * disclosure, reproduction, modification, distribution, or storage 
 * in a retrieval system in any form or by any means is prohibited without 
 * the prior express written permission of McKesson Corporation.
 */

package com.mckesson.eig.output.local.socket;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.net.Socket;

import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputProperty.PropertyFlag;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

/**
 * This class provides the business methods implementations for printer
 * destinations
 *
 * @author OFS
 */
public class SocketDestination extends Destination {

	private static final Log LOG = LogFactory.getLogger(SocketDestination.class);
	private SocketTypeHandler _typeHandler;

    private String _host;
	private String _port;

	/**
	 * TODO
	 */
	public SocketDestination(SocketTypeHandler handler) {

		super();
		if (handler == null) {
			throw new IllegalArgumentException("handler argument is null");
		}
		_typeHandler = handler;
	}

    public void processJob(OutputJob job) {
     }
    
    public StatusInfo queryEndpointStatus() {
        return StatusUtils.createEndpointStatus(EndpointStatus.OK, null);
    }

    public String getHost() {
        return _host;
    }

    @OutputProperty(defaultValue = "localhost", description = "Host Name", label = "Host",
            flags = PropertyFlag.JOB_DEFAULT, index = "1")
    public void setHost(String host) {
        _host = host;
    }

    public String getPort() {
        return _port;
    }

    @OutputProperty(defaultValue = "8080", description = "Port", label = "Port",
            flags = PropertyFlag.JOB_DEFAULT, index = "2")
    public void setPort(String port) {
        _port = port;
    }
}
