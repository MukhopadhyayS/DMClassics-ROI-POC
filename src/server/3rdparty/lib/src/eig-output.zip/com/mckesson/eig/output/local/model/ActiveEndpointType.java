/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.local.model;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Map;

import com.mckesson.eig.output.local.EndpointTypeHandler;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.util.OutputPropertyMap;

/**
 * Object which represents an EndpointType that has been activated in the
 * system. It marries the metadata for an EndpointType with the
 * EndpointTypeHandler and maintains the integrity of the metadata.
 *
 * @author Jon Anderson
 */
public class ActiveEndpointType {

	private EndpointTypeHandler _endpointTypeHandler;
	private EndpointTypeDef _endpointTypeDef;
	private OutputPropertyMap _properties;

	/**
	 * Constructor requiring both the type definition and the handler
	 * to make a valid ActiveEndpointType
	 *
	 * @param endpointTypeDef
	 * @param endpointTypeHandler
	 */
	public ActiveEndpointType(
			EndpointTypeDef endpointTypeDef,
			EndpointTypeHandler endpointTypeHandler) {

	    if (endpointTypeDef == null) {
	        throw new IllegalArgumentException(
	                "endpointTypeDef argument is null");
	    }
		if (endpointTypeHandler == null) {
			throw new IllegalArgumentException(
					"endpointTypeHandler argument is null");
		}

        _endpointTypeHandler = endpointTypeHandler;


		PropertyDef[] propertyDefs = endpointTypeHandler.getPropertyDefs();

		if (propertyDefs == null) {
			_properties = new OutputPropertyMap();
		} else {
		    _properties = new OutputPropertyMap(propertyDefs);
		}

        _properties.addPropertyChangeListener(new ProxyPropertyListener());


		setEndpointTypeDef(endpointTypeDef);
	}


	/**
	 * Return the OutputPropertyMap properties which supports adding listeners
	 * etc.
	 *
	 * @return not <code>null</code>
	 */
	public OutputPropertyMap getProperties() {
		return _properties;
	}

	/**
	 * Returns the EndpointTypeHandler responsible for doing the work
	 * of creating and destroying OutputEndpoints
	 *
	 * @return not <code>null</code>
	 */
	public EndpointTypeHandler getEndpointTypeHandler() {
		return _endpointTypeHandler;
	}

    /**
     * Returns the metadata about the endpoint type
     *
     * @return not <code>null</code>
     */
    public EndpointTypeDef getEndpointTypeDef() {
        return _endpointTypeDef.clone();
    }

	/**
	 * Sets the metadata which describes the endpoint type. This may have a
	 * cascading effect of setting properties on the type handler as well.
	 *
	 * @param endpointTypeDef not <code>null</code>
	 */
    public void setEndpointTypeDef(EndpointTypeDef endpointTypeDef) {
	    if (endpointTypeDef == null) {
	        throw new IllegalArgumentException(
	        		"endpointTypeDef argument is null");
	    }

       _endpointTypeDef = endpointTypeDef.clone();

	    Map<String, ? extends Object> properties =
	    	endpointTypeDef.getProperties();
	    _properties.setProperties(properties);
    }


    // Forward the property changes on the actual endpoint
    class ProxyPropertyListener implements PropertyChangeListener {

        /**
         * @see PropertyChangeListener#propertyChange(PropertyChangeEvent)
         */
        public void propertyChange(PropertyChangeEvent evt) {

            if (evt == null) {
                throw new IllegalArgumentException("evt argument is null");
            }

            String propertyName = evt.getPropertyName();
            Object value = evt.getNewValue();

            getEndpointTypeHandler().setProperty(propertyName, value);

        }

    }

}
