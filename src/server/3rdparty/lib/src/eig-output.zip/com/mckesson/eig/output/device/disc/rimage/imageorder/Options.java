/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage.imageorder;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Options")
public class Options {
    
    public Options() {
        super();
    }

    private String volumeGroup;
   
    public String getVolumeGroup() {
        return volumeGroup;
    }
    
    @XmlAttribute(name = "VolumeGroup")
    public void setVolumeGroup(String volumeGroup) {
        this.volumeGroup = volumeGroup;
    }

}
