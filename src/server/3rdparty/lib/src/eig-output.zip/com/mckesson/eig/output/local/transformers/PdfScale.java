/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;


import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


public class PdfScale {

    private static final Log LOG = LogFactory.getLogger(PdfScale.class);

    public PdfScale() {

    }

    /**
     * Returns name of concatenated file
     */

    public void scale(OutputJob job) {

        // unlimited file size

        String nextLocation = job.getNextLocation();
        ArrayList <String> fileNames = new ArrayList <String>();

        for (JobPart part : job.getParts()) {
            Iterator <String> filesIterator = part.getSourcesIterator();
            nextLocation = part.getNextLocation();
            while (filesIterator.hasNext()) {
                String currFilename = part.getCurrentLocation()
						+ File.separatorChar + filesIterator.next();
                fileNames.add(currFilename);
            }
        }

    }
}
