/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.service;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jws.WebService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mckesson.eig.output.ci.PLAuthenticator;
import com.mckesson.eig.output.ci.PLAuthorizer;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.OutputLovDAO;
import com.mckesson.eig.output.model.DestInfo;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputJobs;
import com.mckesson.eig.output.model.OutputLoV;
import com.mckesson.eig.output.model.OutputRequest;
import com.mckesson.eig.output.model.OutputServicePropertySet;
import com.mckesson.eig.output.model.Property;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.PropertyDefList;
import com.mckesson.eig.output.model.RequestPart;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.security.authorization.OutputACL;
import com.mckesson.eig.output.security.authorization.OutputACL.RIGHTS;
import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.util.SpringUtilities;
import com.mckesson.eig.wsfw.session.WsSession;

/**
 * Default implementation of OutputService
 *
 * @author OFS
 * @author Jon Anderson
 */
@WebService(name = "OutputPortType_v1_0",
            portName = "Output_v1_0",
            serviceName = "OutputService_v1_0",
            targetNamespace = "http://eig.mckesson.com/wsdl/output-v1",
            endpointInterface = "com.mckesson.eig.output.service.OutputService")
public class OutputServiceImpl extends OutputBaseService implements OutputService {

	private static final String AUTHORIZE_KEY_DEL = ".";
    private static final String KEY_AUTHORIZER = "authorizer";

	private Log _log = LogFactory.getLog(getClass());

	private static final String OUTPUT_CONFIGURATION = "OutputConfiguration";

    private OutputManager _outputManager;
    private OutputServicePropertySet _propertySet;
    private DestinationService _destinationService;

    /**
     * Default constructor doesn't do much
     *
     * @param outputManager
     */
    public OutputServiceImpl(OutputManager outputManager, DestinationService destinationService) {
        if (outputManager == null) {
        	throw new IllegalArgumentException("outputManager argument is null");
        }

        _outputManager = outputManager;
        _destinationService = destinationService;
    }

    public OutputServiceImpl() {
    }

    /**
     * Query output job based on the given jobId.
     *
     * @param jobID the job id
     *
     * @return the output job
     *
     * @see com.mckesson.eig.output.service.OutputService #queryOutputJob(int)
     */
    public OutputJob queryOutputJob(int jobID) {

    	OutputACL acl = ((OutputACL) WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY));

    	boolean monitorAllJobs = canMonitorAllJobs(acl.getOutputRights());
    	if (!monitorAllJobs) {
    		validateJobCreator(acl.getActorId(), jobID);
    	}

    	OutputJob job = getOutputJobDAO().readOutputJob(jobID);
    	if (job!= null) {
        	populateJobWithRequestXMLDeatails(job);    		
    	}

    	ArrayList<OutputJob> outputJobs = new ArrayList<OutputJob> ();
    	outputJobs.add(job);
    	_outputManager.updateJobStatusInfoWithEndpointStatus(outputJobs);
    	return job;
    }

    /**
     * This method validates if the actor created the job or not. If the job
     * is not created by the actor then an exception is thrown.
     *
     * @param actorId
     * @param jobID
     */
    private void validateJobCreator(String actorId, int jobID) {

    	OutputJob job = getOutputJobDAO().readOutputJob(jobID);
    	if (!actorId.equals(job.getUserName())) {
    		throw new OutputException("User has no rights to monitor other user's job",
    				OutputErrorCode.NO_RIGHTS_ERROR);
    	}
	}

	/**
     * This method validates if the user has monitor all jobs rights or not.
     *
     * @param outputRights
     * @return
     */
    private boolean canMonitorAllJobs(Map<RIGHTS, Boolean> outputRights) {

    	boolean canMonitorAllJobs = false;
    	Set<RIGHTS> rights = outputRights.keySet();
    	for (Iterator<RIGHTS> iterator = rights.iterator(); iterator.hasNext();) {

    		RIGHTS right = iterator.next();
			if (RIGHTS.MonitorAllJobs.equals(right)) {
				canMonitorAllJobs = outputRights.get(right);
			}
		}
		return canMonitorAllJobs;
	}

	/**
     * This method is used to populate the job with request XML details.
     *
     * @param job
     */
	private void populateJobWithRequestXMLDeatails(OutputJob job) {

		if (job == null) {
			return;
		}
		OutputRequest req = new OutputRequest();
		req = (OutputRequest) OutputUtil.getObject(new StringReader(job.getRequestXML()));

    	job.setProperties(req.getProperties());
    	job.setTransforms(req.getTransforms());
    	job.setDestID(req.getDestID());
    	job.setDestName(req.getDestName());
    	job.setDestType(req.getDestType());
    	job.setLabelData(req.getLabelData());
	}

    /**
     * Query the output jobs based on the given query option.
     *
     * @param queryOptions the query options
     *
     * @return the list< output job>
     *
     * @see com.mckesson.eig.output.service.OutputService#queryOutputJobs(java.util.Map)
     */
    public List<OutputJob> queryOutputJobs(List<MapModel> queryOptions) {

        List<OutputJob> jobs = new ArrayList<OutputJob>();
        if ((queryOptions == null)
            ||  (queryOptions.size() == 0)) {

            jobs = (List<OutputJob>) getOutputJobDAO().readAllOutputJobs();
            _outputManager.updateJobStatusInfoWithEndpointStatus(jobs);
            return jobs;
        }

        // conversion from List to Map
        Map<String, String> options = new HashMap<String, String>();
        for (MapModel mapModel : queryOptions) {
            if (mapModel.getKey() != null) {
                options.put(mapModel.getKey().toString(), mapModel.getValue().toString());
            }
        }

        jobs = (List<OutputJob>) getOutputJobDAO().queryJobs(options);
       	_outputManager.updateJobStatusInfoWithEndpointStatus(jobs);

        return jobs;
    }



    /**
     * Utility method to deserialize request XML and to populate job parts
     * @param job
     */
    private void populateJobPartsWithRequestXMLDetail(OutputJob job) {

        OutputRequest req = new OutputRequest();
        req = (OutputRequest) OutputUtil.getObject(new StringReader(job.getRequestXML()));

        job.setParts(mapOutputRequestToJobPart(job, req));
    }

    /**
     * Utility method to map request part to job part
     * @param job
     * @param req
     * @return
     */
    private List<JobPart> mapOutputRequestToJobPart(OutputJob job, OutputRequest req) {

        List<RequestPart> requestParts = req.getParts();
        if ((requestParts == null) || (requestParts.size() == 0)) {
            return null;
        }

        List<JobPart> jobParts = new ArrayList<JobPart>();
        for (RequestPart part : requestParts) {

            JobPart jobPart = new JobPart();
            jobPart.setOutputJob(job);
            jobPart.setContentID(part.getContentID());
            jobPart.getStatusInfo().setStatusCode(job.getStatusInfo().getStatusCode());

            String contentSourceName = part.getContentSourceName();
            String contentSourceType = part.getContentSourceType();

            jobPart.setContentSourceName(contentSourceName);
            jobPart.setContentSourceType(contentSourceType);
            jobPart.setProperties(part.getProperties());
            jobPart.setPages(0);

            jobPart.setTransforms(part.getTransforms());
            jobParts.add(jobPart);
        }

        return jobParts;
    }

    /**
     * Gets the service property defs.
     *
     * @return the service property defs
     *
     * @see com.mckesson.eig.output.service.OutputService#getServicePropertyDefs()
     */
    public PropertyDefList getServicePropertyDefs() {
        PropertyDefList pdl = new PropertyDefList();
        List<PropertyDef> propertyDefs = Arrays.asList(_outputManager.getPropertyDefs());
        if (propertyDefs != null) {
            pdl.setDelegate(propertyDefs);
        }
        return pdl;
    }

    /**
     * Submit output request.
     *
     * @param request the request
     *
     * @return the output job
     *
     * @see OutputService#submitOutputRequest(com.mckesson.eig.output.model.OutputRequest)
     */
    public OutputJob submitOutputRequest(OutputRequest request) {
        return _outputManager.submitOutputRequest(request);
    }

    /**
     * create output request.
     *
     * @param request the request
     *
     * @return the output job
     *
     * @see OutputService#postAndPause(com.mckesson.eig.output.model.OutputRequest)
     */
    public List<OutputJob> postAndPause(List<OutputRequest> request) {
        return _outputManager.postAndPause(request);
    }

    /**
     * Verifies the status of the job. if job is completed or errored or canceled returns true if
     * job status is in changed status state returns true i.e. if request is to pause job and job
     * is in paused state return true.
     *
     * @param jobID the job id
     * @param requestedStatusPending the requested status pending
     * @param requestedStatus the requested status
     */
    private void isJobCompletedOrStatusSet(int jobID, int requestedStatusPending,
            int requestedStatus) {
        int jobStatus = _outputManager.getJobStatus(jobID);

        if ((jobStatus == RequestStatus.CANCELING.statusCode())
                || (jobStatus == RequestStatus.CANCELED.statusCode())
                || (jobStatus == RequestStatus.COMPLETED.statusCode())
                || (jobStatus == RequestStatus.ERROR.statusCode())) {
            throw new OutputException("Job Is Completed or Status is Already Set",
                    OutputErrorCode.RUNTIME_ERROR);
        }

	    if ((jobStatus == requestedStatusPending) || (jobStatus == requestedStatus)) {
            throw new OutputException("Job Is Completed or Status is Already Set",
                    OutputErrorCode.RUNTIME_ERROR);
	    }

	}

    /**
     * Utility method to update the jobs status and return job.
     *
     * @param jobID the job id
     * @param tmpStatus the tmp status
     *
     * @return the output job
     */
    private OutputJob updateJobStatus(int jobID, StatusInfo tmpStatus) {
        OutputJob job =  _outputManager.updateJobStatus(jobID, tmpStatus);
        populateJobWithRequestXMLDeatails(job);
        return job;

    }

    /**
     * Cancel output job.
     *
     * @param jobID the job id
     *
     * @return the output job
     *
     * @see OutputService#cancelOutputJob(int)
     */
    public OutputJob cancelOutputJob(int jobID) {

    	OutputACL acl = ((OutputACL) WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY));

    	boolean monitorAllJobs = canMonitorAllJobs(acl.getOutputRights());
    	if (!monitorAllJobs) {
    		validateJobCreator(acl.getActorId(), jobID);
    	}

	    isJobCompletedOrStatusSet(jobID, RequestStatus.CANCELING.statusCode(),
	            RequestStatus.CANCELED.statusCode());
	    _outputManager.cancelOutputJob(jobID);
	    return updateJobStatus(jobID, StatusUtils.createRequestStatus(RequestStatus.CANCELING,
	            "Cancel Job Request"));
	}

    /**
     * Pause output job.
     *
     * @param jobID the job id
     *
     * @return the output job
     *
     * @see com.mckesson.eig.output.service.OutputService#pauseOutputJob(java.lang.String)
     */
    public OutputJob pauseOutputJob(int jobID) {

    	OutputACL acl = ((OutputACL) WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY));

    	boolean monitorAllJobs = canMonitorAllJobs(acl.getOutputRights());
    	if (!monitorAllJobs) {
    		validateJobCreator(acl.getActorId(), jobID);
    	}

        isJobCompletedOrStatusSet(jobID, RequestStatus.PAUSING.statusCode(),
                RequestStatus.PAUSED.statusCode());
        return updateJobStatus(jobID, StatusUtils.createRequestStatus(RequestStatus.PAUSING,
                                                                      "Pause Job Request"));
	}

    /**
     * Restart output job.
     *
     * @param jobID the job id
     *
     * @return the output job
     *
     * @see com.mckesson.eig.output.service.OutputService#restartOutputJob(java.lang.String)
     */
    public OutputJob restartOutputJob(int jobID) {

    	OutputACL acl = ((OutputACL) WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY));

    	boolean monitorAllJobs = canMonitorAllJobs(acl.getOutputRights());
    	if (!monitorAllJobs) {
    		validateJobCreator(acl.getActorId(), jobID);
    	}

        isJobCompletedOrStatusSet(jobID, RequestStatus.PROCESSING.statusCode(),
                RequestStatus.RESUMING.statusCode());

        _outputManager.restartOutputJob(jobID);
        return queryOutputJob(jobID);
	}

    /**
     * Gets the service properties.
     *
     * @return the service properties
     *
     * @see com.mckesson.eig.output.service.OutputService#getServiceProperties()
     */
    public OutputServicePropertySet getServiceProperties() {
        if (_propertySet == null) {
            OutputLoV lov = getOutputConfigurationLoV();
            if (lov == null) {
                Map<String, String> map =
                        PropertySupport.propertiesToStrings(_outputManager.getProperties());
                _propertySet = new OutputServicePropertySet();
                _propertySet.setMap(map);
                lov = savePropertyMap(_propertySet);
            } else {
                _propertySet = new OutputServicePropertySet(lov.getData());
            }
            _propertySet.setLov(lov);
        }
        return _propertySet;
    }

	private OutputLoV getOutputConfigurationLoV() {
		OutputLovDAO dao = getOutputLovDAO();
		return dao.retrieveOutputConfiguration();
	}

	private OutputLoV savePropertyMap(OutputServicePropertySet set) {
		String data = set.getMarshallerXML();
		OutputLoV lov = new OutputLoV();
		lov.setData(data);
        lov.setCreatedBy(0);
        lov.setModifiedBy(0);
		lov.setParentId(0);
        lov.setName(OUTPUT_CONFIGURATION);
        createOutputConfigurationLoV(lov);
        return lov;
	}

	private OutputLoV updatePropertyMap(Integer userId) {
		String data = _propertySet.getMarshallerXML();
		OutputLoV lov = _propertySet.getLov();
		if (lov == null) {
		    lov = savePropertyMap(_propertySet);
		    _propertySet.setLov(lov);
		} else {
			lov.setData(data);
	        lov.setModifiedBy(userId.intValue());
			updateOutputConfigurationLoV(lov);
		}
        return lov;
	}

	private void updateOutputConfigurationLoV(OutputLoV lov) {
		OutputLovDAO dao = getOutputLovDAO();
		OutputLoV mergeLov = dao.merge(lov);
		_propertySet.setLov(mergeLov);
	}

	private void createOutputConfigurationLoV(OutputLoV lov) {
		OutputLovDAO dao = getOutputLovDAO();
		Integer i = (Integer) dao.create(lov);
		lov.setId(i.intValue());
	}

	public String getServiceProperty(String property) {
		return PropertySupport.valueToString(_outputManager.getProperty(property));
	}

		protected void authenticateAuthorize(String user) {
			try {

				PLAuthenticator authenticator = (PLAuthenticator) SpringUtilities
					.getInstance().getBeanFactory().getBean(
							"authenticator" + AUTHORIZE_KEY_DEL + "pl");
				authenticator.validate();
				PLAuthorizer authorizator = null;

				authorizator = (PLAuthorizer) SpringUtilities.getInstance()
					.getBeanFactory().getBean(
							KEY_AUTHORIZER + AUTHORIZE_KEY_DEL + "pl");

				OutputACL acl = ((OutputACL)
						WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY));

				WsSession.setSessionData("USERNAME", user);
				if ((acl == null) && (authorizator != null)) {
					authorizator.initializeOutputACL();
				}

			} catch (Exception ex) {
				_log.error("Failed to authorize Job", ex);
			}

		}

	/**
	 * @see OutputService#setServiceProperty(java.lang.String, java.lang.String)
	 */
	public void setServiceProperty(int userId, String property, String value) {
    	setOutputServiceProperty(property, value);
	    updatePropertyMap(userId);
	}

	private void setOutputServiceProperty(String property, String value) {
		_outputManager.setProperty(property, value);
        _propertySet.put(property, value);
	}

	/**
	 * @see com.mckesson.eig.output.service.OutputService
	 * 	#setServiceProperties(OutputServicePropertySet)
	 */
	public void setServiceProperties(int userId,
			OutputServicePropertySet outputServicePropertySet) {
		if (userId <= 0) {
			throw new OutputException("UserId is missing",
					OutputErrorCode.MISSING_DATA);
		}
		if (outputServicePropertySet != null) {
		    for (Property property : outputServicePropertySet.getValues()) {
		    	setOutputServiceProperty(property.getName(), property.getValue());
 		    }
		    updatePropertyMap(userId);
		}
	}

    /**
     * Resubmit output job.
     *
     * @param jobID the job id
     *
     * @see com.mckesson.eig.output.service.OutputService #resubmitOutputJob(int)
     */
    public void resubmitOutputJob(int jobID) {

    	OutputACL acl = ((OutputACL) WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY));

    	boolean monitorAllJobs = canMonitorAllJobs(acl.getOutputRights());
    	if (!monitorAllJobs) {
    		validateJobCreator(acl.getActorId(), jobID);
    	}
		_outputManager.resubmitOutputJob(jobID);
	}

    /**
     * This method is used to redirect an output job.
     *
     * @param jobID
     *            The unique id of the job that should be redirected
     * @param request
     *            This request holds the overridden destination and output preferences that should
     *            be applied when the job is redirected
     */
    public void redirectOutputJob(int jobID, OutputRequest request) {

        OutputACL acl = ((OutputACL) WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY));
        boolean monitorAllJobs = canMonitorAllJobs(acl.getOutputRights());
        if (!monitorAllJobs) {
            validateJobCreator(acl.getActorId(), jobID);
        }
        _outputManager.cancelOutputJob(jobID);
        _outputManager.redirectOutputJob(jobID, request);
    }

    /**
     * Gets the output manager.
     *
     * @return the output manager
     */
    public OutputManager getOutputManager() {
        return _outputManager;
    }

    /**
     * Sets the output manager.
     *
     * @param outputManager the new output manager
     */
    public void setOutputManager(OutputManager outputManager) {
        _outputManager = outputManager;
    }

    public DestinationService getDestinationService() {
        return _destinationService;
    }


    public void setDestinationService(DestinationService destinationService) {
        _destinationService = destinationService;
    }


    /**
     * Re-submitting the output Job As a new Job.
     *
     * When an archived job is to be reprinted, the original job details
     * should not be modified in order to maintain audit trail.
     * So a new job is created during a resubmit of output job.
     * @param jobID The unique id of the job that should be redirected
	  * @param request This request holds the overridden destination and output
	  * preferences that should be applied when the job is redirected
     */
	public OutputJob resubmitAsNewOutputJob(int jobID, OutputRequest request) {

		OutputACL acl = ((OutputACL) WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY));
        boolean monitorAllJobs = canMonitorAllJobs(acl.getOutputRights());
        if (!monitorAllJobs) {
            validateJobCreator(acl.getActorId(), jobID);
        }
        return _outputManager.resubmitAsNewOutputJob(jobID, request);
	}

	/**
 	 * Method to retrieve the output request information for a given jobID and
     * store the document info in the filepath argument.
 	 *
 	 * @param jobID The unique id of the job that should be redirected
 	 * @param filePath This filePath holds the location where the PDF is available
 	 */
	public void retrieveOutputRequestInfo(int jobID, String filePath) {
		_outputManager.retrieveOutputRequestInfo(jobID, filePath);
	}

	/**
     * Query the output jobs based on the given query option.
     *
     * @param queryOptions the query options
     *
     * @return the OutputJobs
     *
     * @see com.mckesson.eig.output.service.OutputService#queryOutputJobsWithDeviceInfo(java.util.List)
     */
    public OutputJobs queryOutputJobsWithDeviceInfo(List<MapModel> queryOptions) {

        List<DestInfo> destInfos        = new ArrayList<DestInfo>();
        Map<Integer, Integer> destIdMap = new HashMap<Integer, Integer>();
        List<OutputJob> outputJobList   = queryOutputJobs(queryOptions);

        for (OutputJob outputJob : outputJobList) {

            int jobId = outputJob.getDestID();

            if (destIdMap.get(jobId) != null) {
                continue;
            }

            DestInfo destInfo = _destinationService.queryDestination(jobId);

            if (destInfo != null) {

                destIdMap.put(jobId, jobId);
                destInfos.add(destInfo);
            }
        }

        OutputJobs outputJobs = new OutputJobs();
        outputJobs.setOutputJobList(outputJobList);
        outputJobs.setDestInfoList(destInfos);

        return outputJobs;
    }
}
