package com.mckesson.eig.output.local.transformers;

import java.awt.Color;
import java.io.InputStream;
import java.io.OutputStream;

import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfGState;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class WatermarkProcessor {
	private static final int FONT_SIZE_72 = 72;
	private static final double OPACITY = 0.5;

	private static final Log LOGGER = LogFactory
		.getLogger("WatermarkProcessor.class");

	public void addWaterMark(InputStream in, OutputStream out, String watermark) {
		try {
			PdfReader tmpReader = new PdfReader(in);
			PdfStamper tmpStamper = new PdfStamper(tmpReader, out);
			int fontsize = new Integer(FONT_SIZE_72);
			float opacity = new Float(OPACITY);
			int pagecount = tmpReader.getNumberOfPages();
			PdfGState gs1 = new PdfGState();
			gs1.setFillOpacity(opacity);

			String text = watermark;
			BaseFont bf = BaseFont.createFont("Helvetica", BaseFont.WINANSI,
					false);
			float txtwidth = bf.getWidthPoint(text, fontsize);
			for (int i = 1; i <= pagecount; i++) {
				PdfContentByte seitex = tmpStamper.getOverContent(i);
				seitex.setColorFill(Color.GRAY);
				Rectangle recc = tmpReader.getCropBox(i);
				float winkel = (float) Math.atan(recc.getHeight()
						/ recc.getWidth());
				float m1 = (float) Math.cos(winkel);
				float m2 = (float) -Math.sin(winkel);
				float m3 = (float) Math.sin(winkel);
				float m4 = (float) Math.cos(winkel);
				float xoff = (float) (-Math.cos(winkel) * txtwidth / 2 - Math
						.sin(winkel)
						* fontsize / 2);
				float yoff = (float) (Math.sin(winkel) * txtwidth / 2 - Math
						.cos(winkel)
						* fontsize / 2);
				seitex.saveState();
				seitex.setGState(gs1);
				seitex.beginText();
				seitex.setFontAndSize(bf, fontsize);
				seitex.setTextMatrix(m1, m2, m3, m4,
						xoff + recc.getWidth() / 2,
						yoff + recc.getHeight() / 2);
				seitex.showText(text);
				seitex.endText();
				seitex.restoreState();
			}
			if (tmpStamper != null) {
				tmpStamper.close();
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}
}
