/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Map implementation that uses a delegate pattern and provides getters and
 * setters which are useful for using in Castor which doesn't like collections
 * as top level objects
 *
 * @author tlsplh4
 * @param <K> key type
 * @param <V> value type
 */

public class GetSetMap< K, V > implements Map< K, V > {

	private Map< K, V > _delegate;

	/**
	 * Uses a HashMap as the delegate
	 */
	public GetSetMap() {
		_delegate = new HashMap< K, V >();
	}

	/**
	 * Uses the provided delegate
	 *
	 * @param delegate not <code>null</code>
	 */
	public GetSetMap(Map< K, V > delegate) {
		if (delegate == null) {
			throw new IllegalArgumentException("delegate is null");
		}
		_delegate = delegate;
	}

	/**
	 * @see java.util.Map#clear()
	 */
	public void clear() {
		_delegate.clear();
	}

	/**
	 * @see java.util.Map#containsKey(java.lang.Object)
	 */
	public boolean containsKey(Object arg0) {
		return _delegate.containsKey(arg0);
	}

	/**
	 * @see java.util.Map#containsValue(java.lang.Object)
	 */
	public boolean containsValue(Object arg0) {
		return _delegate.containsValue(arg0);
	}

	/**
	 * @see java.util.Map#entrySet()
	 */
	public Set<Entry<K, V>> entrySet() {
		return _delegate.entrySet();
	}

	/**
	 * @see java.util.Map#equals(java.lang.Object)
	 */
	@Override
    public boolean equals(Object arg0) {
		return _delegate.equals(arg0);
	}

	/**
	 * @see java.util.Map#get(java.lang.Object)
	 */
	public V get(Object arg0) {
		return _delegate.get(arg0);
	}

	/**
	 * @see java.util.Map#hashCode()
	 */
	@Override
    public int hashCode() {
		return _delegate.hashCode();
	}

	/**
	 * @see java.util.Map#isEmpty()
	 */
	public boolean isEmpty() {
		return _delegate.isEmpty();
	}

	/**
	 * @see java.util.Map#keySet()
	 */
	public Set<K> keySet() {
		return _delegate.keySet();
	}

	/**
	 * @see java.util.Map#put(java.lang.Object, java.lang.Object)
	 */
	public V put(K arg0, V arg1) {
		return _delegate.put(arg0, arg1);
	}

	/**
	 * @see java.util.Map#putAll(java.util.Map)
	 */
	public void putAll(Map< ? extends K, ? extends V > arg0) {
		_delegate.putAll(arg0);
	}

	/**
	 * @see java.util.Map#remove(java.lang.Object)
	 */
	public V remove(Object arg0) {
		return _delegate.remove(arg0);
	}

	/**
	 * @see java.util.Map#size()
	 */
	public int size() {
		return _delegate.size();
	}

	/**
	 * @see java.util.Map#values()
	 */
	public Collection<V> values() {
		return _delegate.values();
	}

	/**
	 * TODO
	 * @param entries
	 */
	@SuppressWarnings("unchecked")
    public void setEntries(Collection entries) {

	    _delegate.clear();
	    if (entries != null)  {

	        Iterator entriesi = entries.iterator();
	        while (entriesi.hasNext()) {

	            Entry entry = (Entry) entriesi.next();
	            _delegate.put((K) entry.getKey(), (V) entry.getValue());
	        }
	    }
	}

	/**
	 * TODO
	 * @return
	 */
	@SuppressWarnings("unchecked")
    public Collection getEntries() {
	    ArrayList list = new ArrayList();
	    for (Entry<K, V> entry : _delegate.entrySet()) {
	        //list.add(new MapItem(entry.getKey(), entry.getValue()));
	    }
	    return list;
	}

	/**
	 * Sets the delegate object. does no validation to see if you are killing
	 * an already populated delegate
	 *
	 * @param delegate not <code>null</code>
	 */
	public void setDelegate(Map<K, V> delegate) {
		if (delegate == null) {
			throw new IllegalArgumentException("delegate argument is null");
		}
		_delegate = delegate;
	}

	/**
	 * Returns whatever our delegate currently is
	 *
	 * @return not <code>null</code>
	 */
	public Map<K, V> getDelegate() {
		return _delegate;
	}
}
