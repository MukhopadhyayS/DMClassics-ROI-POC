/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

 * Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
 * Use of this software and related documentation is governed by a license agreement.
 * This material contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States
 * and international copyright and other intellectual property laws.
 * Use, disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without the
 * prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
 */

package com.mckesson.eig.output.local.mediator.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;

import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.dao.OutputLovDAO;
import com.mckesson.eig.output.local.file.FileDestination;
import com.mckesson.eig.output.local.file.FileTypeHandler;
import com.mckesson.eig.output.local.transformers.Concatenate;
import com.mckesson.eig.output.local.transformers.PdfBookmark;
import com.mckesson.eig.output.model.JobFileList;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputJobFiles;
import com.mckesson.eig.output.service.OutputBaseService;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.PdfUtils;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;

public class MediatorFileJob extends AbstractMediatorJob {

	private static final Log LOG = LogFactory.getLogger(MediatorFileJob.class);

	public static final String ATTACHMENTS_DIR = "ATTACHMENTS";
	public static final String ATTACHMENTS_FINAL_DIR = "ATTACHMENTS_FINAL";
	public static final String PDF_EXT = "pdf";
	public static final String HASH_EXT = ".hash";

	public MediatorFileJob(OutputJob job, Destination d, DestTypeHandler handler) {
		super(job, d, handler);
	}

	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void addFile(String fileName) throws IOException,
			InterruptedException {
		// TODO Auto-generated method stub

	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void initializeJob(Object listener) {
		// TODO Auto-generated method stub

	}

	public void doneWithJob() throws IOException, InterruptedException {
		FileTypeHandler handler = (FileTypeHandler) getHandler();
		FileDestination destination = (FileDestination) getDestination();
		OutputJob job = getJob();
		try {

			Concatenate pdfConcatenate = handler.getConcatenateStrategy();
			long size = destination.getFileMaxSizeInByte(job);
			generateBookmarks(job, handler.getBookmarkStrategy(), size);
			List<String> files = pdfConcatenate.concatenate(job, size);
			Properties p = handler.getCryptoProperties();
			// if encryption required encrypt files
			// owner password is always the request password
			// password is the given at the time of release
			String ownerPassword = destination.getRequestPassword(job);
			String password = destination.getQueuePassword(job);

			if (destination.isPasswordEncrypted(job)) {
				ownerPassword = decryptPassword(ownerPassword);
				password = decryptPassword(password);
			}

			encryptFiles(files, password, ownerPassword, p);

			// add hash file for the output file
			List<String> hashFiles = addHashFile(files, p);

			File jobDirectory = getJobDirectory(job);

			// copy to destination
			copytoDestination(files, jobDirectory);
			copytoDestination(hashFiles, jobDirectory);

			// update status
			updateStatus(job.getJobSeq(), RequestStatus.COMPLETED,
					OutputConstants.MSG_FILE_COMPLETED);
			List<String> allFiles = new ArrayList<String>();
			allFiles.addAll(files);
			allFiles.addAll(hashFiles);
			Calendar completedDate = Calendar.getInstance();
			updateJobResults(job.getJobSeq(), jobDirectory, allFiles,
					completedDate);

			// add purge entity
			// HPF 15.2 - system queues can set purge time to negative number to
			// indicate do not purge
			if (destination.getPurgeTime() > 0) {
				addPurgeEntry(job.getDestID(), job.getJobSeq(), jobDirectory,
						files, completedDate);
				addPurgeEntry(job.getDestID(), job.getJobSeq(), jobDirectory,
						hashFiles, completedDate);
			}

		} catch (Exception e) {
			updateStatus(job.getJobSeq(), RequestStatus.ERROR,
					OutputConstants.MSG_FILE_ERROR + ":" + e.toString());
			LOG.error("Save to File error");
			// create error message file
			writeExceptionToFile(job, e.toString());
			throw new ApplicationException(e);
		}
	}

	private void writeExceptionToFile(OutputJob job, String errMsg) {
		FileDestination destination = (FileDestination) getDestination();
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-dd hh.mm");

		File jobDirectory = new File(destination.getDirectoryName(), job
				.getSubmitInfo().getUser());
		FileTypeHandler.validateDirectory(jobDirectory);
		File errorFile = new File(jobDirectory.getAbsolutePath()
				+ File.separatorChar
				+ job.getPropertyValue(OutputConstants.OUTPUT_FILE_REQUEST_ID)
				+ "-" + dateFormat.format(cal.getTime())
				+ " Error Generating PDF" + "-v"
				+ job.getPropertyValue(OutputConstants.OUTPUT_FILE_RELEASE_NUM)
				+ ".txt");
		try {
			FileWriter writer = new FileWriter(errorFile);
			writer.write("The following error was found generating the PDF file(s).  "
					+ errMsg + "  Please contact your system administrator.");
			writer.close();
		} catch (Exception e1) {
			throw new ApplicationException(e1);
		}
	}

	protected void copytoDestination(List<String> files, File jobDirectory)
			throws IOException {
		if (files != null) {
			for (String s : files) {
				File f = new File(s);
				FileUtils.copyFileToDirectory(f, jobDirectory);
			}
		}
	}

	private File getJobDirectory(OutputJob job) {
		FileDestination destination = (FileDestination) getDestination();
		File jobDirectory = new File(destination.getDirectoryName(), job
				.getSubmitInfo().getUser());
		return jobDirectory;
	}

	protected void generateBookmarks(OutputJob job,
			PdfBookmark bookmarkStrategy, long size) {
		if (bookmarkStrategy != null) {
			bookmarkStrategy.createJobBookmark(job, size);
		}
	}

	private void addPurgeEntry(int destId, int jobId, File jobDirectory,
			List<String> fileNames, Calendar completedDate) {
		if (fileNames.size() > 0) {
			OutputBaseService baseService = new OutputBaseService();
			OutputLovDAO lovDao = baseService.getOutputLovDAO();
			ArrayList<String> fileNameList = new ArrayList<String>();
			for (String s : fileNames) {
				fileNameList.add(getPurgeFile(jobDirectory, s));
			}
			JobFileList fileList = new JobFileList();
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);
			fileList.setLastPurgeDate(cal.getTime());
			ArrayList<OutputJobFiles> outputJobFiles = new ArrayList<OutputJobFiles>();
			OutputJobFiles jobFiles = new OutputJobFiles();
			jobFiles.setCompletedDate(completedDate.getTime());
			jobFiles.setFileNames(fileNameList);
			jobFiles.setJobID(jobId);
			outputJobFiles.add(jobFiles);
			fileList.setJobFileDetails(outputJobFiles);
			lovDao.createFileInfoForDestination(fileList, destId);
		}
	}

	private String getPurgeFile(File jobDirectory, String file) {
		File f = new File(file);
		return jobDirectory.getAbsolutePath() + File.separator + f.getName();
	}

	protected List<String> addHashFile(Collection<String> files, Properties p)
			throws Exception {
		List<String> hashFiles = new ArrayList<String>();
		if (!CollectionUtilities.isEmpty(files)) {
			for (String fileName : files) {
				new File(fileName + HASH_EXT).delete();
				PdfUtils.writeHashValueToFile(fileName, fileName + HASH_EXT, p);
				hashFiles.add(fileName + HASH_EXT);
			}
		}
		return hashFiles;
	}

	protected void encryptFiles(List<String> attachmentPdfs, String password,
			String ownerPassword, Properties cryptoProperties) throws Exception {
		Iterator<String> filesIterator = attachmentPdfs.iterator();
		while (filesIterator.hasNext()) {
			String fileName = filesIterator.next();
			encryptFile(fileName, cryptoProperties, password, ownerPassword);
		}

	}

	private void encryptFile(String fileName, Properties cryptoProperties,
			String password, String ownerPassword) throws Exception {
		PdfUtils.signAndEncryptPdf(fileName, fileName + "encrypt",
				cryptoProperties, password, ownerPassword);

		FileUtils.deleteQuietly(new File(fileName));
		FileUtils.moveFile(new File(fileName + "encrypt"), new File(fileName));
	}

	protected void updateJobResults(int jobId, File jobDirectory,
			List<String> fileNames, Calendar completedDate) {
		// filenames are pointed to temporary path. need to retrieve fileName
		// w/o path
		ArrayList<String> fileNamesNoPath = new ArrayList<String>();

		for (String tmpFileName : fileNames) {
			File tmpFile = new File(tmpFileName);
			fileNamesNoPath.add(tmpFile.getName());
		}
		OutputJobFiles jobFiles = new OutputJobFiles();
		jobFiles.setCompletedDate(completedDate.getTime());
		jobFiles.setFileNames(fileNamesNoPath);
		jobFiles.setJobID(jobId);
		jobFiles.setJobDirectory(jobDirectory.getAbsolutePath());

		updateJobResults(jobId, jobFiles.getXML());
	}
}
