/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.hpf;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import com.mckesson.eig.output.local.source.Source;
import com.mckesson.eig.output.local.source.SourceListener;
import com.mckesson.eig.output.local.source.hpf.service.ContentServiceRunnable;
import com.mckesson.eig.output.local.source.hpf.service.ContentWebServiceController;
import com.mckesson.eig.output.local.source.hpf.service.ContentWebServiceExecutor;
import com.mckesson.eig.output.local.transformers.DefaultHeaderFooter;
import com.mckesson.eig.output.local.transformers.PdfPageSeparator;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.util.FileUtilities;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.OutputTransforms;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.PdfSupport;
import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.BooleanUtilities;
import com.mckesson.eig.utility.util.CollectionUtilities;

/**
 * TODO
 *
 * @author Eric Yu
 */
public class HpfSource extends Source {

	private static final Log LOG = LogFactory.getLogger(HpfSource.class);
	private static final int WORK_PER_THREAD = 10;
	private static final int WAIT_TIME = 1000;

	private HpfRequest _request = new HpfRequest();
	private String _userName;
	private String _password;
	private String _protocol;
	private String _server;
	private String _port;



	private ContentWebServiceController _controller;

	/**
	 * TODO
	 */
	public HpfSource() {
		super();
	}

	protected void processPart(JobPart part) throws Exception {
		boolean continueIfFail = part.getOutputJob().isContinueIfFail();
		if (part != null) {
			List<HpfContent> list = _request.getContent(part);
			if ((list != null) && (list.size() > 0)) {
				Iterator<HpfContent> i = list.iterator();
				int count = 1;
				ContentWebServiceExecutor executor =
					_controller.getContentWebServiceExecutor();
				while (executor == null) {
					try {
						Thread.sleep(WAIT_TIME);
					} catch (InterruptedException e) {
					}
					executor = _controller.getContentWebServiceExecutor();
				}
				try {
					while (i.hasNext()) {
						HpfContent content = i.next();
						File f = getFile(part, count);
						getContentToFile(executor, content, f, continueIfFail);
						if (f.exists()) {
							part.setNoOfPages(count);
							count++;
						} else {
							throw new OutputException(
								"Cannot retrieve content: "
								+ part.getJobID() + "-"
								+ content.getPageId()
								+ ":"
								+ content.getPageNumber(),
								OutputErrorCode.MISSING_DATA);
						}
					}
					LOG.info("processed part: " + part.getPartID());
				} finally {
					executor.setAvailable(true);
				}
			}
		}
	}
	
	protected void processPart(OutputJob job, JobPart part,
			FileUtilities f, SourceListener listener) throws Exception {
		boolean continueIfFail = job.isContinueIfFail();
		if (part != null) {
			List<HpfContent> list = _request.getContent(part);
			if ((list != null) && (list.size() > 0)) {
				ContentWebServiceExecutor executor =
					_controller.getContentWebServiceExecutor();
				while (executor == null) {
					try {
						Thread.sleep(WAIT_TIME);
					} catch (InterruptedException e) {

					}
					executor = _controller.getContentWebServiceExecutor();
				}
				try {
					if (list.size() < WORK_PER_THREAD) {
						for (HpfContent content : list) {
							File file = f.getFile();
							getContentToFile(executor, content, file, continueIfFail);
							if (!file.exists() && continueIfFail) {
								String c = getEmptyPageContentString(part, content.getPageId(), content.getPageNumber());
								addEmptyPage(file, c);
							}
							saveSourceFile(file, job, part, listener);
						}
					} else {
						List<Future<ContentServiceRunnable>> tasks =
							generateTask(executor, list, f, continueIfFail);
						while (tasks.size() > 0) {
							Future<ContentServiceRunnable> task =
								tasks.remove(0);
							saveSourceFiles(task, job,
									part, f, listener, continueIfFail);
						}
					}
				} finally {
					executor.setAvailable(true);
				}
			}
		}
	}

	private void saveSourceFiles(Future<ContentServiceRunnable> task,
			OutputJob job, JobPart part,
			FileUtilities f, SourceListener listener, boolean continueIfFail) {
		while (!task.isDone()) {
			try {
				Thread.sleep(WAIT_TIME);
			} catch (InterruptedException e){
			}
		}
		int idx = 0;
		try {
			ContentServiceRunnable c = task.get();
			List<File> files = c.getFiles();
			for (File file : files) {
				if (!file.exists() && continueIfFail) {
					String content = getEmptyPageContentString(part, c.getImnet(idx), c.getPageNumber(idx));
					addEmptyPage(file, content);
				}
				if(file.exists()) {
					saveSourceFile(file, job, part, listener);
				} else {
					throw new OutputException(
							"Cannot retrieve content: "
							+ part.getJobID() + "-"
							+ c.getImnet(idx)
							+ ":" + c.getPageNumber(idx),
							OutputErrorCode.MISSING_DATA);
				}
				idx++;
			}

		} catch (InterruptedException ie) {
			throw new OutputException(
					"Problem retrieving content: " + part.getJobID(),
					OutputErrorCode.MISSING_DATA);
		} catch (Exception e) {
			throw new OutputException(
					"Problem retrieving content: " + part.getJobID(),
					OutputErrorCode.MISSING_DATA);
		}
	}

	private List<Future<ContentServiceRunnable>> generateTask(
			ContentWebServiceExecutor executor,
			List<HpfContent> list, FileUtilities f, boolean continueIfFail) {
		List<Future<ContentServiceRunnable>> result =
			new ArrayList<Future<ContentServiceRunnable>>();
		ArrayList<String> imnets = new ArrayList<String>();
		ArrayList<String> pageNumbers = new ArrayList<String>();
		ArrayList<File> files = new ArrayList<File>();
		int idx = 0;
		for (HpfContent content : list) {
			String imnet = content.getPageId();
			imnets.add(imnet);
			String pageNumber = content.getPageNumber();
			pageNumbers.add(pageNumber);
			File file = f.getFile();
			files.add(file);
			idx++;
			if ((idx % WORK_PER_THREAD) == 0) {
				Future<ContentServiceRunnable> task =
					executor.getContents(imnets, pageNumbers, files, continueIfFail);
				result.add(task);
				imnets = new ArrayList<String>();
				pageNumbers = new ArrayList<String>();
				files = new ArrayList<File>();
			}
		}
		if (imnets.size() > 0) {
			Future<ContentServiceRunnable> task =
				executor.getContents(imnets, pageNumbers, files, continueIfFail);
			result.add(task);
		}
		return result;
	}

	private void getContentToFile(ContentWebServiceExecutor executor,
			HpfContent content, File f, boolean continueIfFail) {
		String imnet = content.getPageId();
		String pageNumber = content.getPageNumber();
		try {
			executor.getContentToFile(imnet, pageNumber, f, continueIfFail);
		} finally {
			executor.setAvailable(true);
		}
	}

	@OutputProperty(label = "User Name",
			description = "User name credential for the host for the HPF web service",
			index = "1")
	public String getUserName() {
		return _userName;
	}

	public void setUserName(String userName) {
		_userName = userName;
	}


	@OutputProperty(label = "Password",
			description = "Password credential for the host for the HPF web service",
			defaultValue = "", index = "2")

	public String getPassword() {
		return _password;
	}

	public void setPassword(String password) {
		_password = password;
	}


 	@OutputProperty(label = "Protocol",
			description = "Protocol to communicate with the HPF web service",
			defaultValue = "http",
			possibleValues = {"http", "https" }, index = "3")
	public String getProtocol() {
		return _protocol;
	}

	public void setProtocol(String protocol) {
		_protocol = protocol;
	}

	public void setServer(String serverStr) {
		_server = serverStr;
	}

	public void setPort(String portStr) {
		_port = portStr;
	}

	@OutputProperty(label = "CWS Host Name",
			description = "Name of the hosts for the CWS web service",
			defaultValue = "localhost", index = "4",
			pairPropertyName = "port")
	public String getServer() {
		return _server;
	}

	@OutputProperty(label = "Port",
			description = "TCP ports for the host for the CWS web service",
			defaultValue = "80", index = "5")
	public String getPort() {
		return _port;
	}

	protected void saveSourceFile(File file, OutputJob job, JobPart part,
			SourceListener listener) {
		if (file.exists()) {
		    String fileName = file.getAbsolutePath();
		    fileName = processWaterMark(fileName, job, part);
		    fileName = processHeaderFooter(fileName, job, part);
			notifyAddFile(job, listener, fileName);
			part.addSource(fileName);
		}
	}
	
	protected String getEmptyPageContentString(JobPart part, String imnet, String pageNumber) {
		Map<String, String> map = part.getProperties();
		String documentName = "";
		if (map != null) {
			documentName = map.get(HpfRequest.DOCNAME);
		}
		return 	documentName + "   " + imnet + "   " + pageNumber;
	}
		
	protected String processHeaderFooter(String srcFile, OutputJob job,
			JobPart part) {

		Map<String, String> map = getHeaderFooter(job, part);
		if (!CollectionUtilities.isEmpty(map)) {
			int jobTotalPages = job.getTotalPages();
			int jobPageNumber = job.getPages();
			int partPageNumber = part.getPages();
			int partTotalPages = part.getTotalPages();

			if (jobTotalPages <= 0) {
				DefaultHeaderFooter.setJobTotalPage(map, -1);
				DefaultHeaderFooter.setJobCurrentPage(map, -1);
			} else {
				DefaultHeaderFooter.setJobTotalPage(map, jobTotalPages);
				DefaultHeaderFooter.setJobCurrentPage(map, jobPageNumber + 1);
			}

			if (partTotalPages <= 0) {
				DefaultHeaderFooter.setPartTotalPage(map, -1);
				DefaultHeaderFooter.setPartCurrentPage(map, -1);
			} else {
				DefaultHeaderFooter.setPartTotalPage(map, partTotalPages);
				DefaultHeaderFooter.setPartCurrentPage(map, partPageNumber + 1);
			}

			String result = addHeaderFooter(job,srcFile, map);
			int count = PdfSupport.getPageCount(result);
			job.setPages(jobPageNumber + count);
			part.setPages(partPageNumber + count);
			return result;
		}
		return srcFile;
	}

	protected Map<String, String> getHeaderFooter(OutputJob job, JobPart part) {

		OutputTransform partTransform = OutputUtil.lookupPartTransform(part,
				OutputTransforms.HEADER_FOOTER.toString());
		if (partTransform != null) {
			return getHeaderFooter(job).getHeaderFooterProperties(getOutputManager(),
					partTransform);
		}
		OutputTransform jobtTransform = OutputUtil.lookupJobTransform(job,
				OutputTransforms.HEADER_FOOTER.toString());
		if (jobtTransform != null) {
			return getHeaderFooter(job).getHeaderFooterProperties(getOutputManager(),
					jobtTransform);
		}
		return new HashMap<String, String>();
	}


	protected String addHeaderFooter(OutputJob job, String contentPath,
			Map<String, String> properties) {
		File f = new File(contentPath);
		String fileName = f.getName();
		String path = f.getParentFile().getParent();
		String outputFile = path + File.separator
				+ HEADERFOOTER + File.separator + fileName;
		try {
			InputStream in = IOUtilities.createFileInputStream(f);
			OutputStream out = IOUtilities.createFileOutputStream(outputFile);
			getHeaderFooter(job).addHeaderFooter(in, out, properties);
			in.close();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return outputFile;
	}


	public ContentWebServiceController getController() {
		return _controller;
	}

	public void setController(ContentWebServiceController controller) {
		_controller = controller;
	}

}
