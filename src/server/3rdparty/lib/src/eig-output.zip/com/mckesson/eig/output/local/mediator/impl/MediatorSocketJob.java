package com.mckesson.eig.output.local.mediator.impl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;

import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.socket.SocketDestination;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class MediatorSocketJob extends AbstractMediatorJob {

	private static final Log LOG = LogFactory.getLogger(MediatorSocketJob.class);

	public MediatorSocketJob(OutputJob job, Destination d,
			DestTypeHandler handler) {
		super(job, d, handler);
	}

	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void addFile(String fileName) throws IOException,
			InterruptedException {
		SocketDestination destination = (SocketDestination) getDestination();
		OutputJob job = getJob();
		PrintStream ps = null;
		try {
			LOG.info("Start processJob " + job.getJobSeq());
			Socket sock = new Socket(destination.getHost(),
					Integer.parseInt(destination.getPort()));
			ps = new PrintStream(sock.getOutputStream());
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			StringBuilder strLabelIPL = new StringBuilder();
			String strTemp;

			while ((strTemp = in.readLine()) != null) {
				strLabelIPL.append(strTemp);
			}
			ps.println(strLabelIPL.toString());
			LOG.info("End processJob " + job.getJobSeq());
		} catch (Exception e) {
			updateStatus(job.getJobSeq(), RequestStatus.ERROR, "Save to Socket error");
			throw new ApplicationException(e);
		} finally {
			if (ps != null) {
				ps.close();
			}
		}
	}

	public String getName() {
		return null;
	}

	public void initializeJob(Object listener) {
	}

	public void doneWithJob() throws IOException, InterruptedException {
		//update status
		OutputJob job = getJob();
		updateStatus(job.getJobSeq(), RequestStatus.COMPLETED, OutputConstants.MSG_SOCKET_COMPLETED);
	}
}
