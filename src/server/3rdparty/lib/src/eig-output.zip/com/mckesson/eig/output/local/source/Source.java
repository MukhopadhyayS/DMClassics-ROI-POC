package com.mckesson.eig.output.local.source;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.local.BaseComponent;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.OutputPartEndpoint;
import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.local.transformers.DefaultHeaderFooter;
import com.mckesson.eig.output.local.transformers.PdfPageSeparator;
import com.mckesson.eig.output.local.transformers.WatermarkProcessor;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.service.OutputBaseService.DAOName;
import com.mckesson.eig.output.util.FileUtilities;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.OutputTransforms;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.SpringUtilities;
import com.mckesson.eig.utility.util.StringUtilities;

public abstract class Source extends BaseComponent implements
		OutputPartEndpoint {

	private static final Log LOG = LogFactory.getLogger(Source.class);
	private StatusInfo _statusInfo = StatusUtils.createEndpointStatus(
			EndpointStatus.OK, StringUtils.EMPTY);

	private DefaultHeaderFooter _headerFooter;
	private OutputManager _outputManager;

	private static final String WATERMARK = "WATERMARK";
	protected static final String HEADERFOOTER = "HEADERFOOTER";

	private static final int FIVE_HUNDRED = 500;
	private static final int TEWNTY = 20;
	
	private static final String APP_HEADER_FOOTER_CLASS_PREFIX = "com.mckesson.eig.output.local.transformers.";
	private static final String APP_HEADER_FOOTER_CLASS_SUFFIX = "HeaderFooter";


	public Source() {
		super();
	}

	protected abstract void processPart(JobPart part) throws Exception;

	protected abstract void processPart(OutputJob job, JobPart part,
			FileUtilities f, SourceListener listener) throws Exception;

	/**
	 * @see OutputPartEndpoint#processJobParts(OutputJob, Collection)
	 */
	public void processJobParts(OutputJob job, Collection<JobPart> jobParts) {

		int currPartNo = 0;

		if (job == null) {
			throw new IllegalArgumentException("job argument is null");
		}
		if (jobParts == null) {
			throw new IllegalArgumentException("jobParts argument is null");
		}

		int counter = 0;
		if (jobParts.size() > FIVE_HUNDRED) {
			counter = jobParts.size() / TEWNTY;
		}

		OutputJobDAO outputJobDAO = (OutputJobDAO) SpringUtilities
				.getInstance().getBeanFactory().getBean(
						DAOName.Output_JOB_DAO.toString());

		int index = 0;

		try {
			for (JobPart jobPart : jobParts) {
				index++;

				if ((counter != 0) && (index == counter)) {

					if (checkJobStatus(outputJobDAO, job.getJobSeq())) {
						break;
					}
					index = 0;
				}

				currPartNo = jobPart.getPartID();
				processPart(jobPart);
			}
		} catch (Exception ex) {
			_statusInfo = StatusUtils.createEndpointStatus(
					EndpointStatus.ERR_UNKNOWN, ex.getMessage());
			LOG.error("error processing job: " + job.getJobSeq(), ex);

			throw new OutputException("error processing job: "
					+ job.getJobSeq() + " part: " + currPartNo,
					OutputErrorCode.RUNTIME_ERROR);
		}

		_statusInfo = StatusUtils.createEndpointStatus(EndpointStatus.OK,
				"processed job: " + job.getJobSeq());
	}

	private boolean checkJobStatus(OutputJobDAO dao, int jobId) {
		int status = dao.fetchJobStatus(jobId);

		return ((status == RequestStatus.PAUSING.statusCode())
				|| (status == RequestStatus.CANCELING.statusCode()))
				? true : false;
	}

	public StatusInfo queryEndpointStatus() {
		// TODO this could be more advanced like ping to query the remote
		// server, for now we will just return the status from the last call
		// we made
		return _statusInfo;
	}

	/**
	 * TODO
	 *
	 * @param part
	 * @param bytes
	 * @param i
	 */
	public void saveFile(JobPart part, byte[] bytes, int i) {
		File f = getFile(part, i);
		IOUtilities.write(f, bytes);
	}

	/**
	 * TODO
	 *
	 * @param part
	 * @param i
	 * @return
	 */
	public File getFile(JobPart part, int i) {
		String location = part.getCurrentLocation();
		File dir = new File(location);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		String file = getFileName(i);
		part.addSource(file);
		return new File(dir + "/" + file);
	}
	
	/**
	 * TODO
	 *
	 * @param part
	 * @param i
	 * @return
	 */
	public File getAttachment(JobPart part, int i) {
		String location = part.getCurrentLocation();
		File dir = new File(location);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		String file = String.valueOf(i);
		part.addAttachment(file);
		return new File(dir + "/" + file);
	}	

	/**
	 * TODO
	 *
	 * @param i
	 * @return
	 */
	public String getFileName(int i) {
		return i + ".pdf";
	}

	protected void addEmptyPage(File f, String content) {
        PdfPageSeparator pgSeparator = new PdfPageSeparator();
        pgSeparator.addPageSeparator(f.getAbsolutePath(), content);
	}
	
	protected String processWaterMark(String contentPath,
			OutputJob job, JobPart part) {
		String watermark = getWarkMark(job, part);
		if (StringUtilities.isEmpty(watermark)) {
			return contentPath;
		}
		return addWaterMark(contentPath, watermark);
	}

	protected String addWaterMark(String contentPath, String watermark) {
		File f = new File(contentPath);
		String fileName = f.getName();
		String path = f.getParentFile().getParent();
		String outputFile = path + File.separator + WATERMARK + File.separator + fileName;
		try {
			InputStream in = IOUtilities.createFileInputStream(f);
			OutputStream out = IOUtilities.createFileOutputStream(outputFile);
			new WatermarkProcessor().addWaterMark(in, out, watermark);
			in.close();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return outputFile;
	}

	protected String getWarkMark(OutputJob job, JobPart part) {
		OutputTransform transform = OutputUtil.lookupPartTransform(part,
				OutputTransforms.WATERMARK.toString());
		if (transform != null) {
			String watermark = transform.getProperties().get(
					OutputTransforms.WATERMARK.toString());
			if (StringUtilities.isEmpty(watermark)) {
				return watermark;
			}
		}
		transform = OutputUtil.lookupJobTransform(job,
				OutputTransforms.WATERMARK.toString());
		if (transform != null) {
			String watermark = transform.getProperties().get(
					OutputTransforms.WATERMARK.toString());
			if (!StringUtilities.isEmpty(watermark)) {
				return watermark;
			}
		}
		return null;
	}

	public DefaultHeaderFooter getHeaderFooter(OutputJob job) {
		/*
		 * HPF 15.2 - allow header/footer class to be set by application id. 
		 * if application class is not found use default
		 * 
		 * application class name is found using APP_ID + "HeaderFooter" - 
		 * APP_ID must be uppercase ex. ROIHeaderFooter
		 */
			
		//
		DefaultHeaderFooter headerFooter = _headerFooter;
		
		String appId = job.getSubmitInfo().getApplication();
		if (appId != null) {
			try {
				DefaultHeaderFooter appHeaderFooter = (DefaultHeaderFooter)
				Class.forName(APP_HEADER_FOOTER_CLASS_PREFIX 
						      + appId.toUpperCase() 
						      + APP_HEADER_FOOTER_CLASS_SUFFIX).newInstance();	
				headerFooter = appHeaderFooter;
			} catch (Exception e) {
				LOG.debug("application does not have a HeaderFooter specification.  Using default");
			}
	    }
		return headerFooter;
	}

	public void setHeaderFooter(DefaultHeaderFooter headerFooter) {
		_headerFooter = headerFooter;
	}

	public OutputManager getOutputManager() {
		return _outputManager;
	}

	public void setOutputManager(OutputManager outputManager) {
		_outputManager = outputManager;
	}

	public void notifyAddFile(OutputJob job, SourceListener listener, String path) {
		if (listener != null) {
			listener.addFile(job, path);
		}
	}

	public void notifyError(OutputJob job, SourceListener listener, String errorMessage) {
		if (listener != null) {
			listener.error(job, errorMessage);
		}
	}

	protected String processHeaderFooter(String srcFile, OutputJob job,
			JobPart part) {
		return srcFile;
	}

	protected void saveSourceFile(File file, OutputJob job, JobPart part,
			SourceListener listener) {
	    String fileName = file.getAbsolutePath();
	    fileName = processWaterMark(fileName, job, part);
	    fileName = processHeaderFooter(fileName, job, part);
		notifyAddFile(job, listener, fileName);
		part.addSource(fileName);
	}


	protected void saveAttachmentFile(File file, OutputJob job, JobPart part,
			SourceListener listener) {
	    String fileName = file.getAbsolutePath();
		notifyAddFile(job, listener, fileName);
		part.addAttachment(fileName);
	}

    /**
     * @see com.mckesson.eig.output.local.OutputEndpoint#queryEndpointStatus()
     */
    public StatusInfo queryEndpointStatus(boolean validEndPoint) {
		return queryEndpointStatus();
	}
}
