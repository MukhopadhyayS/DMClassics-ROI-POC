/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * Author: Latonia
 */

package com.mckesson.eig.output.local.transformers;


import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.OutputTransform;
import com.mckesson.eig.output.util.LocationSupport;
import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputUtil;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputConstants.OutputTransforms;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;


public class PdfWatermarkPart
extends PdfPartTransforms {

    private static final Log LOG = LogFactory.getLogger(PdfWatermarkPart.class);
	private static final int FIVE_HUNDRED = 500;
	private static final int TEWNTY = 20;

    public PdfWatermarkPart() {

        super();
    }

    public void transform(String sourceFile, String destinationFile, String watermark) {

        PdfWatermark pdfWatermark = new PdfWatermark();
        pdfWatermark.addWatermark(watermark, sourceFile, destinationFile);
    }

    //processes Part water mark Transformation
    @Override
    public void processJobParts(OutputJob job, Collection <JobPart> jobParts) {

        int counter = 0;
        List<JobPart> parts = job.getParts();

        if (parts.size() > FIVE_HUNDRED) {
            counter = parts.size() / TEWNTY;
        }

        OutputJobDAO outputJobDAO = getOutputJobDAO();
        int index   = 0;

        try {
            for (JobPart part : parts) {
                index++;

                if ((counter != 0) && (index == counter)) {

                    if (checkJobStatus(outputJobDAO, job.getJobSeq())) {
                        break;
                    }
                    index = 0;
                }
                processPart(part);
            }
        } catch (Exception e) {
            throw new OutputException("Error: " + e.toString()
                                      + "  processing "
                                      + job.getJobSeq(),
                                      OutputErrorCode.RUNTIME_ERROR);
        }
    }

    public void processPart(JobPart part) {

        if (part == null) {
            throw new IllegalArgumentException("part argument is null");
        }

        OutputTransform transform =
        OutputUtil.lookupPartTransform(part, OutputTransforms.WATERMARK.toString());

        //Set destination directory and clear existing only if work to be done
        if (part.getSources().size()  > 0) {
            LocationSupport.setNextLocation(part, OutputTransforms.WATERMARK.toString());
            LocationSupport.cleanNextLocation(part);               	 
        }
        Iterator <String> filesIterator = part.getSourcesIterator();
        while (filesIterator.hasNext()) {
            String fileName = filesIterator.next();
            String srcFileName = part.getCurrentLocation() + File.separatorChar + fileName;
            String destFileName = part.getNextLocation() + File.separatorChar + fileName;
            transform(srcFileName, destFileName, transform.getProperties()
            .get(OutputTransforms.WATERMARK.toString()));
            LocationSupport.setNextLocationAsCurrentLocation(part);
        }
        //Set current directory only if work to be done
        if (part.getSources().size()  > 0) {
       	 LocationSupport.setNextLocationAsCurrentLocation(part);       	 
        }

        LOG.info("Watermark transform completed for part: " + part.getPartID());
    }
}
