/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/


package com.mckesson.eig.output.local.disc;

import java.io.File;
import java.io.FilenameFilter;

import com.mckesson.eig.output.util.OutputException;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;

/**
 * This class is used to filter the set of files based on the extension
 * The extension argument which is sent should be a valid string, 
 * if it extension is null or empty, instance creation would throw Exception
 *
 * This fileName filter is  Extension is case insensitive by default, 
 * we can change it to caseSensitive using <code>setCaseSensitive(true)</code>
 *  
 * The sample to use the fileNmaeExtension filter is as below
 * 
 * <code>File file = new File(".");
 * FileNameExtensionFilter fileNameExtensionFilter = new FileNameExtensionFilter("BTW");
 * fileNameExtensionFilter.setCaseSensitive(true);
 * File[] files = file.listFiles(fileNameExtensionFilter); </code>
 * 
 * The returned files contains contains only the files with extensoin BTW.
 * 
 * @author Karthik, Easwaran (OFS)
 * @date Aug 29, 2013
 * @since Aug 29, 2013
 *
 */
public class DiscLabelTemplateFilter 
implements FilenameFilter {

	private String _extension = "";
	private boolean _caseSensitive = false;
	
	/**
	 * constructor which takes the extension as the input argument
	 * if the argument is null or empty, 
	 * it would throw OutputException with the error code <code>INVALID_EXTENSION</code>
	 * 
	 * @param extension
	 */
	public DiscLabelTemplateFilter(String extension) {
		setExtension(extension);
	}

	/**
	 * constructor which takes the extension as the input argument
	 * if the argument is null or empty, 
	 * it would throw OutputException with the error code <code>INVALID_EXTENSION</code>
	 * 
	 * @param extension
	 */
	public DiscLabelTemplateFilter(String extension, boolean caseSensitive) {
		setExtension(extension);
	}
	
	public String getExtension() { return _extension; }
	public void setExtension(String extension) {
		
		if (extension == null 
				|| "".equals(extension)) {
			
			throw new OutputException("Argument to the extension Filter should not be Empty", 
									  OutputErrorCode.INVALID_EXTENSION);
		}
		
		if (_caseSensitive) {
			_extension = extension; 
		} else {
			_extension = extension.toUpperCase(); 
		}
	}
	
	public boolean isCaseSensitive() { return _caseSensitive; }
	public void setCaseSensitive(boolean caseSensitive) { _caseSensitive = caseSensitive; }

	/**
	 * 
	 * @see java.io.FilenameFilter#accept(java.io.File, java.lang.String)
	 */
	@Override
	public boolean accept(File dir, String name) {
		
		if (name == null) {
			return false;
		}
		
		if (!_caseSensitive) {
			name = name.toUpperCase();
		}
		
		return name.endsWith(getExtension());
	}

}
