package com.mckesson.eig.output.local.printer.impl;

import java.io.IOException;

import com.mckesson.eig.utility.metric.Metric;

public interface Converter {

    String getConvertType();

    void convert(String inputFileName, String outputFileName,
            String targetName, String flavor, boolean reversOrder, Metric metric)
            throws IOException,
            InterruptedException;
}
