package com.mckesson.eig.output.util;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.RenderedImage;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;
import com.sun.pdfview.PDFFile;
import com.sun.pdfview.PDFPage;
import com.sun.pdfview.PDFRenderer;
import com.sun.pdfview.RefImage;

public class PDFToImage implements Runnable {
    /* Verified for TIFF and PNG formats only */

	private static final int STANDARD_SCREEN_DPI = 72;
	public static final String PORTRAIT = "PORTRAIT";
	public static final String LANDSCAPE = "LANDSCAPE";
	private static final int LETTER_WIDTH = 612;
	private static final int LETTER_HEIGHT = 792;

	private static final Log LOG = LogFactory.getLogger(PDFToImage.class);


 	private String _currDirectory;
	private String _nextDirectory;
	private List _fileList;
    private String _imageFormat;
    private int _resolution;
    private PageFormat _portraitPF;
    private int _imageColor;
    private ImageWriter _imageWriter;
    private ImageWriteParam _writerParams;
	private ArrayList<String> _generatedFiles = new ArrayList<String>();
	private boolean _isFinished = false;
	private boolean _isError = false;


	   @SuppressWarnings("unchecked")
	   public PDFToImage(String currDirectory,
	                     String nextDirectory,
	                     List fileList,
	                     String imageFormat,
	                     int resolution,
	                     int imageColor,
	                     PageFormat pf) {
	       _currDirectory = currDirectory;
	       _nextDirectory = nextDirectory;
	       _fileList = fileList;
	       _imageFormat = imageFormat;
	       _resolution = resolution;
	       _imageColor = imageColor;
	       initWriter();
	    }


	@SuppressWarnings("unchecked")
	private void initWriter() {
        //pdfs are pre-rotated for landscape printing
	    //so we should always use portrait page format to generate images
		_portraitPF = new PageFormat();
		Paper paper = new Paper();

		_portraitPF.setOrientation(PageFormat.PORTRAIT);
		paper.setSize(LETTER_WIDTH, LETTER_HEIGHT);
		paper.setImageableArea(0, 0, LETTER_WIDTH, LETTER_HEIGHT);
		_portraitPF.setPaper(paper);

        /*generated image files will concatenate number+extension*/
		Iterator writerIter = ImageIO.getImageWritersByFormatName(_imageFormat
				.toUpperCase());
		if (writerIter.hasNext()) {
			_imageWriter = (ImageWriter) writerIter.next();
			_writerParams = _imageWriter.getDefaultWriteParam();
			if (_writerParams.canWriteCompressed()) {
				_writerParams.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
				_writerParams.setCompressionType("LZW");
				_writerParams.setCompressionQuality(1.0f);
			}
		} else {
			throw new OutputException(
					"Cannot generate an image writer for image type: "
							+ _imageFormat,
					OutputConstants.OutputErrorCode.RUNTIME_ERROR);
		}
	}

	public boolean isError() {
		return _isError;
	}

	public boolean isFinished() {
		return _isFinished;
	}

	public ArrayList<String> getGeneratedFiles() {
		return _generatedFiles;
	}

	public void run() {
		_isFinished = false;
		_isError = false;
		if (!CollectionUtilities.isEmpty(_fileList)) {
			Iterator j = _fileList.iterator();
			while (j.hasNext() && !_isError) {
				String fileName = (String) j.next();
				String pdfFile = _currDirectory + File.separatorChar + fileName;

				File file = new File(pdfFile);
				RandomAccessFile raf;
				LOG.info("Start conversion of : " + pdfFile + " to image");
				try {
					raf = new RandomAccessFile(file, "r");
					FileChannel channel = raf.getChannel();
					ByteBuffer buf = channel.map(FileChannel.MapMode.READ_ONLY,
							0, channel.size());
					PDFFile pdffile = new PDFFile(buf);

					// write pages of pdfFile to separate image files
					int num = pdffile.getNumPages();
		            for (int i = 1; i <= num; i++) {
		                PDFPage page = pdffile.getPage(i);

		                RenderedImage img = getImage(page);
		                ImageOutputStream output = null;
		                /*generated image files will concatenate number+extension*/
		                String generatedImageFileName = fileName + i + "." + _imageFormat;
		                String tmpImageFileName = _nextDirectory + File.separatorChar
		                                         + generatedImageFileName;
		                output = ImageIO.createImageOutputStream(
		                			new File(tmpImageFileName));
		                _imageWriter.setOutput(output);
		                _imageWriter.write(null, new IIOImage(img, null, null),
		                					_writerParams);
		                _generatedFiles.add(generatedImageFileName);
		                img = null;
						if (output != null) {
							try {
								output.close();
							} catch (Exception e) {
							}
						}
					}
					buf.clear();
					if (raf != null) {
						try {
							raf.close();
						} catch (Exception e) {
						}
					}

					LOG.info("Converted: " + pdfFile + " to image");
				} catch (FileNotFoundException e1) {
					_isError = true;
					LOG.error(e1.toString());
					throw new OutputException(e1.toString(),
						OutputConstants.OutputErrorCode.RUNTIME_ERROR);
				} catch (IOException e) {
					_isError = true;
					LOG.error(e.toString());
					throw new OutputException(e.toString(),
						OutputConstants.OutputErrorCode.RUNTIME_ERROR);
				}
			}
		}
		_isFinished = true;
	}

	public RenderedImage getImage(PDFPage page) {
		// get the width and height for the doc at the default zoom
		int width = (int) page.getBBox().getWidth();
		int height = (int) page.getBBox().getHeight();

		RenderedImage rtnImg = null;
		try {

			int imgWidth = (int) (((float) width / STANDARD_SCREEN_DPI) * _resolution);
			int imgHeight = (int) (((float) height / STANDARD_SCREEN_DPI)
								* _resolution);
			rtnImg = new RefImage(imgWidth, imgHeight, _imageColor);
			Graphics2D graphicImg = ((RefImage) rtnImg).createGraphics();
			printImg(graphicImg, page, imgWidth, imgHeight);
			graphicImg.dispose();
			graphicImg = null;
			return rtnImg;
		} catch (Exception e) {
            throw new OutputException(e.toString(),
                                      OutputConstants.OutputErrorCode.RUNTIME_ERROR);
        }
	}

    // from Printable interface:  prints a single page, given a Graphics
    // to draw into, the page format, and the page number.
    public void printImg(Graphics g,
                                PDFPage page,
                                double imgWidth,
                                double imgHeight) throws PrinterException {

        // fit the PDFPage into the printing area
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, (int) imgWidth, (int) imgHeight);

        double aspect = page.getAspectRatio();
        double paperaspect =  _portraitPF.getWidth() /  _portraitPF.getHeight();

        Rectangle imgbounds;
        if (aspect == paperaspect) {
            imgbounds = new Rectangle(0, 0, (int) imgWidth, (int) imgHeight);
        } else if (aspect > paperaspect) {
            // paper is too tall / pdfpage is too wide
            int height = (int) (imgWidth / aspect);
            imgbounds =
                new Rectangle((int) _portraitPF.getImageableX(),
                              (int) (_portraitPF.getImageableY() + ((imgHeight - height) / 2)),
                              (int) imgWidth,
                              height);
        } else {
            // paper is too wide / pdfpage is too tall
            int width = (int) (imgHeight * aspect);
            imgbounds =
                new Rectangle((int) (((imgWidth - width) / 2)),
                              (int) _portraitPF.getImageableY(),
                              width,
                              (int) imgHeight);
        }
        // render the page
        PDFRenderer pgs = new PDFRenderer(page, g2, imgbounds, null, null);
        try {
            page.waitForFinish();
            pgs.run();
        } catch (InterruptedException ie) {
            throw new OutputException(ie.toString(),
            		OutputConstants.OutputErrorCode.RUNTIME_ERROR);
        } finally {
            g2.dispose();
            g2 = null;
            pgs.cleanup();
            pgs = null;
        }
    }

}
