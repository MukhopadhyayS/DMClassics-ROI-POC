package com.mckesson.eig.output.local.source.filepath;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.io.FileUtils;

import com.mckesson.eig.output.local.source.Source;
import com.mckesson.eig.output.local.source.SourceListener;
import com.mckesson.eig.output.model.JobPart;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.RequestPart;
import com.mckesson.eig.output.util.FileUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class FileSource extends Source {
	private static final Log LOG = LogFactory.getLogger(FileSource.class);
	public static final String FILE_PATHS = "FILEPATHS";

	/**
	 * TODO
	 */
	public FileSource() {
		super();
	}

	protected void processPart(JobPart part) throws Exception {
		if (part != null) {
			List<String> contents = parsePart(part);
			int count = 1;
			for (String content : contents) {
				File sourceFile = new File(content);
				File destFile = getFile(part, count);
				FileUtils.copyFile(sourceFile, destFile, true);
				count++;
			}
			LOG.info("processed part: " + part.getPartID());
		}
	}

	protected void processPart(OutputJob job, JobPart part,
			FileUtilities f, SourceListener listener) throws Exception {
		List<String> contents = parsePart(part);
		for (String content : contents) {
			File sourceFile = new File(content);
			File destFile = f.getFile();
			FileUtils.copyFile(sourceFile, destFile, true);
			saveSourceFile(destFile, job, part, listener);
		}
	}

	private List<String> parsePart(RequestPart part) {
		Map<String, String> map = part.getProperties();
		if (map != null) {
			return getListFromStr(map.get(FILE_PATHS));
		}
		return new ArrayList<String>();
	}

	private List<String> getListFromStr(String str) {
		List<String> result = new ArrayList<String>();
		if (str != null) {
			StringTokenizer st = new StringTokenizer(str, ",");
			while (st.hasMoreTokens()) {
				result.add(st.nextToken());
			}
		}
		return result;
	}
}
