/*
 * Copyright 2011 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.util;

import java.io.IOException;

import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfAnnotation;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfFileSpecification;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPCellEvent;
import com.lowagie.text.pdf.PdfWriter;

public class FileAttachmentEvent implements PdfPCellEvent {

    private static final int FIVE = 5;
    private static final int FIFTEEN = 15;
    private static final int TWENTY = 20;
    /** The PdfWriter to which the file has to be attached. */
    private PdfWriter _writer;
    /** The file specification that will be used to create an annotation. */
    private PdfFileSpecification _fs;
    /** The description that comes with the annotation. */
    private String _description;

    /**
     * Creates a FileAttachmentEvent.
     * 
     * @param writer
     *            the writer to which the file attachment has to be added.
     * @param fs
     *            the file specification.
     * @param description
     *            a description for the file attachment.
     */
    public FileAttachmentEvent(PdfWriter writer, PdfFileSpecification fs,
	    String description) {
	this._writer = writer;
	this._fs = fs;
	this._description = description;
    }

    /**
     * Implementation of the cellLayout method.
     * 
     * @see com.itextpdf.text.pdf.PdfPCellEvent#cellLayout(com.itextpdf.text.pdf.PdfPCell,
     *      com.itextpdf.text.Rectangle, com.itextpdf.text.pdf.PdfContentByte[])
     */
    public void cellLayout(PdfPCell cell, Rectangle position,
	    PdfContentByte[] canvases) {
	try {
	    PdfAnnotation annotation = PdfAnnotation.createFileAttachment(
		    _writer,
		    new Rectangle(position.getLeft() - TWENTY,
			    position.getTop() - FIFTEEN, position.getLeft() - FIVE,
 position.getTop() - FIVE),
		    _description, _fs);
	    annotation.setName(_description);
	    _writer.addAnnotation(annotation);
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }
}
