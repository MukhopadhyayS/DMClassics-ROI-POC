package com.mckesson.eig.output.local.mediator.impl;

import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants.OutputErrorCode;
import com.mckesson.eig.output.util.OutputException;

public class MediatorInterFaxJob extends MediatorFaxJob {
	
    public MediatorInterFaxJob(OutputJob job, Destination d, DestTypeHandler handler) {
		super(job, d, handler);
    }

	public void initializeJob(Object listener) {
		throw new OutputException("MediatorInterFaxJob is not implemented.", 
				OutputErrorCode.GENERAL_APP_ERROR);

	}
}
