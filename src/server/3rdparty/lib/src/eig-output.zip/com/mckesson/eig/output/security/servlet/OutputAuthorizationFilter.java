/*
 * Copyright 2009 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.security.servlet;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.mckesson.eig.output.security.authorization.OutputACL;
import com.mckesson.eig.output.security.authorization.OutputAuthorizationStrategy;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.util.SpringUtilities;
import com.mckesson.eig.utility.util.StringUtilities;
import com.mckesson.eig.wsfw.session.WsSession;

/**
 * @author Pranav Amarasekaran
 * @date   Jul 6, 2009
 * @since  Output 1.0; Jul 6, 2009
 *
 * This authorization filter class is used to set the OutputACL for the current
 * logged in user to the session.
 */
public class OutputAuthorizationFilter 
implements Filter {
	
	private static final String AUTHORIZE_KEY_DEL = ".";
    private static final String KEY_AUTHORIZER = "authorizer";
	
	public OutputAuthorizationFilter() {
		super();
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		
		OutputAuthorizationStrategy strategy = getAuthorizationStrategy();
    	OutputACL acl = ((OutputACL) WsSession.getSessionData(OutputACL.OUTPUT_ACL_KEY));
    	
    	if (acl == null) {
    		strategy.initializeOutputACL();
    	}
    	
    	chain.doFilter(request, response);
	}
	
    protected OutputAuthorizationStrategy getAuthorizationStrategy() {

        String appID = (String) WsSession.getSessionData(WsSession.APP_ID);
        if (StringUtilities.hasContent(appID)) {
            return (OutputAuthorizationStrategy)
                    SpringUtilities.getInstance()
                                   .getBeanFactory()
                                   .getBean(KEY_AUTHORIZER + AUTHORIZE_KEY_DEL + appID);
        }
        throw new ApplicationException("Unable to find the authorization service provider for key "
                                       + "'" + KEY_AUTHORIZER + AUTHORIZE_KEY_DEL + appID + "'");
    }	

	public void init(FilterConfig config) throws ServletException {	
	}
	
	public void destroy() {
	}	
}
