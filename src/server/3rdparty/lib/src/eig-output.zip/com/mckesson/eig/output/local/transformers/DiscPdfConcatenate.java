/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.transformers;

import java.util.ArrayList;
import java.util.List;

import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;

public class DiscPdfConcatenate extends ROIPdfConcatenate {

	private static String DISC_DIR = "DISC_CONCAT";
	private static final Log LOG = LogFactory.getLogger(DiscPdfConcatenate.class);

	public DiscPdfConcatenate() {
		super();
	}

	public List<String> concatenate(OutputJob job, long size) {
	    LOG.info("Generating disc files, job Id: "  + ( job==null ? "Job is null": job.getJobSeq()));
		List<String> allDocs = super.concatenate(job, size);
		return generateDiscFile(job, allDocs, size);
	}

	private List<String> generateDiscFile(OutputJob job, List<String> pdfs, long size)	{
		String location = getTempDirectory(job, DISC_DIR);
		String baseFileName = _nameStrategy.createJobCollectionName(job);
		List<String> result = addFilesToPdfAsDiscContainer(location, baseFileName, pdfs, size, true);
		return result;
	}

	protected List<String> addFilesToPdfAsDiscContainer(String location, String targetFileName, 
			List<String> src, long maxSize, boolean generateHash) {
		List<List<String>> list = divideFileBySize(src, maxSize);
		if (CollectionUtilities.isEmpty(list)) {
			return null;
		}
		List<String> result = new ArrayList<String>();
		int totalNumber = list.size();
		int part = 1;
		for (List<String> files : list) {
			String fileName = _nameStrategy.generateFileNameWithDiscNumberTotalNumber(targetFileName, part, totalNumber);
			String destFile = location + fileName + PDF_EXT;
			createPdfCollection(files, destFile, generateHash);
			result.add(destFile);
			part ++;
		}
		return result;
	}
	
}
