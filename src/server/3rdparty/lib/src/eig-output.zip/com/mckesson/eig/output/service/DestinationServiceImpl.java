/*
 * Copyright 2008-2010 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
package com.mckesson.eig.output.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jws.WebService;

import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.EndpointManager;
import com.mckesson.eig.output.local.EndpointTypeHandler;
import com.mckesson.eig.output.local.device.disc.DiscLabelStrategy;
import com.mckesson.eig.output.local.model.ActiveEndpoint;
import com.mckesson.eig.output.local.model.ActiveEndpointType;
import com.mckesson.eig.output.local.printer.PrintTypeHandler;
import com.mckesson.eig.output.local.source.hpf.service.ContentWebServiceController;
import com.mckesson.eig.output.model.DestDef;
import com.mckesson.eig.output.model.DestInfo;
import com.mckesson.eig.output.model.DestInfoList;
import com.mckesson.eig.output.model.DestTypeInfo;
import com.mckesson.eig.output.model.DestTypeInfoList;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.DeviceInfoList;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.EndpointTypeDef;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.util.MapModel;
import com.mckesson.eig.output.util.MapModelList;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.DeviceType;
import com.mckesson.eig.output.util.OutputConstants.EndpointCategory;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputPropertyMap;
import com.mckesson.eig.output.util.PropertySupport;
import com.mckesson.eig.output.util.StringList;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.util.SpringUtilities;

/**
 * @author OFS
 * @author Jon Anderson
 */

/* TODO
 * Destination Service should be separated for services that support destinations versus sources, devices, etc.
 */

@WebService(name = "DestinationPortType_v1_0", portName = "Destination_v1_0", serviceName = "DestinationService_v1_0", targetNamespace = "http://eig.mckesson.com/wsdl/destination-v1", endpointInterface = "com.mckesson.eig.output.service.DestinationService")
public class DestinationServiceImpl implements DestinationService {

	private EndpointManager _endpointManager;

	private static String HPF_CONTENT_CONTROLLER_BEAN = "hpfContentController";

	/**
	 * TODO
	 * 
	 * @param endpointManager
	 */

	public DestinationServiceImpl(EndpointManager endpointManager) {

		if (endpointManager == null) {
			throw new IllegalArgumentException(
					"endpointManager argument is null");

		}
		_endpointManager = endpointManager;
	}

	public DestinationServiceImpl() {

	}

	/**
	 * @throws Exception
	 * @see DestinationService#defineDestination(com.mckesson.eig.output.model.DestDef)
	 */
	public DestInfo defineDestination(DestDef destDef) throws Exception {

		if (destDef == null) {
			throw new IllegalArgumentException("destDef argument is null");
		}

		destDef.setCreatorType(OutputConstants.QUEUE_CREATOR_USER);
		return createDestInfo(destDef);
	}

	/**
	 * @throws Exception
	 * @see DestinationService#defineSsytemDestination(com.mckesson.eig.output.model.DestDef)
	 */
	public DestInfo defineSystemDestination(DestDef destDef) throws Exception {

		if (destDef == null) {
			throw new IllegalArgumentException("destDef argument is null");
		}
		//To maintain consistency with Output Configuration Settings we
		//create a DestInfo object : output configuration settings 
		//passes in a DestInfo object versus Dest Def
		
		DestInfo destInfo = mapSystemDestDefToDestInfo(destDef);
		destInfo.setCreatorType(OutputConstants.QUEUE_CREATOR_SYSTEM);
		return createDestInfo(destInfo);
	}	
	
	private DestInfo createDestInfo(DestDef destDef)  throws Exception  {
		if (destDef == null) {
			throw new IllegalArgumentException("destDef argument is null");
		}

		ActiveEndpoint endpoint = _endpointManager
				.createActiveEndpoint(destDef);
		return createDestInfo(endpoint);	
	}
	
	public DestInfo updateDestination(DestDef destDef) {
		if (destDef == null) {
			throw new IllegalArgumentException("destDef argument is null");
		}

		destDef.setCreatorType(OutputConstants.QUEUE_CREATOR_USER);
		return updateDestInfo(destDef);
	}
	
	public DestInfo updateSystemDestination(DestDef destDef) {
		if (destDef == null) {
			throw new IllegalArgumentException("destDef argument is null");
		}

		destDef.setCreatorType(OutputConstants.QUEUE_CREATOR_SYSTEM);
		return updateDestInfo(destDef);
	}
	
	private DestInfo updateDestInfo(DestDef destDef) {
		
		ActiveEndpoint endpoint = _endpointManager.updateEndpointDef(destDef);
		refreshHPFSource(destDef);
		return createDestInfo(endpoint);		
	}

	private ContentWebServiceController getHpfContentController() {
		try {
			ContentWebServiceController controller = (ContentWebServiceController) SpringUtilities
					.getInstance().getBeanFactory()
					.getBean(HPF_CONTENT_CONTROLLER_BEAN);
			return controller;
		} catch (Exception e) {
			return null;
		}
	}

	private void refreshHPFSource(DestDef destDef) {
	}

	private DestInfo mapSystemDestDefToDestInfo(DestDef destDef) {
		DestInfo info = null;
		if (destDef != null) {
			String destName = destDef.getName();
			info = new DestInfo();
			info.setName(destDef.getName());
			info.setDescription(destDef.getDescription());
			info.setType(destDef.getType());
			info.setId(destDef.getId());
			info.setTypeId(destDef.getTypeId());
			info.setCreatorType(destDef.getCreatorType());
			info.setProperties(destDef.getProperties());
			info.setStatusInfo(StatusUtils.createEndpointStatus(EndpointStatus.OK, null));
		}
		return info;
	}
	
	
	private DestInfo createDestInfo(ActiveEndpoint activeEndpoint) {
		DestInfo info = null;
		if (activeEndpoint != null) {
			EndpointDef endpointDef = activeEndpoint.getEndpointDef();
			String destName = endpointDef.getName();
			info = new DestInfo();
			info.setName(destName);
			info.setDescription(endpointDef.getDescription());
			info.setType(endpointDef.getType());
			info.setId(endpointDef.getId());
			info.setTypeId(endpointDef.getTypeId());
			info.setCreatorType(endpointDef.getCreatorType());

			OutputPropertyMap propertyMap = activeEndpoint.getProperties();
			info.setProperties(propertyMap.getAsStrings());

			PropertyDef[] propertyDefs = propertyMap.getPropertyDefs();
			if (propertyDefs == null) {
				propertyDefs = PropertySupport.EMPTY_PROPERTY_DEFS;
			}

			info.setPropertyDefs(propertyDefs);
			info.setJobOptionDefs(PropertySupport
					.collectJobDefaultPropertyDefs(propertyDefs));
			info.setStatusInfo(activeEndpoint.getStatusInfo());
		}
		return info;
	}

	/**
	 * @see com.mckesson.eig.output.service.DestinationService#disableDestType(java.lang.String)
	 */
	public void disableDestType(String typeName) {
		ActiveEndpointType activeType = _endpointManager
				.getActiveEndpointType(typeName);
		if (activeType != null) {
			EndpointTypeDef typeDef = activeType.getEndpointTypeDef();
			typeDef.setEnabled(false);
			_endpointManager.updateEndpointTypeDef(typeDef);
		}
	}

	/**
	 * @see com.mckesson.eig.output.service.DestinationService#enableDestType(java.lang.String)
	 */
	public DestTypeInfo enableDestType(String typeName) {
		ActiveEndpointType activeType = _endpointManager
				.getActiveEndpointType(typeName);
		if (activeType != null) {
			EndpointTypeDef typeDef = activeType.getEndpointTypeDef();
			typeDef.setEnabled(true);
			_endpointManager.updateEndpointTypeDef(typeDef);
			return createDestTypeInfo(activeType);
		}
		return null;
	}

	/**
	 * @see DestinationService#getDestProperty(java.lang.String,
	 *      java.lang.String)
	 */
	public String getDestProperty(int destId, String propertyName) {
		OutputPropertyMap map = _endpointManager.getActiveEndpoint(destId)
				.getProperties();
		return map.getAsString(propertyName);
	}

	/**
	 * @see com.mckesson.eig.output.service.DestinationService#getDestTypeInfo(java.lang.String)
	 */
	public DestTypeInfo getDestTypeInfo(String destType) {
		return createDestTypeInfo(_endpointManager
				.getActiveEndpointType(destType));
	}

	private DestTypeInfo createDestTypeInfo(ActiveEndpointType activeType) {

		assert activeType != null : "activeType argument is null";

		DestTypeInfo info = new DestTypeInfo();
		EndpointTypeDef typeDef = activeType.getEndpointTypeDef();
		String type = typeDef.getType();
		info.setType(type);
		info.setDescription(typeDef.getDescription());
		info.setEnabled(typeDef.isEnabled());

		OutputPropertyMap map = activeType.getProperties();
		info.setProperties(map.getAsStrings());
		info.setPropertyDefs(map.getPropertyDefs());

		EndpointTypeHandler handler = activeType.getEndpointTypeHandler();
		info.setPropertyDefs(handler.getPropertyDefs());
		info.setContentTypes(handler.getEndpointContentTypes());
		if (handler instanceof DestTypeHandler) {

			Collection<String> deviceIDs = ((DestTypeHandler) handler)
					.queryDeviceIDs();
			info.setDeviceIDs(deviceIDs);
			if (handler instanceof PrintTypeHandler) {
				addUpdatedPrinters(map.getPropertyDefs(), deviceIDs);
			}
		}

		return info;
	}

	private void addUpdatedPrinters(PropertyDef[] propertyDefs,
			Collection<String> deviceIDs) {

		for (PropertyDef propdef : propertyDefs) {
			if ("availablePrinters".equalsIgnoreCase(propdef.getPropertyName())) {

				String[] possibleValues = new String[deviceIDs.size()];
				propdef.setPossibleValues(deviceIDs.toArray(possibleValues));
				break;
			}
		}
	}

	/**
	 * @see DestinationService#getDestTypeProperty(java.lang.String,
	 *      java.lang.String)
	 */
	public String getDestTypeProperty(String destType, String propertyName) {

		ActiveEndpointType typeDef = _endpointManager
				.getActiveEndpointType(destType);
		return typeDef.getProperties().getAsString(propertyName);
	}

	/**
	 * @see com.mckesson.eig.output.service.DestinationService#getEnabledDestTypes()
	 */
	public DestTypeInfoList getEnabledDestTypes() {
		return getEndpointTypesByCategory(EndpointCategory.DESTINATION, false);
	}

	/**
	 * @see com.mckesson.eig.output.service.DestinationService#getEnabledDestTypes()
	 */
	public DestTypeInfoList getEnabledSourceTypes() {
		return getEndpointTypesByCategory(EndpointCategory.SOURCE, false);
	}

	public DestTypeInfoList getAllSourceTypes() {
		return getEndpointTypesByCategory(EndpointCategory.SOURCE, true);
	}

	public DestTypeInfoList getAllDestTypes() {
		return getEndpointTypesByCategory(EndpointCategory.DESTINATION, true);
	}

	protected DestTypeInfoList getEndpointTypesByCategory(
			EndpointCategory category, boolean includeDisbaled) {
		DestTypeInfoList types = new DestTypeInfoList();

		for (ActiveEndpointType endpointType : _endpointManager
				.getActiveEndpointTypes(includeDisbaled)) {

			EndpointTypeDef typeDef = endpointType.getEndpointTypeDef();

			if (typeDef.getEndpointCategory() == category) {
				if ((includeDisbaled) || typeDef.isEnabled()) {
					DestTypeInfo typeInfo = createDestTypeInfo(endpointType);
					types.add(typeInfo);
				}
			}
		}
		return types;
	}

	/**
	 * @see com.mckesson.eig.output.service.DestinationService#getSupportedDestTypes()
	 */
	public StringList getSupportedDestTypes() {

		StringList allTypes = new StringList();

		for (ActiveEndpointType endpointType : _endpointManager
				.getActiveEndpointTypes()) {

			EndpointTypeDef typeDef = endpointType.getEndpointTypeDef();
			if (typeDef.getEndpointCategory() == EndpointCategory.DESTINATION) {
				if (typeDef.isEnabled()) {
					allTypes.add(typeDef.getType());
				}
			}
		}
		return allTypes;
	}

	/**
	 * @see DestinationService#pauseDestination(java.lang.String)
	 */
	public void pauseDestination(int destId) {
		_endpointManager.pauseActiveEndpoint(destId);
	}

	/**
	 * @see DestinationService#queryDestination(java.lang.String)
	 */
	public DestInfo queryDestination(int destId) {
		return createDestInfo(_endpointManager.getActiveEndpoint(destId));
	}

	/**
	 * @see DestinationService#queryDestination(java.lang.String)
	 */
	public DestInfo queryDestination(String destType, String destName) {
		return createDestInfo(_endpointManager.getActiveEndpoint(destType, destName));
	}	
	
	/**
	 * @see DestinationService#queryDestinations(java.util.Map)
	 */
	public DestInfoList queryDestinationsByCategory(EndpointCategory category) {
		DestInfoList destInfos = new DestInfoList();

		for (ActiveEndpoint destDef : _endpointManager.getActiveEndpoints()) {
			if (destDef.getEndpointDef().getEndpointCategory() == category) {
				destInfos.add(createDestInfo(destDef));
			}
		}
		return filterCreatorType(OutputConstants.QUEUE_CREATOR_USER, destInfos);
	}

	/**
	 * @see DestinationService#queryAllDestinationsByCategory(EndpointCategory)
	 */
	public DestInfoList queryAllDestinationsByCategory(EndpointCategory category) {

		ArrayList<ActiveEndpoint> activeEndpoints = new ArrayList<ActiveEndpoint>();

		for (ActiveEndpointType endpointType : _endpointManager
				.getActiveEndpointTypes(true)) {

			EndpointTypeDef typeDef = endpointType.getEndpointTypeDef();
			if (typeDef.getEndpointCategory() == category) {
				activeEndpoints.addAll(_endpointManager
						.getActiveEndpoints(typeDef.getType()));
			}
		}

		DestInfoList destInfos = new DestInfoList();
		for (ActiveEndpoint destDef : activeEndpoints) {
			destInfos.add(createDestInfo(destDef));

		}
		
		return filterCreatorType(OutputConstants.QUEUE_CREATOR_USER, destInfos);
	}

	/**
	 * @see DestinationService#queryDestinations(java.util.Map)
	 */
	public List<DestInfo> queryDestinations(Map<String, String> queryOptions) {

		List<DestInfo> destInfos = new ArrayList<DestInfo>();

		for (ActiveEndpoint destDef : _endpointManager
				.queryActiveEndpoints(queryOptions)) {
			destInfos.add(createDestInfo(destDef));
		}
		return filterCreatorType(OutputConstants.QUEUE_CREATOR_USER, destInfos);
	}
	
	public DestInfoList querySystemDestinations(List<MapModel> queryOptions) {
		
		Map<String,String> mapQueryOptions = new HashMap<String,String>();
		for (MapModel mapModel : queryOptions) {
			mapQueryOptions.put((String)mapModel.getKey(), (String)mapModel.getValue());
		}
		DestInfoList destInfos = new DestInfoList();

		for (ActiveEndpoint destDef : _endpointManager
				.queryActiveEndpoints(mapQueryOptions)) {
			destInfos.add(createDestInfo(destDef));
		}
		return filterCreatorType(OutputConstants.QUEUE_CREATOR_SYSTEM, destInfos);
	}		
	

	public DestInfoList getDestinations(String typeName) {
		
		return getDestinations(typeName, OutputConstants.QUEUE_CREATOR_USER);
	}
	
	public DestInfoList getSystemDestinations(String typeName) {

		return getDestinations(typeName, OutputConstants.QUEUE_CREATOR_SYSTEM);
	}	
	
	/*
	 * HPF 15.2 - returns queues for specified creatorType
	 */
	private DestInfoList getDestinations(String typeName, String destCreatorType) {
		DestInfoList destInfos = new DestInfoList();

		for (ActiveEndpoint destDef : _endpointManager
				.getActiveEndpoints(typeName)) {
	
			DestInfo destInfo = createDestInfo(destDef);
			if ( destInfo.getCreatorType().equalsIgnoreCase(destCreatorType)) {
				destInfos.add(destInfo);
			}
		}

		return destInfos;	
	}
		

	/**
	 * @see DestinationService#queryDevice(java.lang.String, java.lang.String)
	 */

	/*
	 * TODO - is this method needed Method queries physical device info i.e. for
	 * printer - will query physical XEROX printer
	 */
	public DeviceInfo queryDevice(String typeName, String deviceID) {

		
		ActiveEndpointType typeDef =
			  _endpointManager.getActiveEndpointType(deviceID); 
		DestTypeHandler
			  handler = (DestTypeHandler) typeDef.getEndpointTypeHandler();
		handler.getDevicePropertyDefs(deviceID);

		return new DeviceInfo();
		/*
		 * ActiveEndpointType typeDef =
		 * _endpointManager.getActiveEndpointType(destId); DestTypeHandler
		 * handler = (DestTypeHandler) typeDef.getEndpointTypeHandler();
		 * 
		 * 
		 * DeviceInfo info = new DeviceInfo(); info.setDeviceID(destId);
		 * info.setStatusInfo(handler.queryDeviceStatus(destId));
		 * 
		 * PropertyDef[] defs = handler.getDevicePropertyDefs(destId);
		 * info.setPropertyDefs(defs);
		 * info.setProperties(PropertySupport.propertiesToStrings(
		 * handler.queryDeviceProperties(destId))); return info;
		 */
	}

	/**
	 * @see DestinationService#restartDestination(java.lang.String)
	 */
	public void restartDestination(int destId) {
		_endpointManager.restartActiveEndpoint(destId);
	}

	/**
	 * @see DestinationService#setDestProperty(String, String, String)
	 */
	public void setDestProperty(int destId, String propertyName, String value) {

		ActiveEndpoint destDef = _endpointManager.getActiveEndpoint(destId);
		destDef.getProperties().put(propertyName, value);
	}

	/**
	 * @see DestinationService#setDestTypeProperty(String, String, String)
	 */
	public void setDestTypeProperty(String typeName, String propertyName,
			String propertyValue) {

		ActiveEndpointType destTypeDef = _endpointManager
				.getActiveEndpointType(typeName);
		destTypeDef.getProperties().put(propertyName, propertyValue);
	}

	/**
	 * @see DestinationService#undefineDestination(java.lang.String, boolean)
	 */
	public void undefineDestination(int destId, boolean force) {
		_endpointManager.deleteActiveEndpoint(destId);
	}

	public EndpointManager getEndpointManager() {
		return _endpointManager;
	}

	public void setEndpointManager(EndpointManager endpointManager) {
		_endpointManager = endpointManager;
	}

	/**
	 * This method retrieves all destinations and constructs a map with device
	 * name as key and its corresponding destination Id as value. This method is
	 * added to communicate COS destination Ids to Encore. The requirement for
	 * this API raised as part of Refactor Encore Device Management Design
	 * 
	 * @return MapModelList the MapModelList
	 */
	public MapModelList getDestinationNameIdMap() {

		MapModelList mapModelList = new MapModelList();
		for (ActiveEndpoint destDef : _endpointManager.getActiveEndpoints()) {

			MapModel model = new MapModel();
			model.setKey(destDef.getEndpointDef().getName());
			model.setValue(String.valueOf(destDef.getEndpointDef().getId()));
			mapModelList.add(model);
		}
		return mapModelList;
	}


	/*
	 * HPF 15.2 - added creatorType (system
	 */
	private List<DestInfo> filterCreatorType(String creatorType, List<DestInfo> destInfos) {
		List<DestInfo> filteredDestInfo = new ArrayList<DestInfo>();
		
		for (DestInfo destInfo : destInfos) {
			if (destInfo.getCreatorType().equalsIgnoreCase(creatorType)) {
				filteredDestInfo.add(destInfo);
			}
		}
		
		return filteredDestInfo;		
	}

	private DestInfoList filterCreatorType(String creatorType, DestInfoList destInfos) {
		DestInfoList filteredDestInfo = new DestInfoList();
		
		for (DestInfo destInfo : destInfos) {
			if (destInfo.getCreatorType().equalsIgnoreCase(creatorType)) {
				filteredDestInfo.add(destInfo);
			}
		}
		
		return filteredDestInfo;		
	}

	@Override
	public DestTypeInfoList getSupportedDeviceTypes() {
		return getEndpointTypesByCategory(EndpointCategory.DESTINATION_DEVICE, true);
	}
;
	@Override
	public DestTypeInfoList getSupportedDeviceVendorTypes(String deviceType, boolean includeDisbaled) {
		
		DestTypeInfoList types = new DestTypeInfoList();

		for (ActiveEndpointType endpointType :
			_endpointManager.getActiveDeviceVendorEndpointTypes(deviceType, includeDisbaled)) {

			EndpointTypeDef typeDef = endpointType.getEndpointTypeDef();

			if ((includeDisbaled) || typeDef.isEnabled()) {
				DestTypeInfo typeInfo = createDestTypeInfo(endpointType);
				types.add(typeInfo);
			}
		}
		return types;

	}

	@Override
	public DeviceInfo defineDevice(DeviceInfo deviceInfo) throws Exception {
		if (deviceInfo == null) {
			throw new IllegalArgumentException("deviceInfo argument is null");
		}
		
		deviceInfo.setId(0);
		deviceInfo.setLov(null);
		deviceInfo.setName(deviceInfo.getName().trim());
		return _endpointManager.createDevice(deviceInfo);
	}

	@Override
	public DeviceInfoList queryDevicesByCategory(EndpointCategory category) {
		DeviceInfoList deviceInfos = new DeviceInfoList();
		ArrayList<String> deviceTypes = new ArrayList<String>();

		//Get list of all device types for category
		for (ActiveEndpointType deviceType : _endpointManager.getActiveEndpointTypes()) {
			if (deviceType.getEndpointTypeDef().getEndpointCategory() == category) {
				deviceTypes.add(deviceType.getEndpointTypeDef().getType());
			}
		}
		
		//Retrieve all devices for device types
		List<EndpointDef> activeDevices = _endpointManager.getDevicesByType(deviceTypes);
		for (EndpointDef device : activeDevices) {
			if (!(device instanceof DeviceInfo)) {
				throw new IllegalArgumentException("Device is invalid");
			}
			deviceInfos.add((DeviceInfo)device);
		}
		return deviceInfos;

	}

	@Override
	public DeviceInfo queryDevice(int deviceId) {
		EndpointDef deviceInfo =  _endpointManager.getDevice(deviceId);
		if (!(deviceInfo instanceof DeviceInfo)) {
			throw new IllegalArgumentException("Device is invalid");
		}
		
		//Set properties from property list
		deviceInfo.getProperties();
		return (DeviceInfo) deviceInfo;
	}

	@Override
	public DeviceInfo updateDevice(DeviceInfo deviceInfo) {
		return  _endpointManager.updateDevice(deviceInfo);
	}

	@Override
	public void undefineDevice(int deviceId, boolean force) {
		_endpointManager.deleteDevice(deviceId, force);
	}

	@Override
	public DeviceInfo testDevice(DeviceInfo deviceInfo) {
		
		return _endpointManager.testDevice(deviceInfo);
	}

	@Override
	public List<String> refreshDeviceLabels(int deviceId) {
		EndpointDef deviceInfo =_endpointManager.getDevice(deviceId);
		
		if (deviceInfo != null) {

			
			//Set properties from property list
			deviceInfo.getProperties();
			
			ActiveEndpointType typeDef =
				  _endpointManager.getActiveEndpointType(DeviceType.DISC_DEVICE.name()); 
			if (typeDef.getEndpointTypeHandler() instanceof DiscLabelStrategy) {
				DiscLabelStrategy
				  handler = (DiscLabelStrategy) typeDef.getEndpointTypeHandler();
				  return handler.getLabelTemplates((DeviceInfo)deviceInfo);	
			}
		}
		return null;
	}

}
