/*
 * Copyright 2008 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved. Use of
 * this material is governed by a license agreement. This material contains confidential,
 * proprietary and trade secret information of McKesson Information Solutions and is protected under
 * United States and international copyright and other intellectual property laws. Use, disclosure,
 * reproduction, modification, distribution, or storage in a retrieval system in any form or by any
 * means is prohibited without the prior express written permission of McKesson Information
 * Solutions.
 *
 * author: Latonia
 */

package com.mckesson.eig.output.local.printer;

import javax.print.attribute.standard.JobName;
import javax.print.event.PrintJobEvent;
import javax.print.event.PrintJobListener;

import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public class PrintListener implements PrintJobListener {

    private static final int SLEEP_TIME = 1000;
    private OutputManager _outputManager = null;
    private static final Log LOG = LogFactory.getLogger(PrintListener.class);

    public PrintListener(OutputManager outputManager) {
        _outputManager = outputManager;
    }

    public void printingStart(Integer jobId) {
        _outputManager.updateJobStatus(jobId, StatusUtils.createRequestStatus(
                                     RequestStatus.PRINTING,
                                     "Printing Job"));
        LOG.debug("print Job start printing:" + jobId);
    }

    public void printingCompleted(Integer jobId) {

        _outputManager.updateJobStatus(jobId, StatusUtils.createRequestStatus(
                                                     RequestStatus.COMPLETED,
                                                     "Print Job Completed"));
        LOG.debug("print Job completed successfully:" + jobId);
    }

    public void printingFailed(Integer jobId) {

        _outputManager.updateJobStatus(jobId, StatusUtils.createRequestStatus(
                                                     RequestStatus.ERROR,
                                                     "Printing Error"));
        LOG.debug("print job failed:" + jobId);
    }

    public void printDataTransferCompleted(PrintJobEvent pje) {

        try {
            Thread.sleep(SLEEP_TIME);
            LOG.error("printDataTransferCompleted:" + pje.getPrintJob().getAttributes().
                      get(JobName.class).toString());
        } catch (Exception e) {
            LOG.error("printDataTransferCompleted:" + e.getMessage());
        }
    }

    public void printJobCompleted(PrintJobEvent pje) {

        _outputManager.updateJobStatus(
                            Integer.parseInt(pje.getPrintJob().getAttributes()
                                             .get(JobName.class).toString()),
                                             StatusUtils.createRequestStatus(
                                                     RequestStatus.COMPLETED,
                                                     "Print Job Completed"));
        System.out.println("JOBNAME:" + pje.getPrintJob().getAttributes()
                           .get(JobName.class).toString());
        LOG.debug("print Job completed successfully" + pje);
    }

    public void printJobFailed(PrintJobEvent pje) {
        _outputManager.updateJobStatus(
                             Integer.parseInt(pje.getPrintJob().getAttributes()
                                              .get(JobName.class).toString()),
                                              StatusUtils.createRequestStatus(
                                                      RequestStatus.ERROR,
                                                      "Printing Error"));

        LOG.debug("print job failed" + pje);
    }

    public void printJobNoMoreEvents(PrintJobEvent pje) {

        LOG.debug("All events DONE: " + pje.getPrintEventType());

        if ((pje.getPrintEventType() == PrintJobEvent.JOB_COMPLETE)
                || (pje.getPrintEventType() == PrintJobEvent.NO_MORE_EVENTS)) {
            if (pje.getPrintJob().getAttributes().get(JobName.class) != null) {
                printJobCompleted(pje);
                LOG.debug("JOBNAME:"
                          + pje.getPrintJob().getAttributes().get(JobName.class).toString()
                          + "COMPLETED");
            }
        }
        if (pje.getPrintEventType() == PrintJobEvent.JOB_CANCELED) {
            if (pje.getPrintJob().getAttributes().get(JobName.class) != null) {
                printJobCanceled(pje);
                LOG.debug("JOBNAME:"
                          + pje.getPrintJob().getAttributes().get(JobName.class).toString()
                          + " CANCELED");
            }
        }
        if (pje.getPrintEventType() == PrintJobEvent.JOB_FAILED) {
            if (pje.getPrintJob().getAttributes().get(JobName.class) != null) {
                printJobFailed(pje);
                LOG.debug("JOBNAME:"
                          + pje.getPrintJob().getAttributes().get(JobName.class).toString()
                          + " FAILED");
            }
        }

        if (pje.getPrintEventType() == PrintJobEvent.REQUIRES_ATTENTION) {
            if (pje.getPrintJob().getAttributes().get(JobName.class) != null) {
                printJobRequiresAttention(pje);
                LOG.debug("JOBNAME:"
                          + pje.getPrintJob().getAttributes().get(JobName.class).toString()
                          + " NEEDS ATTENTION");
            }
        }
    }

    public void printJobRequiresAttention(PrintJobEvent pje) {

        _outputManager.updateJobStatus(
                                 Integer.parseInt(pje.getPrintJob().getAttributes()
                                                  .get(JobName.class).toString()),
                                                  StatusUtils.createRequestStatus(
                                                          RequestStatus.ERROR,
                                                          "Printing Error"));
        LOG.debug("Print job requires attention " + pje);
    }

    public void printJobCanceled(PrintJobEvent pje) {

        _outputManager.updateJobStatus(
                                 Integer.parseInt(pje.getPrintJob().getAttributes()
                                                  .get(JobName.class).toString()),
                                                  StatusUtils.createRequestStatus(
                                                          RequestStatus.CANCELED,
                                                          "Print Job Canceled"));
        LOG.debug("Print job cancelled ");
    }
}
