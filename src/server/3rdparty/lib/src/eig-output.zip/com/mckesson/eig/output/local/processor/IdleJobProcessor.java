/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.dao.OutputJobDAO;
import com.mckesson.eig.output.util.OutputSettingConstants;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;

public class IdleJobProcessor extends AbstractJobProcessor {

	protected static final int DEFAULT_JOB_SIZE = 1;
	
    private static final int DEFAULT_IDLE_IN_DAYS = 1;		// 1 day idle time
	private int _idleInDays = DEFAULT_IDLE_IN_DAYS;
    protected static final String DEFAULT_IDLE_ERROR_MESSAGE = "Output server was unable to complete this request. "
			+ "Please check the output device and resubmit the job if needed.";
    public static String _idleErrorMsg = DEFAULT_IDLE_ERROR_MESSAGE;
    protected static final int IDLE_WAITING_TIME = 60 * 60 * 1000;

    public IdleJobProcessor(DefaultTypeHandlerFactory factory,
			OutputManager outputManger, EndpointDAO dao, OutputJobDAO jobDao, JobProcessorHelper helper) {
		super(factory, outputManger, dao, jobDao, helper);
		setExecutorSize(DEFAULT_JOB_SIZE);
	}
	
	/**
	 * This method is used to set the properties
	 *
	 */
	public void setProperties(Properties p) {
		try {
			String value = p.getProperty(OutputSettingConstants.IDLE_IN_DAYS);
			if (value != null) {
				setIdleInDays(Integer.parseInt(value));
			}
			value = p.getProperty(OutputSettingConstants.IDLE_ERROR_MESSAGE);
			if (value != null) {
				setIdleErrorMsg(value);
			}
	    } catch (Exception e) {
	    	LOG.info("Fail to set common processor properties. Use Default. Msg: " + e.getMessage());
	    }
	}
	
	/**
	 * This method is used to process the output job
	 *
	 */
	public boolean processJob() {
		long current = System.currentTimeMillis();
		if (current - _previousCheckingIdleTime > IDLE_WAITING_TIME) {
			boolean b = failedIdleJobForDays();
			while (b) {
				b = failedIdleJobForDays();
			}
			_previousCheckingIdleTime = current;
		}
		return false;
	}

	/**
	 * This method is used to refresh the queue
	 *
	 */
	public void refreshQueueList() {
		// TODO Auto-generated method stub
	}

	protected boolean failedIdleJobForDays() {
		List<RequestStatus> requestStatuses = getProcessingStatus();
		String errorMsg = getIdleErrorMsg();
		return processIdleJobInDaysByChangeStatus(requestStatuses,  RequestStatus.ERROR, getIdleInDays(), errorMsg);
	}

	protected boolean processIdleJobInDaysByChangeStatus(List<RequestStatus> checkStatuses, RequestStatus resetStatus, int idleInDay, String errorMsg) {
		return getJobProcessorHelper().processIdleJobInDaysByChangeStatus(checkStatuses, resetStatus, idleInDay, errorMsg);
	}
	
	public static String getIdleErrorMsg() {
		return _idleErrorMsg;
	}

	public void setIdleErrorMsg(String idleErrorMsg) {
		_idleErrorMsg = idleErrorMsg;
	}

	public int getIdleInDays() {
		return _idleInDays;
	}

	public void setIdleInDays(int idleInDays) {
		_idleInDays = idleInDays;
	}

	protected List<RequestStatus> getProcessingStatus() {
		List<RequestStatus> statuses = new ArrayList<RequestStatus>();
		statuses.add(RequestStatus.PROCESSING);
		statuses.add(RequestStatus.FAXING);
		statuses.add(RequestStatus.EMAILING);
		statuses.add(RequestStatus.PRINTING);
		statuses.add(RequestStatus.FILE_PREPARING);
		statuses.add(RequestStatus.DISC_PREPARING_PROCESSING);
		statuses.add(RequestStatus.DISC_BURNING_PROCESSING);
		return statuses;
	}
}
