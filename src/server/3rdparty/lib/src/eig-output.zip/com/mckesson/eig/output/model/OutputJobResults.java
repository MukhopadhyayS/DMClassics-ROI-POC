package com.mckesson.eig.output.model;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.mckesson.eig.output.util.OutputUtil;

/*
 * OutputJobResults is a container for returning the results for the Output Job
 * 
 * container must hold object for each type of output job which has results to return
 * currently the only supported type is FILE Destination
 * As new types are supported for return results, return objects must be added
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "outputJobResults")
@XmlType(name = "outputJobResults")
public class OutputJobResults {
	
	/*
	 * holds return object for FILE Destinations
	 */
	private OutputJobFiles _outputJobFiles = null;


	public OutputJobResults() {
	}
	
	@XmlElement (name = "outputJobFiles", type = OutputJobFiles.class)
	public void setOutputJobFiles(OutputJobFiles outputJobFiles) {
		_outputJobFiles = outputJobFiles;
	}
	
	public OutputJobFiles getOutputJobFiles() {
		return _outputJobFiles;
	}
	
	public void loadResults(String resultsXML) {
		/*
		 * This method loads the results to the proper result type
		 * TODO: method should resolve result type using root element and then load proper object
		 *       currently there is a single object so method loads FILE destination
		 */
		//should only call if results root element is OutputJobFiles
		loadOutputJobFiles(resultsXML);
	}
	
	private void loadOutputJobFiles(String resultsXML) {
		_outputJobFiles = (OutputJobFiles) OutputUtil.getObject(new StringReader(resultsXML));
	}

}
