package com.mckesson.eig.output.local.disc;

public interface DiscJobListener {
	 public void discJobCanceled();
	 public void discJobFailed();
	 public void discJobPreparingCompleted();
	 public void discJobPreparingStarted();
	 public void discJobBurningCompleted();
	 public void discJobBurningStarted();
}
