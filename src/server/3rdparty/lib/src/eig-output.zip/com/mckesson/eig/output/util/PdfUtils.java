/*
 * Copyright 2011 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import net.sf.jmimemagic.Magic;
import net.sf.jmimemagic.MagicMatch;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfDestination;
import com.lowagie.text.pdf.PdfFileSpecification;
import com.lowagie.text.pdf.PdfNumber;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfSignatureAppearance;
import com.lowagie.text.pdf.PdfStamper;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.collection.PdfCollection;
import com.lowagie.text.pdf.collection.PdfCollectionField;
import com.lowagie.text.pdf.collection.PdfCollectionItem;
import com.lowagie.text.pdf.collection.PdfCollectionSchema;
import com.lowagie.text.pdf.collection.PdfCollectionSort;
import com.lowagie.text.pdf.collection.PdfTargetDictionary;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.io.FileLoader;
import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.StringUtilities;

public final class PdfUtils {

	private static final Log LOG = LogFactory.getLogger(PdfUtils.class);
	private static final int MAX_RETRY = 10;
	private static final int ONETWENTY = 120;
	private static String[] _keys = { "TYPE", "FILE" };
	private static final String DEFAULT_HASH_ALGORITHM = "SHA-256";
    private static final int FONT_SIZE_10 = 10;
    private static final Font FONT_10 = FontFactory.getFont(FontFactory.COURIER, FONT_SIZE_10);


	private PdfUtils() {
		super();
	}

	/**
	 * Creates the PDF.
	 * 
	 * @return the bytes of a PDF file.
	 */
	public static void createPdf(List<String> inFileList,
			String outFileName, boolean generateHash, Properties cryptoProps) throws DocumentException, IOException {

		// step 1
		Document document = new Document();
		// step 2
		PdfWriter writer = PdfWriter.getInstance(document,
				new FileOutputStream(outFileName));
		writer.setPdfVersion(PdfWriter.VERSION_1_7);

		// step 3
		document.open();

		// step 4

		// cover page

		// Added for CR 346,843
		// To load the output-settings.properites if the directory contains
		// blank space in it.
		String propsFile = null;
		try {
			propsFile = (Thread.currentThread().getContextClassLoader()
					.getResource("com/mckesson/eig/output/output-settings.properties"))
					.toURI().getPath();
		} catch (URISyntaxException e) {
			throw new RuntimeException(
					"Unable to load com/mckesson/eig/output/output-settings.properties ",
					e);
		}


		Properties props = new Properties();
		props.load(new FileInputStream(propsFile));

		document.add(new Paragraph(new Chunk(props
				.getProperty("pdf.collections.cover.letter.text.part1"))));
		document.add(new Paragraph(new Chunk(props
				.getProperty("pdf.collections.cover.letter.text.part2"))));
		// add a blank lines
        document.add(Chunk.NEWLINE);

		PdfCollection collection = new PdfCollection(PdfCollection.HIDDEN);
		PdfCollectionSchema schema = getCollectionSchema();
		collection.setSchema(schema);
		PdfCollectionSort sort = new PdfCollectionSort(_keys);
		collection.setSort(sort);
		writer.setCollection(collection);

		// Collection items
		PdfCollectionItem collectionitem = new PdfCollectionItem(schema);
		PdfPTable table = new PdfPTable(1);
		table.setSpacingAfter(ONETWENTY);
		
		String hashAlgorithm = cryptoProps.getProperty("HASH_ALGORITHM", DEFAULT_HASH_ALGORITHM);

		for (String file : inFileList) {

			File f = new File(file);
			String fileName = f.getName();

			PdfTargetDictionary target;
			PdfDestination dest = new PdfDestination(PdfDestination.FITH);
			dest.addFirst(new PdfNumber(1));

			PdfPCell cell = new PdfPCell(new Phrase(fileName));
			cell.setBorder(PdfPCell.NO_BORDER);
			PdfFileSpecification fs;
			fs = PdfFileSpecification
					.fileEmbedded(writer, file, fileName, null);
			collectionitem.addItem("TYPE", "PDF");
			fs.addCollectionItem(collectionitem);
			writer.addFileAttachment(fs);

			target = new PdfTargetDictionary(true);
			target.setFileAttachmentPagename(fileName);
			target.setFileAttachmentName(fileName);
			cell.setCellEvent(new FileAttachmentEvent(writer, fs, String
					.format("Double click to open %s", fileName)));
			
			table.addCell(cell);
			
			if(generateHash) {
				String fileHashValue = "";
				try {
					fileHashValue = getHashValue(file, hashAlgorithm);
				} catch (Exception e) {
					LOG.error("Unable to generate Hash Key for file:" +  fileName + "  Exception: " + e.toString());
				}
				String hashCellValue = hashAlgorithm + ":" + fileHashValue;
				PdfPCell hashCell = new PdfPCell(new Phrase(hashCellValue,FONT_10));
				hashCell.setBorder(PdfPCell.NO_BORDER);
				hashCell.setPaddingLeft(30f);
				table.addCell(hashCell);
			}
		}

		document.add(table);

		// step 5
		document.close();
		writer.close();
		
	}

	/**
	 * Creates a Collection schema.
	 * 
	 * @return a collection schema
	 */
	private static PdfCollectionSchema getCollectionSchema() {
		PdfCollectionSchema schema = new PdfCollectionSchema();

		PdfCollectionField type = new PdfCollectionField("File type",
				PdfCollectionField.TEXT);
		type.setOrder(0);
		schema.addField("TYPE", type);

		PdfCollectionField filename = new PdfCollectionField("FILE",
				PdfCollectionField.FILENAME);
		filename.setOrder(1);
		schema.addField("FILE", filename);

		return schema;
	}

	public static void trySignAndEncryptPdf(String src, String dest,
			Properties cryptoProps, String passwd, String ownerPasswd)
			throws IOException, DocumentException, GeneralSecurityException {

		FileOutputStream os = null;
		PdfReader reader = null;
		PdfStamper stamper = null;
		try {
		
			// reader
			if (ownerPasswd == null) {
				reader = new PdfReader(src);
			} else {
				reader = new PdfReader(src, ownerPasswd.getBytes());
			}
			os = new FileOutputStream(dest);
	
			String keyFile = cryptoProps.getProperty("KEYSTORE_FILE");
			
			boolean needSign = true; 
			if (StringUtilities.isEmpty(keyFile)) {
				needSign = false;
			}
			if (needSign) {
				// stamper
				stamper = PdfStamper.createSignature(reader, os, '\0');
				LOG.debug("Signing pdf is enable");
			} else {
				stamper = new PdfStamper(reader, os);	
				LOG.debug("Signing pdf is disable");
			}
		
			// set encryption and passwords.
			if (passwd == null) { 
				stamper.setEncryption(null, null, 
						PdfWriter.ALLOW_ASSEMBLY
						| PdfWriter.ALLOW_COPY 
						| PdfWriter.ALLOW_PRINTING
						| PdfWriter.ALLOW_FILL_IN 
						| PdfWriter.ALLOW_SCREENREADERS
						| PdfWriter.ENCRYPTION_AES_128, true);
				
			} else if (ownerPasswd == null) { // modified to encrypt if the owner password is null
				stamper.setEncryption(passwd.getBytes(), null, 
						PdfWriter.ALLOW_ASSEMBLY
						| PdfWriter.ALLOW_COPY 
						| PdfWriter.ALLOW_PRINTING
						| PdfWriter.ALLOW_FILL_IN 
						| PdfWriter.ALLOW_SCREENREADERS
						| PdfWriter.ENCRYPTION_AES_128, true);
				
			} else {
				stamper.setEncryption(passwd.getBytes(), ownerPasswd.getBytes(),
						PdfWriter.ALLOW_ASSEMBLY 
						| PdfWriter.ALLOW_COPY
						| PdfWriter.ALLOW_PRINTING
						| PdfWriter.ALLOW_FILL_IN
						| PdfWriter.ALLOW_SCREENREADERS
						| PdfWriter.ENCRYPTION_AES_128, true);
			}
			
			if (needSign) {
				try {
					// Load private key and certificate from classpath
					// Added for CR 346,843
					// To load the KEYSTORE_FILE if the directory contains blank space in
					// it.
					keyFile = (Thread.currentThread().getContextClassLoader()
							.getResource(cryptoProps.getProperty("KEYSTORE_FILE")))
							.toURI().getPath();
				} catch (URISyntaxException e) {
					throw new RuntimeException("Unable to load the KEYSTORE_FILE "
							+ cryptoProps.getProperty("KEYSTORE_FILE"), e);
				}
				String keystorePassword = cryptoProps.getProperty("KEYSTORE_PASSWORD");
				String keyPassword = cryptoProps.getProperty("KEY_PASSWORD");
				KeyStore ks = KeyStore.getInstance(
						cryptoProps.getProperty("KEYSTORE_TYPE"),
						cryptoProps.getProperty("KEYSTORE_PROVIDER"));
				ks.load(new FileInputStream(keyFile), keystorePassword.toCharArray());
				String alias = (String) ks.aliases().nextElement();
				PrivateKey key = (PrivateKey) ks.getKey(alias,
						keyPassword.toCharArray());
				Certificate[] chain = ks.getCertificateChain(alias);
				
				PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
				String certType = cryptoProps.getProperty("CERT_TYPE");
				LOG.debug("certType=" + certType);
				if (certType == null || certType.equalsIgnoreCase("SELF_SIGNED")) {
					LOG.debug("Setting certType= SELF_SIGNED");
					appearance.setCrypto(key, chain, null,
							PdfSignatureAppearance.SELF_SIGNED);
				} else {
					LOG.debug("Setting certType= VERISIGN_SIGNED");
					appearance.setCrypto(key, chain, null,
							PdfSignatureAppearance.VERISIGN_SIGNED);
				}
			}
		
		} finally {
			//close FileOutputStream if it is not properly closed with stamper.close()
			if (stamper != null) {
				stamper.close();
			}
			if (reader != null) {
				reader.close();
			}
			if (os != null) {
				os.close();
			}
		}
	}

	public static void signAndEncryptPdf(String src, String dest,
			Properties cryptoProps, String passwd, String ownerPasswd)
			throws IOException, DocumentException, GeneralSecurityException {
		int count = 0;
		while (true) {
			try {
				trySignAndEncryptPdf(src, dest, cryptoProps, passwd,
						ownerPasswd);
				break;
			} catch (ArrayIndexOutOfBoundsException e) {
				LOG.error("ArrayIndexOutOfBoundsException : retry attempt = "
						+ (count + 1));
				if (count >= MAX_RETRY) {
					throw e;
				}
				count++;
			}
		}
	}
	
	public static void writeHashValueToFile(String in, String out, Properties cryptoProps) throws Exception {
		String algoritm = cryptoProps.getProperty("HASH_ALGORITHM", DEFAULT_HASH_ALGORITHM);
		String hash = getHashValue(in, algoritm);
		try {
		    BufferedWriter writer = new BufferedWriter(new FileWriter(out));
		    writer.write(hash);
		    writer.close();
		} catch (IOException e) {
			LOG.error("Exception write hash to file:" +  e.toString());
		}
	}

	public static String getHashValue(String file, String algorithm) throws Exception {
		MessageDigest md = MessageDigest.getInstance(algorithm);
		FileInputStream fis = new FileInputStream(file);
		byte[] dataBytes = new byte[1024];

		int nread = 0;

		while ((nread = fis.read(dataBytes)) != -1) {
			md.update(dataBytes, 0, nread);
		}
		byte[] mdbytes = md.digest();

		// convert the byte to hex format
		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < mdbytes.length; i++) {
			sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16)
					.substring(1));
		}
		LOG.debug("HASH Value:" + sb.toString());
		return sb.toString();
	}
	
    public static String getFileType(File f) {
        
        try {
        	MagicMatch match = Magic.getMagicMatch(f, false);
        	return match.getMimeType();
        } catch (Exception e) {
            LOG.error("Unable to find file type : " + f.toString());
        }
        return null;
    }
    
    public static Properties loadProperties(String properties) {
	    InputStream in = null;
        Properties p = new Properties();

        try {
        	in = FileLoader.getResourceAsInputStream(properties);
        	if (in != null) {
				p.load(in);
        	}
        } catch (Exception e) {
			throw new ApplicationException("error loading default Property File : " + properties);
        } finally {
        	if (in != null) {
				IOUtilities.close(in);
        	}
        }
        return p;
    }
    

}
