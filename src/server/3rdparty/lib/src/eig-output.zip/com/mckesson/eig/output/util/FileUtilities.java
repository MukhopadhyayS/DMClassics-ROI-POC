package com.mckesson.eig.output.util;

import java.io.File;

import com.mckesson.eig.utility.io.IOUtilities;
import com.mckesson.eig.utility.util.StringUtilities;

public class FileUtilities {
	private int _idx = 0;
	private String _directory;
	private String _extension = "";
	private String _prefix = "";

	public FileUtilities(String directory) {
		_directory = directory;
	}
	
	public FileUtilities(String directory, String extension) {
		this(directory);
		_extension = extension;
	}

	public FileUtilities(String directory, String extension, String prefix) {
		this(directory, extension);
		_prefix = prefix;
	}

	public String writeFile(byte[] bytes) {
		File f = getFile();
		IOUtilities.write(f, bytes);
		return f.getAbsolutePath();
	}

	private synchronized int getIdx() {
		int result = _idx + 1;
		_idx++;
		return result;
	}

	public String getDirectory() {
		return _directory;
	}

	public File getFile() {
		File dir = new File(_directory);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		int idx = getIdx();
		String file = _prefix + idx;
		if(!StringUtilities.isEmpty(_extension)) {
			file += "." + _extension;
		}
		return new File(dir + File.separator + file);
	}
}
