/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

* Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
* Use of this software and related documentation is governed by a license agreement.
* This material contains confidential, proprietary and trade secret information of
* McKesson Information Solutions and is protected under United States
* and international copyright and other intellectual property laws.
* Use, disclosure, reproduction, modification, distribution, or storage
* in a retrieval system in any form or by any means is prohibited without the
* prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
*/

package com.mckesson.eig.output.local.processor;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.MDC;

import com.mckesson.eig.output.device.disc.DiscProviderFactory;
import com.mckesson.eig.output.device.disc.DiscProviderManager;
import com.mckesson.eig.output.local.DefaultTypeHandlerFactory;
import com.mckesson.eig.output.local.DestDeviceTypeHandler;
import com.mckesson.eig.output.local.OutputManager;
import com.mckesson.eig.output.local.dao.EndpointDAO;
import com.mckesson.eig.output.local.device.disc.DiscDevice;
import com.mckesson.eig.output.local.device.disc.DiscStatusListener;
import com.mckesson.eig.output.local.disc.DiscDestination;
import com.mckesson.eig.output.local.disc.DiscTypeHandler;
import com.mckesson.eig.output.local.mediator.OutputJobMediator;
import com.mckesson.eig.output.local.mediator.impl.MediatorDiscJob;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.util.CollectionUtilities;

public class DiscJobProcessRunnable extends JobProcessRunnable {

	private final RequestStatus _requestStatus;
	private final DiscProviderFactory _discProviderFactory;
	private final int _dvdSize;
	private final int _cdSize;
	private final DiscStatusListener _listener;
	
	public DiscJobProcessRunnable(DefaultTypeHandlerFactory factory, EndpointDAO dao,
            OutputManager outputManager, OutputJob job, RequestStatus requestStatus, DiscProviderFactory discProviderFactory,
            int cdSize, int dvdSize, DiscStatusListener listener) {
		super(factory, dao, outputManager, job);
		_requestStatus = requestStatus;
		_discProviderFactory = discProviderFactory;
		_cdSize = cdSize;
		_dvdSize = dvdSize;
		_listener = listener;
    }
	
    private DiscDestination getDiscDestination(int id) {
        EndpointDef def = _dao.getEndpointDef(id);
        return (DiscDestination) _handler.createEndpoint(def);
    }

    private DiscDevice getDiscDevice(String deviceId) {
        EndpointDef def = _dao.getEndpointDef(Integer.valueOf(deviceId));
        DestDeviceTypeHandler handler = ((DiscTypeHandler) _handler).getDestDeviceHandler();
        return (DiscDevice) handler.createEndpoint(def);
    }

    public void run() {
		try {
			long startTime = System.currentTimeMillis();
			if (_requestStatus == RequestStatus.PROCESSING) {
				LOG.debug("Start retrieving source for Job:" + _job.getJobSeq());
				startReceiveContent();
				long finishTime = System.currentTimeMillis();
				LOG.debug("Finished retrieving source for Job:" + _job.getJobSeq()
						+ " in: " + (finishTime - startTime) + " milliseconds");
			} else if (_requestStatus == RequestStatus.DISC_PREPARING_READY) {
				LOG.debug("Start sending disc preparation for Job:" + _job.getJobSeq());
				startDiscPreparing();
				long finishTime = System.currentTimeMillis();
				LOG.debug("Finished sending disc preparation for Job:" + _job.getJobSeq()
						+ " in: " + (finishTime - startTime) + " milliseconds");
			} else if (_requestStatus == RequestStatus.DISC_BURNING_READY) {
				LOG.debug("Start sending disc burning for Job:" + _job.getJobSeq());
				startDiscBurning();
				long finishTime = System.currentTimeMillis();
				LOG.debug("Finished sending disc burning for Job:" + _job.getJobSeq()
						+ " in: " + (finishTime - startTime) + " milliseconds");
			} else if (_requestStatus == RequestStatus.DISC_PREPARING_PROCESSING) {
				LOG.debug("Start checking disc preparation for Job:" + _job.getJobSeq());
				startCheckingDiscPreparing();
				long finishTime = System.currentTimeMillis();
				LOG.debug("Finished  checking disc preparation for Job:" + _job.getJobSeq()
						+ " in: " + (finishTime - startTime) + " milliseconds");
			} else if (_requestStatus == RequestStatus.DISC_BURNING_PROCESSING) {
				LOG.debug("Start checking disc burning for Job:" + _job.getJobSeq());
				startCheckingDiscBurning();
				long finishTime = System.currentTimeMillis();
				LOG.debug("Finished checking disc burning for Job:" + _job.getJobSeq()
						+ " in: " + (finishTime - startTime) + " milliseconds");
			}
	 	} catch (Exception e) {
			error(_job, e.getMessage());
		} finally {
			MDC.remove(JOB_ID);
		}
	}
    
    private void startReceiveContent() throws Exception {
		_srcProcessor.process(_job, this);
   }

    private void startDiscBurning() throws Exception {
    	DiscDestination d = setDestination(_job);
        DiscProviderManager manager = getDiscProviderManager(d.getDiscdevice());
        String orderId = manager.burnDisc(_job);
        _listener.discBurningSubmitted(_job, orderId);        
    }

    private void startDiscPreparing() throws Exception {
    	DiscDestination d = setDestination(_job);
        DiscProviderManager manager = getDiscProviderManager(d.getDiscdevice());
        String orderId = manager.prepareDiscContent(_job);
        _listener.discPreparationSubmitted(_job, orderId);     
    }
    
    private void startCheckingDiscPreparing() throws Exception {
    	DiscDestination d = setDestination(_job);
        DiscProviderManager manager = getDiscProviderManager(d.getDiscdevice());
        Map<StatusInfo, List<String>> map = manager.checkPrepareDiscContentStatus(_job);
        StatusInfo statusInfo = null;
    	Integer jobId = _job.getJobSeq();
        if (!CollectionUtilities.isEmpty(map)) {
			Iterator<StatusInfo> i = map.keySet().iterator();
			statusInfo =  i.next();
		}
		if (statusInfo != null) {
		    if(StatusUtils.isSameStatus(statusInfo, RequestStatus.DISC_BURNING_READY)) {
		    	List<String> fileNames = map.get(statusInfo);
		    	_listener.discPreparationCompleted(jobId, fileNames);
		    } else if(StatusUtils.isSameStatus(statusInfo, RequestStatus.ERROR)) {
		    	_listener.discPreparationFailed(jobId, statusInfo.getDetail());
		    } else if(StatusUtils.isSameStatus(statusInfo, RequestStatus.DISC_PREPARING_PROCESSING)) {
		    	_listener.discPreparationInProgress(jobId, statusInfo.getDetail());
		    }
		}
    }
    
    private DiscProviderManager getDiscProviderManager(DiscDevice device) {
    	return _discProviderFactory.getDiscProviderManager(device.getVendorName());
    }

    private void startCheckingDiscBurning() throws Exception {
    	DiscDestination d = setDestination(_job);
        DiscProviderManager manager = getDiscProviderManager(d.getDiscdevice());
        StatusInfo statusInfo = manager.checkBurnDiscStatus(_job);;
    	Integer jobId = _job.getJobSeq();
		if(statusInfo != null) {
		    if(StatusUtils.isSameStatus(statusInfo, RequestStatus.COMPLETED)) {
		    	_listener.discBurningCompleted(jobId);
		    } else if(StatusUtils.isSameStatus(statusInfo, RequestStatus.ERROR)) {
		    	_listener.discBurningFailed(jobId, statusInfo.getDetail());
		    } else if (StatusUtils.isSameStatus(statusInfo, RequestStatus.DISC_BURNING_PROCESSING)) {
		    	_listener.discBurningInProgress(jobId, statusInfo.getDetail());
		    }
		}
    }
    
    private DiscDestination setDestination(OutputJob job) {
		int destId = job.getDestID();
		DiscDestination d = getDiscDestination(destId);
		DiscDevice device = getDiscDevice(d.getDevice());
		d.setDiscdevice(device);
        job.setDestination(d);
        return d;
    }
    
    public void start(OutputJob job) {
    	setDestination(job);
		try {
			_mJob = OutputJobMediator.createJob(job, job.getDestination(), _handler);
			MediatorDiscJob mediatorDiscJob = (MediatorDiscJob)_mJob;
			mediatorDiscJob.setDiscSize(_cdSize, _dvdSize);
		} catch (Exception e) {
			_outputManager.updateJobStatus(
					job.getJobSeq(),
					StatusUtils.createRequestStatus(RequestStatus.ERROR,
							e.getMessage()));
		}
	}
}
