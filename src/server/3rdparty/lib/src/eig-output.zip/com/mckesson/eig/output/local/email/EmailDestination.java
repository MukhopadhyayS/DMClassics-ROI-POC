package com.mckesson.eig.output.local.email;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.commons.lang.StringUtils;

import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.file.FileConstants;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.model.PropertyDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.EndpointStatus;
import com.mckesson.eig.output.util.OutputProperty;
import com.mckesson.eig.output.util.OutputProperty.PropertyFlag;
import com.mckesson.eig.output.util.status.StatusUtils;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;



public class EmailDestination extends Destination {

    private static final int DEFAULT_EMAIL_SIZE = 25;
    private static final String EMAIL_DIR = "EMAIL";
    private String _smtpHost;
	private String _smtpPort;
	private String _fromEmailAddress;
	private String _fromName;
	private String _mimeType;
	private String _subject;
	private String _body;
    private static final Log LOG = LogFactory
			.getLogger(EmailDestination.class);

	private static final boolean DEBUG = LOG.isDebugEnabled();
    private long _emailSizeMb;
	private EmailDestinationHandler _handler;
	private String 		_name;
	private StatusInfo 	_status;
    private String _filePassword;
    private boolean _filePasswordRequired;
    private boolean _subjectBodyOverride;

	public EmailDestination(EmailDestinationHandler handler, String name) {
		_name = name;
		_status = StatusUtils.createEndpointStatus(EndpointStatus.OK, null);
		_handler = handler;
//		_emailSizeMb = DEFAULT_EMAIL_SIZE;
	}

	public PropertyDef[] getJobOptionDefs() {
		// TODO Auto-generated method stub
		return null;
	}

    public void processJob(OutputJob job) {
	}

	/**
	 * This method is used to get the queue password.
	 * @param job - outputjob
	 * @return
	 */
	public String getQueuePassword(OutputJob job) {
		
		// Default queue password
		String qPassword = job.getPropertyValue(OutputConstants.OUTPUT_FILE_PASSWORD);
		// custom queue password from output job
		boolean isNotBlank = StringUtils.isNotBlank(qPassword); 
	    qPassword = (isNotBlank) ? qPassword : getPassword();
	    
	    return (StringUtils.isNotBlank(qPassword) || getPasswordRequired()) ? 
	    		StringUtils.trim(qPassword) : null;
	}
	
	/**
	 * This method is used to return the request level password in output job.
	 * @param job - outputjob
	 * @return if exists request level password it returns, otherwise null
	 */
	public String getRequestPassword(OutputJob job) {
		
		// Check whether the Request level password is available in outputjob.
		String reqPassword = job.getPropertyValue(OutputConstants.OUTPUT_FILE_REQUEST_PASSWORD);
		return !StringUtils.isNotBlank(reqPassword) ? null : reqPassword;
	}
    
    public StatusInfo queryEndpointStatus() {
		return _status;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

    @OutputProperty(
            defaultValue = "",
            description = "SMTP Host Name or IP",
            label = "SMTP Host",
            required = "true",
            possibleValues = { "^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])(\\.([a-zA-Z0-9]"
            					+ "|[a-zA-Z0-9][a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9]))*$" },
            index = "1")
	public String getSmtpHost() {
		return _smtpHost;
	}

	public void setSmtpHost(String smtpHost) {
		_smtpHost = smtpHost;
	}

  	@OutputProperty(
            defaultValue = "25",
            description = "SMTP Port",
            label = "SMTP Port",
            possibleValues = { "\\d+" },
            required = "true",
            index = "2")
	public String getSmtpPort() {
		return _smtpPort;
	}

	public void setSmtpPort(String smtpPort) {
		_smtpPort = smtpPort;
	}

    @OutputProperty(
            defaultValue = "",
            description = "From Email Address",
            label = "From Email Address",
			possibleValues = {"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$" },
            required = "true",
            index = "4")
	public String getFromEmailAddress() {
		return _fromEmailAddress;
	}

	public void setFromEmailAddress(String fromEmailAddress) {
		_fromEmailAddress = fromEmailAddress;
	}

    @OutputProperty(
            defaultValue = "",
            description = "From Name",
            label = "From Name",
            required = "true",
            possibleValues = {"^[a-zA-Z\\'.\\s]{1,100}$"},
            index = "5")
    public String getFromName() {
        return _fromName;
    }

    public void setFromName(String fromName) {
        _fromName = fromName;
    }


    @OutputProperty(
            defaultValue = "text/html",
            description = "Email Mime Type: text, xml, html",
            label = "Mime Type",
			index="11")
	public String getMimeType() {
		//always return text_html
		//TODO:  update if other mime types are supported
		return OutputConstants.TEXT_HTML;
	}

	public void setMimeType(String mimeType) {
		_mimeType = mimeType;
	}

 	@OutputProperty(
            defaultValue = "",
            description = "Email Subject",
            label = "Email Subject",
            index = "6",
            contextMenu = { "Release Date|insertAtCursor('<<$PARENT_ID>>','<<RELEASE_DATE>>');",
            		"Request Date|insertAtCursor('<<$PARENT_ID>>','<<REQUEST_DATE>>');",
            		"Request Id|insertAtCursor('<<$PARENT_ID>>','<<REQUEST_ID>>');"})
            
	public String getSubject() {
		return _subject;
	}

	public void setSubject(String subject) {
		_subject = subject;
	}	
	
 	@OutputProperty(
            defaultValue = "",
            description = "Email Body",
            label = "Email Body",
            rowCount = "5",
            index = "7",
            contextMenu = { "Release Date|insertAtCursor('<<$PARENT_ID>>','<<RELEASE_DATE>>');",
            		"Request Date|insertAtCursor('<<$PARENT_ID>>','<<REQUEST_DATE>>');",
            		"Request Id|insertAtCursor('<<$PARENT_ID>>','<<REQUEST_ID>>');"})
	public String getBody() {
		return _body;
	}

	public void setBody(String body) {
		_body = body;
	}

    @OutputProperty(
            defaultValue = "No",
            description = "Allow user to override subject and body of email",
            label = "Override subject and body?",
            possibleValues = {"Yes", "No" },
            index = "8")
	public boolean getSubjectOverride() {
	return _filePasswordRequired;
	}

	public void setSubjectOverride(boolean subjectOverride) {
	_subjectBodyOverride = subjectOverride;
	}	
	
    /**
     * TODO
     * @return the _emailSizeMb
     */
    @OutputProperty(defaultValue = "25",
                    description = "Enter the maximum email attachment size limit",
                    possibleValues = { "\\d+" },
                    label = "Email Size Limit" ,
                    required = "true",
                    index = "3")
    public long getEmailSizeMb() {
        return _emailSizeMb;
    }

    /**
     * TODO
     * @param emailSizeMb the _emailSizeMb to set
     */
    public void setEmailSizeMb(long emailSizeMb) {
        _emailSizeMb = emailSizeMb;
    }

    @OutputProperty(
                    defaultValue = "Yes",
                    description = "Is a password required to open PDF file",
                    label = "Password Required for PDF Files",
                    possibleValues = {"Yes", "No" },
                    bindingProperty = "password",
                    index = "9")
    public boolean getPasswordRequired() {
        return _filePasswordRequired;
    }

    public void setPasswordRequired(boolean passwordRequired) {
        _filePasswordRequired = passwordRequired;
    }

    @OutputProperty(
                    defaultValue = "",
                    description = "Enter a PDF password to be used as a default whenever "
                                  +  "any user emails a PDF.",
                    label = "Default Password",
                    flags = PropertyFlag.JOB_DEFAULT,
                    index = "10",
                    maxLength = "50")
    public String getPassword() {
        return _filePassword;
    }

    public void setPassword(String password) {
        _filePassword = password;
    }
    
    public boolean isValidEmailAddress(String email) {
    	   boolean result = true;
    	   try {
    	      InternetAddress emailAddr = new InternetAddress(email);
    	      emailAddr.validate();
    	   } catch (AddressException ex) {
    		   LOG.info(email + " : " + ex.toString());
    		   throw new ApplicationException(ex);
    	   }
    	   return result;
    }
    
    public long getEmailSizeInByte() {
        return _emailSizeMb * FileConstants.MB_SIZE;
    }
    
    
}
