/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

 * Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
 * Use of this software and related documentation is governed by a license agreement.
 * This material contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States
 * and international copyright and other intellectual property laws.
 * Use, disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without the
 * prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
 */

package com.mckesson.eig.output.local.mediator.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.mckesson.eig.output.local.DestTypeHandler;
import com.mckesson.eig.output.local.Destination;
import com.mckesson.eig.output.local.email.EmailBean;
import com.mckesson.eig.output.local.email.EmailDestination;
import com.mckesson.eig.output.local.email.EmailDestinationHandler;
import com.mckesson.eig.output.local.transformers.Concatenate;
import com.mckesson.eig.output.model.OutputJob;
import com.mckesson.eig.output.util.OutputConstants;
import com.mckesson.eig.output.util.OutputConstants.RequestStatus;
import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;
import com.mckesson.eig.utility.util.CollectionUtilities;
import com.mckesson.eig.utility.util.StringUtilities;

public class MediatorEMailJob extends MediatorFileJob {

	private static final Log LOG = LogFactory.getLogger(MediatorEMailJob.class);

	public MediatorEMailJob(OutputJob job, Destination d,
			DestTypeHandler handler) {
		super(job, d, handler);
	}

	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void addFile(String fileName) throws IOException,
			InterruptedException {
		// TODO Auto-generated method stub

	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void initializeJob(Object listener) {
		// TODO Auto-generated method stub

	}

	public void doneWithJob() throws IOException, InterruptedException {
		EmailDestinationHandler handler = (EmailDestinationHandler) getHandler();
		EmailDestination destination = (EmailDestination) getDestination();
		OutputJob job = getJob();
		try {
			LOG.info("Started processing Email Job:\t");
			Concatenate pdfConcatenate = handler.getConcatenateStrategy();
			long size = destination.getEmailSizeInByte();
			generateBookmarks(job, handler.getBookmarkStrategy(), size);
			List<String> files = pdfConcatenate.concatenate(job, size);
			Properties p = handler.getCryptoProperties();
			// if encryption required encrypt files
			// ownerpassword is always the request password
			// password is the given at the time of release
			String ownerPassword = destination.getRequestPassword(job);
			String password = destination.getQueuePassword(job);

			if (destination.isPasswordEncrypted(job)) {
				ownerPassword = decryptPassword(ownerPassword);
				password = decryptPassword(password);
			}

			encryptFiles(files, password, ownerPassword, p);
			// add hash file for the output file

			email(job, files, destination, handler.isSendHash(), p);
			updateStatus(job.getJobSeq(), RequestStatus.COMPLETED,
					OutputConstants.MSG_EMAIL_COMPLETED);
			LOG.info("Finished processing Email Job: ");

		} catch (Exception ex) {
			LOG.error("Failed to process Email Job");
			throw new ApplicationException(ex);
		}

	}

	private void email(OutputJob job, List<String> fileList,
			EmailDestination destination, boolean sendHash, Properties p)
			throws Exception {

		Map<String, String> props = job.getProperties();

		EmailBean emailObj = new EmailBean();

		emailObj.setJobId(job.getJobSeq());
		emailObj.setJobName(job.getJobName());
		emailObj.setToEmail(props.get(OutputConstants.MESSAGE_TO));
		emailObj.setMessage(props.get(OutputConstants.MESSAGE_BODY));
		emailObj.setBcc(props.get(OutputConstants.MESSAGE_BCC));
		emailObj.setCc(props.get(OutputConstants.MESSAGE_CC));

		// Configuration taken either from request or from configuration
		emailObj.setSubject(StringUtilities.isEmpty(props
				.get(OutputConstants.MESSAGE_SUBJECT)) ? destination
				.getSubject() : props.get(OutputConstants.MESSAGE_SUBJECT));

		emailObj.setMimeType(StringUtilities.isEmpty(props
				.get(OutputConstants.MESSAGE_MIMETYPE)) ? destination
				.getMimeType() : props.get(OutputConstants.MESSAGE_MIMETYPE));

		// This is from Configuration
		emailObj.setFromEmail(destination.getFromEmailAddress());
		emailObj.setSmtpHost(destination.getSmtpHost());
		emailObj.setSmtpPort(destination.getSmtpPort());
		emailObj.setFromName(destination.getFromName());

		// LOG.debug(props.toString());

		try {
			int i = 0;
			if (fileList != null) {
				List<String> hashFiles = null;
				if (sendHash) {
					hashFiles = addHashFile(fileList, p);
				}
				for (String fileName : fileList) {
					List<String> attachmentList = new ArrayList<String>();
					attachmentList.add(fileName);
					if ((sendHash) && (!CollectionUtilities.isEmpty(hashFiles))) {
						String hashFile = hashFiles.get(i);
						i++;
						attachmentList.add(hashFile);
					}
					emailObj.setAttachments(attachmentList);
					sendEmail(emailObj);
				}
			}
		} catch (Exception e) {
			LOG.error("Exception in Email Processing", e);
			throw e;
		}
	}

	public void sendEmail(EmailBean emailInfo) throws Exception {
		if (emailInfo != null) {
			try {
				String smtpHost = emailInfo.getSmtpHost();
				String smtpPort = emailInfo.getSmtpPort();
				String from = emailInfo.getFromEmail();
				String to = emailInfo.getToEmail();
				String subject = emailInfo.getSubject();
				String msg = emailInfo.getMessage();
				String mimeType = emailInfo.getMimeType();
				// Added to display from name in the email
				String fromName = emailInfo.getFromName();

				// Get an initialized Email Session:
				Session session = getEmailSession(smtpHost, smtpPort);

				// Construct the message
				Message message = new MimeMessage(session);
				// Added to display from name in the email
				Address fromAddress = new InternetAddress(from, fromName);
				message.setFrom(fromAddress);
				message.setRecipient(Message.RecipientType.TO,
						new InternetAddress(to));

				if (StringUtilities.hasContent(emailInfo.getCc())) {
					message.setRecipient(Message.RecipientType.CC,
							new InternetAddress(emailInfo.getCc()));
				}

				if (StringUtilities.hasContent(emailInfo.getBcc())) {
					message.setRecipient(Message.RecipientType.BCC,
							new InternetAddress(emailInfo.getBcc()));
				}

				message.setSubject(subject);

				List<String> attachmentList = emailInfo.getAttachments();
				MimeBodyPart messageBodyPart = new MimeBodyPart();
				MimeMultipart mimemultipart = new MimeMultipart();
				messageBodyPart.setContent(msg, mimeType);
				mimemultipart.addBodyPart(messageBodyPart);
				for (Iterator<String> iter = attachmentList.iterator(); iter
						.hasNext();) {
					String file = iter.next();
					if (file != null) {
						MimeBodyPart attachmentBodyPart = new MimeBodyPart();
						DataSource source = new FileDataSource(file);
						attachmentBodyPart.setDataHandler(new DataHandler(
								source));
						String fileName = extractFileName(file);
						attachmentBodyPart.setFileName(fileName == null ? file
								: fileName);
						mimemultipart.addBodyPart(attachmentBodyPart);
					}
				}
				message.saveChanges();
				message.setContent(mimemultipart);
				Transport.send(message);

			} catch (AddressException ae) {
				LOG.error("Error Resolving Address", ae);
				throw ae;
			} catch (MessagingException me) {
				LOG.error("Error Handling Message", me);
				throw me;
			} catch (Exception e) {
				LOG.error(e);
				throw e;
			}
		}
	}

	private String extractFileName(String path) {
		StringTokenizer token = new StringTokenizer(path, ""
				+ File.separatorChar);
		String temp;
		while (token.hasMoreElements()) {
			temp = (String) token.nextElement();
			if (temp.indexOf(".") != -1) {
				return temp;
			}
		}
		return null;
	}

	private Session getEmailSession(String smtpHost, String smtpPort) {
		try {
			java.util.Properties props = new java.util.Properties();
			props.put("mail.smtp.host", smtpHost);
			props.put("mail.smtp.port", smtpPort);
			if (LOG.isDebugEnabled()) {
				props.put("mail.debug", "true");
			}
			Session session = Session.getInstance(props);
			return session;
		} catch (Exception ex) {
			LOG.error(ex.getMessage());
			return null;
		}
	}
}
