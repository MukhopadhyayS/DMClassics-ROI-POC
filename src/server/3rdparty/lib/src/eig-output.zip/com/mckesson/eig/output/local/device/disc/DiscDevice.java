/*
BEGIN-COPYRIGHT-COMMENT Do not remove or modify this line!

 * Copyright (c) 2013 McKesson Corporation and/or one of its subsidiaries. All Rights Reserved.
 * Use of this software and related documentation is governed by a license agreement.
 * This material contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States
 * and international copyright and other intellectual property laws.
 * Use, disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without the
 * prior express written permission of McKesson Information Solutions.

END-COPYRIGHT-COMMENT  Do not remove or modify this line!
 */

package com.mckesson.eig.output.local.device.disc;

import com.mckesson.eig.output.local.BaseComponent;
import com.mckesson.eig.output.local.OutputEndpoint;
import com.mckesson.eig.output.model.DeviceInfo;
import com.mckesson.eig.output.model.EndpointDef;
import com.mckesson.eig.output.model.StatusInfo;
import com.mckesson.eig.output.util.OutputProperty;

/**
 * @author Latonia Howard
 * @date Sept 4, 2013
 * @since Sept 4, 2013
 * 
 */
public class DiscDevice extends BaseComponent implements OutputEndpoint {

	private String _vendorName;
	private String _temporaryLocation;
	protected int _deviceId;

	public DiscDevice(EndpointDef endpointDef) {
		super();

		if (endpointDef == null) {
			throw new IllegalArgumentException("endpointDef argument is null");
		}

		super.getProperties().getProperties()
				.putAll(endpointDef.getProperties());
		
		this._deviceId = endpointDef.getId();
		this._vendorName = ((DeviceInfo) endpointDef).getVendor();
	}

	@OutputProperty(defaultValue = "", description = "Vendor of the External Disc Device", label = "Vendor Name", required = "true", index = "")
	public String getVendorName() {
		return _vendorName;
	}

	public void setVendorName(String vendorName) {
		_vendorName = vendorName;
	}

	@OutputProperty(defaultValue = "", description = "Temporary PDF Location", label = "Temporary PDF Location", possibleValues = { "(\\\\\\\\(\\d{1,3}\\.){3,3}(\\d{1,3})|"
			+ "(\\\\\\\\)[^\\/:*|<>?\"]+)(\\\\[^\\/:*|<>?\"])*" }, required = "true", index = "3")
	public String getTemporaryLocation() {
		return _temporaryLocation;
	}

	public void setTemporaryLocation(String temporaryLocation) {
		_temporaryLocation = temporaryLocation;
	}

	@Override
	public StatusInfo queryEndpointStatus() {
		return null;
	}
	
    /**
     * @see com.mckesson.eig.output.local.OutputEndpoint#queryEndpointStatus()
     */
    public StatusInfo queryEndpointStatus(boolean validEndPoint) {
		return queryEndpointStatus();
	}
	
	public int getDeviceId() {
		return _deviceId;
	}

	public void setDeviceId(int _deviceId) {
		this._deviceId = _deviceId;
	}
}
