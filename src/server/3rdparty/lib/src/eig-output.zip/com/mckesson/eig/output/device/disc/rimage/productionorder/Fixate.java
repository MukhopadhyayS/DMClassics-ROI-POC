/*
 * Copyright 2013 McKesson Corporation and/or one of its subsidiaries.
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */
/**
 * @author Iryna Politykina
 *
 */

package com.mckesson.eig.output.device.disc.rimage.productionorder;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAttribute;

import com.mckesson.eig.output.device.disc.rimage.RimageConstants;

@XmlRootElement(name = "Fixate")
public class Fixate {
    
    private String type;
    
    private Boolean _final;

    public Fixate() {
        super();
        this._final = Boolean.TRUE;
        this.type = RimageConstants.TYPE_SAO;
        
    }

    public String getType() {
        return type;
    }

    @XmlAttribute(name = "Type")
    public void setType(String type) {
        this.type = type;
    }

    public Boolean get_final() {
        return _final;
    }

    @XmlAttribute(name = "Final")
    public void set_final(Boolean _final) {
        this._final = _final;
    }
    

}
