/**
 * Copyright � 2010 McKesson Corporation and/or one of its subsidiaries.
 * All rights reserved.
 *
 * Use of this material is governed by a license agreement. This material
 * contains confidential, proprietary and trade secret information of
 * McKesson Information Solutions and is protected under United States and
 * international copyright and other intellectual property laws. Use,
 * disclosure, reproduction, modification, distribution, or storage
 * in a retrieval system in any form or by any means is prohibited without
 * the prior express written permission of McKesson Information Solutions.
 */

package com.mckesson.eig.output.local.source.hpf.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import com.mckesson.eig.utility.exception.ApplicationException;
import com.mckesson.eig.utility.log.Log;
import com.mckesson.eig.utility.log.LogFactory;

public abstract class WebServiceCaller {

	private static final Log LOG = LogFactory.getLogger(WebServiceCaller.class);
	private String _levelerURL = "";
	private Boolean _useLeveler;

	private static final int TOTAL_RETRIES = 4;

	public String getLevelerURL() {
		return _levelerURL;
	}

	public void setLevelerURL(String levelerURL) {
		_levelerURL = levelerURL;
	}

	public Boolean getUseLeveler() {
		return _useLeveler;
	}

	public void setUseLeveler(Boolean useLeveler) {
		_useLeveler = useLeveler;
	}

	protected WebServiceCaller(Boolean useLeveler, String levelerURL) {
		_levelerURL = levelerURL;
		_useLeveler = useLeveler;
	}

	protected String getWebURL(String url) {
		String webURL = url;
		if (_useLeveler != null && _useLeveler.booleanValue()) {
			String result = getRedirectURLFromLeveler();
			if (result.length() > 0) {
				String server = getValue(result, "<host>", "</host>", null);
				if (server == null) {
					throw new ApplicationException(
					"All Common Web Servers are down or inactive on the "
					+ "Load Leveler, please contact System Administrator.");
				}
				try {
					URL webserverURL = new URL(url);
					String file = webserverURL.getFile();
					String protocol = webserverURL.getProtocol();
					int port = webserverURL.getPort();
					int serverPort = Integer.parseInt(getValue(result,
							"<port>", "</port>", String.valueOf(port)));
					URL newURL = new URL(protocol, server, serverPort, file);
					webURL = newURL.toString();
				} catch (Exception e) {
					throw new ApplicationException(
					"Unable to parse the returned message from Load Leveler.",
					e);
				}
			}
		}
		return webURL;
	}

	private String getRedirectURLFromLeveler() {
		URLConnection connection = null;
		try {
			URL url = new URL(_levelerURL);
			connection = url.openConnection();
			connection.setDoInput(true);
			connection.setDoOutput(true);
			BufferedOutputStream os = new BufferedOutputStream(connection
					.getOutputStream());
			os.flush();
			BufferedInputStream is = new BufferedInputStream(connection
					.getInputStream());
			DataInputStream dis = new DataInputStream(is);
			int size = connection.getContentLength();
			if (size == 0) {
				throw new ApplicationException(
				"Failed to get the redirected url from Load Leveler, "
				+ "please contact System Administrator.");
			}
			byte[] data = new byte[size];
			dis.readFully(data);
			return new String(data);
		} catch (MalformedURLException mfue) {
			throw new ApplicationException("Load Leveler URL [" + _levelerURL
					+ "] is incorrect, please contact System Administrator.");
		} catch (IOException ioe) {
			throw new ApplicationException(getExceptionDetail(ioe, connection));
		}
	}

	private String getExceptionDetail(Exception e, URLConnection connection) {
		if (connection != null) {
			try {
				int responseCode = ((HttpURLConnection) connection)
						.getResponseCode();
				return getMessage(responseCode);
			} catch (IOException ioe) {
				LOG.error("Load Leveler is down or the URL " + _levelerURL
				+ " incorrect, please contact System Administrator. ");
			}
		}

		return "Load Leveler is down or the URL " + _levelerURL
				+ " incorrect, please contact System Administrator. "
				+ e.getMessage();
	}

	private String getMessage(int code) {
		StringBuilder detail = new StringBuilder();
		if (code == HttpURLConnection.HTTP_NOT_FOUND) {
			detail.append("Load Leveler is down or the URL ");
			detail.append(_levelerURL);
			detail.append(" incorrect, please contact System Administrator. ");
		} else if (code > HttpURLConnection.HTTP_BAD_REQUEST
				&& code < HttpURLConnection.HTTP_INTERNAL_ERROR) {
			detail.append("WebServiceCaller encountered error ");
			detail.append(code);
			detail.append(" while connecting to ");
			detail.append(_levelerURL);
			detail.append(" please contact System Administrator. ");
		} else if (code > HttpURLConnection.HTTP_INTERNAL_ERROR) {
			detail.append("Load Leveler encountered error ");
			detail.append(code);
			detail.append(" while processing ");
			detail.append(_levelerURL);
			detail.append(" please contact System Administrator. ");
		}

		return detail.toString();
	}

	private String getValue(String result, String start, String end,
			String defaultValue) {
		int hostStart = result.indexOf(start);
		int hostEnd = result.indexOf(end);
		return (hostStart > 0 && hostEnd > 0) ? result.substring(hostStart
				+ start.length(), hostEnd) : defaultValue;
	}

	public String createTime(String strUrl) {
		int retries = 0;
		while (retries < TOTAL_RETRIES) {
			retries++;
			try {
				URL url = new URL(strUrl);
				return SecureToken.createTime(url.getProtocol() + "://"
						+ url.getHost() + ":" + url.getPort());
			} catch (Exception e) {
				LOG.error(e);
			}
		}
		return null;
	}

	/**
	 * @return
	 * @throws SOAPException
	 */
	protected SOAPMessage createSOAPMessage() throws SOAPException
	{
		MessageFactory mf = MessageFactory.newInstance();
		SOAPMessage msg = mf.createMessage();
		return msg;
	}

	/**
	 * @return SOAPConnection
	 * @throws SOAPException
	 */
	protected SOAPConnection createSOAPConnection() throws SOAPException
	{
		SOAPConnectionFactory scf = SOAPConnectionFactory.newInstance();
		SOAPConnection conn = scf.createConnection();
		return conn;
	}
}
