package com.mckesson.eig.reports.utils;


import org.owasp.esapi.codecs.Codec;

public class MSSQLCodecAdvanced extends Codec {
    
    public String encodeCharacter(char[] immune, Character c) {
        
    	if (c.charValue() == '\'') {
            return "\'\'";
    	}
        return "" + c;
    }
}
