/**
 * Copyright 2007 McKesson Corporation and/or one of its subsidiaries. 
 * All Rights Reserved.
 *
 * Use of this material is governed by a license agreement. This material 
 * contains confidential, proprietary and trade secret information of 
 * McKesson Corporation and/or one of its subsidiaries and is protected 
 * under United States and international copyright and other intellectual
 * property laws. Use, disclosure, reproduction, modification, distribution,
 * or storage in a retrieval system in any form or by any means is prohibited
 * without the prior express written permission of McKesson Corporation.
 */

package com.mckesson.eig.utility.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class NormalBeanProperty implements BeanProperty {

    private static final Object[] EMPTY_ARRAY = new Object[0];

    private final Method _readMethod;

    public NormalBeanProperty(Method method) {
        _readMethod = method;
    }

    public Object read(Object bean) throws IllegalAccessException,
            InvocationTargetException, NoSuchMethodException {
        return _readMethod.invoke(bean, EMPTY_ARRAY);
    }
}
