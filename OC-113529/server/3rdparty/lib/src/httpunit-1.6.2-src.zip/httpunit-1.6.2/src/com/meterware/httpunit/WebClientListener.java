package com.meterware.httpunit;
/********************************************************************************************************************
 * $Id: WebClientListener.java,v 1.1 2002/02/28 14:30:33 russgold Exp $
 *
 * Copyright (c) 2002, Russell Gold
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 *******************************************************************************************************************/


/**
 * A listener for messages sent and received by a web client.
 *
 * @author <a href="mailto:Oliver.Imbusch.extern@HVBSystems.com">Oliver Imbusch</a>
 * @author <a href="mailto:russgold@acm.org">Russell Gold</a>
 **/
public interface WebClientListener {

    /**
     * Invoked when the web client sends a request.
     */
    public void requestSent( WebClient src, WebRequest req );


    /**
     * Invoked when the web client receives a response.
     */
    public void responseReceived( WebClient src, WebResponse resp );
}

